CREATE PROCEDURE [mea].[prc_MeasureType_get]    
(
 @OwnerID AS int
)
AS    
BEGIN    
 SELECT [MeasureTypeId]  
      ,[OwnerID]  
      ,[Name]  
      ,[AllowNestedMeasures]  
      ,[AllowCategories]  
      ,[AllowChecklist]  
      ,[AllowDueDate]  
      ,[DueDateMandatory]  
      ,[DueDateDefault]  
      ,[AllowRelated]  
      ,[AllowResources]  
  FROM [mea].[MeasureType]  
    
END    
