CREATE PROCEDURE [mea].[prc_LT_MeasureTemplate_get]  
(  
 @MeasureTemplateID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [LanguageID]  
      ,[MeasureTemplateID]  
      ,[Name]  
      ,[Description]  
      ,[Subject]  
 FROM [mea].[LT_MeasureTemplate]  
 WHERE  
 [MeasureTemplateID] = @MeasureTemplateID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
