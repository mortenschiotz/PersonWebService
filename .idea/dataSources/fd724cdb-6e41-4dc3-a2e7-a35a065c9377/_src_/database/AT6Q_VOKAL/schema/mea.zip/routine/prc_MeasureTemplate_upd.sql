CREATE PROCEDURE [mea].[prc_MeasureTemplate_upd]    
(
	@MeasureTemplateID int,
	@CustomerID int = null,
	@MeasureTypeID int,
	@ChangedBy int = null,
	@Active bit,
	@Deleted bit,
	@Editable bit,
	@Private bit,
	@cUserid int,  
	@Log smallint = 1
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

 UPDATE [mea].[MeasureTemplate]
 SET
	[CustomerID] = @CustomerID,
	[MeasureTypeID] = @MeasureTypeID,
	[ChangedBy] = @ChangedBy,
	[ChangedDate] = getdate(),
	[Active] = @Active,
	[Deleted ] = @Deleted, 
	[Editable] = @Editable,
	[Private] = @Private
 WHERE
	[MeasureTemplateId] = @MeasureTemplateID
 
 Set @Err = @@Error 
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'mea.MeasureTemplate',0,  
  ( SELECT * FROM [mea].[MeasureTemplate]   
   WHERE  
   [MeasureTemplateID] = @MeasureTemplateID    FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  

END
