CREATE PROCEDURE mea.prc_LT_Category_get  
 @CategoryId int    
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int        
SELECT [LanguageID]
      ,[CategoryId]
      ,[Name]
      ,[Description]
  FROM [mea].[LT_Category] 
 WHERE      
  [mea].[LT_Category].CategoryId = @CategoryId    
 Set @Err = @@Error    
    
 RETURN @Err    
END    

