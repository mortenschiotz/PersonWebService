CREATE PROCEDURE [mea].[prc_CheckListItemTemplate_get]   
(
	@MeasureTemplateID int
)
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int  
   
 SELECT [CheckListItemTemplateId]
       ,MeasureTemplateID
	   ,[No]
 FROM [mea].[CheckListItemTemplate]  
 WHERE MeasureTemplateID = @MeasureTemplateID
   
 Set @Err = @@Error  
  
 RETURN @Err  
    
END
