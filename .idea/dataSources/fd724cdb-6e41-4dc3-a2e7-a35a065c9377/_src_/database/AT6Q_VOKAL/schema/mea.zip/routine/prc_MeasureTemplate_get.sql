CREATE PROCEDURE [mea].[prc_MeasureTemplate_get]   
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int  
   
 SELECT [MeasureTemplateId]
       ,[CustomerID]
	   ,[MeasureTypeID]
	   ,[CreatedBy]
	   ,[CreatedDate]
	   ,[ChangedBy]
	   ,[ChangedDate]
	   ,[Active]
	   ,[Deleted ]
	   ,[Editable]
	   ,[Private]
 FROM [mea].[MeasureTemplate]  
   
 Set @Err = @@Error  
  
 RETURN @Err  
    
END
