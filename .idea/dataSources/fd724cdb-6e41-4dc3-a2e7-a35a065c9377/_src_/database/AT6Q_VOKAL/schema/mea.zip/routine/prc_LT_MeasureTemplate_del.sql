CREATE PROCEDURE [mea].[prc_LT_MeasureTemplate_del]
	@LanguageID int,
	@MeasureTemplateID int,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    DELETE [mea].[LT_MeasureTemplate]
    WHERE     [MeasureTemplateID] = @MeasureTemplateID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_MeasureTemplate',0,
		( SELECT * FROM [mea].[LT_MeasureTemplate]
			WHERE
			([MeasureTemplateID] = @MeasureTemplateID AND [LanguageID] = @LanguageID) 				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
