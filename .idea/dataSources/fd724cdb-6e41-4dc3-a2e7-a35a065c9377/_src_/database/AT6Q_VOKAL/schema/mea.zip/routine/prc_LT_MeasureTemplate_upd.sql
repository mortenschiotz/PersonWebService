CREATE PROCEDURE [mea].[prc_LT_MeasureTemplate_upd]
	@LanguageID int,
	@MeasureTemplateID int,
	@Name nvarchar(256) = NULL,
	@Description nvarchar(max) = NULL,
	@Subject nvarchar(256) = NULL,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    UPDATE [mea].[LT_MeasureTemplate]
    SET    
         [Name] = @Name,
		 [Description] = @Description,
		 [Subject] = @Subject
    WHERE
		[LanguageID] = @LanguageID AND
		[MeasureTemplateID] = @MeasureTemplateID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_MeasureTemplate',0,
		( SELECT * FROM [mea].[MeasureTemplate]
			WHERE
			[MeasureTemplateID] = @MeasureTemplateID				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
