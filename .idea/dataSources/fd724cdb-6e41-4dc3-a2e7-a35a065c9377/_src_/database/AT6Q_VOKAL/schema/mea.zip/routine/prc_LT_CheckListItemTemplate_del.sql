CREATE PROCEDURE [mea].[prc_LT_CheckListItemTemplate_del]
	@LanguageID int,
	@CheckListItemTemplateID int,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    DELETE [mea].[LT_CheckListItemTemplate]
    WHERE     [CheckListItemTemplateID] = @CheckListItemTemplateID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_CheckListItemTemplate',2,
		( SELECT * FROM [mea].[LT_CheckListItemTemplate]
			WHERE
			([CheckListItemTemplateID] = @CheckListItemTemplateID AND [LanguageID] = @LanguageID) 				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
