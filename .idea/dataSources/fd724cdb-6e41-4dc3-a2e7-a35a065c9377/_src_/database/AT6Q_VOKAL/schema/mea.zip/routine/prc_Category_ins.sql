CREATE PROCEDURE [mea].[prc_Category_ins]
 (		   
		   @CategoryId int = null output,  
		   @MeasureTypeId  int,
           @CustomerId  int = null,
           @CreatedBy int,
           @CreatedDate datetime,
           @ChangedBy int,
           @ChangedDate datetime,
           @cUserid int,  
		   @Log smallint = 1)
AS

BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [mea].[Category]
           ([MeasureTypeId]
           ,[CustomerId]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[ChangedBy]
           ,[ChangedDate])
     VALUES
           (
           @MeasureTypeId,
           @CustomerId,
           @CreatedBy,
           @CreatedDate,
           @ChangedBy,
           @ChangedDate
           )
  
 Set @Err = @@Error  
 Set @CategoryId = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Category',0,  
  ( SELECT * FROM  [mea].[Category] 
   WHERE  
   [CategoryId] = @CategoryId     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END

