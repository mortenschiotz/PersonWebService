CREATE PROCEDURE [mea].[prc_CheckListItemTemplate_ins]    
(
	@CheckListItemTemplateID int = null output,
	@MeasureTemplateID int,
	@No smallint,
	@cUserid int,  
	@Log smallint = 1
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

 INSERT INTO [mea].[CheckListItemTemplate]
 (
	[MeasureTemplateID],
	[No]
 )
 VALUES
 (
	@MeasureTemplateID,
	@No
 )
 
 Set @Err = @@Error 
 Set @CheckListItemTemplateID = scope_identity()
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'mea.CheckListItemTemplate',0,  
  ( SELECT * FROM [mea].[CheckListItemTemplate]   
   WHERE  
   [CheckListItemTemplateID] = @CheckListItemTemplateID    FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  

END
