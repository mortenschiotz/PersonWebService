CREATE PROCEDURE [mea].[prc_Category_Get]

AS
BEGIN
	SELECT [CategoryId]
      ,[MeasureTypeId]
      ,[CustomerId]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[ChangedBy]
      ,[ChangedDate]
  FROM [mea].[Category]

END

