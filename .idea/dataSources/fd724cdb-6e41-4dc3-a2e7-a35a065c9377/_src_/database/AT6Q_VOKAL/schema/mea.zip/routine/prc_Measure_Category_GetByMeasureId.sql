CREATE PROCEDURE [mea].[prc_Measure_Category_GetByMeasureId]
(
	@MeasureId int
)
AS
BEGIN
	SELECT CategoryId from mea.Measure_Category where MeasureId = @MeasureId
END
