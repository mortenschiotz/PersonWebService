CREATE PROCEDURE [mea].[prc_MeasureTemplate_del]
(
	@MeasureTemplateID int,
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'mea.MeasureTemplate',0,
		( SELECT * FROM [mea].[MeasureTemplate] 
			WHERE
			[MeasureTemplateID] = @MeasureTemplateID FOR XML AUTO) as data,
				getdate() 
	END

	DELETE FROM mea.MeasureTemplate
	WHERE
		[MeasureTemplateID] = @MeasureTemplateID
	
	Set @Err = @@Error  
	
	RETURN @Err
END
