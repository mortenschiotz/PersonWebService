CREATE PROCEDURE [mea].[prc_CheckListItemTemplate_del]
(
	@CheckListItemTemplateID int,
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'mea.CheckListItemTemplate',2,
		( SELECT * FROM [mea].[CheckListItemTemplate] 
			WHERE
			[CheckListItemTemplateID] = @CheckListItemTemplateID FOR XML AUTO) as data,
				getdate() 
	END

	DELETE FROM mea.CheckListItemTemplate
	WHERE
		[CheckListItemTemplateID] = @CheckListItemTemplateID
	
	Set @Err = @@Error  
	
	RETURN @Err
END
