CREATE PROCEDURE [mea].[prc_Category_del]    
(    
 @CategoryId int,    
 @cUserid int,    
 @Log smallint = 1    
)    
AS    
BEGIN    
 SET NOCOUNT ON    
 DECLARE @Err Int    
    
 IF @Log = 1     
 BEGIN     
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)     
  SELECT @cUserid,'mea.Category',2,    
  ( SELECT * FROM [mea].[Category]     
   WHERE    
   [CategoryId] = @CategoryId    
    FOR XML AUTO) as data,    
   getdate()     
 END     
    
    
 DELETE FROM [mea].[Category]    
 WHERE    
  [CategoryId] = @CategoryId    
    
 Set @Err = @@Error    
    
 RETURN @Err    
END    
    
