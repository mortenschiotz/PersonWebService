

CREATE PROCEDURE [mea].[prc_MeasureType_ins]
 (		   
		   @MeasureTypeId int = null output,  
		   @OwnerID  int,
           @Name nvarchar(256),
           @AllowNestedMeasures  bit,
           @AllowCategories bit,
           @AllowChecklist bit,
           @AllowDueDate bit,
           @DueDateMandatory bit,
           @DueDateDefault smallint,
           @AllowRelated bit,
           @AllowResources bit,
           @cUserid int,  
		   @Log smallint = 1)
AS

BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [mea].[MeasureType]
           ([OwnerID]
           ,[Name]
           ,[AllowNestedMeasures]
           ,[AllowCategories]
           ,[AllowChecklist]
           ,[AllowDueDate]
           ,[DueDateMandatory]
           ,[DueDateDefault]
           ,[AllowRelated]
           ,[AllowResources])
     VALUES
           (
           @OwnerID,
           @Name,
           @AllowNestedMeasures,
           @AllowCategories,
           @AllowChecklist,
           @AllowDueDate,
           @DueDateMandatory,
           @DueDateDefault,
           @AllowRelated,
           @AllowResources
           )
  
 Set @Err = @@Error  
 Set @MeasureTypeId = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'MeasureType',0,  
  ( SELECT * FROM  [mea].[MeasureType] 
   WHERE  
   [MeasureTypeId] = @MeasureTypeId     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END  



