CREATE PROCEDURE [mea].[prc_LT_MeasureTemplate_ins]
	@LanguageID int,
	@MeasureTemplateID int,
	@Name nvarchar(256) = NULL,
	@Description nvarchar(max) = NULL,
	@Subject nvarchar(256) = NULL,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [mea].[LT_MeasureTemplate]
           ([LanguageID]
           ,[MeasureTemplateID]
           ,[Name]
           ,[Description]
           ,[Subject])
    VALUES
           (@LanguageID
           ,@MeasureTemplateID
           ,@Name
           ,@Description
           ,@Subject)
           
    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_MeasureTemplate',0,
		( SELECT * FROM [mea].[LT_MeasureTemplate]
			WHERE
			[LanguageID] = @LanguageID AND
			[MeasureTemplateID] = @MeasureTemplateID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
