CREATE PROCEDURE [mea].[prc_SearchMeasureByCreatedOrResponsible]
(
    @UserID			INT,
    @SearchString	nvarchar(max),
    @RowCount		int output,
    @IsSubject		BIT =0,
    @IsResponsible	BIT=0,
    @PageIndex		INT=1,
    @PageSize		INT =10
)
AS
BEGIN
DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#SearchResult')) DROP TABLE #SearchResult;

	WITH RecQry AS
				(
					SELECT m.MeasureId 
					  FROM mea.Measure m
					 WHERE( m.CreatedBy =@UserID OR m.Responsible = @UserID)  AND Active =1 --AND Deleted =0
					UNION ALL
					SELECT a.MeasureId
					  FROM mea.Measure a INNER JOIN RecQry b
						ON a.ParentID = b.MeasureId
				)
Select ms.MeasureId,ms.MeasureTypeId, ms.ParentId,ms.CreatedBy,ms.CreatedDate,ms.ChangedBy, ms.ChangedDate, ms.Responsible, ms.StatusId, ms.[Private], ms.[Subject], ms.[Description],ms.[Started], ms.[DueDate], ms.[Completed], ms.CopyFrom, ms.Active, ms.Deleted, us.FirstName,us.LastName,ROW_NUMBER() OVER (ORDER BY ms.MeasureId DESC) AS Row
INTO #SearchResult
FROM mea.Measure ms
	INNER JOIN org.[User] us ON us.UserID = ms.Responsible OR us.UserID = ms.CreatedBy
WHERE  EXISTS (SELECT 1 FROM RecQry WHERE MeasureId= ms.MeasureId) AND ms.Deleted =0
AND 
(
((@IsSubject=1 AND @IsResponsible=0) AND ms.[Subject] LIKE '%'+@SearchString+'%')
	OR
((@IsSubject=0 AND @IsResponsible=1) AND (us.LastName LIKE '%'+@SearchString+'%' OR us.FirstName LIKE '%'+@SearchString+'%' AND us.EntityStatusID = @ActiveEntityStatusID))
	OR
((@IsSubject=0 AND @IsResponsible=0) AND (us.LastName LIKE '%'+@SearchString+'%' OR us.FirstName LIKE '%'+@SearchString+'%' OR ms.[Subject] LIKE '%'+@SearchString+'%' AND us.EntityStatusID = @ActiveEntityStatusID))
)

SELECT @RowCount=Count(MeasureId) FROM #SearchResult
SELECT MeasureId,MeasureTypeId, ParentId,CreatedBy,CreatedDate,ChangedBy, ChangedDate, Responsible, StatusId, [Private], [Subject], [Description],[Started], [DueDate], [Completed], CopyFrom, Active, Deleted,FirstName,LastName FROM #SearchResult
WHERE Row between
(@PageIndex - 1) * @PageSize + 1 and @PageIndex*@PageSize

DROP TABLE #SearchResult
END

