CREATE PROCEDURE [mea].[prc_LT_CheckListItemTemplate_ins]
	@LanguageID int,
	@CheckListItemTemplateID int,
	@Text nvarchar(max) = '',
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [mea].[LT_CheckListItemTemplate]
           ([LanguageID]
           ,[CheckListItemTemplateID]
           ,[Text])
    VALUES
           (@LanguageID
           ,@CheckListItemTemplateID
           ,@Text)
           
    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_CheckListItemTemplate',0,
		( SELECT * FROM [mea].[LT_CheckListItemTemplate]
			WHERE
			[LanguageID] = @LanguageID AND
			[CheckListItemTemplateID] = @CheckListItemTemplateID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
