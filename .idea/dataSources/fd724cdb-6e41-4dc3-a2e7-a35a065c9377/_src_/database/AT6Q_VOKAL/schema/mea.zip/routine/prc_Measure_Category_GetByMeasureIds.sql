 CREATE PROCEDURE [mea].[prc_Measure_Category_GetByMeasureIds]
(
 @MeasureIds nvarchar(max)
)
AS
BEGIN
 SELECT mc.CategoryId,lc.LanguageID, mc.MeasureId , lc.Name, lc.Description
 FROM mea.Measure_Category mc INNER JOIN mea.LT_Category lc ON lc.CategoryId = mc.CategoryId
 WHERE mc.MeasureId IN (SELECT value FROM dbo.funcListToTableInt(@MeasureIds,',')) 
END
