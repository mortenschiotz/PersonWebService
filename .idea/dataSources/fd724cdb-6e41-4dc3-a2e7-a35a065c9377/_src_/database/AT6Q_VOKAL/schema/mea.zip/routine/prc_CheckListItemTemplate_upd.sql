CREATE PROCEDURE [mea].[prc_CheckListItemTemplate_upd]    
(
	@CheckListItemTemplateID int,
	@MeasureTemplateID int,
	@No smallint,
	@cUserid int,  
	@Log smallint = 1
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

 UPDATE [mea].[CheckListItemTemplate]
 SET
	[MeasureTemplateID] = @MeasureTemplateID,
	[No] = @No
 WHERE
	[CheckListItemTemplateId] = @CheckListItemTemplateID
 
 Set @Err = @@Error 
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'mea.CheckListItemTemplate',1,  
  ( SELECT * FROM [mea].[CheckListItemTemplate]   
   WHERE  
   [CheckListItemTemplateID] = @CheckListItemTemplateID    FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  

END
