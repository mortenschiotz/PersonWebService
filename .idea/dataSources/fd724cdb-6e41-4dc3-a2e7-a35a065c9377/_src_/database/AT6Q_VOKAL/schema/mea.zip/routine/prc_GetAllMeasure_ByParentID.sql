CREATE PROCEDURE [mea].[prc_GetAllMeasure_ByParentID]
    (
      @ParentId INT ,
      @IsMaster BIT = 0
    )
AS 
BEGIN
	
                WITH    N ( MeasureId, ParentId, [StatusID], Deleted, ACTIVE, CopyFrom )
                          AS ( SELECT   MeasureId ,
                                        ParentId ,
                                        StatusID ,
                                        Deleted ,
                                        Active ,
                                        CopyFrom
                               FROM     mea.Measure
                               WHERE    (MeasureId IN (	SELECT  MeasureId FROM mea.Measure WHERE  (@IsMaster = 1 AND (CopyFrom = @ParentId OR ParentId = @ParentId)) OR (@IsMaster =0 AND ParentId=@ParentId)))
							   UNION ALL
                               SELECT   np.MeasureId ,
                                        np.ParentId ,
                                        np.[StatusID] ,
                                        np.Deleted ,
                                        np.Active ,
                                        np.CopyFrom
                               FROM     mea.Measure AS np
                                        JOIN N ON N.MeasureId = np.ParentID
                             )
                    SELECT DISTINCT MeasureId ,
                            ParentId ,
                            StatusId
                    FROM    N
                    WHERE   N.Deleted = 0
                            AND N.Active = 1
                
END
