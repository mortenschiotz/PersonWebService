CREATE PROCEDURE [mea].[prc_LT_CheckListItemTemplate_get]  
(  
 @CheckListItemTemplateID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	   [LanguageID]  
      ,[CheckListItemTemplateID]  
      ,[Text] 
 FROM [mea].[LT_CheckListItemTemplate]  
 WHERE  
 [CheckListItemTemplateID] = @CheckListItemTemplateID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
