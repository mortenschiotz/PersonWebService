CREATE PROCEDURE [imp].[prc_ImportFile_Dataget]
(
	@ImportFileID	int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT Data
	FROM [imp].Importfiles
	WHERE [ImportFileID] = @ImportFileID

	Set @Err = @@Error

	RETURN @Err
End
