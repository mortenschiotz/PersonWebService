CREATE PROCEDURE [imp].[prc_ImportFiles_get]
(
  @Userid INT
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ImportFileID],
	[UserID],
	[MIMEType],
	[Data],
	[DataError],
	[Created],
	[EmailSendtTo],
	[Description],
	[Size],
	[SizeError],
	[Filename],
	[FilenameError],
	ISNULL([SurveyID], 0) AS 'SurveyID'
	FROM [imp].[ImportFiles]
	WHERE UserId = @Userid

	Set @Err = @@Error

	RETURN @Err
END