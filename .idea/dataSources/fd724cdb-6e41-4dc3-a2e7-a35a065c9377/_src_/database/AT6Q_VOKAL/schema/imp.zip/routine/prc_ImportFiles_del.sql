

CREATE PROCEDURE [imp].[prc_ImportFiles_del]
(
	@ImportFileID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ImportFiles',2,
		( SELECT * FROM [imp].[ImportFiles] 
			WHERE
			[ImportFileID] = @ImportFileID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [imp].[ImportFiles]
	WHERE
		[ImportFileID] = @ImportFileID

	Set @Err = @@Error

	RETURN @Err
END

