CREATE PROCEDURE [imp].[prc_ImportFile_DataErrorget]
(
	@ImportFileID	int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT DataError
	FROM [imp].Importfiles
	WHERE [ImportFileID] = @ImportFileID

	Set @Err = @@Error

	RETURN @Err
End
