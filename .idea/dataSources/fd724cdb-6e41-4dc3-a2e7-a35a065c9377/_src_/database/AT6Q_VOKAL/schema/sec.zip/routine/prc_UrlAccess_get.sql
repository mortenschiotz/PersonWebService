CREATE PROCEDURE [sec].[prc_UrlAccess_get]  
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int  
  
 SELECT   
	  [UrlAccessId]
      ,[SiteId]
      ,[Controller]
      ,[Action]
      ,[MenuItemId]
 FROM [sec].[UrlAccess]
  
 Set @Err = @@Error  
  
 RETURN @Err  
  
END
