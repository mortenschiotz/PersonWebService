CREATE PROCEDURE [sec].[prc_UrlAccess_ins]    
   (
   @UrlAccessID int = null output,  
   @SiteId  Integer,
   @Controller  nvarchar(128),
   @Action  nvarchar(128),
   @MenuItemId AS INTEGER,
   @cUserid int,  
   @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [sec].[UrlAccess]
           ([SiteId]
           ,[Controller]
           ,[Action]
           ,[MenuItemId])
     VALUES
     (@SiteId,
     @Controller,
     @Action,
     @MenuItemId)
  
 Set @Err = @@Error  
 Set @UrlAccessID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'UrlAccess',0,  
  ( SELECT * FROM [sec].[UrlAccess]   
   WHERE  
   [UrlAccessID] = @UrlAccessID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END
