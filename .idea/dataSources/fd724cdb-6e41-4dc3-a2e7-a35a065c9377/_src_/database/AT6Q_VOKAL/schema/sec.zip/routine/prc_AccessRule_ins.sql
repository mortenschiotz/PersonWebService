CREATE PROCEDURE [sec].[prc_AccessRule_ins]
(
	@AccessRuleID int = NULL output,
	@No int,
    @Inheritance int,
    @ItemID int,
    @TableTypeID smallint, 
    @TableTypeParameters  nvarchar(512),
    @Access int,
    @Type  int,
    @AccessRuleName NVARCHAR(512)='',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN

	SET NOCOUNT ON
	DECLARE @Err Int
	INSERT INTO [sec].[AccessRule]
           ([No]
           ,[Inheritance]
           ,[ItemID]
           ,[TableTypeID]
           ,[TableTypeParameters]
           ,[Access]
           ,[Type]
           ,[AccessRuleName])
     VALUES
           (@No,
			@Inheritance,
			@ItemID,
			@TableTypeID, 
			@TableTypeParameters,
			@Access,
			@Type,
			@AccessRuleName
			)
	Set @Err = @@Error
	Set @AccessRuleID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessRule',0,
		( SELECT * FROM [sec].[AccessRule] 
			WHERE [AccessRuleID] = @AccessRuleID				 FOR XML AUTO) as data,	getdate() 
	 END
	RETURN @Err
END
