CREATE PROCEDURE [sec].[prc_AccessControlList_get]
AS
BEGIN
SET NOCOUNT ON
DECLARE @Err int
SELECT
    [AccessControlListID],
    [GroupAccessRuleID],
    [AccessGroupID],
    [No],
    [RuleType]
FROM [sec].[AccessControlList]
SET @Err = @@Error
RETURN @Err
END
