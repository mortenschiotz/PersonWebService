CREATE PROCEDURE [sec].[prc_RuleGroup_del]
(  
 @RuleGroupID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN
SET NOCOUNT ON
DECLARE @Err int
IF @Log = 1 BEGIN
INSERT INTO [Log].[AuditLog] (UserId, TableName, Type, Data, Created)
    SELECT
        @cUserid,
        'RuleGroup',
        2,
        (SELECT
            *
        FROM [sec].[RuleGroup]
        WHERE [RuleGroupID] = @RuleGroupID
        FOR xml AUTO)
        AS data,
        GETDATE()
END
DELETE FROM [sec].[RuleGroup]
WHERE [RuleGroupID] = @RuleGroupID
SET @Err = @@Error
RETURN @Err
END

