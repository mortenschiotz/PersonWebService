CREATE PROCEDURE [sec].[prc_RuleGroup_get]
AS
BEGIN
SET NOCOUNT ON
DECLARE @Err int
SELECT
    [RuleGroupID],
    [GroupAccessRuleID],
    [AccessRuleID]
FROM [sec].[RuleGroup]
SET @Err = @@Error
RETURN @Err
END

