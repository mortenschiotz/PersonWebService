CREATE PROCEDURE [sec].[prc_GroupAccessRule_del]
(  
 @GroupAccessRuleID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN
SET NOCOUNT ON
DECLARE @Err int
IF @Log = 1 BEGIN
INSERT INTO [Log].[AuditLog] (UserId, TableName, Type, Data, Created)
    SELECT
        @cUserid,
        'GroupAccessRule',
        2,
        (SELECT
            *
        FROM [sec].[GroupAccessRule]
        WHERE [GroupAccessRuleID] = @GroupAccessRuleID
        FOR xml AUTO)
        AS data,
        GETDATE()

END
DELETE FROM [sec].[GroupAccessRule]
WHERE [GroupAccessRuleID] = @GroupAccessRuleID
SET @Err = @@Error
RETURN @Err
END
