CREATE PROCEDURE [sec].[prc_AccessControlList_del]
(  
 @AccessControlListID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN
SET NOCOUNT ON
DECLARE @Err int
IF @Log = 1 BEGIN
INSERT INTO [Log].[AuditLog] (UserId, TableName, Type, Data, Created)
    SELECT
        @cUserid,
        'AccessControlList',
        2,
        (SELECT
            *
        FROM [sec].[AccessControlList]
        WHERE [AccessControlListID] = @AccessControlListID
        FOR xml AUTO)
        AS data,
        GETDATE()
END
DELETE FROM [sec].[AccessControlList]
WHERE [AccessControlListID] = @AccessControlListID
SET @Err = @@Error
RETURN @Err
END
