CREATE PROCEDURE [sec].[prc_AccessRule_upd]
(
	@AccessRuleID int,
	@No int,
    @Inheritance int,
    @ItemID int,
    @TableTypeID smallint, 
    @TableTypeParameters  nvarchar(512),
    @Access int,
    @Type  int,
    @AccessRuleName NVARCHAR(512) ='',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	UPDATE  [sec].[AccessRule]
	SET     [No] = @No
           ,[Inheritance] =@Inheritance
           ,[ItemID] = @ItemID
           ,[TableTypeID] = @TableTypeID
           ,[TableTypeParameters] = @TableTypeParameters
           ,[Access] = @Access
           ,[Type] =  @Type
           ,[AccessRuleName]=@AccessRuleName
     WHERE 
	 [AccessRuleID] = @AccessRuleID 
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessRule',1,
		( SELECT * FROM [sec].[AccessRule] 
			WHERE
        	[AccessRuleID] = @AccessRuleID				 FOR XML AUTO) as data,
				getdate() 
	 END
	RETURN @Err
END
