CREATE PROCEDURE [sec].[prc_AccessRule_del]
(  
 @AccessRuleID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN
SET NOCOUNT ON
DECLARE @Err int
IF @Log = 1 BEGIN

INSERT INTO [Log].[AuditLog] (UserId, TableName, Type, Data, Created)

    SELECT        @cUserid,        'AccessRule',        2,        (SELECT            *
        FROM [sec].[AccessRule]
        WHERE [AccessRuleID] = @AccessRuleID
        FOR xml AUTO)
        AS data,
        GETDATE()

END
DELETE FROM [sec].[AccessRule]
WHERE [AccessRuleID] = @AccessRuleID
SET @Err = @@Error
RETURN @Err
END
