CREATE PROCEDURE [sec].[prc_GroupAccessRule_upd]
(
	@GroupAccessRuleID int,
	@GroupName nvarchar(512),
    @Description  nvarchar(512),
	@cUserid int,
	@Log smallint = 1
)

AS
BEGIN
SET NOCOUNT ON
DECLARE @Err int
UPDATE [sec].[GroupAccessRule]
SET [GroupName] = @GroupName,
    [Description] = @Description
WHERE [GroupAccessRuleID] = @GroupAccessRuleID
IF @Log = 1 BEGIN
INSERT INTO [Log].[AuditLog] (UserId, TableName, Type, Data, Created)
    SELECT
        @cUserid,
        'GroupAccessRule',
        1,
        (SELECT
            *
        FROM [sec].[GroupAccessRule]
        WHERE [GroupAccessRuleID] = @GroupAccessRuleID
        FOR xml AUTO)
        AS data,
        GETDATE()
END
RETURN @Err
END
