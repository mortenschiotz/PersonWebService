CREATE PROCEDURE [sec].[prc_AccessRule_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	SELECT [AccessRuleID]
      ,[No]
      ,[Inheritance]
      ,[ItemID]
      ,[TableTypeID]
      ,[TableTypeParameters]
      ,[Access]
      ,[Type]
      ,[AccessRuleName]
    FROM [sec].[AccessRule]
	ORDER BY [No]
	Set @Err = @@Error
	RETURN @Err
END
