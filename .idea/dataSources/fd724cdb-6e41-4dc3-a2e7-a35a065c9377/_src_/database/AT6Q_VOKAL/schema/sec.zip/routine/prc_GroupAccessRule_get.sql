CREATE PROCEDURE [sec].[prc_GroupAccessRule_get]
AS
BEGIN
SET NOCOUNT ON
DECLARE @Err int
SELECT
    [GroupAccessRuleID],
    [GroupName],
    [Description]

FROM [sec].[GroupAccessRule]
SET @Err = @@Error
RETURN @Err
END
