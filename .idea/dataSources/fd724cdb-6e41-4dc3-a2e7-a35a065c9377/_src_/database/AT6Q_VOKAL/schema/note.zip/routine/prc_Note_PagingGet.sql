CREATE PROCEDURE [note].[prc_Note_PagingGet]
(
	@UserID                     int,
	@ListNoteTypeID             nvarchar(max)='',
	@LanguageID                 int,
	@FallbackLanguageID         int,
	@RowCount                   int output,
	@RowIndex                   int = 0,
	@PageSize                   int = 0,
	@HDID                       int = 0,
	@NotifyAtNextLogin          bit = 0,
    @NoteIDList                 varchar(max) = '',
    @FilterSourceTableTypeID    int = 0,
    @FilterSourceItemID         int = 0
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @Err Int, @ToRow int
    DECLARE @NoteTypeID int, @CheckValidInDateRange bit = 1
    CREATE TABLE #Note (NoteID int, CreatedBy int, Created datetime, AccessType int, NotifyAtNextLogin bit, Active bit) 
    DECLARE cur CURSOR READ_ONLY FOR
    SELECT * FROM dbo.funcListToTableInt(@ListNoteTypeID,',')
    OPEN cur
    FETCH NEXT FROM cur INTO  @NoteTypeID
        WHILE @@FETCH_STATUS =0
        BEGIN
            INSERT INTO #Note EXEC [note].[prc_Note_getByAccess] @UserID, @NoteTypeID, @HDID, @NotifyAtNextLogin, @NoteIDList, @CheckValidInDateRange, @FilterSourceTableTypeID, @FilterSourceItemID
            FETCH NEXT FROM cur INTO  @NoteTypeID
        END
    CLOSE cur
    DEALLOCATE cur
    SELECT @RowCount = COUNT(NoteID) FROM #Note WHERE Active = 1
    
    IF @RowIndex > @RowCount
    BEGIN
	   RETURN
    END

    SET @ToRow = @RowIndex + @PageSize - 1
    IF @ToRow > @RowCount OR (@RowIndex = 0 AND @PageSize = 0)  -- Exceed total number of rows or get all notes
    BEGIN
	   SET @ToRow = @RowCount
    END
    
    SELECT v.NoteID, v.[Subject], v.Note, v.CreatedBy, v.Created, v.AccessType, v.Changed,
           (SELECT TOP 1 rl.DateRead FROM note.NoteReadLog rl WHERE rl.NoteID = v.NoteID AND rl.UserID = @UserID) DateRead
    FROM (
	   SELECT row_number() OVER (ORDER BY n.Created DESC) AS RowNum, n.NoteID, n.AccessType,
              ISNULL(ltn.[Subject],fblt.[Subject]) [Subject], ISNULL(ltn.Note,fblt.Note) Note, n.CreatedBy, n.Created, n2.Changed
	   FROM #Note n
	   LEFT JOIN note.LT_Note ltn ON n.NoteID = ltn.NoteID AND ltn.LanguageID = @LanguageID  
	   LEFT JOIN note.LT_Note fblt ON n.NoteID = fblt.NoteID AND fblt.LanguageID = @FallbackLanguageID
	   LEFT JOIN note.Note n2 ON n.NoteID = n2.NoteID
	   WHERE (n.NotifyAtNextLogin = 1 OR @NotifyAtNextLogin = 0) AND n.Active = 1
    ) v WHERE v.RowNum BETWEEN @RowIndex AND @ToRow
	ORDER BY  v.Created DESC
	
    Set @Err = @@Error
    DROP TABLE #Note

    RETURN @Err
END
