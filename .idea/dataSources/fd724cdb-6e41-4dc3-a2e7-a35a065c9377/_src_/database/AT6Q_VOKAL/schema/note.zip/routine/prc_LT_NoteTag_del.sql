CREATE PROCEDURE [note].[prc_LT_NoteTag_del]
(
	@LanguageID int,
	@NoteTagID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_NoteTag',2,
		( SELECT * FROM [note].[LT_NoteTag] 
			WHERE
			[NoteTagID] = @NoteTagID
			AND [LanguageID] = @LanguageID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [note].[LT_NoteTag]
	WHERE
		[NoteTagID] = @NoteTagID
		AND [LanguageID] = @LanguageID

	Set @Err = @@Error
	
	RETURN @Err
END
