CREATE PROCEDURE [note].[prc_NoteAccess_del]
(
	@NoteAccessID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteAccess',2,
		( SELECT * FROM [note].[NoteAccess] 
			WHERE
			[NoteAccessID] = @NoteAccessID FOR XML AUTO) as data,
				getdate() 
	 END

	DELETE FROM [note].[NoteAccess]
	WHERE
		[NoteAccessID] = @NoteAccessID
		
	Set @Err = @@Error
	
	
	RETURN @Err
END
