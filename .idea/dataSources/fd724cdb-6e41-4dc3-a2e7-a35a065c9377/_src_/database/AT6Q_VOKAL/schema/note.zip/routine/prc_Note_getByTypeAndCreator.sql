CREATE PROCEDURE [note].[prc_Note_getByTypeAndCreator]
(
    @NoteTypeID	        int,
    @LanguageID         int,
    @FallbackLanguageID int,
    @UserIDList         varchar(max) = '',
    @GetDeniedNote      bit = 0
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @DenyPermission int = 2, @HD_TT int, @UserType_TT int, @DepartmentType_TT int
    DECLARE @NoteAccess AS TABLE (NoteID int, NoteAccessID int, TableTypeID int, ItemID nvarchar(max), AccessRight int, Name nvarchar(max))
    DECLARE @UserIDTable AS TABLE (UserID int)

    SELECT @HD_TT       = TableTypeID FROM TableType WHERE Name='H_D'
    SELECT @UserType_TT = TableTypeID FROM TableType WHERE Name='UserType'
    SELECT @DepartmentType_TT = TableTypeID FROM TableType WHERE Name='DepartmentType'

    INSERT INTO @UserIDTable (UserID) SELECT Value FROM dbo.funcListToTableInt(@UserIDList, ',')
   
    DECLARE c_Access CURSOR LOCAL FAST_FORWARD READ_ONLY FOR
    SELECT n.NoteID, na.NoteAccessID, na.TableTypeID, na.ItemID, na.[Type] AccessRight
    FROM   note.NoteAccess na
    JOIN   note.Note n ON n.NoteID = na.NoteID AND na.[Type] != @DenyPermission AND n.NoteTypeID = @NoteTypeID AND n.Deleted = 0
     AND   (n.CreatedBy IN (SELECT UserID FROM @UserIDTable) OR ISNULL(@UserIDList,'') = '')
    UNION
    SELECT n.NoteID, na.NoteAccessID, cna.TableTypeID, cna.ItemID, na.[Type] AccessRight
    FROM   note.NoteAccess na JOIN note.Combine_NoteAccess cna ON na.NoteAccessID = cna.NoteAccessID
    JOIN   note.Note n ON n.NoteID = na.NoteID AND na.[Type] != @DenyPermission AND n.NoteTypeID = @NoteTypeID AND n.Deleted = 0
     AND   (n.CreatedBy IN (SELECT UserID FROM @UserIDTable) OR ISNULL(@UserIDList,'') = '')

    DECLARE @NoteID int = 0, @NoteAccessID int = 0, @TableTypeID int, @ItemID nvarchar(max), @Type int, @Name nvarchar(max),
            @prev_NoteID int = 0, @prev_NoteAccessID int = 0, @prev_TableTypeID int, @prev_ItemID nvarchar(max), @prev_Type int, @CombinedName nvarchar(max) = ''

    OPEN c_Access
    FETCH NEXT FROM c_Access INTO @NoteID, @NoteAccessID, @TableTypeID, @ItemID, @Type
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @NoteAccessID != @prev_NoteAccessID AND @prev_NoteAccessID > 0
        BEGIN
            IF @GetDeniedNote = 1
            BEGIN
                INSERT INTO @NoteAccess (NoteID, NoteAccessID, TableTypeID, ItemID, AccessRight, Name)
                VALUES (@prev_NoteID, @prev_NoteAccessID, @prev_TableTypeID, @prev_ItemID, @DenyPermission, @CombinedName)
            END
            ELSE
            BEGIN
                INSERT INTO @NoteAccess (NoteID, NoteAccessID, TableTypeID, ItemID, AccessRight, Name)
                VALUES (@prev_NoteID, @prev_NoteAccessID, @prev_TableTypeID, @prev_ItemID, @prev_Type, @CombinedName)
            END
            SET @CombinedName = ''
        END
        
        SELECT @prev_NoteID = @NoteID, @prev_NoteAccessID = @NoteAccessID, @prev_TableTypeID = @TableTypeID, @prev_ItemID = @ItemID, @prev_Type = @Type

        IF @CombinedName != '' SET @CombinedName = @CombinedName + '-'

        IF @TableTypeID = @UserType_TT
        BEGIN
            SELECT @CombinedName = @CombinedName + lt.[Name]
            FROM   org.LT_UserType lt
            WHERE  lt.UserTypeID = @ItemID AND lt.LanguageID = @LanguageID
        END
        ELSE IF @TableTypeID = @HD_TT
        BEGIN
            SELECT @CombinedName = @CombinedName + d.Name
            FROM   org.H_D hd JOIN  org.Department d ON hd.DepartmentID = d.DepartmentID AND hd.HDID = @ItemID
        END
		ELSE IF @TableTypeID = @DepartmentType_TT
        BEGIN
            SELECT @CombinedName = @CombinedName + ltDepartment.Name
            FROM   org.LT_DepartmentType ltDepartment
            WHERE  ltDepartment.DepartmentTypeID = @ItemID AND ltDepartment.LanguageID = @LanguageID
        END
        FETCH NEXT FROM c_Access INTO @NoteID, @NoteAccessID, @TableTypeID, @ItemID, @Type

        IF @@FETCH_STATUS != 0
        BEGIN
            IF @GetDeniedNote = 1
            BEGIN
                INSERT INTO @NoteAccess (NoteID, NoteAccessID, TableTypeID, ItemID, AccessRight, Name)
                VALUES (@prev_NoteID, @prev_NoteAccessID, @prev_TableTypeID, @prev_ItemID, @DenyPermission, @CombinedName)
            END
            ELSE
            BEGIN
                INSERT INTO @NoteAccess (NoteID, NoteAccessID, TableTypeID, ItemID, AccessRight, Name)
                VALUES (@prev_NoteID, @prev_NoteAccessID, @prev_TableTypeID, @prev_ItemID, @prev_Type, @CombinedName)
            END
        END
    END
    CLOSE c_Access
    DEALLOCATE c_Access
    
	SELECT n.NoteID, ISNULL(ltn.[Subject],fblt.[Subject]) [Subject], ISNULL(ltn.Note,fblt.Note) Note, n.Active,
           (u.FirstName + ' ' + u.LastName) CreatedByName, n.Created, n.StartDate, n.EndDate, n.NotifyAtNextLogin, na.TableTypeID, na.Name Receiver
	FROM   note.Note n JOIN org.[User] u ON n.CreatedBy = u.UserID
     AND   (u.UserID IN (SELECT UserID FROM @UserIDTable) OR ISNULL(@UserIDList,'') = '')
	LEFT JOIN note.LT_Note ltn ON n.NoteID = ltn.NoteID AND ltn.LanguageID = @LanguageID  
	LEFT JOIN note.LT_Note fblt ON n.NoteID = fblt.NoteID AND fblt.LanguageID = @FallbackLanguageID
    LEFT JOIN @NoteAccess na ON n.NoteID = na.NoteID
	WHERE n.NoteTypeID = @NoteTypeID
      AND n.Deleted = 0
    ORDER BY n.NoteID

END

