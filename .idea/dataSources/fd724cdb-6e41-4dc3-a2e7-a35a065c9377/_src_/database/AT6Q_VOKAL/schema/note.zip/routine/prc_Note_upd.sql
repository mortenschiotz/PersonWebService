CREATE PROCEDURE [note].[prc_Note_upd]
(
	@NoteID int,
	@NoteTypeID int,
	@Active bit,
	@ExtID nvarchar(64),
	@NotifyAtNextLogin bit,
	@StartDate datetime,
	@EndDate datetime,
	@CreatedBy int,
	@ChangedBy int,
	@Deleted bit,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [note].[Note]
	SET
		[NoteTypeID] = @NoteTypeID,
		[Active] = @Active,
		[ExtID] = @ExtID,
		[NotifyAtNextLogin] = @NotifyAtNextLogin,
		[StartDate] = @StartDate,
		[EndDate] = @EndDate,
		[CreatedBy] = @CreatedBy,
		[Changed] = getdate(),
		[ChangedBy] = @ChangedBy,
		[Deleted] = @Deleted
	WHERE
		[NoteID] = @NoteID

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Note',1,
		( SELECT * FROM [note].[Note] 
			WHERE
			[NoteID] = @NoteID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
