CREATE PROCEDURE [note].[prc_NoteTypeAccess_get]
(
	@NoteTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT 
		[NoteTypeAccessID],
		[NoteTypeID],
		[TableTypeID],
		[ItemID],
		[Type],
		[Created]
	FROM [note].[NoteTypeAccess]
	WHERE [NoteTypeID] = @NoteTypeID
		
	Set @Err = @@Error
	
	RETURN @Err
END
