CREATE PROCEDURE [note].[prc_NoteTag_ins]
(
	@NoteTagID int = null output,
	@NoteTypeID int,
	@Type smallint,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [note].[NoteTag]
	(
		[NoteTypeID],
		[Type],
		[No]
	)
	VALUES
	(
		@NoteTypeID,
		@Type,
		@No
	)

	Set @Err = @@Error
	Set @NoteTagID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTag',0,
		( SELECT * FROM [note].[NoteTag] 
			WHERE
			[NoteTagID] = @NoteTagID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
