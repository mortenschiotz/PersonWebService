CREATE PROCEDURE [note].[prc_NoteType_get]
	@OwnerID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    SELECT 
		[NoteTypeID],
		[OwnerID],
		[Name],
		[UseVersioning],
		[UseReadLog],
		[UseHTML],
		[UseEncryption],
		[Created]
	FROM [note].[NoteType]
	WHERE [OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err

END
