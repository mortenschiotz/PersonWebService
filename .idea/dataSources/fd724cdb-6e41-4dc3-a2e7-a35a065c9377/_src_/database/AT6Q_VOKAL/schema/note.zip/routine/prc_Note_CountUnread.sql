CREATE PROCEDURE [note].[prc_Note_CountUnread]
(
    @UserID            int,
    @ListNoteTypeID    nvarchar(512)='',
    @HDID              int = 0,
    @NoteCount         int = 0 OUTPUT,
    @NotifyAtNextLogin bit = 0
)
AS
BEGIN
       set @NoteCount=0
    SET NOCOUNT ON
    DECLARE @NoteTypeID int, @CheckValidInDateRange bit = 1
    CREATE TABLE #Note (NoteID int, CreatedBy int, Created datetime, AccessType int, NotifyAtNextLogin bit, Active bit) 
    DECLARE cur CURSOR READ_ONLY FOR
    SELECT * FROM dbo.funcListToTableInt(@ListNoteTypeID,',')
    OPEN cur
    FETCH NEXT FROM cur INTO  @NoteTypeID
        WHILE @@FETCH_STATUS =0
        BEGIN
            INSERT INTO #Note EXEC [note].[prc_Note_getByAccess] @UserID, @NoteTypeID, @HDID, @NotifyAtNextLogin, '', @CheckValidInDateRange
            FETCH NEXT FROM cur INTO  @NoteTypeID
        END
    CLOSE cur
    DEALLOCATE cur
    SELECT @NoteCount = COUNT(n.NoteID) FROM #Note n
    WHERE NOT EXISTS (SELECT 1 FROM note.NoteReadLog rl WHERE rl.NoteID = n.NoteID AND rl.UserID = @UserID) AND n.Active = 1

    DROP TABLE #Note
END
