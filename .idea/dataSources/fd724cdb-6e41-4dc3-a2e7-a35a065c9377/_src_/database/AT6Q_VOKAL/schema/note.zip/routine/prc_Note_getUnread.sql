CREATE PROCEDURE [note].[prc_Note_getUnread]
(
    @UserID            int,
    @ListNoteTypeID    nvarchar(512)='',
    @HDID              int = 0,
    @NotifyAtNextLogin bit = 0
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @NoteTypeID int, @CheckValidInDateRange bit = 1
    CREATE TABLE #Note (NoteID int, CreatedBy int, Created datetime, AccessType int, NotifyAtNextLogin bit, Active bit) 
    DECLARE cur CURSOR READ_ONLY FOR
    SELECT * FROM dbo.funcListToTableInt(@ListNoteTypeID,',')
    OPEN cur
    FETCH NEXT FROM cur INTO  @NoteTypeID
        WHILE @@FETCH_STATUS =0
        BEGIN
            INSERT INTO #Note EXEC [note].[prc_Note_getByAccess] @UserID, @NoteTypeID, @HDID, @NotifyAtNextLogin, '', @CheckValidInDateRange
            FETCH NEXT FROM cur INTO  @NoteTypeID
        END
    CLOSE cur
    DEALLOCATE cur
    SELECT n.NoteID, n.CreatedBy, n.Created, n.AccessType, n.NotifyAtNextLogin, n.Active, ISNULL(ns.[TableTypeID],0) [TableTypeID], ISNULL(ns.[ItemID],0) [ItemID]
    FROM #Note n
    LEFT JOIN [note].[NoteSource] ns ON ns.[NoteID] = n.[NoteID]
    WHERE NOT EXISTS (SELECT 1 FROM note.NoteReadLog rl WHERE rl.NoteID = n.NoteID AND rl.UserID = @UserID) AND n.Active = 1

    DROP TABLE #Note
END
