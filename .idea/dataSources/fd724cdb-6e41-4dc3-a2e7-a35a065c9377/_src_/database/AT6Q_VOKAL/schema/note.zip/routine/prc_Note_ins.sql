CREATE PROCEDURE [note].[prc_Note_ins]
(
	@NoteID int = null output,
	@NoteTypeID int,
	@Active bit,
	@ExtID nvarchar(64),
	@NotifyAtNextLogin bit,
	@StartDate datetime,
	@EndDate datetime,
	@CreatedBy int,
	@ChangedBy int,
	@Deleted bit,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [note].[Note]
	(
		[NoteTypeID],
		[Active],
		[ExtID],
		[NotifyAtNextLogin],
		[StartDate],
		[EndDate],
		[CreatedBy],
		[ChangedBy],
		[Deleted]
	)
	VALUES
	(
		@NoteTypeID,
		@Active,
		@ExtID,
		@NotifyAtNextLogin,
		@StartDate,
		@EndDate,
		@CreatedBy,
		@ChangedBy,
		@Deleted
	)

	Set @Err = @@Error
	Set @NoteID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Note',0,
		( SELECT * FROM [note].[Note] 
			WHERE
			[NoteID] = @NoteID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
