CREATE PROCEDURE [note].[prc_NoteType_del]
(
	@NoteTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteType',2,
		( SELECT * FROM [note].[NoteType] 
			WHERE
			[NoteTypeID] = @NoteTypeID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [note].[NoteType]
	WHERE
		[NoteTypeID] = @NoteTypeID
		
	Set @Err = @@Error
	
	RETURN @Err
END
