CREATE PROCEDURE [note].[prc_NoteTag_upd]
(
	@NoteTagID int,
	@NoteTypeID int,
	@Type smallint,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [note].[NoteTag]
	SET
		[NoteTypeID] = @NoteTypeID,
		[Type] = @Type,
		[No] = @No
	WHERE
		[NoteTagID] = @NoteTagID

	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTag',1,
		( SELECT * FROM [note].[NoteTag] 
			WHERE
			[NoteTagID] = @NoteTagID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
