CREATE PROCEDURE [note].[prc_LT_Note_del]
(
	@LanguageID int,
	@NoteID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Note',2,
		( SELECT * FROM [note].[LT_Note] 
			WHERE
			[NoteID] = @NoteID
			AND [LanguageID] = @LanguageID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [note].[LT_Note]
	WHERE
		[NoteID] = @NoteID
		AND [LanguageID] = @LanguageID

	Set @Err = @@Error
	
	RETURN @Err
END
