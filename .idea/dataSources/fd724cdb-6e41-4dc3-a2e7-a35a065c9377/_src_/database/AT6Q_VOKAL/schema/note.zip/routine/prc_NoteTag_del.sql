CREATE PROCEDURE [note].[prc_NoteTag_del]
(
	@NoteTagID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTag',2,
		( SELECT * FROM [note].[NoteTag] 
			WHERE
			[NoteTagID] = @NoteTagID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [note].[NoteTag]
	WHERE
		[NoteTagID] = @NoteTagID
		
	Set @Err = @@Error
	
	RETURN @Err
END
