CREATE PROCEDURE [note].[prc_NoteTag_Note_ins]
(
	@NoteID int,
	@NoteTagID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [note].[NoteTag_Note]
	(
		[NoteID],
		[NoteTagID]
	)
	VALUES
	(
		@NoteID,
		@NoteTagID
	)
		
	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTag_Note',0,
		( SELECT * FROM [note].[NoteTag_Note] 
			WHERE
			[NoteID] = @NoteID
			AND [NoteTagID] = @NoteTagID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
