CREATE PROCEDURE [note].[prc_LT_Note_get]
	@NoteID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[NoteID],
		[Subject],
		[Note],
		[Created]
	FROM [note].[LT_Note]
	WHERE [NoteID] = @NoteID
	
	Set @Err = @@Error

	RETURN @Err
  
END
