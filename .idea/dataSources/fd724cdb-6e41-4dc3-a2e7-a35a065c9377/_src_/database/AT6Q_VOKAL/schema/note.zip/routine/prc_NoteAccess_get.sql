CREATE PROCEDURE [note].[prc_NoteAccess_get]
(
	@NoteID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT 
		[NoteAccessID],
		[NoteID],
		[TableTypeID],
		[ItemID],
		[Type],
		[Created]
	FROM [note].[NoteAccess]
	WHERE [NoteID] = @NoteID
		
	Set @Err = @@Error
	
	RETURN @Err
END
