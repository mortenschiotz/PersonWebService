CREATE PROCEDURE [note].[prc_LT_Note_upd]
(
	@LanguageID int,
	@NoteID int,
	@Subject nvarchar(max),
	@Note nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [note].[LT_Note]
	SET
		[LanguageID] = @LanguageID,
		[NoteID] = @NoteID,
		[Subject] = @Subject,
		[Note] = @Note
	WHERE
		[NoteID] = @NoteID
		AND [LanguageID] = @LanguageID

	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Note',1,
		( SELECT * FROM [note].[LT_Note] 
			WHERE
			[NoteID] = @NoteID
			AND [LanguageID] = @LanguageID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
