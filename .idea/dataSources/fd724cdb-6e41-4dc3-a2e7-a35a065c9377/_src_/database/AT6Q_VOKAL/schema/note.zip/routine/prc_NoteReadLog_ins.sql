CREATE PROCEDURE [note].[prc_NoteReadLog_ins]
(
	@NoteID int,
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [note].[NoteReadLog]
	(
		[NoteID],
		[UserID]
	)
	VALUES
	(
		@NoteID,
		@UserID
	)
		
	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteReadLog',0,
		( SELECT * FROM [note].[NoteReadLog] 
			WHERE
			[NoteID] = @NoteID
			AND [UserID] = @UserID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
