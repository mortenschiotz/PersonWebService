CREATE PROCEDURE [note].[prc_NoteSource_get]
(
	@NoteID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT 
		[NoteSourceID],
		[NoteID],
		[TableTypeID],
		[ItemID],
		[Type],
		[Created]
	FROM [note].[NoteSource]
	WHERE [NoteID] = @NoteID
		
	Set @Err = @@Error
	
	RETURN @Err
END
