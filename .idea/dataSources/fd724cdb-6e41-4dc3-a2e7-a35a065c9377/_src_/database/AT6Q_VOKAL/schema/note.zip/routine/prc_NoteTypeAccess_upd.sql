CREATE PROCEDURE [note].[prc_NoteTypeAccess_upd]
(
	@NoteTypeAccessID int,
	@NoteTypeID int,
	@TableTypeID int,
	@ItemID int,
	@Type smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [note].[NoteTypeAccess]
	SET
		[NoteTypeID] = @NoteTypeID,
		[TableTypeID] = @TableTypeID,
		[ItemID] = @ItemID,
		[Type] = @Type
	WHERE
		[NoteTypeAccessID] = @NoteTypeAccessID
	
	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTypeAccess',1,
		( SELECT * FROM [note].[NoteTypeAccess] 
			WHERE
			[NoteTypeAccessID] = @NoteTypeAccessID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
