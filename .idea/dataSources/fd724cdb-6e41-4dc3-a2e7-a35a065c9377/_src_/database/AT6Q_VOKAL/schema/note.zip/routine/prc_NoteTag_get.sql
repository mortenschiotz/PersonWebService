CREATE PROCEDURE [note].[prc_NoteTag_get]
	@NoteTypeID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[NoteTagID],
		[NoteTypeID],
		[Type],
		[No],
		[Created]
	FROM [note].[NoteTag]
	WHERE [NoteTypeID] = @NoteTypeID
	
	Set @Err = @@Error

	RETURN @Err
  
END
