CREATE PROCEDURE [note].[prc_NoteSource_del]
(
	@NoteSourceID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteSource',2,
		( SELECT * FROM [note].[NoteSource] 
			WHERE
			[NoteSourceID] = @NoteSourceID FOR XML AUTO) as data,
				getdate() 
	 END

	DELETE FROM [note].[NoteSource]
	WHERE
		[NoteSourceID] = @NoteSourceID
		
	Set @Err = @@Error
	
	
	RETURN @Err
END
