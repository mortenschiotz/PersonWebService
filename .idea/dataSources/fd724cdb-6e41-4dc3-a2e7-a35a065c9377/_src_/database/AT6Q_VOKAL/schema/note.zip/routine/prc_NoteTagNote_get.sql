CREATE PROCEDURE [note].[prc_NoteTagNote_get]
(
	@NoteID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT 
		[NoteID],
		[NoteTagID],
		[Created]
	FROM [note].[NoteTagNote]
	WHERE [NoteID] = @NoteID
		
	Set @Err = @@Error
	
	RETURN @Err
END
