CREATE PROCEDURE [note].[prc_LT_NoteTag_get]
	@NoteTagID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[NoteTagID],
		[Name],
		[Description],
		[Created]
	FROM [note].[LT_NoteTag]
	WHERE [NoteTagID] = @NoteTagID
	
	Set @Err = @@Error

	RETURN @Err
  
END
