CREATE PROCEDURE [note].[prc_Note_get]
	@NoteTypeID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    SELECT 
		[NoteID],
		[NoteTypeID],
		[Active],
		[ExtID],
		[NotifyAtNextLogin],
		[StartDate],
		[EndDate],
		[CreatedBy],
		[Created],
		[ChangedBy],
		[Changed],
		[Deleted]
	FROM [note].[Note]
	WHERE [NoteTypeID] = @NoteTypeID

	Set @Err = @@Error

	RETURN @Err

END
