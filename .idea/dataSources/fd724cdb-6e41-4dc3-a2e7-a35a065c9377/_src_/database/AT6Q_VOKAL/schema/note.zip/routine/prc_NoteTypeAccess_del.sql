CREATE PROCEDURE [note].[prc_NoteTypeAccess_del]
(
	@NoteTypeAccessID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteTypeAccess',2,
		( SELECT * FROM [note].[NoteTypeAccess] 
			WHERE
			[NoteTypeAccessID] = @NoteTypeAccessID FOR XML AUTO) as data,
				getdate() 
	 END

	DELETE FROM [note].[NoteTypeAccess]
	WHERE
		[NoteTypeAccessID] = @NoteTypeAccessID
		
	Set @Err = @@Error
	
	
	RETURN @Err
END
