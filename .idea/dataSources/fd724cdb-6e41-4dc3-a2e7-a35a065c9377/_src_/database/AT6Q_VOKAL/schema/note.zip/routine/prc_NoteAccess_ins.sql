CREATE PROCEDURE [note].[prc_NoteAccess_ins]
(
	@NoteAccessID int = null output,
	@NoteID int,
	@TableTypeID int,
	@ItemID int,
	@Type smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [note].[NoteAccess]
	(
		[NoteID],
		[TableTypeID],
		[ItemID],
		[Type]
	)
	VALUES
	(
		@NoteID,
		@TableTypeID,
		@ItemID,
		@Type
	)
	
	Set @Err = @@Error
	Set @NoteAccessID = scope_identity()
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'NoteAccess',0,
		( SELECT * FROM [note].[NoteAccess] 
			WHERE
			[NoteAccessID] = @NoteAccessID FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
