
CREATE PROCEDURE [res].[prc_Status_get]    
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

    SELECT     
	  [StatusID]
      ,[No]
 FROM [res].[Status]    
 
 Set @Err = @@Error    

 RETURN @Err    

END 
