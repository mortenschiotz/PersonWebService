  
CREATE PROCEDURE [res].[prc_MediaType_get]  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	[MediaTypeID],  
	[CodeName]
 FROM [res].[MediaType]  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
