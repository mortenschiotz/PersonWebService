  
CREATE PROCEDURE [res].[prc_LT_Category_del]
(
	@CategoryID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_Category',0,
		( SELECT * FROM [res].[LT_Category] 
			WHERE
			[CategoryID] = @CategoryID AND [LanguageID] = @LanguageID	FOR XML AUTO) as data,
				getdate() 
	END

	DELETE FROM res.LT_Category
	WHERE
		[CategoryID] = @CategoryID AND [LanguageID] = @LanguageID
	
	Set @Err = @@Error  
	
	RETURN @Err
END  
