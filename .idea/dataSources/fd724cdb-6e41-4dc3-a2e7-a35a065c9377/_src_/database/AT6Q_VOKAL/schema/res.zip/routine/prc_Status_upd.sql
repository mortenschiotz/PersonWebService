CREATE PROCEDURE [res].[prc_Status_upd]    
(
	@StatusID int,
	@No int,
	@cUserid int,  
	@Log smallint = 1
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

 UPDATE [res].[Status]
 SET	
	[No] = @No
 WHERE
	[StatusID] = @StatusID
 
 Set @Err = @@Error  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'res.Status',0,  
  ( SELECT * FROM [res].[Status]   
   WHERE  
   [StatusID] = @StatusID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  

END 
