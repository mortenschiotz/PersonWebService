CREATE PROCEDURE [res].[prc_Provider_get]  
 @OwnerID int  
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int  
   
 SELECT [ProviderId]
       ,[Icon]
       ,[OwnerId]
       ,[CustomerId]
       ,[LinkGenerationMethod]
       ,[ExtID]
	   ,[UseLogging]
 FROM [res].[Provider]  
 WHERE [OwnerID] = @OwnerID  
   
 Set @Err = @@Error  
  
 RETURN @Err  
    
END
