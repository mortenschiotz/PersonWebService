
CREATE PROCEDURE [res].[prc_LT_Status_del]  
(  
	@StatusID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)  
AS  
BEGIN  
 	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_Status',2,
		( SELECT * FROM [res].[LT_Status] 
			WHERE
			[LanguageID] = @LanguageID AND
			[StatusID] = @StatusID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	  
	DELETE
	FROM res.LT_Status
	WHERE
		[StatusID] = @StatusID AND [LanguageID] = @LanguageID
  
	Set @Err = @@Error  
	RETURN @Err
END  
