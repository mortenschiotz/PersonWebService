CREATE PROCEDURE [res].[prc_Resource_get]    
(
	@CategoryID as int
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

    SELECT     
	  [ResourceId]
      ,[MediaTypeId]
      ,[CategoryId]
      ,[URL]
      ,[StatusID]
      ,[Deleted]
      ,[ValidTo]
      ,[ValidFrom]
      ,[Active]
      ,[ExtId]
      ,[Updated]
      ,[Created]
      ,[AuthorName]
	  ,[Author]
      ,[CreatedBy]
      ,[No]
      ,[ShowAuthor]
      ,[ShowTopBar]
      ,[ShowCompleteCheckbox]
      ,[IsExternal]
      ,[ShowPublishedDate]
      ,[ShowNote]
      
 FROM [res].[Resource]    
 WHERE [CategoryID] = @CategoryID
 ORDER BY [No]

 Set @Err = @@Error    

 RETURN @Err    

END
