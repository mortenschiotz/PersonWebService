CREATE PROCEDURE [res].[prc_LT_Resource_get]  
(  
 @ResourceID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [ResourceID],  
 [LanguageID],  
 [Name],  
 [Description],
 [URL],
 [Keyword],
 isnull([NoteHeading],'') [NoteHeading],
 isnull([CompletedCheckText],'') [CompletedCheckText],
 isnull([CompletedInfoText],'') [CompletedInfoText],
 isnull([Tooltip],'') [Tooltip]
 FROM [res].[LT_Resource]  
 WHERE  
 [ResourceID] = @ResourceID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END 
