  
CREATE PROCEDURE [res].[prc_LT_MediaType_get]  
(  
	@MediaTypeID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	[MediaTypeID],  
	[LanguageID],  
	[Name]
 FROM [res].[LT_MediaType]  
 WHERE  
	[MediaTypeID] = @MediaTypeID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
