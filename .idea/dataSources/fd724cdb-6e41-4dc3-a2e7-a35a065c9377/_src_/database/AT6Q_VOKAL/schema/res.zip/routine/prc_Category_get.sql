CREATE PROCEDURE [res].[prc_Category_get]  
(  
	@ProviderID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	[CategoryID],  
	[CustomerID],  
	[ProviderID],
    [No],
    [ExtID]
 FROM [res].[Category]  
 WHERE  
	[ProviderID] = @ProviderID 
  
 Set @Err = @@Error  
  
 RETURN @Err  
END
