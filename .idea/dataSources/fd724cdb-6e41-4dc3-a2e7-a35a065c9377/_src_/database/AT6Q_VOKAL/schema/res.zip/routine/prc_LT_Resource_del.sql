  
CREATE PROCEDURE [res].[prc_LT_Resource_del]
(
	@ResourceID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_Resource',0,
		( SELECT * FROM [res].[LT_Resource] 
			WHERE
			[ResourceID] = @ResourceID AND [LanguageID] = @LanguageID	FOR XML AUTO) as data,
				getdate() 
	END

	DELETE FROM res.LT_Resource
	WHERE
		[ResourceID] = @ResourceID AND [LanguageID] = @LanguageID
	
	Set @Err = @@Error  
	
	RETURN @Err
END  
