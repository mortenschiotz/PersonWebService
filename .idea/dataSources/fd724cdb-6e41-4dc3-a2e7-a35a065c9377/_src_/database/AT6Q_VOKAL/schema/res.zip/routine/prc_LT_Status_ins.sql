
CREATE PROCEDURE [res].[prc_LT_Status_ins]  
(  
	@StatusID int,
	@LanguageID int,
	@Name nvarchar(250),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)  
AS  
BEGIN  
 SET NOCOUNT ON  
	DECLARE @Err Int  
  
	INSERT INTO res.LT_Status
	(
		[LanguageID],
		[StatusID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@StatusID,
		@Name,
		@Description
	)
  
	Set @Err = @@Error  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_Status',0,
		( SELECT * FROM [res].[LT_Status] 
			WHERE
			[StatusID] = @StatusID AND [LanguageID] = @LanguageID	FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END  
