
CREATE PROCEDURE [res].[prc_LT_Status_get]  
(  
	@StatusID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	[StatusID],  
	[LanguageID],  
	[Name],  
	[Description]
 FROM [res].[LT_Status]  
 WHERE  
	[StatusID] = @StatusID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
