CREATE PROCEDURE [res].[prc_Category_ins]
(
	@CategoryID int = null output,
	@CustomerID int,
	@ProviderID int,
    @No int = 0,
    @ExtID nvarchar(128) = '',
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	INSERT INTO res.Category
	(
		CustomerId,
		ProviderId,
        [No],
        [ExtID]
	)
	VALUES
	(
		@CustomerID,
		@ProviderID,
        @No,
        @ExtID 
	)
  
	Set @Err = @@Error  
	Set @CategoryID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.Category',0,
		( SELECT * FROM [res].[Category] 
			WHERE
			[CategoryID] = @CategoryID	FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END
