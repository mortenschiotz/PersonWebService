  
CREATE PROCEDURE [res].[prc_LT_Provider_get]  
(  
	@ProviderID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	[ProviderID],  
	[LanguageID],  
	[Name],  
	[Description]  
 FROM [res].[LT_Provider]  
 WHERE  
	[ProviderID] = @ProviderID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
