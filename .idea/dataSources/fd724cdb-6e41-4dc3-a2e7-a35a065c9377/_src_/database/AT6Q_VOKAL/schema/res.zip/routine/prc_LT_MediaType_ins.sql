  
CREATE PROCEDURE [res].[prc_LT_MediaType_ins]
(
	@MediaTypeID int,
	@LanguageID int,
	@Name nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	INSERT INTO res.LT_MediaType
	(
		[LanguageID],
		[MediaTypeID],
		[Name]
	)
	VALUES
	(
		@LanguageID,
		@MediaTypeID,
		@Name
	)
  
	Set @Err = @@Error  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_MediaType',0,
		( SELECT * FROM [res].[LT_MediaType] 
			WHERE
			[MediaTypeID] = @MediaTypeID AND [LanguageID] = @LanguageID	FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END  
