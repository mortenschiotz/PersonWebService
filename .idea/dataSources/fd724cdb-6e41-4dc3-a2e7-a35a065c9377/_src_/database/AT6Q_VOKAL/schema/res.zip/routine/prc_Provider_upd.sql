CREATE PROCEDURE [res].[prc_Provider_upd]    
(
	@ProviderID int,
	@Icon nvarchar(128),
	@OwnerID int,
	@CustomerID int,
	@LinkGenerationMethod nvarchar(512),
    @ExtID NVARCHAR(512),
	@UseLogging bit = 0,
	@cUserid int,  
	@Log smallint = 1
)
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    

 UPDATE [res].[Provider]
 SET
	[Icon] = @Icon,
	[OwnerId] = @OwnerID,
	[CustomerId] = @CustomerID,
	[LinkGenerationMethod] = @LinkGenerationMethod,
    [ExtID] = @ExtID,
	[UseLogging] = @UseLogging
 WHERE
	[ProviderId] = @ProviderID
 
 Set @Err = @@Error 
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'res.Provider',0,  
  ( SELECT * FROM [res].[Provider]   
   WHERE  
   [ProviderID] = @ProviderID    FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  

END
