  
CREATE PROCEDURE [res].[prc_Resource_del]
(
	@ResourceID int,
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.Resource',0,
		( SELECT * FROM [res].[Resource] 
			WHERE
			[ResourceID] = @ResourceID FOR XML AUTO) as data,
				getdate() 
	END

	DELETE FROM res.[Resource]
	WHERE
		[ResourceID] = @ResourceID
	
	Set @Err = @@Error  
	
	RETURN @Err
END  
