
CREATE PROCEDURE [res].[prc_Resource_XC_get]
(
	@ResourceID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
		[ResourceID],
		[XCID]
	FROM [res].[Resource_XC]
	WHERE 
		[ResourceID] = @ResourceID

	Set @Err = @@Error

	RETURN @Err
END

