  
CREATE PROCEDURE [res].[prc_LT_Provider_upd]
(
	@ProviderID int,
	@LanguageID int,
	@Name nvarchar(max),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @Err Int  
  
	UPDATE res.LT_Provider
	SET
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[ProviderID] = @ProviderID AND [LanguageID] = @LanguageID
	
	Set @Err = @@Error  
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'res.LT_Provider',0,
		( SELECT * FROM [res].[LT_Provider] 
			WHERE
			[ProviderID] = @ProviderID AND [LanguageID] = @LanguageID	FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END  
