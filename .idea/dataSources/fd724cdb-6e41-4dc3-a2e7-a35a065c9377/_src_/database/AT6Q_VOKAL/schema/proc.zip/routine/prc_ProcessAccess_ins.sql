
CREATE PROCEDURE [proc].[prc_ProcessAccess_ins]
(
	@ProcessAccessID int = null output,
	@ProcessID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessAccess]
	(
		[ProcessID],
		[DepartmentID]
	)
	VALUES
	(
		@ProcessID,
		@DepartmentID
	)

	Set @Err = @@Error
	Set @ProcessAccessID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAccess',0,
		( SELECT * FROM [proc].[ProcessAccess] 
			WHERE
			[ProcessAccessID] = @ProcessAccessID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

