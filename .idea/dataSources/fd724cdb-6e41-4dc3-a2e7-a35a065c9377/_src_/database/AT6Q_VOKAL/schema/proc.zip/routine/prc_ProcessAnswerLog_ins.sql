
CREATE PROCEDURE [proc].[prc_ProcessAnswerLog_ins]
(
	@ProcessAnswerLogID int = null output,
	@UserID int,
	@ProcessAnswerID int,
	@ProcessLevelID int,
	@Comment nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessAnswerLog]
	(
		[UserID],
		[ProcessAnswerID],
		[ProcessLevelID],
		[Comment]
	)
	VALUES
	(
		@UserID,
		@ProcessAnswerID,
		@ProcessLevelID,
		@Comment
	)

	Set @Err = @@Error
	Set @ProcessAnswerLogID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAnswerLog',0,
		( SELECT * FROM [proc].[ProcessAnswerLog] 
			WHERE
			[ProcessAnswerLogID] = @ProcessAnswerLogID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

