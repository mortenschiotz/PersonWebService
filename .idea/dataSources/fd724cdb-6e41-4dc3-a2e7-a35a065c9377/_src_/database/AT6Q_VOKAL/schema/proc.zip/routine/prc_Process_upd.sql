


CREATE PROCEDURE [proc].[prc_Process_upd]
(
	@ProcessID int,
	@ProcessGroupID int,
	@DepartmentID int,
	@Active smallint,
	@TargetValue float,
	@UserID int,
	@CustomerID int,
	@StartDate datetime,
	@DueDate datetime,
	@Responsible nvarchar(128),
	@URL nvarchar(512),
	@No smallint,
	@ProcessTypeID int = NULL,
	@isPublic smallint = 0,
	@PeriodID int = NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [proc].[Process]
	SET
		[ProcessGroupID] = @ProcessGroupID,
		[DepartmentID] = @DepartmentID,
		[Active] = @Active,
		[TargetValue] = @TargetValue,
		[UserID] = @UserID,
		[CustomerID] = @CustomerID,
		[StartDate] = @StartDate,
		[DueDate] = @DueDate,
		[Responsible] = @Responsible,
		[URL] = @URL,
		[No] = @No,
		[ProcessTypeID] = @ProcessTypeID ,
		[isPublic] = @isPublic,
		[PeriodID] = @PeriodID
	WHERE
		[ProcessID] = @ProcessID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Process',1,
		( SELECT * FROM [proc].[Process] 
			WHERE
			[ProcessID] = @ProcessID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END




