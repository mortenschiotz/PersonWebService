
CREATE PROCEDURE [proc].[prc_LT_ProcessGroup_upd]
(
	@ProcessGroupID int,
	@LanguageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [proc].[LT_ProcessGroup]
	SET
		[ProcessGroupID] = @ProcessGroupID,
		[LanguageID] = @LanguageID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[ProcessGroupID] = @ProcessGroupID AND
		[LanguageID] = @LanguageID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ProcessGroup',1,
		( SELECT * FROM [proc].[LT_ProcessGroup] 
			WHERE
			[ProcessGroupID] = @ProcessGroupID AND
			[LanguageID] = @LanguageID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

