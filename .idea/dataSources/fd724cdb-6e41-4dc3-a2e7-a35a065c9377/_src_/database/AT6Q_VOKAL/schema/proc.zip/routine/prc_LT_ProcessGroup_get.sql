
Create PROCEDURE [proc].[prc_LT_ProcessGroup_get]
(
	@ProcessGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessGroupID],
	[LanguageID],
	[Name],
	[Description]
	FROM [proc].[LT_ProcessGroup]
	WHERE
	[ProcessGroupID] = @ProcessGroupID

	Set @Err = @@Error

	RETURN @Err
END

