

CREATE PROCEDURE [proc].[prc_ProcessAnswer_del]
(
	@ProcessAnswerID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAnswer',2,
		( SELECT * FROM [proc].[ProcessAnswer] 
			WHERE
			[ProcessAnswerID] = @ProcessAnswerID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[ProcessAnswer]
	WHERE
		[ProcessAnswerID] = @ProcessAnswerID

	Set @Err = @@Error

	RETURN @Err
END

