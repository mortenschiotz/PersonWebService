

CREATE PROCEDURE [proc].[prc_Process_del]
(
	@ProcessID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Process',2,
		( SELECT * FROM [proc].[Process] 
			WHERE
			[ProcessID] = @ProcessID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[Process]
	WHERE
		[ProcessID] = @ProcessID

	Set @Err = @@Error

	RETURN @Err
END

