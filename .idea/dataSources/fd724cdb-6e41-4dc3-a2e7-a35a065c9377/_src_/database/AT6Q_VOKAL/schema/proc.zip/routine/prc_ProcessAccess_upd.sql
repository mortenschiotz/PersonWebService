
CREATE PROCEDURE [proc].[prc_ProcessAccess_upd]
(
	@ProcessAccessID int,
	@ProcessID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [proc].[ProcessAccess]
	SET
		[ProcessID] = @ProcessID,
		[DepartmentID] = @DepartmentID
	WHERE
		[ProcessAccessID] = @ProcessAccessID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAccess',1,
		( SELECT * FROM [proc].[ProcessAccess] 
			WHERE
			[ProcessAccessID] = @ProcessAccessID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

