CREATE PROCEDURE [proc].[prc_LT_ProcessValue_get]
(
	@ProcessValueID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessValueID],
	[LanguageID],
	[Name],
	[Description],
	[URLName] ,
	[LeadText],
	[LeadAnswerText] 
	FROM [proc].[LT_ProcessValue]
	WHERE
	[ProcessValueID] = @ProcessValueID

	Set @Err = @@Error

	RETURN @Err
END
