
CREATE PROCEDURE [proc].[prc_ProcessGroup_ins]
(
	@ProcessGroupID int = null output,
	@OwnerID int,
	@CustomerID INT=NULL,
	@Active smallint,
	@UserID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessGroup]
	(
		[OwnerID],
		[CustomerID],
		[Active],
		[UserID],
		[No]
	)
	VALUES
	(
		@OwnerID,
		@CustomerID,
		@Active,
		@UserID,
		@No
	)

	Set @Err = @@Error
	Set @ProcessGroupID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessGroup',0,
		( SELECT * FROM [proc].[ProcessGroup] 
			WHERE
			[ProcessGroupID] = @ProcessGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

