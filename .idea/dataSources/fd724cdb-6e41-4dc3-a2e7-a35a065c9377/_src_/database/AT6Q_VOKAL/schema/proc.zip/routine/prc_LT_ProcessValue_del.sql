

CREATE PROCEDURE [proc].[prc_LT_ProcessValue_del]
(
	@ProcessValueID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ProcessValue',2,
		( SELECT * FROM [proc].[LT_ProcessValue] 
			WHERE
			[ProcessValueID] = @ProcessValueID AND
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[LT_ProcessValue]
	WHERE
		[ProcessValueID] = @ProcessValueID AND
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

