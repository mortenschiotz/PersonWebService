

CREATE PROCEDURE [proc].[prc_ProcessValue_del]
(
	@ProcessValueID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessValue',2,
		( SELECT * FROM [proc].[ProcessValue] 
			WHERE
			[ProcessValueID] = @ProcessValueID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[ProcessValue]
	WHERE
		[ProcessValueID] = @ProcessValueID

	Set @Err = @@Error

	RETURN @Err
END

