CREATE PROCEDURE [proc].[prc_LT_ProcessType_get]
(
	@ProcessTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessTypeID],
	[LanguageID],
	[Name],
	[Description],
	[DescriptionFieldName] ,
	[Helptext],
	[WizardStep1],
	[WizardStep2],
	[WizardStep3],
	[WizardStep4],
	[WizardStep5],
	[AnswerHeader],
	[WizardStep1Desc],
	[WizardStep2Desc],
	[WizardStep3Desc],
	[WizardStep4Desc],
	[WizardStep5Desc]
	FROM [proc].[LT_ProcessType]
	WHERE
	[ProcessTypeID] = @ProcessTypeID

	Set @Err = @@Error

	RETURN @Err
END
