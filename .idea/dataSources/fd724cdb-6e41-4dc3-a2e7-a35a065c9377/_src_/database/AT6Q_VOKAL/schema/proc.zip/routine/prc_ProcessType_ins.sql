CREATE PROCEDURE [proc].[prc_ProcessType_ins]
(
	@ProcessTypeID int = null output,
	@No smallint,
	@OwnerID int,
	@CssClass nvarchar(128) = '',
	@DepartmentSelect bit = 1,
	@UserSelect bit = 0,
	@FilesAbove bit = 1,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessType]
	(
		[No],
		[OwnerID],
		[CssClass],
		[DepartmentSelect],
		[UserSelect],
		[FilesAbove]
	)
	VALUES
	(
		@No,
		@OwnerID,
		@CssClass,
		@DepartmentSelect,
		@UserSelect,
		@FilesAbove
	)

	Set @Err = @@Error
	Set @ProcessTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessType',0,
		( SELECT * FROM [proc].[ProcessType] 
			WHERE
			[ProcessTypeID] = @ProcessTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
