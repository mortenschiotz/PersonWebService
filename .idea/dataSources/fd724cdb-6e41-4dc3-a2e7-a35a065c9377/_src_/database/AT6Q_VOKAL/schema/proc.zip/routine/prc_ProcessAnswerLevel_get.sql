
CREATE PROCEDURE [proc].[prc_ProcessAnswerLevel_get]
(
	@ProcessAnswerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessAnswerID],
	[ProcessLevelID],
	[Description],
	[Created]
	FROM [proc].[ProcessAnswerLevel]
	WHERE
	[ProcessAnswerID] = @ProcessAnswerID

	Set @Err = @@Error

	RETURN @Err
END

