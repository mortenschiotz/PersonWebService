
CREATE PROCEDURE [proc].[prc_LT_ProcessLevel_ins]
(
	@ProcessLevelID int,
	@LanguageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[LT_ProcessLevel]
	(
		[ProcessLevelID],
		[LanguageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@ProcessLevelID,
		@LanguageID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ProcessLevel',0,
		( SELECT * FROM [proc].[LT_ProcessLevel] 
			WHERE
			[ProcessLevelID] = @ProcessLevelID AND
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

