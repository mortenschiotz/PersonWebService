
Create PROCEDURE [proc].[prc_LT_Process_get]
(
	@ProcessID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessID],
	[LanguageID],
	[Name],
	[Description],
	[Created]
	FROM [proc].[LT_Process]
	WHERE
	[ProcessID] = @ProcessID

	Set @Err = @@Error

	RETURN @Err
END

