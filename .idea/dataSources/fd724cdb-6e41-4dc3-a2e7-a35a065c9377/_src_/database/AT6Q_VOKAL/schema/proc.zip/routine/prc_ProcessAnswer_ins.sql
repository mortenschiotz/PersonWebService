
CREATE PROCEDURE [proc].[prc_ProcessAnswer_ins]
(
	@ProcessAnswerID int = null output,
	@ProcessID int,
	@ProcessLevelID int,
	@DepartmentID int,
	@RoleID INT=NULL,
	@UserID INT=NULL,
	@LastModified datetime,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessAnswer]
	(
		[ProcessID],
		[ProcessLevelID],
		[DepartmentID],
		[RoleID],
		[UserID],
		[LastModified]
	)
	VALUES
	(
		@ProcessID,
		@ProcessLevelID,
		@DepartmentID,
		@RoleID,
		@UserID,
		@LastModified
	)

	Set @Err = @@Error
	Set @ProcessAnswerID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAnswer',0,
		( SELECT * FROM [proc].[ProcessAnswer] 
			WHERE
			[ProcessAnswerID] = @ProcessAnswerID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

