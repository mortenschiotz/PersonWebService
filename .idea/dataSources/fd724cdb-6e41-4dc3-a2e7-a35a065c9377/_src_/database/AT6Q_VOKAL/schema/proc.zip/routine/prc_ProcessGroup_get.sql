
CREATE PROCEDURE [proc].[prc_ProcessGroup_get]
(
	@OwnerID int,
	@CustomerID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessGroupID],
	[OwnerID],
	ISNULL([CustomerID], 0) AS 'CustomerID',
	[Active],
	[UserID],
	[No],
	[Created]
	FROM [proc].[ProcessGroup]
	WHERE
	[OwnerID] = @OwnerID
	and (@CustomerID is null or CustomerID = @customerid)
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


