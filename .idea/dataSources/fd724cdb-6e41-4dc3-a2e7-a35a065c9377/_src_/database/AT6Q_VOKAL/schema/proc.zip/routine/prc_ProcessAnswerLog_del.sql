

CREATE PROCEDURE [proc].[prc_ProcessAnswerLog_del]
(
	@ProcessAnswerLogID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAnswerLog',2,
		( SELECT * FROM [proc].[ProcessAnswerLog] 
			WHERE
			[ProcessAnswerLogID] = @ProcessAnswerLogID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[ProcessAnswerLog]
	WHERE
		[ProcessAnswerLogID] = @ProcessAnswerLogID

	Set @Err = @@Error

	RETURN @Err
END

