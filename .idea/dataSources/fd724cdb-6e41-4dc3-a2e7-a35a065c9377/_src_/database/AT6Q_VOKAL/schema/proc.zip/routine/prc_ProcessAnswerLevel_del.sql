

CREATE PROCEDURE [proc].[prc_ProcessAnswerLevel_del]
(
	@ProcessAnswerID int,
	@ProcessLevelID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessAnswerLevel',2,
		( SELECT * FROM [proc].[ProcessAnswerLevel] 
			WHERE
			[ProcessAnswerID] = @ProcessAnswerID AND
			[ProcessLevelID] = @ProcessLevelID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[ProcessAnswerLevel]
	WHERE
		[ProcessAnswerID] = @ProcessAnswerID AND
		[ProcessLevelID] = @ProcessLevelID

	Set @Err = @@Error

	RETURN @Err
END

