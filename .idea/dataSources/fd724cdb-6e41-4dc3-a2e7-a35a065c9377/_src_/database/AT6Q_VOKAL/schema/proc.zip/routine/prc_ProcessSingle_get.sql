
Create PROCEDURE [proc].[prc_ProcessSingle_get]
(
    @ProcessID int

)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessID],
	[ProcessGroupID],
	[DepartmentID],
	[Active],
	[TargetValue],
	[UserID],
	ISNULL([CustomerID], 0) AS 'CustomerID',
	ISNULL([StartDate], 0) AS 'StartDate',
	ISNULL([DueDate], 0) AS 'DueDate',
	[Responsible],
	[URL],
	[No],
	ISNULL([PeriodID],0) as 'PeriodID',
	[Created],
	isnull(ProcessTypeID,0) As 'ProcessTypeID' ,
	isPublic 
	FROM [proc].[Process] P
	WHERE
	 [ProcessID] = @ProcessID
	
	

	Set @Err = @@Error

	RETURN @Err
END

