

CREATE PROCEDURE [proc].[prc_Process_ins]
(
	@ProcessID int = null output,
	@ProcessGroupID int,
	@DepartmentID int,
	@Active smallint,
	@TargetValue float,
	@UserID int,
	@CustomerID INT=NULL,
	@StartDate DATETIME=NULL,
	@DueDate DATETIME=NULL,
	@Responsible nvarchar(128),
	@URL nvarchar(512),
	@No smallint,
	@ProcessTypeID int = NULL,
	@isPublic smallint = 0,
	@PeriodID int = NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[Process]
	(
		[ProcessGroupID],
		[DepartmentID],
		[Active],
		[TargetValue],
		[UserID],
		[CustomerID],
		[StartDate],
		[DueDate],
		[Responsible],
		[URL],
		[No],
		[ProcessTypeID],
		[isPublic],
		[PeriodID]
	)
	VALUES
	(
		@ProcessGroupID,
		@DepartmentID,
		@Active,
		@TargetValue,
		@UserID,
		@CustomerID,
		@StartDate,
		@DueDate,
		@Responsible,
		@URL,
		@No,
		@ProcessTypeID,
		@isPublic,
		@PeriodID
	)

	Set @Err = @@Error
	Set @ProcessID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Process',0,
		( SELECT * FROM [proc].[Process] 
			WHERE
			[ProcessID] = @ProcessID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END




