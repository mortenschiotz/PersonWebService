
CREATE PROCEDURE [proc].[prc_LT_Process_del]
(
	@ProcessID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Process',2,
		( SELECT * FROM [proc].[LT_Process] 
			WHERE
			[ProcessID] = @ProcessID AND
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[LT_Process]
	WHERE
		[ProcessID] = @ProcessID AND
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

