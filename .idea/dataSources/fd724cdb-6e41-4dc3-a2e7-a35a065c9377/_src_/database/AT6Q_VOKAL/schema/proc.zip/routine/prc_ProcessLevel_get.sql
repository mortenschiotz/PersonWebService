
CREATE PROCEDURE [proc].[prc_ProcessLevel_get]
(
	@ProcessID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessLevelID],
	[ProcessValueID],
	ISNULL([ProcessID], 0) AS 'ProcessID',
	[Created]
	FROM [proc].[ProcessLevel]
	WHERE
	[ProcessID] = @ProcessID

	Set @Err = @@Error

	RETURN @Err
END

