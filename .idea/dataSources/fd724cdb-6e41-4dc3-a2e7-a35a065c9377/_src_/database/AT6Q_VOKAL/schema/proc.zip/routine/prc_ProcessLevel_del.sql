

CREATE PROCEDURE [proc].[prc_ProcessLevel_del]
(
	@ProcessLevelID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessLevel',2,
		( SELECT * FROM [proc].[ProcessLevel] 
			WHERE
			[ProcessLevelID] = @ProcessLevelID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [proc].[ProcessLevel]
	WHERE
		[ProcessLevelID] = @ProcessLevelID

	Set @Err = @@Error

	RETURN @Err
END

