CREATE Proc [proc].[prc_Processes_by_Userid]
(
 @Userid int,
 @Ownerid int
)
AS
  Select distinct p.ProcessID
  from [proc].Process p
  JOIN [proc].ProcessAnswer pa on p.Processid = pa.processid and ( pa.UserID = @Userid or p.UserID = @Userid)
