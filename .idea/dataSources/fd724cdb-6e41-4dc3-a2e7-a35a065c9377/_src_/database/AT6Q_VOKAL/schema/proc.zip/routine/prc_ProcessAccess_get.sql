
CREATE PROCEDURE [proc].[prc_ProcessAccess_get]
(
	@ProcessID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessAccessID],
	[ProcessID],
	[DepartmentID],
	[Created]
	FROM [proc].[ProcessAccess]
	WHERE
	[ProcessID] = @ProcessID

	Set @Err = @@Error

	RETURN @Err
END

