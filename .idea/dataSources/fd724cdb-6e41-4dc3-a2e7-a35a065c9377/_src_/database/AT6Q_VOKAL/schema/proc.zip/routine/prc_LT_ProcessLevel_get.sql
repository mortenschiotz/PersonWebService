
Create PROCEDURE [proc].[prc_LT_ProcessLevel_get]
(
	@ProcessLevelID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessLevelID],
	[LanguageID],
	[Name],
	[Description],
	[Created]
	FROM [proc].[LT_ProcessLevel]
	WHERE
	[ProcessLevelID] = @ProcessLevelID

	Set @Err = @@Error

	RETURN @Err
END

