CREATE PROCEDURE [proc].[prc_ProcessValue_get]
(
	@OwnerID int = null,
	@ProcessTypeID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessValueID],
	[No],
	[Value],
	[BackGroundColor],
	[OwnerID],
	isnull([ProcessTypeID],0) as 'ProcessTypeID',
	[URL],
	[ReadOnly] as 'ReadOnly', 
	[Created]
	FROM [proc].[ProcessValue]
	WHERE
	([OwnerID] = @OwnerID or @OwnerID is null)
	and  ([ProcessTypeID] = @ProcessTypeID or @ProcessTypeID is null)
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
