
CREATE PROCEDURE [proc].[prc_ProcessAnswerLog_get]
(
	@ProcessAnswerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessAnswerLogID],
	[UserID],
	[ProcessAnswerID],
	[ProcessLevelID],
	[Comment],
	[Created]
	FROM [proc].[ProcessAnswerLog]
	WHERE
	[ProcessAnswerID] = @ProcessAnswerID

	Set @Err = @@Error

	RETURN @Err
END

