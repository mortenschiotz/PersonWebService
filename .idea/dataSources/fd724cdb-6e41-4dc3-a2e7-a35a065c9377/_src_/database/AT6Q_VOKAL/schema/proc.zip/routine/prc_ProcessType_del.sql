-- [proc].[prc_ProcessType_del] 12,0,0
CREATE PROCEDURE [proc].[prc_ProcessType_del]
(
	@ProcessTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessType',2,
		( SELECT * FROM [proc].[ProcessType] 
			WHERE
			[ProcessTypeID] = @ProcessTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 

    DELETE FROM [proc].[process]
    WHERE [ProcessTypeID] = @ProcessTypeID
		
	DELETE FROM [proc].[ProcessValue]
	WHERE [ProcessTypeID] = @ProcessTypeID

	DELETE FROM [proc].[ProcessType]
	WHERE [ProcessTypeID] = @ProcessTypeID

	Set @Err = @@Error

	RETURN @Err
END

