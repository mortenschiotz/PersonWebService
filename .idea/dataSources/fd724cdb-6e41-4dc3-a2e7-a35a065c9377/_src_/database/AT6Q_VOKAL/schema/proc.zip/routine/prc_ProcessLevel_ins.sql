
CREATE PROCEDURE [proc].[prc_ProcessLevel_ins]
(
	@ProcessLevelID int = null output,
	@ProcessValueID int,
	@ProcessID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [proc].[ProcessLevel]
	(
		[ProcessValueID],
		[ProcessID]
	)
	VALUES
	(
		@ProcessValueID,
		@ProcessID
	)

	Set @Err = @@Error
	Set @ProcessLevelID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessLevel',0,
		( SELECT * FROM [proc].[ProcessLevel] 
			WHERE
			[ProcessLevelID] = @ProcessLevelID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

