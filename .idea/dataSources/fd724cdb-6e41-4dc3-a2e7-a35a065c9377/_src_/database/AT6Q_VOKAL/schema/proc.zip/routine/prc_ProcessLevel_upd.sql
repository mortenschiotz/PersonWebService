
CREATE PROCEDURE [proc].[prc_ProcessLevel_upd]
(
	@ProcessLevelID int,
	@ProcessValueID int,
	@ProcessID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [proc].[ProcessLevel]
	SET
		[ProcessValueID] = @ProcessValueID,
		[ProcessID] = @ProcessID
	WHERE
		[ProcessLevelID] = @ProcessLevelID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessLevel',1,
		( SELECT * FROM [proc].[ProcessLevel] 
			WHERE
			[ProcessLevelID] = @ProcessLevelID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

