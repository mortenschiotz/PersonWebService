
CREATE PROCEDURE [proc].[prc_ProcessGroup_upd]
(
	@ProcessGroupID int,
	@OwnerID int,
	@CustomerID INT=NULL,
	@Active smallint,
	@UserID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [proc].[ProcessGroup]
	SET
		[OwnerID] = @OwnerID,
		[CustomerID] = @CustomerID,
		[Active] = @Active,
		[UserID] = @UserID,
		[No] = @No
	WHERE
		[ProcessGroupID] = @ProcessGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ProcessGroup',1,
		( SELECT * FROM [proc].[ProcessGroup] 
			WHERE
			[ProcessGroupID] = @ProcessGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

