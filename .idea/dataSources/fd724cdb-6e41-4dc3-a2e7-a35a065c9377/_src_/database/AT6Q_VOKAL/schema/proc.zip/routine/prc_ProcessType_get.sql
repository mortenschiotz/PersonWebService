CREATE PROCEDURE [proc].[prc_ProcessType_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessTypeID],
	[No],
	[OwnerID],
	[CssClass],
	[DepartmentSelect],
	[UserSelect],
	[FilesAbove] ,
	[Created]
	FROM [proc].[ProcessType]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
