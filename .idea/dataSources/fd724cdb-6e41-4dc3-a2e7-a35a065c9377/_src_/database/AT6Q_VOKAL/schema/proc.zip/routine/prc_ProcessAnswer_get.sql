
CREATE PROCEDURE [proc].[prc_ProcessAnswer_get]
(
	@ProcessID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ProcessAnswerID],
	[ProcessID],
	[ProcessLevelID],
	[DepartmentID],
	ISNULL([RoleID], 0) AS 'RoleID',
	ISNULL([UserID], 0) AS 'UserID',
	[LastModified],
	[Created]
	FROM [proc].[ProcessAnswer]
	WHERE
	[ProcessID] = @ProcessID

	Set @Err = @@Error

	RETURN @Err
END

