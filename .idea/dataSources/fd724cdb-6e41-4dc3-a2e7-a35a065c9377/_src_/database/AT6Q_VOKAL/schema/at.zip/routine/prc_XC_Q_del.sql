CREATE PROCEDURE [at].[prc_XC_Q_del]
(
	@XCID int,
	@QuestionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XC_Q',2,
		( SELECT * FROM [at].[XC_Q] 
			WHERE
			[XCID] = @XCID AND
			[QuestionID] = @QuestionID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	DELETE FROM [at].[XC_Q]
	WHERE
		[XCID] = @XCID AND
		[QuestionID] = @QuestionID
	Set @Err = @@Error
	RETURN @Err
END
