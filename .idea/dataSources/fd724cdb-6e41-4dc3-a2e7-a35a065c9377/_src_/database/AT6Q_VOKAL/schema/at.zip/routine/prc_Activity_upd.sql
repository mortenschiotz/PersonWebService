CREATE PROCEDURE [at].[prc_Activity_upd]
(
	@ActivityID int,
	@LanguageID int,
	@OwnerID int,
	@StyleSheet nvarchar(128),
	@Type smallint,
	@No smallint,
	@TooltipType smallint,
	@Listview smallint,
	@Descview smallint,
	@Chartview smallint,
	@OLAPServer nvarchar(64),
	@OLAPDB nvarchar(64),
	@SelectionHeaderType smallint = 0,
	@ExtID nvarchar(64)='',
	@cUserid int,
	@Log smallint = 1,
	@UseOLAP bit = 1,
	@ArchetypeID int = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Activity]
	SET
		[LanguageID] = @LanguageID,
		[OwnerID] = @OwnerID,
		[StyleSheet] = @StyleSheet,
		[Type] = @Type,
		[No] = @No,
		[TooltipType] = @TooltipType,
		[Listview] = @Listview,
		[Descview] = @Descview,
		[Chartview] = @Chartview,
		[OLAPServer] = @OLAPServer,
		[OLAPDB] = @OLAPDB,
		[SelectionHeaderType] = @SelectionHeaderType,
		[ExtID] = @ExtID,
		[UseOLAP]= @UseOLAP,
		[ArchetypeID] = @ArchetypeID
	WHERE
		[ActivityID] = @ActivityID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Activity',1,
		( SELECT * FROM [at].[Activity] 
			WHERE
			[ActivityID] = @ActivityID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
