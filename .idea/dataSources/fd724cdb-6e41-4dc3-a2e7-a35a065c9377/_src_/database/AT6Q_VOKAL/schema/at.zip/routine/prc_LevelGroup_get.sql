



CREATE PROCEDURE [at].[prc_LevelGroup_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LevelGroupID],
	[ActivityID],
	[Tag],
	[No],
	isNull([CustomerID],0) 'CustomerID',
	ISNULL([Departmentid],0) 'DepartmentID',
	ISNULL([RoleID],0) 'RoleID'
	FROM [at].[LevelGroup]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


