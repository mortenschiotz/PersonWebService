
CREATE PROCEDURE [at].[prc_StatusLog_ins]
(
	@StatusLogID int = null output,
	@StatusTypeID int,
	@ResultID bigint = null,
	@CVID int = null,
	@UserID int,
	@Comment ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[StatusLog]
	(
		[StatusTypeID],
		[ResultID],
		[CVID],
		[UserID],
		[Comment]
	)
	VALUES
	(
		@StatusTypeID,
		@ResultID,
		@CVID,
		@UserID,
		@Comment
	)

	Set @Err = @@Error
	Set @StatusLogID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'StatusLog',0,
		( SELECT * FROM [at].[StatusLog] 
			WHERE
			[StatusLogID] = @StatusLogID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

