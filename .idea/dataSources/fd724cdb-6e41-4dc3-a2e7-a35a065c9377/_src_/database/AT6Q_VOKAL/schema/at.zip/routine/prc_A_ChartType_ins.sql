
CREATE PROCEDURE [at].[prc_A_ChartType_ins]
(
	@AChartTypeID int = null output,
	@ReportChartTypeID int,
	@ActivityID int,
	@No smallint,
	@DefaultSelected smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[A_ChartType]
	(
		[ReportChartTypeID],
		[ActivityID],
		[No],
		[DefaultSelected]
	)
	VALUES
	(
		@ReportChartTypeID,
		@ActivityID,
		@No,
		@DefaultSelected
	)

	Set @Err = @@Error
	Set @AChartTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_ChartType',0,
		( SELECT * FROM [at].[A_ChartType] 
			WHERE
			[AChartTypeID] = @AChartTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

