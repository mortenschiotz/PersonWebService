

CREATE PROCEDURE [at].[prc_AGroup_del]
(
	@AGID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AGroup',2,
		( SELECT * FROM [at].[AGroup] 
			WHERE
			[AGID] = @AGID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[AGroup]
	WHERE
		[AGID] = @AGID

	Set @Err = @@Error

	RETURN @Err
END

