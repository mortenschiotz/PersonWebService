
CREATE PROCEDURE [at].[prc_LT_Period_get]
(
	@PeriodID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PeriodID],
	[Name],
	[Description]
	FROM [at].[LT_Period]
	WHERE
	[PeriodID] = @PeriodID

	Set @Err = @@Error

	RETURN @Err
END

