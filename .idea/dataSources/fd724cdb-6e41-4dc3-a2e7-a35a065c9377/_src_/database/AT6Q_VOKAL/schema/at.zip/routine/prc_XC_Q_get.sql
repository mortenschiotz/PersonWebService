CREATE PROCEDURE [at].[prc_XC_Q_get]
(
	@XCID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	SELECT
	[XCID],
	[QuestionID]
	FROM [at].[XC_Q]
	WHERE
	[XCID] = @XCID
	Set @Err = @@Error
	RETURN @Err
END
