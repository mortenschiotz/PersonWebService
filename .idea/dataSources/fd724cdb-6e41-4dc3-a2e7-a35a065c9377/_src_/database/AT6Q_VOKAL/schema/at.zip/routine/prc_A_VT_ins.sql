CREATE PROCEDURE [at].[prc_A_VT_ins]
(
	@AVTID int = null output,
	@ViewTypeID int,
	@ActivityID int,
	@No smallint,
	@Type smallint,
	@Template varchar(64),
	@ShowPercentage BIT,
	@ActivityViewID int=null,
	@LevelGroupID int=null,
	@CssClass nvarchar(64)='',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[A_VT]
	(
		[ViewTypeID],
		[ActivityID],
		[No],
		[Type],
		[Template],
		[ShowPercentage],
		[ActivityViewID],
		[LevelGroupID],
		[CssClass]
	)
	VALUES
	(
		@ViewTypeID,
		@ActivityID,
		@No,
		@Type,
		@Template,
		@ShowPercentage,
		@ActivityViewID,
		@LevelGroupID,
		@CssClass
	)

	Set @Err = @@Error
	Set @AVTID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_VT',0,
		( SELECT * FROM [at].[A_VT] 
			WHERE
			[AVTID] = @AVTID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
