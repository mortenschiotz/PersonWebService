
CREATE PROCEDURE [at].[prc_QA_CalcParamter_ins]
(
	@QA_CalcParamterID int = null output,
	@CFID int,
	@No smallint,
	@Name varchar(32),
	@QuestionID int,
	@AlternativeID int,
	@CategoryID int,
	@CalcType smallint,
	@Format nvarchar(32),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[QA_CalcParamter]
	(
		[CFID],
		[No],
		[Name],
		[QuestionID],
		[AlternativeID],
		[CategoryID],
		[CalcType],
		[Format]
	)
	VALUES
	(
		@CFID,
		@No,
		@Name,
		@QuestionID,
		@AlternativeID,
		@CategoryID,
		@CalcType,
		@Format
	)

	Set @Err = @@Error
	Set @QA_CalcParamterID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'QA_CalcParamter',0,
		( SELECT * FROM [at].[QA_CalcParamter] 
			WHERE
			[QA_CalcParamterID] = @QA_CalcParamterID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

