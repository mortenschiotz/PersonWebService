

CREATE PROCEDURE [at].[prc_ST_CQ_del]
(
	@ST_CQ_ID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ST_CQ',2,
		( SELECT * FROM [at].[ST_CQ] 
			WHERE
			[ST_CQ_ID] = @ST_CQ_ID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[ST_CQ]
	WHERE
		[ST_CQ_ID] = @ST_CQ_ID

	Set @Err = @@Error

	RETURN @Err
END

