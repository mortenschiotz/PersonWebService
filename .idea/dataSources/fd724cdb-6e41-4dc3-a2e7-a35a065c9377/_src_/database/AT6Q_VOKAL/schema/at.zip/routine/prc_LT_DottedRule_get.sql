


CREATE PROCEDURE [at].[prc_LT_DottedRule_get]
(
	@DottedRuleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[DottedRuleID],
	[Name],
	[Description]
	FROM [at].[LT_DottedRule]
	WHERE
	[DottedRuleID] = @DottedRuleID

	Set @Err = @@Error

	RETURN @Err
END

