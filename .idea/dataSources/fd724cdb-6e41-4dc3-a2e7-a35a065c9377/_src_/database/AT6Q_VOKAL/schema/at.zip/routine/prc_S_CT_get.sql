
CREATE PROCEDURE [at].[prc_S_CT_get]
(
	@ScaleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ScaleID],
	[ReportCalcTypeID]
	FROM [at].[S_CT]
	WHERE
	[ScaleID] = @ScaleID

	Set @Err = @@Error

	RETURN @Err
END

