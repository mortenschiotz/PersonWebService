

CREATE PROCEDURE [at].[prc_Question_get]
(
	@PageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[QuestionID],
	[PageID],
	ISNULL([ScaleID], 0) AS 'ScaleID',
	[No],
	[Type],
	[Inverted],
	[Mandatory],
	[Status],
	[CssClass],
	[ExtId],
	[Tag],
	[Created],
	ISNULL([SectionID],0) as 'SectionID'
	FROM [at].[Question]
	WHERE
	[PageID] = @PageID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


