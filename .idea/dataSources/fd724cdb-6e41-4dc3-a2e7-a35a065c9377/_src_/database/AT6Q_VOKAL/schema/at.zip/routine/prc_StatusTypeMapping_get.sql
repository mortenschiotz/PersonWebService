
CREATE PROCEDURE [at].[prc_StatusTypeMapping_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[StatusTypeMappingID],
	[ActivityID],
	ISNULL([CustomerID], 0) AS 'CustomerID',
	ISNULL([FromStatusTypeID],0) AS 'FromStatusTypeID',
	[ToStatusTypeID],
	[No],
	[Created],
	[ShowActionInUI],
	[Settings]
	FROM [at].[StatusTypeMapping]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
