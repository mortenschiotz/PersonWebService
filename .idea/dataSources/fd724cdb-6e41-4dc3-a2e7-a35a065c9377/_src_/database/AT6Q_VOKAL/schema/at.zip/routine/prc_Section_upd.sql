
CREATE PROCEDURE [at].[prc_Section_upd]
(
	@SectionID int,
	@ActivityID int,
	@Type smallint,
	@MinOccurance smallint,
	@MaxOccurance smallint,
	@Moveable bit,
	@CssClass nvarchar(64) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Section]
	SET
		[ActivityID] = @ActivityID,
		[Type] = @Type,
		[MinOccurance] = @MinOccurance,
		[MaxOccurance] = @MaxOccurance,
		[Moveable] = @Moveable,
		[CssClass] = @CssClass
	WHERE
		[SectionID] = @SectionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Section',1,
		( SELECT * FROM [at].[Section] 
			WHERE
			[SectionID] = @SectionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


