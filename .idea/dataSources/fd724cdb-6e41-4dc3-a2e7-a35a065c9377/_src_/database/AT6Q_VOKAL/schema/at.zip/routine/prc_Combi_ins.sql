
CREATE PROCEDURE [at].[prc_Combi_ins]
(
	@CombiID int = null output,
	@ChoiceID int,
	@QuestionID int,
	@AlternativeID INT=NULL,
	@ValueFormula varchar(100),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Combi]
	(
		[ChoiceID],
		[QuestionID],
		[AlternativeID],
		[ValueFormula]
	)
	VALUES
	(
		@ChoiceID,
		@QuestionID,
		@AlternativeID,
		@ValueFormula
	)

	Set @Err = @@Error
	Set @CombiID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Combi',0,
		( SELECT * FROM [at].[Combi] 
			WHERE
			[CombiID] = @CombiID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

