


CREATE PROCEDURE [at].[prc_Section_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SectionID],
	[ActivityID],
	[Type],
	[MinOccurance],
	[MaxOccurance],
	[Moveable],
	[Created],
	[CssClass]
	FROM [at].[Section]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END


