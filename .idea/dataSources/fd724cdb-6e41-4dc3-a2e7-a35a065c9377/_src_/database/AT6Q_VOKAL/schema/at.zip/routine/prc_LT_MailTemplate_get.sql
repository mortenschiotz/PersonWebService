CREATE PROCEDURE [at].[prc_LT_MailTemplate_get]
(
	@MailTemplateID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[MailTemplateID],
	[Name],
	[Subject],
	[Body]
	FROM [at].[LT_MailTemplate]
	WHERE
	[MailTemplateID] = @MailTemplateID

	Set @Err = @@Error

	RETURN @Err
END