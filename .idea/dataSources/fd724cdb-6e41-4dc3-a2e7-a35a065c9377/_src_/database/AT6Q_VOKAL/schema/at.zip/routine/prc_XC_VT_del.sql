

CREATE PROCEDURE [at].[prc_XC_VT_del]
(
	@XCVTID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XC_VT',2,
		( SELECT * FROM [at].[XC_VT] 
			WHERE
			[XCVTID] = @XCVTID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[XC_VT]
	WHERE
		[XCVTID] = @XCVTID

	Set @Err = @@Error

	RETURN @Err
END

