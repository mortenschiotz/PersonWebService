

CREATE PROCEDURE [at].[prc_LT_Action_del]
(
	@LanguageID int,
	@ActionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Action',2,
		( SELECT * FROM [at].[LT_Action] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ActionID] = @ActionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Action]
	WHERE
		[LanguageID] = @LanguageID AND
		[ActionID] = @ActionID

	Set @Err = @@Error

	RETURN @Err
END

