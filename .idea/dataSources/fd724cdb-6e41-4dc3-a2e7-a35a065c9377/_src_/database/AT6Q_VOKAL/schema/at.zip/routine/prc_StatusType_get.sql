CREATE PROCEDURE [at].[prc_StatusType_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	SELECT
	[StatusTypeID],
	ISNULL([OwnerID], 0) AS 'OwnerID',
	[Type],
	[No],
	[Value]
	FROM [at].[StatusType]
	WHERE
	([OwnerID] = @OwnerID) OR ([OwnerID] IS NULL)
	ORDER BY [No]
	Set @Err = @@Error
	RETURN @Err

END
