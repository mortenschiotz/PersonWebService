
CREATE PROCEDURE [at].[prc_ActivityView_QA_get]
(
	@ActivityViewQID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityViewQID],
	[AlternativeID],
	[No]
	FROM [at].[ActivityView_QA]
	WHERE
	[ActivityViewQID] = @ActivityViewQID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

