CREATE PROCEDURE [at].[prc_BulkGroup_get]
(
	@SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BulkGroupID],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	ISNULL([SurveyID], 0) AS 'SurveyID',
	ISNULL([No], 0) AS 'No',
	ISNULL([Css], '') AS 'Css',
	ISNULL([Icon], '') AS 'Icon',
	ISNULL([Tag], '') AS 'Tag'
	FROM [at].[BulkGroup]
	WHERE
	[SurveyID] = @SurveyID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


