CREATE PROCEDURE [at].[prc_MailTemplate_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[MailTemplateID],
	ISNULL([OwnerID], 0) AS 'OwnerID'
	FROM [at].[MailTemplate]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END
