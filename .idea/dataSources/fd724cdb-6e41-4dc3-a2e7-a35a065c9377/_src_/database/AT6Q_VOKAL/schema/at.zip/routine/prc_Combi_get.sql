
CREATE PROCEDURE [at].[prc_Combi_get]
(
	@ChoiceID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[CombiID],
	[ChoiceID],
	[QuestionID],
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	[ValueFormula]
	FROM [at].[Combi]
	WHERE
	[ChoiceID] = @ChoiceID

	Set @Err = @@Error

	RETURN @Err
END

