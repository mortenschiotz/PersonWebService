
CREATE PROCEDURE [at].[prc_LT_OwnerColor_get]
(
	@OwnerColorID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[OwnerColorID],
	[LanguageID],
	[Name],
	[Created]
	FROM [at].[LT_OwnerColor]
	WHERE
	[OwnerColorID] = @OwnerColorID

	Set @Err = @@Error

	RETURN @Err
END

