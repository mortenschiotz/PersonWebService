
CREATE PROCEDURE [at].[prc_DR_S_get]
(
	@DottedRuleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DottedRuleID],
	[ScaleID]
	FROM [at].[DR_S]
	WHERE
	[DottedRuleID] = @DottedRuleID

	Set @Err = @@Error

	RETURN @Err
END

