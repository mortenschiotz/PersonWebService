
CREATE PROCEDURE [at].[prc_LT_Action_get]
(
	@ActionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ActionID],
	ISNULL([Response], '') AS 'Response'
	FROM [at].[LT_Action]
	WHERE
	[ActionID] = @ActionID

	Set @Err = @@Error

	RETURN @Err
END

