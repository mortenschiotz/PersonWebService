
CREATE PROCEDURE [at].[prc_LT_ActivityView_del]
(
	@LanguageID int,
	@ActivityViewID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ActivityView',2,
		( SELECT * FROM [at].[LT_ActivityView] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ActivityViewID] = @ActivityViewID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_ActivityView]
	WHERE
		[LanguageID] = @LanguageID AND
		[ActivityViewID] = @ActivityViewID

	Set @Err = @@Error

	RETURN @Err
END


