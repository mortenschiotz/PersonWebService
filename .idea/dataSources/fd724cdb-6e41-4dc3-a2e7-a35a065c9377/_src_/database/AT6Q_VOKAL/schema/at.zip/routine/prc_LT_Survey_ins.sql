

CREATE PROCEDURE [at].[prc_LT_Survey_ins]
(
	@LanguageID int,
	@SurveyID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@Info nvarchar(max),
	@FinishText nvarchar(max),
	@DisplayName nvarchar(256) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_Survey]
	(
		[LanguageID],
		[SurveyID],
		[Name],
		[Description],
		[Info],
		[FinishText],
		[DisplayName]
	)
	VALUES
	(
		@LanguageID,
		@SurveyID,
		@Name,
		@Description,
		@Info,
		@FinishText,
		@DisplayName
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Survey',0,
		( SELECT * FROM [at].[LT_Survey] 
			WHERE
			[LanguageID] = @LanguageID AND
			[SurveyID] = @SurveyID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


