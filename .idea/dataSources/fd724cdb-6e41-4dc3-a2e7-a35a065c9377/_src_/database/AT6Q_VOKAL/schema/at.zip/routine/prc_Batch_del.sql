

CREATE PROCEDURE [at].[prc_Batch_del]
(
	@BatchID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Batch',2,
		( SELECT * FROM [at].[Batch] 
			WHERE
			[BatchID] = @BatchID
			 FOR XML AUTO) as data,
			getdate() 
	END 

	DELETE FROM [at].[Access]
	WHERE
		[BatchID] = @BatchID
		
	DELETE FROM [at].[Batch]
	WHERE
		[BatchID] = @BatchID

	Set @Err = @@Error

	RETURN @Err
END


