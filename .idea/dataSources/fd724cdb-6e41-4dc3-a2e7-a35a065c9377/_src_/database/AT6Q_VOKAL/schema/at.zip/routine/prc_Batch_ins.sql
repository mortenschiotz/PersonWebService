
CREATE PROCEDURE [at].[prc_Batch_ins]
(
	@BatchID int = null output,
	@SurveyID int,
	@UserID INT=NULL,
	@DepartmentID INT=NULL,
	@Name nvarchar(256),
	@No smallint,
	@StartDate DATETIME=NULL,
	@EndDate DATETIME=NULL,
	@Status smallint,
	@MailStatus smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Batch]
	(
		[SurveyID],
		[UserID],
		[DepartmentID],
		[Name],
		[No],
		[StartDate],
		[EndDate],
		[Status],
		[MailStatus]
	)
	VALUES
	(
		@SurveyID,
		@UserID,
		@DepartmentID,
		@Name,
		@No,
		@StartDate,
		@EndDate,
		@Status,
		@MailStatus
	)

	Set @Err = @@Error
	Set @BatchID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Batch',0,
		( SELECT * FROM [at].[Batch] 
			WHERE
			[BatchID] = @BatchID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

