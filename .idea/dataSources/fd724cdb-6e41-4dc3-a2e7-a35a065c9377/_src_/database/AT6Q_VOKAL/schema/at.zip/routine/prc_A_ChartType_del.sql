

CREATE PROCEDURE [at].[prc_A_ChartType_del]
(
	@AChartTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_ChartType',2,
		( SELECT * FROM [at].[A_ChartType] 
			WHERE
			[AChartTypeID] = @AChartTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[A_ChartType]
	WHERE [AChartTypeID] = @AChartTypeID

	Set @Err = @@Error

	RETURN @Err
END

