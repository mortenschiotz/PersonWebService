CREATE PROCEDURE [at].[prc_LT_A_VT_get]
(
	@AVTID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[AVTID],
	[Name],
	[Description],
	[TextAbove],
	[TextBelow]
	FROM [at].[LT_A_VT]
	WHERE
	[AVTID] = @AVTID

	Set @Err = @@Error

	RETURN @Err
END