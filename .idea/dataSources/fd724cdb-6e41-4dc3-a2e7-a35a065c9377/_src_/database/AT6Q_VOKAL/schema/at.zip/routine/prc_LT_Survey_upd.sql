



CREATE PROCEDURE [at].[prc_LT_Survey_upd]
(
	@LanguageID int,
	@SurveyID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@Info nvarchar(max),
	@FinishText nvarchar(max),
	@DisplayName nvarchar(256) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_Survey]
	SET
		[LanguageID] = @LanguageID,
		[SurveyID] = @SurveyID,
		[Name] = @Name,
		[Description] = @Description,
		[Info] = @Info,
		[FinishText] = @FinishText,
		[DisplayName] = @DisplayName
	WHERE
		[LanguageID] = @LanguageID AND
		[SurveyID] = @SurveyID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Survey',1,
		( SELECT * FROM [at].[LT_Survey] 
			WHERE
			[LanguageID] = @LanguageID AND
			[SurveyID] = @SurveyID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


