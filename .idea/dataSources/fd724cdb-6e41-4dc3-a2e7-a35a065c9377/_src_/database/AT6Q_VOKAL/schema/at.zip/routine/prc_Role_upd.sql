
CREATE PROCEDURE [at].[prc_Role_upd]
(
	@RoleID int,
	@Ownerid int,
	@No smallint,
	@Type smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Role]
	SET
		[Ownerid] = @Ownerid,
		[No] = @No,
		[Type] = @Type
	WHERE
		[RoleID] = @RoleID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Role',1,
		( SELECT * FROM [at].[Role] 
			WHERE
			[RoleID] = @RoleID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

