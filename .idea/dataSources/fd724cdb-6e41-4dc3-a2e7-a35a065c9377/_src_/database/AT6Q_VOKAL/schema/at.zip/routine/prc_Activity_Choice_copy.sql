

CREATE proc [at].[prc_Activity_Choice_copy]
(
  @FromActivityID int,
  @ToActivityID int
) as
	Declare @ChoiceID as int 
	Declare @NewChoiceID as int 
	Declare @ActionID as int
	Declare @NewActionID as int

	declare ChoiceList cursor for
	select ChoiceID from at.Choice where activityid = @FromActivityID 
	OPEN ChoiceList
	FETCH NEXT FROM ChoiceList 
	INTO @ChoiceID
		
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    Insert into choice(ActivityID, Name, No, DepartmentID, DepartmentTypeID, RoleID, Type, Created)
	    select @ToActivityID, Name, No, DepartmentID, DepartmentTypeID, RoleID, Type,getdate() 
	    from choice where choiceid = @ChoiceID
	
	    select @NewChoiceID = SCOPE_IDENTITY()
	    
	    insert into at.Combi(ChoiceID, QuestionID, AlternativeID, ValueFormula)
	    select @NewChoiceID , QuestionID, AlternativeID, ValueFormula
	    from at.Combi where choiceid = @ChoiceID
	    
		declare ActionList cursor for
		select ActionID from [Action] where ChoiceID = @ChoiceID
		OPEN ActionList
		FETCH NEXT FROM ActionList 
		INTO @ActionID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			insert into at.Action(ChoiceID, No, PageID, QuestionID, AlternativeID, Type)
			select	  @NewChoiceID, No, PageID, QuestionID, AlternativeID, Type
			from at.Action where ActionID = @ActionID
	    
			select @NewActionID = SCOPE_IDENTITY()

			insert into at.LT_Action(LanguageID, ActionID, Response)
			select	  LanguageID, @NewActionID, Response
			from at.LT_Action where ActionID = @ActionID

			FETCH NEXT FROM ActionList 
			INTO @ActionID
		END
		CLOSE ActionList
		DEALLOCATE ActionList

	    FETCH NEXT FROM ChoiceList 
	    INTO @ChoiceID
	   
	END
	CLOSE ChoiceList
	DEALLOCATE ChoiceList
	
