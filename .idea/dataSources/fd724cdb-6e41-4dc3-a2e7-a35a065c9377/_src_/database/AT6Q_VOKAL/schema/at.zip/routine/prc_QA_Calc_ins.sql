CREATE PROCEDURE  [at].[prc_QA_Calc_ins]  
(  
 @QAID int = null output,  
 @QuestionID int,  
 @AlternativeID int,  
 @CFID int,  
 @MinValue float,  
 @MaxValue float,  
 @No smallint,  
 @NewValue float,  
 @UseNewValue smallint,  
 @UseCalculatedValue smallint,  
 @RoleID int = null,  
 @cUserid int,  
 @Log smallint = 1,
 @ItemID int = NULL
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [at].[QA_Calc]  
 (  
  [QuestionID],  
  [AlternativeID],  
  [CFID],  
  [MinValue],  
  [MaxValue],  
  [No],  
  [NewValue],  
  [UseNewValue],  
  [UseCalculatedValue],  
  [RoleID],
  [ItemID]  
 )  
 VALUES  
 (  
  @QuestionID,  
  @AlternativeID,  
  @CFID,  
  @MinValue,  
  @MaxValue,  
  @No,  
  @NewValue,  
  @UseNewValue,  
  @UseCalculatedValue,  
  @RoleID,
  @ItemID  
 )  
  
 Set @Err = @@Error  
 Set @QAID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'QA_Calc',0,  
  ( SELECT * FROM [at].[QA_Calc]   
   WHERE  
   [QAID] = @QAID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END  
  
  
  
