CREATE PROCEDURE [at].[prc_LT_BulkGroup_get]
(
	@BulkGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[BulkGroupID],
	ISNULL([Name], '') AS 'Name',
	ISNULL([Description], '') AS 'Description',
	ISNULL([ToolTip], '') AS 'ToolTip'
	FROM [at].[LT_BulkGroup]
	WHERE
	[BulkGroupID] = @BulkGroupID

	Set @Err = @@Error

	RETURN @Err
END


