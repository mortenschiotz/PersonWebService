
CREATE PROCEDURE [at].[prc_Scale_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ScaleID],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	[MinSelect],
	[MaxSelect],
	[Type],
	[MinValue],
	[MaxValue],
	[Created],
	[Tag],
	[ExtID]
	FROM [at].[Scale]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END

