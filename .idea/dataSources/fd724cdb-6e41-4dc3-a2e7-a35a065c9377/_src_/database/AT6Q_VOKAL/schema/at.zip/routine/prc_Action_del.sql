

CREATE PROCEDURE [at].[prc_Action_del]
(
	@ActionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Action',2,
		( SELECT * FROM [at].[Action] 
			WHERE
			[ActionID] = @ActionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Action]
	WHERE
		[ActionID] = @ActionID

	Set @Err = @@Error

	RETURN @Err
END

