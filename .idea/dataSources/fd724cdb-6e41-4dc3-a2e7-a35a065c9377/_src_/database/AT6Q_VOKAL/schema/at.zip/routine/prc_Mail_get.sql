
CREATE PROCEDURE [at].[prc_Mail_get]
(
	@SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[MailID],
	[SurveyID],
	ISNULL([BatchID], 0) AS 'BatchID',
	[Type],
	[From],
	[Bcc],
	[StatusMail],
	[Created]
	FROM [at].[Mail]
	WHERE
	[SurveyID] = @SurveyID

	Set @Err = @@Error

	RETURN @Err
END

