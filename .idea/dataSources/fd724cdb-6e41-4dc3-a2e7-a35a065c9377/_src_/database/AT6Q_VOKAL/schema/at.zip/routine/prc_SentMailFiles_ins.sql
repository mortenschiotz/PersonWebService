
CREATE PROCEDURE [at].[prc_SentMailFiles_ins]
(
	@SentMailFileID int = null output,
	@MIMEType nvarchar(64),
	@Data varbinary,
	@Description ntext,
	@Size bigint,
	@Filename nvarchar(128)='',
	@SentMailID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[SentMailFiles]
	(
		[MIMEType],
		[Data],
		[Description],
		[Size],
		[Filename],
		[SentMailID]
	)
	VALUES
	(
		@MIMEType,
		@Data,
		@Description,
		@Size,
		@Filename,
		@SentMailID
	)

	Set @Err = @@Error
	Set @SentMailFileID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SentMailFiles',0,
		( SELECT * FROM [at].[SentMailFiles] 
			WHERE
			[SentMailFileID] = @SentMailFileID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

