

CREATE PROCEDURE [at].[prc_StatusType_ins]
(
	@StatusTypeID int = null output,
	@OwnerID INT=NULL,
	@Type int,
	@No smallint,
	@Value float = 0,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[StatusType]
	(
		[OwnerID],
		[Type],
		[No],
		[Value]
	)
	VALUES
	(
		@OwnerID,
		@Type,
		@No,
		@Value
	)

	Set @Err = @@Error
	Set @StatusTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'StatusType',0,
		( SELECT * FROM [at].[StatusType] 
			WHERE
			[StatusTypeID] = @StatusTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


