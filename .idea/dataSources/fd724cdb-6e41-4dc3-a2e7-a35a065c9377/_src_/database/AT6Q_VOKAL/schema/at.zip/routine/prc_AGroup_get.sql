CREATE PROCEDURE [at].[prc_AGroup_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AGID],
	[ActivityID],
	ISNULL([ScaleID], 0) AS 'ScaleID',
	[Type],
	[Tag],
	[ExtId],
	[No],
	[CssClass]
	FROM [at].[AGroup]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
