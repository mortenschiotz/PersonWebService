CREATE PROCEDURE [at].[prc_Bulk_del]
(
	@BulkID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bulk',2,
		( SELECT * FROM [at].[Bulk] 
			WHERE
			[BulkID] = @BulkID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Bulk]
	WHERE
		[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


