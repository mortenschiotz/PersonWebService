CREATE PROCEDURE [at].[prc_XC_A_get]
(
	@XCID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[XCID],
	[ActivityID],
	[No],
	[Listview],
	[Descview],
	[Chartview],
	[FillColor],
	[BorderColor]
	FROM [at].[XC_A]
	WHERE
	[XCID] = @XCID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

