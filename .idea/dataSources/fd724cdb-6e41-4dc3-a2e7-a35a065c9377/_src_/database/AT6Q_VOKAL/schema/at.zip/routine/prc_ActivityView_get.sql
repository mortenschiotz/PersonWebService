
CREATE PROCEDURE [at].[prc_ActivityView_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityViewID],
	ISNULL([DepartmentID], 0) AS 'DepartmentID',
	ISNULL([CustomerID], 0) AS 'CustomerID',
	[ActivityID],
	[Created]
	FROM [at].[ActivityView]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END

