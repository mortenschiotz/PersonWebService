CREATE PROCEDURE [at].[prc_LT_Survey_get]
(
	@SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[SurveyID],
	[Name],
	[Description],
	[Info],
	[FinishText],
	[DisplayName]
	FROM [at].[LT_Survey]
	WHERE
	[SurveyID] = @SurveyID

	Set @Err = @@Error

	RETURN @Err
END
