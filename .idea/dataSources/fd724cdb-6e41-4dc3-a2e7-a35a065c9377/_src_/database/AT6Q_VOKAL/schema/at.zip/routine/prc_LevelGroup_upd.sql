
CREATE PROCEDURE [at].[prc_LevelGroup_upd]
(
	@LevelGroupID int,
	@ActivityID int,
	@Tag nvarchar(128),
	@No smallint,
	@CustomerID int = null,
	@DepartmentID int = null,
	@RoleID int = null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LevelGroup]
	SET
		[ActivityID] = @ActivityID,
		[Tag] = @Tag,
		[No] = @No,
		[CustomerID] = @CustomerID,
		[DepartmentID] = @DepartmentID,
		[RoleID] = @RoleID
	WHERE
		[LevelGroupID] = @LevelGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LevelGroup',1,
		( SELECT * FROM [at].[LevelGroup] 
			WHERE
			[LevelGroupID] = @LevelGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END




