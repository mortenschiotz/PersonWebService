CREATE PROCEDURE [at].[prc_LT_XC_VT_get]
(
	@XCVTID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[XCVTID],
	[Name],
	[Description],
	[TextAbove],
	[TextBelow]
	FROM [at].[LT_XC_VT]
	WHERE
	[XCVTID] = @XCVTID

	Set @Err = @@Error

	RETURN @Err
END