
CREATE PROCEDURE [at].[prc_LT_ScoreTemplateGroup_ins]
(
	@STGroupID int,
	@LanguageID int,
	@Name nvarchar(256),
	@Description ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_ScoreTemplateGroup]
	(
		[ScoreTemplateGroupID],
		[LanguageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@STGroupID,
		@LanguageID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ScoreTemplateGroup',0,
		( SELECT * FROM [at].[LT_ScoreTemplateGroup] 
			WHERE
			[ScoreTemplateGroupID] = @STGroupID AND
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

