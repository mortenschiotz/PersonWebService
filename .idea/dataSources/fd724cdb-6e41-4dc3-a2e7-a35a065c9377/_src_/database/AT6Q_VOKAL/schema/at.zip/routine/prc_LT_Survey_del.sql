

CREATE PROCEDURE [at].[prc_LT_Survey_del]
(
	@LanguageID int,
	@SurveyID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Survey',2,
		( SELECT * FROM [at].[LT_Survey] 
			WHERE
			[LanguageID] = @LanguageID AND
			[SurveyID] = @SurveyID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Survey]
	WHERE
		[LanguageID] = @LanguageID AND
		[SurveyID] = @SurveyID

	Set @Err = @@Error

	RETURN @Err
END

