CREATE PROCEDURE [at].[prc_Activity_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityID],
	[LanguageID],
	[OwnerID],
	[StyleSheet],
	[Type],
	[No],
	[TooltipType],
	[Listview],
	[Descview],
	[Chartview],
	[OLAPServer],
	[OLAPDB],
	[Created],
	[SelectionHeaderType],
	[ExtID],
	[UseOLAP],
	[ArchetypeID]
	FROM [at].[Activity]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
