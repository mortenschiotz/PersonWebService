CREATE PROCEDURE [at].[prc_Bulk_upd]
(
	@BulkID int,
	@BulkGroupID int,
	@No smallint,
	@Css varchar(50),
	@Icon varchar(50),
	@Tag varchar(50),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Bulk]
	SET		
		[BulkGroupID] = @BulkGroupID,
		[No] = @No,
		[Css] = @Css,
		[Icon] = @Icon,
		[Tag] = @Tag
	WHERE
		[BulkID] = @BulkID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bulk',1,
		( SELECT * FROM [at].[Bulk] 
			WHERE
			[BulkID] = @BulkID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


