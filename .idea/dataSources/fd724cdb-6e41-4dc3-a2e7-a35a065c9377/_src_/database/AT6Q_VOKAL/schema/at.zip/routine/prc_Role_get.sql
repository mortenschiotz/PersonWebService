CREATE PROCEDURE [at].[prc_Role_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[RoleID],
	[Ownerid],
	[Created],
	[No],
	[Type]
	FROM [at].[Role]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END