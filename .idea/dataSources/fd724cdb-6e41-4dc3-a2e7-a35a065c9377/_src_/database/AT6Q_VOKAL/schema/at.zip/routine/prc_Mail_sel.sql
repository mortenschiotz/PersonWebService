

CREATE PROCEDURE [at].[prc_Mail_sel]
(
	@MailID int
)
AS
BEGIN
	SET NOCOUNT ON

	SELECT
	[SurveyID],
	[Type],
	[From],
	[Bcc],
	[StatusMail],
	[Created]
	FROM [at].[Mail]
	WHERE
	[MailID] = @MailID

END

