CREATE PROCEDURE [at].[prc_Page_upd]  
(  
 @PageID int,  
 @ActivityID int,  
 @No smallint,  
 @Type smallint,  
 @CssClass nvarchar(64) = '',  
 @ExtID nvarchar(64), 
 @Tag nvarchar(128) = '',  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 UPDATE [at].[Page]  
 SET  
  [ActivityID] = @ActivityID,  
  [No] = @No,  
  [Type] = @Type,  
  [CssClass] = @CssClass,
  [ExtID]  = @ExtID,
  [Tag] = @Tag
 WHERE  
  [PageID] = @PageID  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Page',1,  
  ( SELECT * FROM [at].[Page]   
   WHERE  
   [PageID] = @PageID    FOR XML AUTO) as data,  
   getdate()  
 END  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END 
