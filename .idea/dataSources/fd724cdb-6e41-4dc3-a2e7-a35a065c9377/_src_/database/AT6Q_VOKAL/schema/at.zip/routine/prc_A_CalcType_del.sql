
CREATE PROCEDURE [at].[prc_A_CalcType_del]
(
	@ACALCTYPEID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_CalcType',2,
		( SELECT * FROM [at].[A_CalcType] 
			WHERE
			[ACALCTYPEID] = @ACALCTYPEID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[A_CalcType]
	WHERE
		[ACALCTYPEID] = @ACALCTYPEID

	Set @Err = @@Error

	RETURN @Err
END

