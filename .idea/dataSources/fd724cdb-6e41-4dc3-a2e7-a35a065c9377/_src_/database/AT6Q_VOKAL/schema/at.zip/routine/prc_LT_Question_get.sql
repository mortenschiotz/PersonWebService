CREATE PROCEDURE [at].[prc_LT_Question_get]
(
	@QuestionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[QuestionID],
	[Name],
	[Title],
	[ReportText],
	[Description],
	[ShortName]
	FROM [at].[LT_Question]
	WHERE
	[QuestionID] = @QuestionID

	Set @Err = @@Error

	RETURN @Err
END

