
CREATE PROCEDURE [at].[prc_LT_Action_ins]
(
	@LanguageID int,
	@ActionID int,
	@Response nvarchar(max)=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_Action]
	(
		[LanguageID],
		[ActionID],
		[Response]
	)
	VALUES
	(
		@LanguageID,
		@ActionID,
		@Response
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Action',0,
		( SELECT * FROM [at].[LT_Action] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ActionID] = @ActionID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

