CREATE PROCEDURE [at].[prc_LT_Activity_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ActivityID],
	[Name],
	[Info],
	[StartText],
	[Description],
	[RoleName],
	[SurveyName],
	[BatchName],
	[DisplayName],
	[ShortName]
	FROM [at].[LT_Activity]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END
