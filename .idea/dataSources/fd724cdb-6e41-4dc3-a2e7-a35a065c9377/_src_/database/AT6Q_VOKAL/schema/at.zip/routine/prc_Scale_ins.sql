
CREATE PROCEDURE [at].[prc_Scale_ins]
(
	@ScaleID int = null output,
	@ActivityID INT=NULL,
	@MinSelect smallint,
	@MaxSelect smallint,
	@Type smallint,
	@MinValue float,
	@MaxValue float,
	@Tag nvarchar(128),
	@ExtID nvarchar(64),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Scale]
	(
		[ActivityID],
		[MinSelect],
		[MaxSelect],
		[Type],
		[MinValue],
		[MaxValue],
		[Tag],
		[ExtID]
	)
	VALUES
	(
		@ActivityID,
		@MinSelect,
		@MaxSelect,
		@Type,
		@MinValue,
		@MaxValue,
		@Tag,
		@ExtID
	)

	Set @Err = @@Error
	Set @ScaleID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Scale',0,
		( SELECT * FROM [at].[Scale] 
			WHERE
			[ScaleID] = @ScaleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

