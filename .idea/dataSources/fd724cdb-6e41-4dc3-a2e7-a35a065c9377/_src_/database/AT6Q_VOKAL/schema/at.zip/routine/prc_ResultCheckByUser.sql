CREATE PROCEDURE [at].[prc_ResultCheckByUser] 
(
    @ListUserID     nvarchar(max),
    @OwnerID        int,
    @StatusTypeID	int
)
AS
BEGIN
    --DECLARE @ActiveEntityStatusID VARCHAR(2) = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
	DECLARE @ActiveEntityStatusID INT = 0, @sqlCommand nvarchar(max)
    DECLARE @ReportServer   nvarchar(84),
            @ReportDB       nvarchar(84),
            @cmd            nvarchar(512)   

	SELECT TOP 1 @ReportServer = ReportServer, @ReportDB = ReportDB FROM at.Activity
	SET @sqlCommand = N'SELECT @p_ActiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Active'''
	EXECUTE sp_executesql @sqlCommand, N'@p_ActiveEntityStatusID INT OUTPUT', @p_ActiveEntityStatusID = @ActiveEntityStatusID OUTPUT

    IF object_id('tempdb..#Result_temp') IS NOT NULL
    DROP TABLE #Result_temp    
    CREATE TABLE #Result_temp (UserID int,res int Default (0))
    INSERT INTO #Result_temp (UserID) SELECT value FROM dbo.funcListToTableInt(@ListUserID,',')

    DECLARE cur CURSOR READ_ONLY FOR 
    SELECT DISTINCT ReportServer, ReportDB FROM at.Survey WHERE ActivityID IN (SELECT ActivityID from at.Activity WHERE OwnerID = @OwnerID)
    OPEN cur
    FETCH NEXT FROM cur INTO @ReportServer, @ReportDB
        WHILE @@FETCH_STATUS=0
        BEGIN
            SET @cmd ='UPDATE #Result_temp  SET res =1 FROM #Result_temp r WHERE EXISTS (SELECT 1 FROM  [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Result where StatusTypeID='+CONVERT(varchar(max), @StatusTypeID)+' AND UserID =r.UserID AND r.UserID >0 AND [EntityStatusID] = '+CONVERT(NVARCHAR(14), @ActiveEntityStatusID)+' AND Deleted IS NULL)'
            EXECUTE sp_executesql @cmd
        FETCH NEXT FROM cur INTO @ReportServer, @ReportDB
        END
    CLOSE cur
    DEALLOCATE cur
    SELECT UserID,res FROM #Result_temp
    DROP TABLE #Result_temp
END
