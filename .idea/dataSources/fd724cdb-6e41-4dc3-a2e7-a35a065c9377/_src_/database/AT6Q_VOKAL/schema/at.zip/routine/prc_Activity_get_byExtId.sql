
CREATE PROCEDURE [at].[prc_Activity_get_byExtId]  
(  
 @OwnerID int,  
 @ExtId nvarchar(64)  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [ActivityID],  
 [LanguageID],  
 [OwnerID],  
 [StyleSheet],  
 [Type],  
 [No],  
 [TooltipType],  
 [Listview],  
 [Descview],  
 [Chartview],  
 [OLAPServer],  
 [OLAPDB],  
 [Created],  
 [SelectionHeaderType],  
 [ExtID]  
 FROM [at].[Activity]  
 WHERE  
 [OwnerID] = @OwnerID  
 and [ExtID]= @ExtId  
 ORDER BY [No]  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  