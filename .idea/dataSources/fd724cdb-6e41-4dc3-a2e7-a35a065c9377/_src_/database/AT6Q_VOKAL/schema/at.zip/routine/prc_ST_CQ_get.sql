
CREATE PROCEDURE [at].[prc_ST_CQ_get]
(
      @ScoreTemplateID int
)
AS
BEGIN
      SET NOCOUNT ON
      DECLARE @Err Int

      SELECT
      [ST_CQ_ID],
      [ScoreTemplateID],
      ISNULL([CategoryID], 0) AS 'CategoryID',
      ISNULL([QuestionID], 0) AS 'QuestionID',
      ISNULL([AlternativeID], 0) AS 'AlternativeID',
      [MinValue],
      [MaxValue],
      [ItemID]
      FROM [at].[ST_CQ]
      WHERE
      [ScoreTemplateID] = @ScoreTemplateID

      Set @Err = @@Error

      RETURN @Err
END


