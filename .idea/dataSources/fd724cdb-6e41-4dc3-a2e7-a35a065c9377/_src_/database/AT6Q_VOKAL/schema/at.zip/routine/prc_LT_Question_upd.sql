

CREATE PROCEDURE [at].[prc_LT_Question_upd]
(
	@LanguageID int,
	@QuestionID int,
	@Name ntext,
	@Title ntext,
	@ReportText nvarchar(512),
	@Description nvarchar(max),
	@ShortName nvarchar(64) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_Question]
	SET
		[LanguageID] = @LanguageID,
		[QuestionID] = @QuestionID,
		[Name] = @Name,
		[Title] = @Title,
		[ReportText] = @ReportText,
		[Description] = @Description,
		[ShortName] = @ShortName
	WHERE
		[LanguageID] = @LanguageID AND
		[QuestionID] = @QuestionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Question',1,
		( SELECT * FROM [at].[LT_Question] 
			WHERE
			[LanguageID] = @LanguageID AND
			[QuestionID] = @QuestionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


