
CREATE PROCEDURE [at].[prc_Batch_upd]
(
	@BatchID int,
	@SurveyID int,
	@UserID INT=NULL,
	@DepartmentID INT=NULL,
	@Name nvarchar(256),
	@No smallint,
	@StartDate DATETIME=NULL,
	@EndDate DATETIME=NULL,
	@Status smallint,
	@MailStatus smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Batch]
	SET
		[SurveyID] = @SurveyID,
		[UserID] = @UserID,
		[DepartmentID] = @DepartmentID,
		[Name] = @Name,
		[No] = @No,
		[StartDate] = @StartDate,
		[EndDate] = @EndDate,
		[Status] = @Status,
		[MailStatus] = @MailStatus
	WHERE
		[BatchID] = @BatchID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Batch',1,
		( SELECT * FROM [at].[Batch] 
			WHERE
			[BatchID] = @BatchID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

