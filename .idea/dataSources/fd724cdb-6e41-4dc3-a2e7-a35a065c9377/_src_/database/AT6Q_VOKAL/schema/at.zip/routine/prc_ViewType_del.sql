

CREATE PROCEDURE [at].[prc_ViewType_del]
(
	@ViewTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ViewType',2,
		( SELECT * FROM [at].[ViewType] 
			WHERE
			[ViewTypeID] = @ViewTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[ViewType]
	WHERE
		[ViewTypeID] = @ViewTypeID

	Set @Err = @@Error

	RETURN @Err
END

