CREATE PROCEDURE [at].[prc_B_Q_ins]
(
	@BulkID int,
	@QuestionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[B_Q]
	(
		[BulkID],
		[QuestionID]
	)
	VALUES
	(
		@BulkID,
		@QuestionID
	)

	Set @Err = @@Error

	RETURN @Err
END


