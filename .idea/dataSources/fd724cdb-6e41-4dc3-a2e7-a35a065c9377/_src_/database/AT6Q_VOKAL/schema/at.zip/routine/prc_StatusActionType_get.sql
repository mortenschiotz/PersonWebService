
CREATE PROCEDURE [at].[prc_StatusActionType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[StatusActionTypeID],
	[Name],
	[No],
	[Created]
	FROM [at].[StatusActionType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

