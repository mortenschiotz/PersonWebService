

CREATE PROCEDURE [at].[prc_LT_XCategory_del]
(
	@LanguageID int,
	@XCID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_XCategory',2,
		( SELECT * FROM [at].[LT_XCategory] 
			WHERE
			[LanguageID] = @LanguageID AND
			[XCID] = @XCID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_XCategory]
	WHERE
		[LanguageID] = @LanguageID AND
		[XCID] = @XCID

	Set @Err = @@Error

	RETURN @Err
END

