CREATE PROCEDURE [at].[prc_LT_A_S_get] (@ASID INT)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	SELECT [ASID],
		[LanguageID],
		[StatusName],
		[StatusDescription],
		[ReadOnlyText]
	FROM [at].[LT_A_S]
	WHERE [ASID] = @ASID

	SET @Err = @@Error

	RETURN @Err
END
