CREATE PROCEDURE [at].[prc_LT_XCategory_get]
(
	@XCID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[XCID],
	[Name],
	[Description]
	FROM [at].[LT_XCategory]
	WHERE
	[XCID] = @XCID

	Set @Err = @@Error

	RETURN @Err
END
