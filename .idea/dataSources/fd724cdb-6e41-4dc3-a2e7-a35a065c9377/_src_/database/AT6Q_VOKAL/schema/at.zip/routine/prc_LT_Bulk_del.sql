CREATE PROCEDURE [at].[prc_LT_Bulk_del]
(
	@LanguageID int,
	@BulkID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Bulk',2,
		( SELECT * FROM [at].[LT_Bulk] 
			WHERE
			[LanguageID] = @LanguageID AND
			[BulkID] = @BulkID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Bulk]
	WHERE
		[LanguageID] = @LanguageID AND
		[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


