
CREATE PROCEDURE [at].[prc_MailTemplate_upd]
(
	@MailTemplateID int,
	@OwnerID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[MailTemplate]
	SET
		[OwnerID] = @OwnerID
	WHERE
		[MailTemplateID] = @MailTemplateID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'MailTemplate',1,
		( SELECT * FROM [at].[MailTemplate] 
			WHERE
			[MailTemplateID] = @MailTemplateID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

