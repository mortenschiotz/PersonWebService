
CREATE PROCEDURE [at].[prc_XCategoryType_ins] (
	@XCategoryTypeID INT = NULL OUTPUT
	,@OwnerID INT
	,@ExtID NVARCHAR(64)
	,@No SMALLINT
	,@cUserid INT
	,@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	INSERT INTO [at].[XCategoryType] (
		[OwnerID]
		,[ExtID]
		,[No]
		)
	VALUES (
		@OwnerID
		,@ExtID
		,@No
		)

	SET @Err = @@Error
	SET @XCategoryTypeID = SCOPE_IDENTITY()

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'XCategoryType'
			,0
			,(
				SELECT *
				FROM [at].[XCategoryType]
				WHERE [XCTypeID] = @XCategoryTypeID
				FOR XML AUTO
				) AS data
			,GETDATE()
	END

	RETURN @Err
END
