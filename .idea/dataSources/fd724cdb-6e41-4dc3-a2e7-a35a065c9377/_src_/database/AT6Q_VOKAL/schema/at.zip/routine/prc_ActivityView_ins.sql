
CREATE PROCEDURE [at].[prc_ActivityView_ins]
(
	@ActivityViewID int = null output,
	@DepartmentID INT=NULL,
	@CustomerID INT=NULL,
	@ActivityID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[ActivityView]
	(
		[DepartmentID],
		[CustomerID],
		[ActivityID]
	)
	VALUES
	(
		@DepartmentID,
		@CustomerID,
		@ActivityID
	)

	Set @Err = @@Error
	Set @ActivityViewID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ActivityView',0,
		( SELECT * FROM [at].[ActivityView] 
			WHERE
			[ActivityViewID] = @ActivityViewID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

