
CREATE PROCEDURE [at].[prc_ScoreTemplate_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ScoreTemplateID],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	ISNULL([XCID], 0) AS 'XCID',
	[Type],
	[No],
	[OwnerColorID],
	[DefaultState],
	[Created]
	FROM [at].[ScoreTemplate]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

