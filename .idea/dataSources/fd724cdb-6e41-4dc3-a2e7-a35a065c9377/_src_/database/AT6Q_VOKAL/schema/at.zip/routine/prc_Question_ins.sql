
CREATE PROCEDURE [at].[prc_Question_ins]
(
	@QuestionID int = null output,
	@PageID int,
	@ScaleID int=null,
	@No smallint,
	@Type smallint,
	@Inverted bit,
	@Mandatory bit,
	@Status smallint,
	@CssClass nvarchar(64),
	@ExtId nvarchar(64),
	@Tag nvarchar(128),
	@SectionID int = null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Question]
	(
		[PageID],
		[ScaleID],
		[No],
		[Type],
		[Inverted],
		[Mandatory],
		[Status],
		[CssClass],
		[ExtId],
		[Tag],
		[SectionID]
	)
	VALUES
	(
		@PageID,
		@ScaleID,
		@No,
		@Type,
		@Inverted,
		@Mandatory,
		@Status,
		@CssClass,
		@ExtId,
		@Tag,
		@SectionID
	)

	Set @Err = @@Error
	Set @QuestionID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Question',0,
		( SELECT * FROM [at].[Question] 
			WHERE
			[QuestionID] = @QuestionID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


