CREATE PROCEDURE [at].[prc_XC_P_get]
(
	@XCID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	SELECT
	[XCID],
	[PageID]
	FROM [at].[XC_P]
	WHERE
	[XCID] = @XCID
	Set @Err = @@Error
	RETURN @Err
END
