CREATE PROCEDURE [at].[prc_OwnerColor_del]
(
	@OwnerColorID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'OwnerColor',2,
		( SELECT * FROM [at].[OwnerColor] 
			WHERE
			[OwnerColorID] = @OwnerColorID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[OwnerColor]
	WHERE
		[OwnerColorID] = @OwnerColorID

	Set @Err = @@Error

	RETURN @Err
END

