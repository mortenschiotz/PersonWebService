CREATE PROCEDURE [at].[prc_AGroup_upd]
(
	@AGID int,
	@ActivityID int,
	@ScaleID int,
	@Type smallint,
	@Tag nvarchar(256),
	@ExtId nvarchar(256),
	@No smallint,
	@cUserid int,
	@Log smallint = 1,
	@CssClass nvarchar(64)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[AGroup]
	SET
		[ActivityID] = @ActivityID,
		[ScaleID] = @ScaleID,
		[Type] = @Type,
		[Tag] = @Tag,
		[ExtId] = @ExtId,
		[No] = @No,
		[CssClass]=@CssClass
	WHERE
		[AGID] = @AGID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AGroup',1,
		( SELECT * FROM [at].[AGroup] 
			WHERE
			[AGID] = @AGID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
