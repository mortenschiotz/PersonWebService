CREATE PROCEDURE [at].[prc_AG_A_del]
(
	@AGID int,
	@AlternativeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AG_A',2,
		( SELECT * FROM [at].[AG_A] 
			WHERE
			[AGID] = @AGID AND
			[AlternativeID] = @AlternativeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[AG_A]
	WHERE
		[AGID] = @AGID AND
		[AlternativeID] = @AlternativeID

	Set @Err = @@Error

	RETURN @Err
END
