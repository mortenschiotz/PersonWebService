---

CREATE PROCEDURE [at].[prc_Category_get]    
(    
 @ActivityID int,    
 @ParentID int = 0    
)    
AS    
BEGIN    
 SET NOCOUNT ON    
 DECLARE @Err Int    
    
 IF @ParentID is null    
    Begin    
      Set @ParentID = 0    
 End    
    
 SELECT    
 [CategoryID],    
 [ActivityID],    
 ISNULL([ParentID], 0) AS 'ParentID',    
 [Tag],    
 [Type],    
 [No],    
 [Fillcolor],    
 [BorderColor],    
 [Weight],    
 [NType],    
 [ProcessCategory],    
 [ExtID],  
 [Created],
 [AnswerItemID],
 [RenderAsDefault],
 [AvgType]   
 FROM [at].[Category]    
 WHERE    
 [ActivityID] = @ActivityID AND ISNULL([ParentID],0) = @ParentID    
 ORDER BY [No]    
    
 Set @Err = @@Error    
    
 RETURN @Err    
END    
