CREATE PROCEDURE [at].[prc_AG_A_upd]
(
	@AGID int,
	@AlternativeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[AG_A]
	SET
		[AGID] = @AGID,
		[AlternativeID] = @AlternativeID
	WHERE
		[AGID] = @AGID AND
		[AlternativeID] = @AlternativeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AG_A',1,
		( SELECT * FROM [at].[AG_A] 
			WHERE
			[AGID] = @AGID AND
			[AlternativeID] = @AlternativeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
