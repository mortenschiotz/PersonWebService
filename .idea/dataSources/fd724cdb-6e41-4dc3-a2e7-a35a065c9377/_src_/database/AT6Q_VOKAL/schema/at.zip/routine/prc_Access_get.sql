CREATE PROCEDURE [at].[prc_Access_get]  
(  
 @SurveyID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [AccessID],  
 [SurveyID],  
 ISNULL([BatchID], 0) AS 'BatchID',  
 ISNULL([RoleID], 0) AS 'RoleID',  
 ISNULL([DepartmentID], 0) AS 'DepartmentID',  
 ISNULL([DepartmentTypeID], 0) AS 'DepartmentTypeID',  
 ISNULL([HDID], 0) AS 'HDID',  
 ISNULL([PageID], 0) AS 'PageID',  
 ISNULL([QuestionID], 0) AS 'QuestionID',  
 ISNULL([CustomerID],0) AS 'CustomerID',  
 [Type],  
 [Mandatory],  
 [Created]  
 FROM [at].[Access]  
 WHERE  
 [SurveyID] = @SurveyID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END
