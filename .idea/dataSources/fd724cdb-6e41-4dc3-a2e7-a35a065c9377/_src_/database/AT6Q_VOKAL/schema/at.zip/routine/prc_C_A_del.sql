

CREATE PROCEDURE [at].[prc_C_A_del]
(
	@CustomerID int,
	@ActivityID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'C_A',2,
		( SELECT * FROM [at].[C_A] 
			WHERE
			[CustomerID] = @CustomerID AND
			[ActivityID] = @ActivityID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[C_A]
	WHERE
		[CustomerID] = @CustomerID AND
		[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END

