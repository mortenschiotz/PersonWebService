
CREATE PROCEDURE [at].[prc_LT_XCategoryType_get] (@XCategoryTypeID INT)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	SELECT [LanguageID]
		,[XCTypeID]
		,[Name]
		,[Description]
	FROM [at].[LT_XCategoryType]
	WHERE [XCTypeID] = @XCategoryTypeID

	SET @Err = @@Error

	RETURN @Err
END
