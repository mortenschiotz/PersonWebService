CREATE PROCEDURE [at].[prc_A_VT_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AVTID],
	[ViewTypeID],
	[ActivityID],
	[No],
	[Type],
	[Template],
	[ShowPercentage],
	ISNULL([ActivityViewID],0) AS 'ActivityViewID',
	ISNULL([LevelGroupID],0) AS 'LevelGroupID',
	[CssClass]
	FROM [at].[A_VT]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
