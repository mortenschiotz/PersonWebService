CREATE PROCEDURE [at].[prc_LT_Section_del]
(
	@LanguageID int,
	@SectionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Section',2,
		( SELECT * FROM [at].[LT_Section] 
			WHERE
			[LanguageID] = @LanguageID AND
			[SectionID] = @SectionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Section]
	WHERE
		[LanguageID] = @LanguageID AND
		[SectionID] = @SectionID

	Set @Err = @@Error

	RETURN @Err
END

