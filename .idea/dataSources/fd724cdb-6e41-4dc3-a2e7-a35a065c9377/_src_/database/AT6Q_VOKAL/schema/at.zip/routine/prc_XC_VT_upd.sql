
CREATE PROCEDURE [at].[prc_XC_VT_upd]
(
	@XCVTID int,
	@ViewTypeID int,
	@XCID int,
	@No smallint,
	@Type smallint,
	@Template varchar(64),
	@ShowPercentage BIT,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[XC_VT]
	SET
		[ViewTypeID] = @ViewTypeID,
		[XCID] = @XCID,
		[No] = @No,
		[Type] = @Type,
		[Template] = @Template,
		[ShowPercentage] = @ShowPercentage
	WHERE
		[XCVTID] = @XCVTID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XC_VT',1,
		( SELECT * FROM [at].[XC_VT] 
			WHERE
			[XCVTID] = @XCVTID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

