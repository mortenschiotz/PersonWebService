
CREATE PROCEDURE [at].[prc_LT_StatusType_ins]
(
	@LanguageID int,
	@StatusTypeID int,
	@Name varchar(50),
	@Description varchar(250),
	@DefaultActionName Nvarchar(512) ='',
	@DefaultActionDescription NVARCHAR(MAX) ='',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_StatusType]
	(
		[LanguageID],
		[StatusTypeID],
		[Name],
		[Description],
		[DefaultActionName],
		[DefaultActionDescription]
	)
	VALUES
	(
		@LanguageID,
		@StatusTypeID,
		@Name,
		@Description,
		@DefaultActionName,
		@DefaultActionDescription
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_StatusType',0,
		( SELECT * FROM [at].[LT_StatusType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[StatusTypeID] = @StatusTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
