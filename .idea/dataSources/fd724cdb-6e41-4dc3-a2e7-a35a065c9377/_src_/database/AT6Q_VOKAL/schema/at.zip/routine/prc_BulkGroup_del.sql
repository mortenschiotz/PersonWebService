CREATE PROCEDURE [at].[prc_BulkGroup_del]
(
	@BulkGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'BulkGroup',2,
		( SELECT * FROM [at].[BulkGroup] 
			WHERE
			[BulkGroupID] = @BulkGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[BulkGroup]
	WHERE
		[BulkGroupID] = @BulkGroupID

	Set @Err = @@Error

	RETURN @Err
END


