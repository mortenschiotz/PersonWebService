
CREATE PROCEDURE [at].[prc_OwnerColor_get]
(
	@OwnerID int = null,
	@ThemeID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[OwnerColorID],
	ISNULL([ThemeID],0) as 'ThemeID',
	ISNULL([OwnerID],0) as 'OwnerID',
	ISNULL([CustomerID], 0) AS 'CustomerID',
	[FriendlyName],
	[FillColor],
	[TextColor],
	[BorderColor],
	[No],
	[Created]
	FROM [at].[OwnerColor]
	WHERE
	( [OwnerID] = @OwnerID or @Ownerid is null)
	and ([ThemeID] = @ThemeID or @ThemeID is null)
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
