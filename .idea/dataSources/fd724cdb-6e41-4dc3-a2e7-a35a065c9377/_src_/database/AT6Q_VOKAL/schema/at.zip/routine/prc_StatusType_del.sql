CREATE PROCEDURE [at].[prc_StatusType_del]
(
	@StatusTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'StatusType',2,
		( SELECT * FROM [at].[StatusType] 
			WHERE
			[StatusTypeID] = @StatusTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[StatusType]
	WHERE
		[StatusTypeID] = @StatusTypeID

	Set @Err = @@Error

	RETURN @Err
END

