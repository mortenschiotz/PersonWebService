
CREATE PROCEDURE [at].[prc_ScoreTemplateGroup_upd]
(
	@STGroupID int,
	@ActivityID int = null,
	@XCID int = null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[ScoreTemplateGroup]
	SET
		[ActivityID] = @ActivityID,
		[XCID] = @XCID
	WHERE
		[ScoreTemplateGroupID] = @STGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ScoreTemplateGroup',1,
		( SELECT * FROM [at].[ScoreTemplateGroup] 
			WHERE
			[ScoreTemplateGroupID] = @STGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

