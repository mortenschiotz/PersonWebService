
CREATE PROCEDURE [at].[prc_ActivityView_upd]
(
	@ActivityViewID int,
	@DepartmentID int,
	@CustomerID int,
	@ActivityID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[ActivityView]
	SET
		[DepartmentID] = @DepartmentID,
		[CustomerID] = @CustomerID,
		[ActivityID] = @ActivityID
	WHERE
		[ActivityViewID] = @ActivityViewID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ActivityView',1,
		( SELECT * FROM [at].[ActivityView] 
			WHERE
			[ActivityViewID] = @ActivityViewID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

