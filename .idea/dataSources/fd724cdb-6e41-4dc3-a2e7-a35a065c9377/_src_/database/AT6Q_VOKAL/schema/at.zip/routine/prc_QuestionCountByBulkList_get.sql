CREATE PROCEDURE [at].[prc_QuestionCountByBulkList_get]
	@BulkIDs varchar(Max)
AS
BEGIN	
	SELECT DISTINCT BulkID, COUNT(QuestionID) as QuestionCount FROM	
	(
		SELECT bp.BulkID, q.QuestionID from at.Question q
		INNER JOIN at.B_P bp ON q.PageID = bp.PageID
		WHERE bp.BulkID IN (select value from dbo.funcListToTableInt(@BulkIDs,','))	
		UNION ALL 
		SELECT bq.BulkID, q.QuestionID from at.Question q
		INNER JOIN at.B_Q bq ON q.QuestionID = bq.QuestionID	
		WHERE bq.BulkID IN (select value from dbo.funcListToTableInt(@BulkIDs,','))
	) as Result
	Group by BulkID

END
