CREATE PROCEDURE [at].[prc_ActivityView_QA_del]
(
	@ActivityViewQID int,
	@AlternativeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ActivityView_QA',2,
		( SELECT * FROM [at].[ActivityView_QA] 
			WHERE
			[ActivityViewQID] = @ActivityViewQID AND
			[AlternativeID] = @AlternativeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[ActivityView_QA]
	WHERE
		[ActivityViewQID] = @ActivityViewQID AND
		[AlternativeID] = @AlternativeID

	Set @Err = @@Error

	RETURN @Err
END

