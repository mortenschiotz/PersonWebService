CREATE PROCEDURE [at].[prc_Bulk_get]
(
	@BulkGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BulkID],
	ISNULL([BulkGroupID], 0) AS 'BulkGroupID',
	ISNULL([No], 0) AS 'No',
	ISNULL([Css], '') AS 'Css',
	ISNULL([Icon], '') AS 'Icon',
	ISNULL([Tag], '') AS 'Tag'
	FROM [at].[Bulk]
	WHERE
	[BulkGroupID] = @BulkGroupID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


