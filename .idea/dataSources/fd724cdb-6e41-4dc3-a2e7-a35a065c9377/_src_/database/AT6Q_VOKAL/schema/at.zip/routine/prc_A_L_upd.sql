
CREATE PROCEDURE [at].[prc_A_L_upd]
(
	@ActivityID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[A_L]
	SET
		[ActivityID] = @ActivityID,
		[LanguageID] = @LanguageID
	WHERE
		[ActivityID] = @ActivityID AND
		[LanguageID] = @LanguageID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_L',1,
		( SELECT * FROM [at].[A_L] 
			WHERE
			[ActivityID] = @ActivityID AND
			[LanguageID] = @LanguageID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

