
CREATE PROCEDURE [at].[prc_A_R_ins]
(
	@ActivityID int,
	@RoleID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[A_R]
	(
		[ActivityID],
		[RoleID],
		[No]
	)
	VALUES
	(
		@ActivityID,
		@RoleID,
		@No
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_R',0,
		( SELECT * FROM [at].[A_R] 
			WHERE
			[ActivityID] = @ActivityID AND
			[RoleID] = @RoleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

