

CREATE PROCEDURE [at].[prc_LevelLimit_del]
(
	@LevelLimitID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LevelLimit',2,
		( SELECT * FROM [at].[LevelLimit] 
			WHERE
			[LevelLimitID] = @LevelLimitID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LevelLimit]
	WHERE
		[LevelLimitID] = @LevelLimitID

	Set @Err = @@Error

	RETURN @Err
END

