
CREATE PROCEDURE [at].[prc_DR_S_ins]
(
	@DottedRuleID int,
	@ScaleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[DR_S]
	(
		[DottedRuleID],
		[ScaleID]
	)
	VALUES
	(
		@DottedRuleID,
		@ScaleID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DR_S',0,
		( SELECT * FROM [at].[DR_S] 
			WHERE
			[DottedRuleID] = @DottedRuleID AND
			[ScaleID] = @ScaleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

