CREATE PROCEDURE [at].[prc_B_R_get]
(
	@BulkID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BulkID],
	[RoleID]
	FROM [at].[B_R]
	WHERE
	[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


