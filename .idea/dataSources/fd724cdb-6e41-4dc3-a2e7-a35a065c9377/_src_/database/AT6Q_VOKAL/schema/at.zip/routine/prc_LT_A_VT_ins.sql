
CREATE PROCEDURE [at].[prc_LT_A_VT_ins]
(
	@LanguageID int,
	@AVTID int,
	@Name nvarchar(256),
	@Description ntext,
	@TextAbove ntext,
	@TextBelow ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_A_VT]
	(
		[LanguageID],
		[AVTID],
		[Name],
		[Description],
		[TextAbove],
		[TextBelow]
	)
	VALUES
	(
		@LanguageID,
		@AVTID,
		@Name,
		@Description,
		@TextAbove,
		@TextBelow
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_A_VT',0,
		( SELECT * FROM [at].[LT_A_VT] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AVTID] = @AVTID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

