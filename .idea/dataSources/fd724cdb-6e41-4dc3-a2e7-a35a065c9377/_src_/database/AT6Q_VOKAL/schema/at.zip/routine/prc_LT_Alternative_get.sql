
CREATE PROCEDURE [at].[prc_LT_Alternative_get]
(
	@AlternativeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[AlternativeID],
	[Name],
	[Label],
	[Description]
	FROM [at].[LT_Alternative]
	WHERE
	[AlternativeID] = @AlternativeID

	Set @Err = @@Error

	RETURN @Err
END

