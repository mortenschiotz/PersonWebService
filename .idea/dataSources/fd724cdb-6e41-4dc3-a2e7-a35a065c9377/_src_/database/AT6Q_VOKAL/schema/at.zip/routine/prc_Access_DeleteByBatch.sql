--DEV: Tom
--Task 22147: Implement the posibility to edit survey/batch in the list after user has ordered the survey/batch
CREATE PROCEDURE [at].[prc_Access_DeleteByBatch]
(
	@BatchID int
)
AS
BEGIN	
	DELETE FROM [at].[Access]
	WHERE [BatchID] = @BatchID	
END
