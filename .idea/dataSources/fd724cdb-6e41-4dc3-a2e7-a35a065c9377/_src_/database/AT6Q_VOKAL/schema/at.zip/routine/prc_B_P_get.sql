CREATE PROCEDURE [at].[prc_B_P_get]
(
	@BulkID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BulkID],
	[PageID]
	FROM [at].[B_P]
	WHERE
	[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


