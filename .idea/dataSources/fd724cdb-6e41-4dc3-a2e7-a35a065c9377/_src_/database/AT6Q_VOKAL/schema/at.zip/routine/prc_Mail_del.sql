

CREATE PROCEDURE [at].[prc_Mail_del]
(
	@MailID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Mail',2,
		( SELECT * FROM [at].[Mail] 
			WHERE
			[MailID] = @MailID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Mail]
	WHERE
		[MailID] = @MailID

	Set @Err = @@Error

	RETURN @Err
END

