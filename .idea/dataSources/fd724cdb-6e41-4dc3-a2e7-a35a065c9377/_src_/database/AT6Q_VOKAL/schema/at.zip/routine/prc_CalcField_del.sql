CREATE PROCEDURE  [at].[prc_CalcField_del]
(
	@CFID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'CalcField',2,
		( SELECT * FROM [at].[CalcField] 
			WHERE
			[CFID] = @CFID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[CalcField]
	WHERE
		[CFID] = @CFID

	Set @Err = @@Error

	RETURN @Err
END

