
CREATE PROCEDURE [at].[prc_UG_R_ins]
(
	@UserGroupID int,
	@ActivityID int,
	@RoleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[UG_R]
	(
		[UserGroupID],
		[ActivityID],
		[RoleID]
	)
	VALUES
	(
		@UserGroupID,
		@ActivityID,
		@RoleID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UG_R',0,
		( SELECT * FROM [at].[UG_R] 
			WHERE
			[UserGroupID] = @UserGroupID AND
			[ActivityID] = @ActivityID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

