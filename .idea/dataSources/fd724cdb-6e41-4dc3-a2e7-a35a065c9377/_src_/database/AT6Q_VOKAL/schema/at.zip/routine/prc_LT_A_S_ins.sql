CREATE PROCEDURE [at].[prc_LT_A_S_ins] (
	@LanguageID INT,
	@ASID INT,
	@StatusName NVARCHAR(512),
	@StatusDescription NVARCHAR(512),
	@ReadOnlyText NVARCHAR(MAX) = '',
	@cUserid INT,
	@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	INSERT INTO [at].[LT_A_S] (
		[ASID],
		[LanguageID],
		[StatusName],
		[StatusDescription],
		[ReadOnlyText]
		)
	VALUES (
		@ASID,
		@LanguageID,
		@StatusName,
		@StatusDescription,
		@ReadOnlyText
		)

	SET @Err = @@Error

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId,
			TableName,
			Type,
			Data,
			Created
			)
		SELECT @cUserid,
			'LT_A_S',
			0,
			(
				SELECT *
				FROM [at].[LT_A_S]
				WHERE [LanguageID] = @LanguageID
					AND [ASID] = @ASID
				FOR XML AUTO
				) AS data,
			getdate()
	END

	RETURN @Err
END
