
CREATE PROCEDURE [at].[prc_DR_C_del]
(
	@DottedRuleID int,
	@CategoryID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DR_C',2,
		( SELECT * FROM [at].[DR_C] 
			WHERE
			[DottedRuleID] = @DottedRuleID AND
			[CategoryID] = @CategoryID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[DR_C]
	WHERE
		[DottedRuleID] = @DottedRuleID AND
		[CategoryID] = @CategoryID

	Set @Err = @@Error

	RETURN @Err
END

