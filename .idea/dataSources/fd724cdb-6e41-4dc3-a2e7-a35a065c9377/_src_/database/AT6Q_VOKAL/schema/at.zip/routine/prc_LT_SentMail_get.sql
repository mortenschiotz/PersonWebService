CREATE PROCEDURE [at].[prc_LT_SentMail_get]
(
	@SentMailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[SentMailID],
	[Name],
	[Subject],
	[Body]
	FROM [at].[LT_SentMail]
	WHERE
	[SentMailID] = @SentMailID

	Set @Err = @@Error

	RETURN @Err
END