
CREATE PROCEDURE [at].[prc_Role_ins]
(
	@RoleID int = null output,
	@Ownerid int,
	@No smallint,
	@Type smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Role]
	(
		[Ownerid],
		[No],
		[Type]
	)
	VALUES
	(
		@Ownerid,
		@No,
		@Type
	)

	Set @Err = @@Error
	Set @RoleID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Role',0,
		( SELECT * FROM [at].[Role] 
			WHERE
			[RoleID] = @RoleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

