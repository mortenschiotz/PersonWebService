
CREATE PROCEDURE [at].[prc_C_A_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[CustomerID],
	[ActivityID],
	[No]
	FROM [at].[C_A]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

