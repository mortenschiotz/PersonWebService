
CREATE PROCEDURE [at].[prc_LT_Section_get]
(
	@SectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[SectionID],
	[Name],
	[Title],
	[Description]
	FROM [at].[LT_Section]
	WHERE
	[SectionID] = @SectionID

	Set @Err = @@Error

	RETURN @Err
END

