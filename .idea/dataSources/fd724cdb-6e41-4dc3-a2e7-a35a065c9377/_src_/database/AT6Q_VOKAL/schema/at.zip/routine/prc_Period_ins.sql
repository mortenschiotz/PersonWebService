

CREATE PROCEDURE [at].[prc_Period_ins]
(
	@PeriodID int = null output,
	@Ownerid int,
	@No smallint,
	@StartDate datetime = null,
	@EndDate datetime = null,
	@ExtID nvarchar(64) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Period]
	(
		[Ownerid],
		[No],
		[Startdate],
		[EndDate],
		[ExtID]
	)
	VALUES
	(
		@Ownerid,
		@No,
		@StartDate,
		@Enddate,
		@ExtID
	)

	Set @Err = @@Error
	Set @PeriodID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Period',0,
		( SELECT * FROM [at].[Period] 
			WHERE
			[PeriodID] = @PeriodID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


