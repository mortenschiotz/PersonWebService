

CREATE PROCEDURE [at].[prc_LT_LevelLimit_del]
(
	@LevelLimitID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LevelLimit',2,
		( SELECT * FROM [at].[LT_LevelLimit] 
			WHERE
			[LevelLimitID] = @LevelLimitID AND
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_LevelLimit]
	WHERE
		[LevelLimitID] = @LevelLimitID AND
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

