CREATE PROCEDURE [at].[prc_Choice_ins] (
	@ChoiceID INT = NULL OUTPUT
	,@ActivityID INT = NULL
	,@SurveyID INT = NULL
	,@RoleID INT = NULL
	,@DepartmentID INT = NULL
	,@HDID INT = NULL
	,@DepartmentTypeID INT = NULL
	,@UserGroupID INT = NULL
	,@UserTypeID INT = NULL
	,@Name NVARCHAR(64)
	,@No SMALLINT
	,@Type SMALLINT
	,@cUserid INT
	,@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	INSERT INTO [at].[Choice] (
		[ActivityID]
		,[SurveyID]
		,[RoleID]
		,[DepartmentID]
		,[HDID]
		,[DepartmentTypeID]
		,[UserGroupID]
		,[UserTypeID]
		,[Name]
		,[No]
		,[Type]
		)
	VALUES (
		@ActivityID
		,@SurveyID
		,@RoleID
		,@DepartmentID
		,@HDID
		,@DepartmentTypeID
		,@UserGroupID
		,@UserTypeID
		,@Name
		,@No
		,@Type
		)

	SET @Err = @@Error
	SET @ChoiceID = scope_identity()

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'Choice'
			,0
			,(
				SELECT *
				FROM [at].[Choice]
				WHERE [ChoiceID] = @ChoiceID
				FOR XML AUTO
				) AS data
			,getdate()
	END

	RETURN @Err
END
