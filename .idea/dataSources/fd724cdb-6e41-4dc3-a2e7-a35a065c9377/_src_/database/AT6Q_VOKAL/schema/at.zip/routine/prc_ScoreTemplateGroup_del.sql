

CREATE PROCEDURE [at].[prc_ScoreTemplateGroup_del]
(
	@STGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ScoreTemplateGroup',2,
		( SELECT * FROM [at].[ScoreTemplateGroup] 
			WHERE
			[ScoreTemplateGroupID] = @STGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[ScoreTemplateGroup]
	WHERE
		[ScoreTemplateGroupID] = @STGroupID

	Set @Err = @@Error

	RETURN @Err
END

