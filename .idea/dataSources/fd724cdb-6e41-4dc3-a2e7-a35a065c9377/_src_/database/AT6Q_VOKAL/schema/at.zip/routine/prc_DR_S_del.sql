
CREATE PROCEDURE [at].[prc_DR_S_del]
(
	@DottedRuleID int,
	@ScaleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DR_S',2,
		( SELECT * FROM [at].[DR_S] 
			WHERE
			[DottedRuleID] = @DottedRuleID AND
			[ScaleID] = @ScaleID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[DR_S]
	WHERE
		[DottedRuleID] = @DottedRuleID AND
		[ScaleID] = @ScaleID

	Set @Err = @@Error

	RETURN @Err
END

