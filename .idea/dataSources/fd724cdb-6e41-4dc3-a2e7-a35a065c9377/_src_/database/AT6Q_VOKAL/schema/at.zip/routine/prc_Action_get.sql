CREATE PROCEDURE [at].[prc_Action_get]
(
	@ChoiceID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActionID],
	[ChoiceID],
	[No],
	ISNULL([PageID], 0) AS 'PageID',
	ISNULL([QuestionID], 0) AS 'QuestionID',
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	[Type],
	[Created],
	[AVTID]
	FROM [at].[Action]
	WHERE
	[ChoiceID] = @ChoiceID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
