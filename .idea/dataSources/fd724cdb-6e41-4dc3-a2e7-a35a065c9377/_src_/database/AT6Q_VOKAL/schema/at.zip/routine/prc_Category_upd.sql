--

CREATE PROCEDURE [at].[prc_Category_upd]      
(      
 @CategoryID int,      
 @ActivityID int,      
 @ParentID INT=NULL,      
 @Tag nvarchar(128),      
 @Type smallint,      
 @No smallint,      
 @Fillcolor varchar(16),      
 @BorderColor varchar(16),      
 @Weight float,      
 @NType smallint,      
 @ProcessCategory bit,      
 @cUserid int,      
 @Log smallint = 1,  
 @ExtID nvarchar(64),
 @AnswerItemID int = null,
 @RenderAsDefault bit =1,
 @AvgType smallint = 0
)      
AS      
BEGIN      
 SET NOCOUNT ON      
 DECLARE @Err Int      
      
 UPDATE [at].[Category]      
 SET      
  [ActivityID] = @ActivityID,      
  [ParentID] = @ParentID,      
  [Tag] = @Tag,      
  [Type] = @Type,      
  [No] = @No,      
  [Fillcolor] = @Fillcolor,      
  [BorderColor] = @BorderColor,      
  [Weight] = @Weight,      
  [NType] = @NType,      
  [ProcessCategory]=@ProcessCategory,  
  [ExtID]  = @ExtID,
  [AnswerItemID]  = @AnswerItemID,
  [RenderAsDefault] = @RenderAsDefault,
  [AvgType] = @AvgType
 WHERE      
  [CategoryID] = @CategoryID      
      
 IF @Log = 1       
 BEGIN       
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)       
  SELECT @cUserid,'Category',1,      
  ( SELECT * FROM [at].[Category]       
   WHERE      
   [CategoryID] = @CategoryID    FOR XML AUTO) as data,      
   getdate()      
 END      
      
 Set @Err = @@Error      
      
 RETURN @Err      
END 
