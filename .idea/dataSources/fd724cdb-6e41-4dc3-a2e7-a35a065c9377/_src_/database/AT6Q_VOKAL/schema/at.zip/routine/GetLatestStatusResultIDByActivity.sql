CREATE FUNCTION [at].[GetLatestStatusResultIDByActivity]
(
    @UserID	 int,
    @ActivityID int,
    @ExcludeStatusTypeID varchar(max),
    @PriorStatusTypeID   int = 0
)
RETURNS nvarchar(max)
AS
BEGIN
	DECLARE @ResultStatus   int,
            @ReturnValue    nvarchar(max),
            @SavedStatus    int = 0,
            @SavedValue     nvarchar(max),
            @SurveyID       int,
            @ReportServer   nvarchar(max),
            @ReportDB       nvarchar(max),
            @sqlCommand     nvarchar(max) = N'',
            @Parameters     nvarchar(max) = N'@p_SurveyID int,@p_UserID int,@p_StatusTypeID varchar(max),@p_ResultStatus int OUTPUT,@p_ReturnValue nvarchar(max) OUTPUT',
			@ActiveEntityStatusID INT = 0

	SELECT @ReportServer = ReportServer, @ReportDB = ReportDB FROM at.Activity WHERE ActivityID = @ActivityID
	SET @sqlCommand = N'SELECT @p_ActiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Active'''
	EXECUTE sp_executesql @sqlCommand, N'@p_ActiveEntityStatusID INT OUTPUT', @p_ActiveEntityStatusID = @ActiveEntityStatusID OUTPUT
	
	DECLARE c_Survey CURSOR SCROLL READ_ONLY FOR
	SELECT s.SurveyID, '[' + s.ReportServer + ']', '[' + s.ReportDB + ']' FROM at.Survey s WHERE s.ActivityID = @ActivityID AND s.Status > 0
	ORDER BY s.EndDate DESC, s.StartDate DESC
	
	OPEN c_Survey
	FETCH NEXT FROM c_Survey INTO @SurveyID, @ReportServer, @ReportDB
	WHILE @@FETCH_STATUS=0
	BEGIN
	   -- Take the prioritized status type as highest priority
	   IF @PriorStatusTypeID > 0
	   BEGIN
		  SET @sqlCommand = N'SELECT TOP 1 @p_ResultStatus = StatusTypeID, @p_ReturnValue = (CONVERT(NVARCHAR(10),StatusTypeID) + ''|'' + CONVERT(NVARCHAR(32),ResultID))
						  FROM ' + @ReportServer + '.' + @ReportDB + '.' + 'dbo.Result
						  WHERE SurveyID = @p_SurveyID AND UserID = @p_UserID AND StatusTypeID = ' + CONVERT(VARCHAR(10),@PriorStatusTypeID)+' AND Deleted IS NULL AND EntityStatusID = ' + CONVERT(NVARCHAR(14), @ActiveEntityStatusID) +
						  ' ORDER BY ISNULL(Created,getdate()) DESC'
		  EXECUTE sp_executesql @sqlCommand, @Parameters, @p_SurveyID = @SurveyID, @p_UserID = @UserID, @p_StatusTypeID = @ExcludeStatusTypeID, @p_ResultStatus = @ResultStatus OUTPUT, @p_ReturnValue = @ReturnValue OUTPUT
		  IF @ResultStatus = @PriorStatusTypeID BREAK
	   END
	   
	   -- Get the latest status in the survey except excluded ones
	   SET @sqlCommand = N'SELECT TOP 1 @p_ResultStatus = StatusTypeID, @p_ReturnValue = (CONVERT(NVARCHAR(10),StatusTypeID) + ''|'' + CONVERT(NVARCHAR(32),ResultID))
					   FROM ' + @ReportServer + '.' + @ReportDB + '.' + 'dbo.Result
					   WHERE SurveyID = @p_SurveyID AND UserID = @p_UserID AND StatusTypeID NOT IN (@p_StatusTypeID) AND Deleted IS NULL AND EntityStatusID = ' + CONVERT(NVARCHAR(14), @ActiveEntityStatusID) +
					   ' ORDER BY ISNULL(Created,getdate()) DESC'
	   EXECUTE sp_executesql @sqlCommand, @Parameters, @p_SurveyID = @SurveyID, @p_UserID = @UserID, @p_StatusTypeID = @ExcludeStatusTypeID, @p_ResultStatus = @ResultStatus OUTPUT, @p_ReturnValue = @ReturnValue OUTPUT
	   
	   -- If found a status
	   IF @ResultStatus IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.funcListToTableInt(@ExcludeStatusTypeID,',') WHERE Value = @ResultStatus)
	   BEGIN
		  -- If having a prioritized status type then continue to search for it in other surveys
		  IF @PriorStatusTypeID > 0 AND @SavedStatus = 0
          BEGIN
			 SET @SavedStatus = @ResultStatus
             SET @SavedValue = @ReturnValue
          END
		  ELSE IF @PriorStatusTypeID = 0  -- Else return the status
			 BREAK
	   END
		  
	   FETCH NEXT FROM c_Survey INTO @SurveyID, @ReportServer, @ReportDB
	END
	
	-- If having a prioritized status type and didn't find one but found other status then return that status
	IF @PriorStatusTypeID > 0 AND @ResultStatus != @PriorStatusTypeID AND @SavedStatus != 0
    BEGIN
        SET @ResultStatus = @SavedStatus
        SET @ReturnValue = @SavedValue
    END
	
	-- Looking for a status other than no result
     IF @ResultStatus IS NULL
     BEGIN
	  FETCH FIRST FROM c_Survey INTO @SurveyID, @ReportServer, @ReportDB
	  WHILE @@FETCH_STATUS=0
	  BEGIN
		 SET @sqlCommand = N'SELECT TOP 1 @p_ResultStatus = StatusTypeID, @p_ReturnValue = (CONVERT(NVARCHAR(10),StatusTypeID) + ''|'' + CONVERT(NVARCHAR(32),ResultID))
						 FROM ' + @ReportServer + '.' + @ReportDB + '.' + 'dbo.Result
						 WHERE SurveyID = @p_SurveyID AND UserID = @p_UserID AND StatusTypeID IN (@p_StatusTypeID) AND Deleted IS NULL AND EntityStatusID = ' + CONVERT(NVARCHAR(14), @ActiveEntityStatusID) + 
						 ' ORDER BY ResultID DESC'
		 EXECUTE sp_executesql @sqlCommand, @Parameters, @p_SurveyID = @SurveyID, @p_UserID = @UserID, @p_StatusTypeID = @ExcludeStatusTypeID, @p_ResultStatus = @ResultStatus OUTPUT, @p_ReturnValue = @ReturnValue OUTPUT
		 IF @ResultStatus IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.funcListToTableInt(@ExcludeStatusTypeID,',') WHERE Value = @ResultStatus) BREAK
		  
		 FETCH NEXT FROM c_Survey INTO @SurveyID, @ReportServer, @ReportDB
	  END
     END
	CLOSE c_Survey
	DEALLOCATE c_Survey
	
	RETURN ISNULL(@ReturnValue,'0|0')
END
