
CREATE PROCEDURE [at].[prc_LT_Alternative_upd]
(
	@LanguageID int,
	@AlternativeID int,
	@Name nvarchar(256),
	@Label nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_Alternative]
	SET
		[LanguageID] = @LanguageID,
		[AlternativeID] = @AlternativeID,
		[Name] = @Name,
		[Label] = @Label,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[AlternativeID] = @AlternativeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Alternative',1,
		( SELECT * FROM [at].[LT_Alternative] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AlternativeID] = @AlternativeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

