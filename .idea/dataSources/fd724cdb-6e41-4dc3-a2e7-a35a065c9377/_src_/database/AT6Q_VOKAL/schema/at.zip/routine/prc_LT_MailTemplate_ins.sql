
CREATE PROCEDURE [at].[prc_LT_MailTemplate_ins]
(
	@LanguageID int,
	@MailTemplateID int,
	@Name nvarchar(256),
	@Subject nvarchar(256),
	@Body nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_MailTemplate]
	(
		[LanguageID],
		[MailTemplateID],
		[Name],
		[Subject],
		[Body]
	)
	VALUES
	(
		@LanguageID,
		@MailTemplateID,
		@Name,
		@Subject,
		@Body
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_MailTemplate',0,
		( SELECT * FROM [at].[LT_MailTemplate] 
			WHERE
			[LanguageID] = @LanguageID AND
			[MailTemplateID] = @MailTemplateID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

