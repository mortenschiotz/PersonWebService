

CREATE PROCEDURE [at].[prc_Role_del]
(
	@RoleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Role',2,
		( SELECT * FROM [at].[Role] 
			WHERE
			[RoleID] = @RoleID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Role]
	WHERE
		[RoleID] = @RoleID

	Set @Err = @@Error

	RETURN @Err
END

