
CREATE PROCEDURE [at].[prc_StatusLog_get]
(
	@CVID int,
	@Resultid bigint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[StatusLogID],
	[StatusTypeID],
	ISNULL([ResultID], 0) AS 'ResultID',
	ISNULL([CVID], 0) AS 'CVID',
	[UserID],
	[Comment],
	[Created]
	FROM [at].[StatusLog]
	WHERE
	 ([CVID] = @CVID AND @ResultID IS NULL) OR
	 ([Resultid] = @Resultid AND @CVID IS NULL)

	Set @Err = @@Error

	RETURN @Err
END

