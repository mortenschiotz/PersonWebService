

CREATE PROCEDURE [at].[prc_LT_A_VT_del]
(
	@LanguageID int,
	@AVTID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_A_VT',2,
		( SELECT * FROM [at].[LT_A_VT] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AVTID] = @AVTID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_A_VT]
	WHERE
		[LanguageID] = @LanguageID AND
		[AVTID] = @AVTID

	Set @Err = @@Error

	RETURN @Err
END

