--

CREATE PROCEDURE [at].[prc_Category_ins]      
(      
 @CategoryID int = null output,      
 @ActivityID int,      
 @ParentID INT=NULL,      
 @Tag nvarchar(128),      
 @Type smallint,      
 @No smallint,      
 @Fillcolor varchar(16),      
 @BorderColor varchar(16),      
 @Weight float,      
 @NType smallint,      
 @ProcessCategory bit,      
 @cUserid int,      
 @Log smallint = 1,  
 @ExtID nvarchar(64),
 @AnswerItemID int = null ,
 @RenderAsDefault bit =1,
 @AvgType smallint = 0
)      
AS      
BEGIN      
 SET NOCOUNT ON      
 DECLARE @Err Int      
      
 INSERT INTO [at].[Category]      
 (      
  [ActivityID],      
  [ParentID],      
  [Tag],      
  [Type],      
  [No],      
  [Fillcolor],      
  [BorderColor],      
  [Weight],      
  [NType],    
  [ProcessCategory],      
  [ExtID],
  [AnswerItemID]  ,
  [RenderAsDefault],
  [AvgType]
 )      
 VALUES      
 (      
  @ActivityID,      
  @ParentID,      
  @Tag,      
  @Type,      
  @No,      
  @Fillcolor,      
  @BorderColor,      
  @Weight,      
  @NType,    
  @ProcessCategory,  
  @ExtID,
  @AnswerItemID,
  @RenderAsDefault,
  @AvgType  
 )      
      
 Set @Err = @@Error      
 Set @CategoryID = scope_identity()      
      
 IF @Log = 1       
 BEGIN       
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)       
  SELECT @cUserid,'Category',0,      
  ( SELECT * FROM [at].[Category]       
   WHERE      
   [CategoryID] = @CategoryID     FOR XML AUTO) as data,      
    getdate()       
  END      
      
 RETURN @Err      
END 
