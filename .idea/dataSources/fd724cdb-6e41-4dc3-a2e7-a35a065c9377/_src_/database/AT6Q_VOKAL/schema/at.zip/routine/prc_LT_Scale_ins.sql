
CREATE PROCEDURE [at].[prc_LT_Scale_ins]
(
	@LanguageID int,
	@ScaleID int,
	@Name nvarchar(256),
	@Title nvarchar(max),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_Scale]
	(
		[LanguageID],
		[ScaleID],
		[Name],
		[Title],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@ScaleID,
		@Name,
		@Title,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Scale',0,
		( SELECT * FROM [at].[LT_Scale] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ScaleID] = @ScaleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

