
CREATE PROCEDURE [at].[prc_MailTemplate_ins]
(
	@MailTemplateID int = null output,
	@OwnerID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[MailTemplate]
	(
		[OwnerID]
	)
	VALUES
	(
		@OwnerID
	)

	Set @Err = @@Error
	Set @MailTemplateID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'MailTemplate',0,
		( SELECT * FROM [at].[MailTemplate] 
			WHERE
			[MailTemplateID] = @MailTemplateID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

