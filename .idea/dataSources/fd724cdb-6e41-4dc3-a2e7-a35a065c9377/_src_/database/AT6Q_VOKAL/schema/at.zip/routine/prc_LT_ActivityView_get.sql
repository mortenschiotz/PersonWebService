

CREATE PROCEDURE [at].[prc_LT_ActivityView_get]
(
	@ActivityViewID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ActivityViewID],
	[Name],
	[Description]
	FROM [at].[LT_ActivityView]
	WHERE
	[ActivityViewID] = @ActivityViewID

	Set @Err = @@Error

	RETURN @Err
END


