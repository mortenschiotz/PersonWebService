CREATE PROCEDURE [at].[prc_Q_C_upd]    
(    
 @QuestionID int,    
 @CategoryID int,    
 @Weight float,    
 @No smallint,    
 @Visible smallint,    
 @cUserid int,    
 @Log smallint = 1,
 @ItemID int = NULL
)    
AS    
BEGIN    
 SET NOCOUNT ON    
 DECLARE @Err Int    
    
 UPDATE [at].[Q_C]    
 SET    
  [QuestionID] = @QuestionID,    
  [CategoryID] = @CategoryID,    
  [Visible] =@Visible,  
  [Weight] = @Weight,    
  [No] = @No,
  [ItemID] = @ItemID
 WHERE    
  [QuestionID] = @QuestionID AND    
  [CategoryID] = @CategoryID    
    
 IF @Log = 1     
 BEGIN     
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)     
  SELECT @cUserid,'Q_C',1,    
  ( SELECT * FROM [at].[Q_C]     
   WHERE    
   [QuestionID] = @QuestionID AND    
   [CategoryID] = @CategoryID    FOR XML AUTO) as data,    
   getdate()    
 END    
    
 Set @Err = @@Error    
    
 RETURN @Err    
END    
        
