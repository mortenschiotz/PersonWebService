CREATE PROCEDURE [at].[prc_LT_ViewType_get]
(
	@ViewTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ViewTypeID],
	[Name],
	[Description]
	FROM [at].[LT_ViewType]
	WHERE
	[ViewTypeID] = @ViewTypeID

	Set @Err = @@Error

	RETURN @Err
END
