
CREATE PROCEDURE [at].[prc_ViewType_upd]
(
	@ViewTypeID int,
	@Type int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[ViewType]
	SET
		[Type] = @Type,
		[No] = @No
	WHERE
		[ViewTypeID] = @ViewTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ViewType',1,
		( SELECT * FROM [at].[ViewType] 
			WHERE
			[ViewTypeID] = @ViewTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

