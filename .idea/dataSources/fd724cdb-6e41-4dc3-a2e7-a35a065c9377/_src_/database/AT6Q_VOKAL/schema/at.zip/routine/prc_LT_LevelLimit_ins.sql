
CREATE PROCEDURE [at].[prc_LT_LevelLimit_ins]
(
	@LevelLimitID int,
	@LanguageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_LevelLimit]
	(
		[LevelLimitID],
		[LanguageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LevelLimitID,
		@LanguageID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LevelLimit',0,
		( SELECT * FROM [at].[LT_LevelLimit] 
			WHERE
			[LevelLimitID] = @LevelLimitID AND
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

