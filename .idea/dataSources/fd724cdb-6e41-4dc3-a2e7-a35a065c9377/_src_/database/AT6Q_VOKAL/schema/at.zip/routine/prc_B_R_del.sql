CREATE PROCEDURE [at].[prc_B_R_del]
(
	@BulkID int,
	@RoleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	


	DELETE FROM [at].[B_R]
	WHERE
		[BulkID] = @BulkID AND
		[RoleID] = @RoleID

	Set @Err = @@Error

	RETURN @Err
END


