CREATE PROCEDURE [at].[prc_ResultByUser_getAll]
(
	@OwnerID            int,
	@UserID             int,
	@AccessGroupList    nvarchar(max) = N'',
	@ActivityID         int = 0,
    @SurveyID           int = 0
)
As
BEGIN
	--exec [at].[prc_ResultByUser_getAll] 15, 406, N'6,8'
	SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	DECLARE @Err				int,
			@SurveyTableType	int,	-- get the ID of Survey from dbo.TableType
			@ActivityTableType	int,	-- get the ID of Activity from dbo.TableType
			@DeniedSurveyList	varchar(max)='',
			@AccessGenericCount	int,
			@ReportServer		nvarchar(64)=N'',
			@ReportDB			nvarchar(64)=N'',
			@sqlCommand         nvarchar(max),
			@Parameters         nvarchar(max) = N''

	SELECT  @SurveyTableType   = TableTypeID FROM dbo.TableType WHERE Name = 'Survey'
	SELECT  @ActivityTableType = TableTypeID FROM dbo.TableType WHERE Name = 'Activity'
    DECLARE @ActiveEntityStatusID VARCHAR(2) = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	SELECT @AccessGenericCount = count(AccessID)
	FROM AccessGeneric a
	JOIN AccessGroup g ON a.AccessGroupID = g.AccessGroupID
	WHERE  a.TableTypeID IN (@ActivityTableType, @SurveyTableType)
	  AND  g.OwnerID = @OwnerID

	CREATE TABLE #DeniedSurveyList (ReportServer nvarchar(64), ReportDB nvarchar(64), DeniedSurvey int)
	CREATE TABLE #UserResult (ResultID bigint, ActivityID int, SurveyID int, BatchID int, DepartmentID int,
	   RoleID int, UserGroupID int, StartDate datetime, EndDate datetime, StatusTypeID int,
	   ReportServer nvarchar(64), ReportDB nvarchar(64), ActivityNo smallint, LastUpdated datetime, Created datetime, ValidFrom datetime, ValidTo datetime,
	   ParentResultID bigint, ParentResultSurveyID int, CustomerID int, Deleted DATETIME2(7), EntityStatusID int, EntityStatusReasonID int)

	IF @AccessGenericCount > 0 AND len(@AccessGroupList) > 0
	BEGIN
		-- Denied activities to group
		SET @sqlCommand = N'INSERT INTO #DeniedSurveyList (ReportServer, ReportDB, DeniedSurvey)
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN at.Survey s ON a.Elementid = s.ActivityID AND a.Type = 2
		WHERE  a.TableTypeID = @p_ActivityTableType
		  AND  a.AccessGroupID IN (' + @AccessGroupList + ')'
		IF @ActivityID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.ActivityID = ' + convert(NVARCHAR(32),@ActivityID)
		END
		SET @Parameters = N'@p_ActivityTableType int'
		EXECUTE sp_executesql @sqlCommand, @Parameters, @p_ActivityTableType = @ActivityTableType

		-- Full/Read access activities to others group and not granted to their own groups
		SET @sqlCommand = N'INSERT INTO #DeniedSurveyList (ReportServer, ReportDB, DeniedSurvey)
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN AccessGroup g ON a.AccessGroupID = g.AccessGroupID
		JOIN at.Survey s ON a.Elementid = s.ActivityID AND a.Type IN (0,1)
		WHERE  a.TableTypeID = @p_ActivityTableType
		  AND  a.AccessGroupID NOT IN (' + @AccessGroupList + ')
		  AND  g.OwnerID = @p_OwnerID
		EXCEPT
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN at.Survey s ON a.Elementid = s.ActivityID AND a.Type IN (0,1)
		WHERE  a.TableTypeID = @p_ActivityTableType
		  AND  a.AccessGroupID IN (' + @AccessGroupList + ')'
		IF @ActivityID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.ActivityID = ' + convert(NVARCHAR(32),@ActivityID)
		END
		SET @Parameters = N'@p_ActivityTableType int,@p_OwnerID int'
		EXECUTE sp_executesql @sqlCommand, @Parameters, @p_ActivityTableType = @ActivityTableType, @p_OwnerID = @OwnerID

		-- Denied surveys to group
		SET @sqlCommand = N'INSERT INTO #DeniedSurveyList (ReportServer, ReportDB, DeniedSurvey)
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN at.Survey s ON a.Elementid = s.SurveyID AND a.Type = 2
		WHERE  a.TableTypeID = @p_SurveyTableType
		  AND  a.AccessGroupID IN (' + @AccessGroupList + ')'
		IF @ActivityID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.ActivityID = ' + convert(NVARCHAR(32),@ActivityID)
		END
        IF @SurveyID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.SurveyID = ' + convert(NVARCHAR(32),@SurveyID)
		END
		SET @Parameters = N'@p_SurveyTableType int'
		EXECUTE sp_executesql @sqlCommand, @Parameters, @p_SurveyTableType = @SurveyTableType

		-- Full/Read access surveys to others group and not granted to their own groups
		SET @sqlCommand = N'INSERT INTO #DeniedSurveyList (ReportServer, ReportDB, DeniedSurvey)
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN AccessGroup g ON a.AccessGroupID = g.AccessGroupID
		JOIN at.Survey s ON a.Elementid = s.SurveyID AND a.Type IN (0,1)
		WHERE  a.TableTypeID = @p_SurveyTableType
		  AND  a.AccessGroupID NOT IN (' + @AccessGroupList + ')
		  AND  g.OwnerID = @p_OwnerID
		EXCEPT
		SELECT s.ReportServer, s.ReportDB, s.SurveyID
		FROM AccessGeneric a
		JOIN at.Survey s ON a.Elementid = s.SurveyID AND a.Type IN (0,1)
		WHERE  a.TableTypeID = @p_SurveyTableType
		  AND  a.AccessGroupID IN (' + @AccessGroupList + ')'
		IF @ActivityID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.ActivityID = ' + convert(NVARCHAR(32),@ActivityID)
		END
        IF @SurveyID > 0
		BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND s.SurveyID = ' + convert(NVARCHAR(32),@SurveyID)
		END
		SET @Parameters = N'@p_SurveyTableType int,@p_OwnerID int'
		EXECUTE sp_executesql @sqlCommand, @Parameters, @p_SurveyTableType = @SurveyTableType, @p_OwnerID = @OwnerID
	END

	DECLARE c_ResultDatabase CURSOR READ_ONLY FOR
	SELECT DISTINCT s.ReportServer, s.ReportDB
	FROM at.Survey s JOIN at.Activity act ON act.ActivityID = s.ActivityID AND act.OwnerID = @OwnerID

	OPEN c_ResultDatabase
	FETCH NEXT FROM c_ResultDatabase INTO @ReportServer, @ReportDB
	WHILE @@FETCH_STATUS=0
	BEGIN
	   -- Get result except denied surveys
	   SET @sqlCommand = N'INSERT INTO #UserResult (ResultID, ActivityID, SurveyID, BatchID, DepartmentID, RoleID, UserGroupID, StartDate, EndDate, StatusTypeID, ReportServer, ReportDB, ActivityNo, 
			LastUpdated, Created, ValidFrom, ValidTo, ParentResultID, ParentResultSurveyID, CustomerID, Deleted, EntityStatusID, EntityStatusReasonID)
	   SELECT ResultID, NULL, SurveyID, BatchID, DepartmentID, RoleID, UserGroupID, StartDate, EndDate, StatusTypeID, @p_ReportServer, @p_ReportDB, NULL, 
			LastUpdated, Created, ValidFrom, ValidTo, ParentResultID, ParentResultSurveyID, CustomerID, Deleted, EntityStatusID, EntityStatusReasonID
	   FROM	[' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Result r
	   WHERE  NOT EXISTS (SELECT 1 FROM #DeniedSurveyList s WHERE s.DeniedSurvey = r.SurveyID)
	     AND  r.UserID = @p_UserID
	     AND  r.EntityStatusID = '+@ActiveEntityStatusID+' AND r.Deleted IS NULL '
	   IF @ActivityID > 0
	   BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND r.SurveyID IN (SELECT s1.SurveyID FROM at.Survey s1 WHERE s1.ActivityID = ' + convert(NVARCHAR(32),@ActivityID) + ')'
	   END
       IF @SurveyID > 0
	   BEGIN
		  SET @sqlCommand = @sqlCommand + ' AND r.SurveyID = ' + convert(NVARCHAR(32),@SurveyID)
	   END
	   SET @Parameters = N'@p_ReportServer nvarchar(64),@p_ReportDB nvarchar(64),@p_UserID int'
	   EXECUTE sp_executesql @sqlCommand, @Parameters, @p_ReportServer = @ReportServer, @p_ReportDB = @ReportDB, @p_UserID = @UserID

	   FETCH NEXT FROM c_ResultDatabase INTO @ReportServer, @ReportDB
	END
	CLOSE c_ResultDatabase
	DEALLOCATE c_ResultDatabase

	UPDATE #UserResult SET ActivityID = (SELECT s.ActivityID FROM at.Survey s WHERE s.SurveyID = ur.SurveyID)
	FROM #UserResult ur
	
	DELETE FROM #UserResult WHERE ActivityID IS NULL

	UPDATE #UserResult SET ActivityNo = (SELECT a.No FROM at.Activity a WHERE a.ActivityID = ur.ActivityID)
	FROM #UserResult ur

	SELECT * FROM #UserResult ORDER BY ActivityNo, StartDate DESC

	DROP TABLE #DeniedSurveyList
	DROP TABLE #UserResult

	Set @Err = @@Error

	RETURN @Err
END
