CREATE PROCEDURE [at].[prc_LT_Bulk_get]
(
	@BulkID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[BulkID],
	ISNULL([Name], '') AS 'Name',
	ISNULL([Description], '') AS 'Description',
	ISNULL([ToolTip], '') AS 'ToolTip'
	FROM [at].[LT_Bulk]
	WHERE
	[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


