CREATE PROCEDURE [at].[prc_LT_Mail_get]
(
	@MailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[MailID],
	[Name],
	[Subject],
	[Body]
	FROM [at].[LT_Mail]
	WHERE
	[MailID] = @MailID

	Set @Err = @@Error

	RETURN @Err
END
