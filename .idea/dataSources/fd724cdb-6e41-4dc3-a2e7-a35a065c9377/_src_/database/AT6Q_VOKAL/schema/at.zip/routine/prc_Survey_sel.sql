CREATE PROCEDURE [at].[prc_Survey_sel]
(
	@SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SurveyID],
	[ActivityID],
	ISNULL([HierarchyID], 0) AS 'HierarchyID',
	[StartDate],
	[EndDate],
	[Anonymous],
	[Status],
	[ShowBack],
	[LanguageID],
	[ButtonPlacement],
	[UsePageNo],
	[LinkURL],
	[FinishURL],
	[CreateResult],
	[ReportDB],
	[ReportServer],
	[StyleSheet],
	[Type],
	[Created],
	[LastProcessed],
	[ReProcessOLAP],
	[No],
	[OLAPServer],
	[OLAPDB],
	ISNULL([PeriodID],0) as 'PeriodID',
	DeleteResultOnUserDelete,
	ProcessCategorys
	FROM [at].[Survey]
	WHERE
	[SurveyID] = @SurveyID

	Set @Err = @@Error

	RETURN @Err
END

