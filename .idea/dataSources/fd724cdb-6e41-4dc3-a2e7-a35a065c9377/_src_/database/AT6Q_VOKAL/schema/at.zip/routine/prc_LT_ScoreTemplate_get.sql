CREATE PROCEDURE [at].[prc_LT_ScoreTemplate_get]
(
	@ScoreTemplateID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ScoreTemplateID],
	[LanguageID],
	[Name],
	[Description]
	FROM [at].[LT_ScoreTemplate]
	WHERE
	[ScoreTemplateID] = @ScoreTemplateID

	Set @Err = @@Error

	RETURN @Err
END
