CREATE PROCEDURE [at].[prc_XCategoryType_get] (@OwnerID INT)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	SELECT [XCTypeID]
		,[OwnerID]
		,[ExtID]
		,[No]
		,[Created]
	FROM [at].[XCategoryType]
	WHERE [OwnerID] = @OwnerID
	ORDER BY [No]

	SET @Err = @@Error

	RETURN @Err
END
