
CREATE PROCEDURE [at].[prc_DR_Q_del]
(
	@DottedRuleID int,
	@QuestionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DR_Q',2,
		( SELECT * FROM [at].[DR_Q] 
			WHERE
			[DottedRuleID] = @DottedRuleID AND
			[QuestionID] = @QuestionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[DR_Q]
	WHERE
		[DottedRuleID] = @DottedRuleID AND
		[QuestionID] = @QuestionID

	Set @Err = @@Error

	RETURN @Err
END

