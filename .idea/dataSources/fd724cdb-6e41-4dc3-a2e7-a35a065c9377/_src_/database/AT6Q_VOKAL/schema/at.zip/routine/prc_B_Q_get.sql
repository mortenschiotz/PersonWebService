CREATE PROCEDURE [at].[prc_B_Q_get]
(
	@BulkID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BulkID],
	[QuestionID]
	FROM [at].[B_Q]
	WHERE
	[BulkID] = @BulkID

	Set @Err = @@Error

	RETURN @Err
END


