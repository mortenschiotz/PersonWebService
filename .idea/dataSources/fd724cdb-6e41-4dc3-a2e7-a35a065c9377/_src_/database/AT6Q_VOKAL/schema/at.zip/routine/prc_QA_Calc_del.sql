

CREATE PROCEDURE  [at].[prc_QA_Calc_del]
(
	@QAID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'QA_Calc',2,
		( SELECT * FROM [at].[QA_Calc] 
			WHERE
			[QAID] = @QAID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[QA_Calc]
	WHERE
		[QAID] = @QAID

	Set @Err = @@Error

	RETURN @Err
END

