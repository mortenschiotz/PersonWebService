CREATE PROCEDURE [at].[prc_LT_Scale_get]
(
	@ScaleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ScaleID],
	[Name],
	[Title],
	[Description]
	FROM [at].[LT_Scale]
	WHERE
	[ScaleID] = @ScaleID

	Set @Err = @@Error

	RETURN @Err
END