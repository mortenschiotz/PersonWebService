


CREATE PROCEDURE [at].[prc_Period_del]
(
	@PeriodID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Period',2,
		( SELECT * FROM [at].[Period] 
			WHERE
			[PeriodID] = @PeriodID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Period]
	WHERE
		[PeriodID] = @PeriodID

	Set @Err = @@Error

	RETURN @Err
END

