

CREATE PROCEDURE [at].[prc_ViewType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ViewTypeID],
	[Type],
	[No],
	[Created]
	FROM [at].[ViewType]

	Set @Err = @@Error

	RETURN @Err
END

