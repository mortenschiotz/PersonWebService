
Create Proc [at].[prc_LT_Alternative_Activity_Get]
(
  @ActivityID int
)
as

Select LTA.Languageid, LTA.AlternativeID,LTA.name, LTA.Label, LTA.Description from 
at.Scale  S
Join At.Alternative A on S.Scaleid = A.scaleid
Join at.LT_Alternative LTA on LTA.Alternativeid = A.Alternativeid
where activityid = @ActivityID
Order by LTA.AlternativeID