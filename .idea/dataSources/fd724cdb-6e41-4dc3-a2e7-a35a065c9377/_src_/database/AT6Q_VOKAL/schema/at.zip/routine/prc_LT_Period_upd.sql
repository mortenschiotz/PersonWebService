
CREATE PROCEDURE [at].[prc_LT_Period_upd]
(
	@LanguageID int,
	@PeriodID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_Period]
	SET
		[LanguageID] = @LanguageID,
		[PeriodID] = @PeriodID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[PeriodID] = @PeriodID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Period',1,
		( SELECT * FROM [at].[LT_Period] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PeriodID] = @PeriodID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

