CREATE PROCEDURE [at].[prc_AG_A_ins]
(
	@AGID int,
	@AlternativeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[AG_A]
	(
		[AGID],
		[AlternativeID]
	)
	VALUES
	(
		@AGID,
		@AlternativeID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AG_A',0,
		( SELECT * FROM [at].[AG_A] 
			WHERE
			[AGID] = @AGID AND
			[AlternativeID] = @AlternativeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
