CREATE PROCEDURE [at].[prc_LT_Role_get]
(
	@RoleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[RoleID],
	[Name],
	[Description]
	FROM [at].[LT_Role]
	WHERE
	[RoleID] = @RoleID

	Set @Err = @@Error

	RETURN @Err
END
