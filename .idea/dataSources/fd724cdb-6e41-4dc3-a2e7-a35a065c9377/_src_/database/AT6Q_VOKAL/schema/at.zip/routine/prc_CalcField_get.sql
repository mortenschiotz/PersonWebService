CREATE PROCEDURE  [at].[prc_CalcField_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[CFID],
	[ActivityID],
	[Name],
	[Formula],
	[Format],
	[Created],
	AllParametersMustExist,
	[Type]
	FROM [at].[CalcField]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END
