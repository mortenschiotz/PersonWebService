CREATE PROCEDURE [at].[prc_XCategory_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[XCID],
	ISNULL([ParentID], 0) AS 'ParentID',
	[OwnerID],
	[Type],
	[Status],
	[No],
	[Created],
	[ExtId]
	FROM [at].[XCategory]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
