CREATE PROCEDURE [at].[prc_LT_ScoreTemplateGroup_get]
(
	@STGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ScoreTemplateGroupID],
	[LanguageID],
	[Name],
	[Description]
	FROM [at].[LT_ScoreTemplateGroup]
	WHERE
	[ScoreTemplateGroupID] = @STGroupID

	Set @Err = @@Error

	RETURN @Err
END
