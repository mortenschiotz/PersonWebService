CREATE PROCEDURE [at].[prc_B_Q_del]
(
	@BulkID int,
	@QuestionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	


	DELETE FROM [at].[B_Q]
	WHERE
		[BulkID] = @BulkID AND
		[QuestionID] = @QuestionID

	Set @Err = @@Error

	RETURN @Err
END


