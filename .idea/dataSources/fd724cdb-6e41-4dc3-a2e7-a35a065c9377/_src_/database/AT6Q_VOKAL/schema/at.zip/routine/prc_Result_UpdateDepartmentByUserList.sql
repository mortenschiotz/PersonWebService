CREATE PROCEDURE [at].[prc_Result_UpdateDepartmentByUserList] 
(
    @ListUserID     nvarchar(512),
    @OwnerID        int,
    @DepartmentID	int
)
AS
BEGIN
    DECLARE @ReportServer   nvarchar(84),
            @ReportDB       nvarchar(84),
            @cmd            nvarchar(512)   
    IF object_id('tempdb..#Result_temp') IS NOT NULL
    DROP TABLE #Result_temp    
    CREATE TABLE #Result_temp (UserID int,res int Default (0))
    INSERT INTO #Result_temp (UserID) SELECT value FROM dbo.funcListToTableInt(@ListUserID,',')

    DECLARE cur CURSOR READ_ONLY FOR 
    SELECT DISTINCT ReportServer, ReportDB FROM at.Survey WHERE ActivityID IN (SELECT ActivityID from at.Activity WHERE OwnerID = @OwnerID)
    OPEN cur
    FETCH NEXT FROM cur INTO @ReportServer, @ReportDB
        WHILE @@FETCH_STATUS=0
        BEGIN
            SET @cmd ='UPDATE  [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Result SET DepartmentID = '+convert(nvarchar(max), @DepartmentID)+' WHERE UserID IN(SELECT UserID FROM #Result_temp)'
            EXECUTE sp_executesql @cmd
        FETCH NEXT FROM cur INTO @ReportServer, @ReportDB
        END
    CLOSE cur
    DEALLOCATE cur
    DROP TABLE #Result_temp
END
