CREATE PROCEDURE [at].[prc_LT_LevelLimit_get]
(
	@LevelLimitID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LevelLimitID],
	[LanguageID],
	[Name],
	[Description]
	FROM [at].[LT_LevelLimit]
	WHERE
	[LevelLimitID] = @LevelLimitID

	Set @Err = @@Error

	RETURN @Err
END