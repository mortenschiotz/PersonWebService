
CREATE PROCEDURE [at].[prc_LT_Period_del]
(
	@LanguageID int,
	@PeriodID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Period',2,
		( SELECT * FROM [at].[LT_Period] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PeriodID] = @PeriodID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Period]
	WHERE
		[LanguageID] = @LanguageID AND
		[PeriodID] = @PeriodID

	Set @Err = @@Error

	RETURN @Err
END

