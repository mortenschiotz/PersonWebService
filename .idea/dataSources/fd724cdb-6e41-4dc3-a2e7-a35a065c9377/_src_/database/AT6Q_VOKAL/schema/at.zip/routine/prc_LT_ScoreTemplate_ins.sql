
CREATE PROCEDURE [at].[prc_LT_ScoreTemplate_ins]
(
	@ScoreTemplateID int,
	@LanguageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_ScoreTemplate]
	(
		[ScoreTemplateID],
		[LanguageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@ScoreTemplateID,
		@LanguageID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ScoreTemplate',0,
		( SELECT * FROM [at].[LT_ScoreTemplate] 
			WHERE
			[ScoreTemplateID] = @ScoreTemplateID AND
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

