CREATE PROCEDURE [at].[prc_Access_ins]  
(  
 @AccessID int = null output,  
 @SurveyID int,  
 @BatchID int = null,  
 @RoleID int=null,  
 @DepartmentID int=null,  
 @HDID int=null,  
 @DepartmentTypeID int=null,  
 @CustomerID int=null,  
 @PageID int=null,  
 @QuestionID int=null,  
 @Type smallint,  
 @Mandatory bit,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [at].[Access]  
 (  
  [SurveyID],  
  [BatchID],  
  [RoleID],  
  [DepartmentID],  
  [DepartmentTypeID],  
  [HDID],  
  [CustomerID],  
  [PageID],  
  [QuestionID],  
  [Type],  
  [Mandatory]  
 )  
 VALUES  
 (  
  @SurveyID,  
  @BatchID,  
  @RoleID,  
  @DepartmentID,  
  @DepartmentTypeID,  
  @HDID,
     @CustomerID,  
  @PageID,  
  @QuestionID,  
  @Type,  
  @Mandatory  
 )  
  
 Set @Err = @@Error  
 Set @AccessID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Access',0,  
  ( SELECT * FROM [at].[Access]   
   WHERE  
   [AccessID] = @AccessID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END  
