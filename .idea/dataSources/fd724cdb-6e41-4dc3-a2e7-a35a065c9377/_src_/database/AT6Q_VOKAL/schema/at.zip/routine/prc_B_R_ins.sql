CREATE PROCEDURE [at].[prc_B_R_ins]
(
	@BulkID int,
	@RoleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[B_R]
	(
		[BulkID],
		[RoleID]
	)
	VALUES
	(
		@BulkID,
		@RoleID
	)

	Set @Err = @@Error


	RETURN @Err
END


