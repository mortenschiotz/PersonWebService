
CREATE PROCEDURE [at].[prc_DR_Q_ins]
(
	@DottedRuleID int,
	@QuestionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[DR_Q]
	(
		[DottedRuleID],
		[QuestionID]
	)
	VALUES
	(
		@DottedRuleID,
		@QuestionID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DR_Q',0,
		( SELECT * FROM [at].[DR_Q] 
			WHERE
			[DottedRuleID] = @DottedRuleID AND
			[QuestionID] = @QuestionID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

