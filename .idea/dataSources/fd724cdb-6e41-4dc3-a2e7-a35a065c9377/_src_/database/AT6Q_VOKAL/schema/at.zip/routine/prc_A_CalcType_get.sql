

CREATE PROCEDURE [at].[prc_A_CalcType_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ACALCTYPEID],
	[ReportCalcTypeID],
	[ActivityID],
	[No],
	[DefaultSelected],
	[Format],
	[Created]
	FROM [at].[A_CalcType]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


