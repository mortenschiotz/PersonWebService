
CREATE PROCEDURE [at].[prc_SentMailFiles_get]
(
	@SentMailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SentMailFileID],
	[MIMEType],
	[Data],
	[Created],
	[Description],
	[Size],
	ISNULL([Filename], '') AS 'Filename',
	ISNULL([SentMailID], 0) AS 'SentMailID'
	FROM [at].[SentMailFiles]
	WHERE
	[SentMailID] = @SentMailID

	Set @Err = @@Error

	RETURN @Err
END

