CREATE PROCEDURE [at].[prc_Bulk_ins]
(
	@BulkID int output,
	@BulkGroupID int,
	@No smallint,
	@Css varchar(50),
	@Icon varchar(50),
	@Tag varchar(50),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Bulk]
	(		
		[BulkGroupID],
		[No],
		[Css],
		[Icon],
		[Tag]
	)
	VALUES
	(		
		@BulkGroupID,
		@No,
		@Css,
		@Icon,
		@Tag
	)

	Set @BulkID = scope_identity()

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bulk',0,
		( SELECT * FROM [at].[Bulk] 
			WHERE
			[BulkID] = @BulkID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


