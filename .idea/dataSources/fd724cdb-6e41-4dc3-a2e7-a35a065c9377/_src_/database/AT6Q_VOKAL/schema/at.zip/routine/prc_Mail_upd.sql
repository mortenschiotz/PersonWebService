
CREATE PROCEDURE [at].[prc_Mail_upd]
(
	@MailID int,
	@SurveyID int,
	@BatchID INT=NULL,
	@Type smallint,
	@From nvarchar(256),
	@Bcc nvarchar(max),
	@StatusMail nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Mail]
	SET
		[SurveyID] = @SurveyID,
		[BatchID] = @BatchID,
		[Type] = @Type,
		[From] = @From,
		[Bcc] = @Bcc,
		[StatusMail] = @StatusMail
	WHERE
		[MailID] = @MailID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Mail',1,
		( SELECT * FROM [at].[Mail] 
			WHERE
			[MailID] = @MailID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

