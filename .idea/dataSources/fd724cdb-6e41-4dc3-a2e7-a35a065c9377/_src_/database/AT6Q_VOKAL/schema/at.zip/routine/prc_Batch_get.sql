
CREATE PROCEDURE [at].[prc_Batch_get]
(
	@SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BatchID],
	[SurveyID],
	ISNULL([UserID], 0) AS 'UserID',
	ISNULL([DepartmentID], 0) AS 'DepartmentID',
	[Name],
	[No],
	ISNULL([StartDate], 0) AS 'StartDate',
	ISNULL([EndDate], 0) AS 'EndDate',
	[Status],
	[MailStatus],
	[Created]
	FROM [at].[Batch]
	WHERE
	[SurveyID] = @SurveyID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

