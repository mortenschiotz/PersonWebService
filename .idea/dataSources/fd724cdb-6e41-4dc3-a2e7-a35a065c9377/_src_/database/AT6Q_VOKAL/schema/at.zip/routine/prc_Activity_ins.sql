CREATE PROCEDURE [at].[prc_Activity_ins]
(
	@ActivityID int = null output,
	@LanguageID int,
	@OwnerID int,
	@StyleSheet nvarchar(128),
	@Type smallint,
	@No smallint,
	@TooltipType smallint,
	@Listview smallint,
	@Descview smallint,
	@Chartview smallint,
	@OLAPServer nvarchar(64),
	@OLAPDB nvarchar(64),
	@SelectionHeaderType smallint = 0,
	@ExtID nvarchar(64)='',
	@cUserid int,
	@Log smallint = 1,
	@UseOLAP bit = 1,
	@ArchetypeID int = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[Activity]
	(
		[LanguageID],
		[OwnerID],
		[StyleSheet],
		[Type],
		[No],
		[TooltipType],
		[Listview],
		[Descview],
		[Chartview],
		[OLAPServer],
		[OLAPDB],
		[SelectionHeaderType],
		[ExtID],
		[UseOLAP],
		[ArchetypeID]
	)
	VALUES
	(
		@LanguageID,
		@OwnerID,
		@StyleSheet,
		@Type,
		@No,
		@TooltipType,
		@Listview,
		@Descview,
		@Chartview,
		@OLAPServer,
		@OLAPDB,
		@SelectionHeaderType,
		@ExtID,
		@UseOLAP,
		@ArchetypeID
	)

	Set @Err = @@Error
	Set @ActivityID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Activity',0,
		( SELECT * FROM [at].[Activity] 
			WHERE
			[ActivityID] = @ActivityID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

