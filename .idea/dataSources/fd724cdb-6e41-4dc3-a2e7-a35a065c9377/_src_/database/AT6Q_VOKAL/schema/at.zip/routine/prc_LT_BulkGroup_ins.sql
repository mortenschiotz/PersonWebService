CREATE PROCEDURE [at].[prc_LT_BulkGroup_ins]
(
	@LanguageID int,
	@BulkGroupID int,
	@Name varchar(100),
	@Description varchar(500),
	@ToolTip ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_BulkGroup]
	(
		[LanguageID],
		[BulkGroupID],
		[Name],
		[Description],
		[ToolTip]
	)
	VALUES
	(
		@LanguageID,
		@BulkGroupID,
		@Name,
		@Description,
		@ToolTip
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_BulkGroup',0,
		( SELECT * FROM [at].[LT_BulkGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[BulkGroupID] = @BulkGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


