
CREATE PROCEDURE [at].[prc_ReportCalcType_upd]
(
	@ReportCalcTypeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[ReportCalcType]
	SET
		[ReportCalcTypeID] = @ReportCalcTypeID,
		[No] = @No
	WHERE
		[ReportCalcTypeID] = @ReportCalcTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportCalcType',1,
		( SELECT * FROM [at].[ReportCalcType] 
			WHERE
			[ReportCalcTypeID] = @ReportCalcTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

