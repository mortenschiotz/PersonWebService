
CREATE PROCEDURE [at].[prc_LT_LevelGroup_upd]
(
	@LanguageID int,
	@LevelGroupID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_LevelGroup]
	SET
		[LanguageID] = @LanguageID,
		[LevelGroupID] = @LevelGroupID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[LevelGroupID] = @LevelGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LevelGroup',1,
		( SELECT * FROM [at].[LT_LevelGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[LevelGroupID] = @LevelGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


