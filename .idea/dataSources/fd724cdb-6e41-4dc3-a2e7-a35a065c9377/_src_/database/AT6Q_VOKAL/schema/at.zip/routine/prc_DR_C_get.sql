
CREATE PROCEDURE [at].[prc_DR_C_get]
(
	@DottedRuleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DottedRuleID],
	[CategoryID]
	FROM [at].[DR_C]
	WHERE
	[DottedRuleID] = @DottedRuleID

	Set @Err = @@Error

	RETURN @Err
END

