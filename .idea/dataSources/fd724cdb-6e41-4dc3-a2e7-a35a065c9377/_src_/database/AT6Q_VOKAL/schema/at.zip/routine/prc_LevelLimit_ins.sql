CREATE PROCEDURE [at].[prc_LevelLimit_ins]  
(  
 @LevelLimitID int = null output,  
 @LevelGroupID int = null,  
 @CategoryID int = null,  
 @QuestionID int = null,  
 @AlternativeID int = null,  
 @MinValue float,  
 @MaxValue float,  
 @SigChange float,  
 @OwnerColorID int,  
 @NegativeTrend bit = 0,  
 @cUserid int,  
 @Log smallint = 1,
 @ItemID int = NULL,
 @ExtID nvarchar(64)='',
 @MatchingType int = 0
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [at].[LevelLimit]  
 (  
  [LevelGroupID],  
  [CategoryID],  
  [QuestionID],  
  [AlternativeID],  
  [MinValue],  
  [MaxValue],  
  [Sigchange],  
  [OwnerColorID],  
  [NegativeTrend],
  [ItemID],
  [ExtID],
  [MatchingType]  
 )  
 VALUES  
 (  
  @LevelGroupID,  
  @CategoryID,  
  @QuestionID,  
  @AlternativeID,  
  @MinValue,  
  @MaxValue,  
  @SigChange,  
  @OwnerColorID ,  
  @NegativeTrend,
  @ItemID,
  @ExtID,
  @MatchingType  
 )  
  
 Set @Err = @@Error  
 Set @LevelLimitID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'LevelLimit',0,  
  ( SELECT * FROM [at].[LevelLimit]   
   WHERE  
   [LevelLimitID] = @LevelLimitID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END
