CREATE PROCEDURE [at].[prc_Page_get]  
(  
 @ActivityID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [PageID],  
 ISNULL([ActivityID], 0) AS 'ActivityID',  
 [No],  
 ISNULL([Created], 0) AS 'Created',  
 [Type],  
 [CssClass],
 [ExtID],
 [Tag]
 FROM [at].[Page]  
 WHERE  
 [ActivityID] = @ActivityID  
 ORDER BY [No]  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END 
