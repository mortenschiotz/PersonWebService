
CREATE PROCEDURE [at].[prc_SM_BU_get]
(
	@SentMailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SentMailID],
	[BatchID],
	[ResultID]
	FROM [at].[SM_BU]
	WHERE
	[SentMailID] = @SentMailID

	Set @Err = @@Error

	RETURN @Err
END

