
CREATE PROCEDURE [at].[prc_XCategoryType_del] (
	@XCategoryTypeID INT
	,@cUserid INT
	,@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'CategoryType'
			,2
			,(
				SELECT *
				FROM [at].[XCategoryType]
				WHERE [XCTypeID] = @XCategoryTypeID
				FOR XML AUTO
				) AS data
			,GETDATE()
	END

	DELETE
	FROM [at].[XCategoryType]
	WHERE [XCTypeID] = @XCategoryTypeID

	SET @Err = @@Error

	RETURN @Err
END
