CREATE PROCEDURE [at].[prc_LT_Page_get]
(
	@PageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PageID],
	[Name],
	[Info],
	[Description]
	FROM [at].[LT_Page]
	WHERE
	[PageID] = @PageID

	Set @Err = @@Error

	RETURN @Err
END
