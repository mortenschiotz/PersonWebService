CREATE PROCEDURE [at].[prc_ActivityView_Q_del]
(
	@ActivityViewQID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ActivityView_Q',2,
		( SELECT * FROM [at].[ActivityView_Q] 
			WHERE
			[ActivityViewQID] = @ActivityViewQID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[ActivityView_Q]
	WHERE
		[ActivityViewQID] = @ActivityViewQID

	Set @Err = @@Error

	RETURN @Err
END

