
CREATE PROCEDURE [at].[prc_ActivityView_QA_upd]
(
	@ActivityViewQID int,
	@AlternativeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[ActivityView_QA]
	SET
		[ActivityViewQID] = @ActivityViewQID,
		[AlternativeID] = @AlternativeID,
		[No] = @No
	WHERE
		[ActivityViewQID] = @ActivityViewQID AND
		[AlternativeID] = @AlternativeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ActivityView_QA',1,
		( SELECT * FROM [at].[ActivityView_QA] 
			WHERE
			[ActivityViewQID] = @ActivityViewQID AND
			[AlternativeID] = @AlternativeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

