CREATE PROCEDURE [at].[prc_B_P_del]
(
	@BulkID int,
	@PageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	
	DELETE FROM [at].[B_P]
	WHERE
		[BulkID] = @BulkID AND
		[PageID] = @PageID

	Set @Err = @@Error

	RETURN @Err
END


