

CREATE PROCEDURE [at].[prc_LT_Question_del]
(
	@LanguageID int,
	@QuestionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Question',2,
		( SELECT * FROM [at].[LT_Question] 
			WHERE
			[LanguageID] = @LanguageID AND
			[QuestionID] = @QuestionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_Question]
	WHERE
		[LanguageID] = @LanguageID AND
		[QuestionID] = @QuestionID

	Set @Err = @@Error

	RETURN @Err
END

