
CREATE PROCEDURE [at].[prc_LT_AGroup_get]
(
	@AGID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[AGID],
	[Name],
	[Title],
	[Description]
	FROM [at].[LT_AGroup]
	WHERE
	[AGID] = @AGID

	Set @Err = @@Error

	RETURN @Err
END

