

CREATE PROCEDURE [at].[prc_LT_ScoreTemplate_del]
(
	@ScoreTemplateID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ScoreTemplate',2,
		( SELECT * FROM [at].[LT_ScoreTemplate] 
			WHERE
			[ScoreTemplateID] = @ScoreTemplateID AND
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_ScoreTemplate]
	WHERE
		[ScoreTemplateID] = @ScoreTemplateID AND
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

