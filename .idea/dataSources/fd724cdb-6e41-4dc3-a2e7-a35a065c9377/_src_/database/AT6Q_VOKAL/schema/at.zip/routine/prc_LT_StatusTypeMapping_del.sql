CREATE PROCEDURE [at].[prc_LT_StatusTypeMapping_del]
(
	@LanguageID int,
	@StatusTypeMappingID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_StatusTypeMapping',2,

		( SELECT * FROM [at].[LT_StatusTypeMapping] 
			WHERE
			[LanguageID] = @LanguageID AND
			[StatusTypeMappingID] = @StatusTypeMappingID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	DELETE FROM [at].[LT_StatusTypeMapping]
	WHERE
		[LanguageID] = @LanguageID AND
		[StatusTypeMappingID] = @StatusTypeMappingID
	Set @Err = @@Error
	RETURN @Err
END
