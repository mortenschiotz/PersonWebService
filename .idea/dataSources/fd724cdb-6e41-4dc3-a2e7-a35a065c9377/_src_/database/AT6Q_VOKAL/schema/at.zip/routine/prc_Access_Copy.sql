

CREATE proc [at].[prc_Access_Copy]
(
  @FromSurveyID int,
  @ToSurveyID int
) as
	 insert into at.Access(SurveyID, RoleID, DepartmentID, DepartmentTypeID,CustomerID, PageID, QuestionID, Type, Mandatory)
	 select @ToSurveyID, RoleID, DepartmentID, DepartmentTypeID,Customerid, PageID, QuestionID, Type, Mandatory
	 From at.Access where surveyid = @FromSurveyID

