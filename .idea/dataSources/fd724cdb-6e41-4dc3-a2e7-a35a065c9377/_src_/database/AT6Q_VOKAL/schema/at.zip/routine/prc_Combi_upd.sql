
CREATE PROCEDURE [at].[prc_Combi_upd]
(
	@CombiID int,
	@ChoiceID int,
	@QuestionID int,
	@AlternativeID INT=NULL,
	@ValueFormula varchar(100),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Combi]
	SET
		[ChoiceID] = @ChoiceID,
		[QuestionID] = @QuestionID,
		[AlternativeID] = @AlternativeID,
		[ValueFormula] = @ValueFormula
	WHERE
		[CombiID] = @CombiID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Combi',1,
		( SELECT * FROM [at].[Combi] 
			WHERE
			[CombiID] = @CombiID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

