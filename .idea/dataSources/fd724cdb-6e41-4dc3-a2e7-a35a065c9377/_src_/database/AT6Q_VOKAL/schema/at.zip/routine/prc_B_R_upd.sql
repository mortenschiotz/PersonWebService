CREATE PROCEDURE [at].[prc_B_R_upd]
(
	@BulkID int,
	@RoleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[B_R]
	SET
		[BulkID] = @BulkID,
		[RoleID] = @RoleID
	WHERE
		[BulkID] = @BulkID AND
		[RoleID] = @RoleID

	Set @Err = @@Error

	RETURN @Err
END


