
CREATE PROCEDURE [at].[prc_LT_StatusType_get]
(
	@StatusTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[StatusTypeID],
	[Name],
	[Description],
	[DefaultActionName],
	[DefaultActionDescription]
	FROM [at].[LT_StatusType]
	WHERE
	[StatusTypeID] = @StatusTypeID

	Set @Err = @@Error

	RETURN @Err
END
