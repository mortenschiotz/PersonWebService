
CREATE PROCEDURE [at].[prc_LT_LevelGroup_get]
(
	@LevelGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[LevelGroupID],
	[Name],
	[Description]
	FROM [at].[LT_LevelGroup]
	WHERE
	[LevelGroupID] = @LevelGroupID

	Set @Err = @@Error

	RETURN @Err
END


