

CREATE PROCEDURE [at].[prc_QA_CalcParamter_del]
(
	@QA_CalcParamterID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'QA_CalcParamter',2,
		( SELECT * FROM [at].[QA_CalcParamter] 
			WHERE
			[QA_CalcParamterID] = @QA_CalcParamterID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[QA_CalcParamter]
	WHERE
		[QA_CalcParamterID] = @QA_CalcParamterID

	Set @Err = @@Error

	RETURN @Err
END

