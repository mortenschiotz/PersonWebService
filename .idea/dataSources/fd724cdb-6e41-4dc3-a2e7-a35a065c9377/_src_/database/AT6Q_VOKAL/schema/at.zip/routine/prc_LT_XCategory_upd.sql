
CREATE PROCEDURE [at].[prc_LT_XCategory_upd]
(
	@LanguageID int,
	@XCID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_XCategory]
	SET
		[LanguageID] = @LanguageID,
		[XCID] = @XCID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[XCID] = @XCID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_XCategory',1,
		( SELECT * FROM [at].[LT_XCategory] 
			WHERE
			[LanguageID] = @LanguageID AND
			[XCID] = @XCID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

