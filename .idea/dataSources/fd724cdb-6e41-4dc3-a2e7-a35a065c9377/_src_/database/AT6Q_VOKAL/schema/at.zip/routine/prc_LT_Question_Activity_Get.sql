


-- AT.prc_LT_Question_Activity_Get 19
CREATE Proc [at].[prc_LT_Question_Activity_Get]
(
  @ActivityID int
)
as

Select  LTQ.LanguageID, LTQ.QuestionID, LTQ.Name, LTQ.Title, LTQ.ReportText, LTQ.Description , LTQ.ShortName
from At.Page P
join At.Question Q on Q.Pageid = P.Pageid and P.activityid = @ActivityID
Join at.LT_Question LTQ on LTQ.Questionid = Q.Questionid
Order by LTQ.QuestionID

