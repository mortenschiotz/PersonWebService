CREATE PROCEDURE [at].[prc_DottedRule_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DottedRuleID],
	[ActivityID],
	ISNULL([SurveyID], 0) AS 'SurveyID',
	[Active],
	[UseOnAllQuestions],
	[UseOnAllCategorys],
	[MinResult],
	[MinResultPercentage],
	[FrequencyDottedType],
	[FrequencyDottedLimit],
	[FrequencyDotZeroValues],
	[FrequencyMinAlternativeCountDotted],
	[AverageDottedType],
	[AverageDottedLimit],
    [OnlyDepartmentsBelow],
    FrequencyMinQuestionCountDotted
	FROM [at].[DottedRule]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END
