
CREATE PROCEDURE [at].[prc_SentMail_get]
(
	@MailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SentMailID],
	[MailID],
	[LanguageID],
	[Type],
	[From],
	[Bcc],
	[StatusMail],
	[Status],
	ISNULL([Sent], 0) AS 'Sent',
	[Created]
	FROM [at].[SentMail]
	WHERE
	[MailID] = @MailID

	Set @Err = @@Error

	RETURN @Err
END

