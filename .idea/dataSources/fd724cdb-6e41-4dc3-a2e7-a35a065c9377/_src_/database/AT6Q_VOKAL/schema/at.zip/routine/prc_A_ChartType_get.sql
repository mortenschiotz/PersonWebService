
CREATE PROCEDURE [at].[prc_A_ChartType_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AChartTypeID],
	[ReportChartTypeID],
	[ActivityID],
	[No],
	[DefaultSelected],
	[Created]
	FROM [at].[A_ChartType]
	WHERE
	[ActivityID] = @ActivityID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

