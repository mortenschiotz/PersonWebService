
CREATE PROCEDURE [at].[prc_LT_DottedRule_ins]
(
	@LanguageID int,
	@DottedRuleID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_DottedRule]
	(
		[LanguageID],
		[DottedRuleID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@DottedRuleID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_DottedRule',0,
		( SELECT * FROM [at].[LT_DottedRule] 
			WHERE
			[LanguageID] = @LanguageID AND
			[DottedRuleID] = @DottedRuleID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

