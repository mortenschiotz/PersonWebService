CREATE PROCEDURE [at].[prc_LT_BulkGroup_del]
(
	@LanguageID int,
	@BulkGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_BulkGroup',2,
		( SELECT * FROM [at].[LT_BulkGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[BulkGroupID] = @BulkGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_BulkGroup]
	WHERE
		[LanguageID] = @LanguageID AND
		[BulkGroupID] = @BulkGroupID

	Set @Err = @@Error

	RETURN @Err
END


