
CREATE PROCEDURE [at].[prc_CalcParameter_get]
(
	@CFID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[CalcParameterID],
	[CFID],
	[No],
	[Name],
	ISNULL([QuestionID], 0) AS 'QuestionID',
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	ISNULL([CategoryID], 0) AS 'CategoryID',
	[CalcType],
	[Format],
	[ItemID],
	[Created]
	FROM [at].[CalcParameter]
	WHERE
	[CFID] = @CFID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
