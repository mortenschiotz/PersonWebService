

CREATE PROCEDURE [at].[prc_SentMailFiles_del]
(
	@SentMailFileID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SentMailFiles',2,
		( SELECT * FROM [at].[SentMailFiles] 
			WHERE
			[SentMailFileID] = @SentMailFileID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[SentMailFiles]
	WHERE
		[SentMailFileID] = @SentMailFileID

	Set @Err = @@Error

	RETURN @Err
END

