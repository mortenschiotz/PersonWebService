CREATE PROCEDURE [at].[prc_B_P_upd]
(
	@BulkID int,
	@PageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[B_P]
	SET
		[BulkID] = @BulkID,
		[PageID] = @PageID
	WHERE
		[BulkID] = @BulkID AND
		[PageID] = @PageID

	
	Set @Err = @@Error

	RETURN @Err
END


