CREATE PROCEDURE [at].[prc_LT_Page_ins]
(
	@LanguageID int,
	@PageID int,
	@Name nvarchar(max),
	@Info nvarchar(max),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_Page]
	(
		[LanguageID],
		[PageID],
		[Name],
		[Info],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@PageID,
		@Name,
		@Info,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Page',0,
		( SELECT * FROM [at].[LT_Page] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PageID] = @PageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
