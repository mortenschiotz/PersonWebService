
CREATE PROCEDURE [at].[prc_LT_Category_get]
(
	@CategoryID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[CategoryID],
	[Name],
	[Description],
	[DescriptionExtended]
	FROM [at].[LT_Category]
	WHERE
	[CategoryID] = @CategoryID

	Set @Err = @@Error

	RETURN @Err
END

