
CREATE PROCEDURE [at].[prc_MailFiles_get]
(
	@MailID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[MailFileID],
	[MIMEType],
	[Data],
	[Created],
	[Description],
	[Size],
	ISNULL([Filename], '') AS 'Filename',
	ISNULL([MailID], 0) AS 'MailID'
	FROM [at].[MailFiles]
	WHERE
	[MailID] = @MailID

	Set @Err = @@Error

	RETURN @Err
END

