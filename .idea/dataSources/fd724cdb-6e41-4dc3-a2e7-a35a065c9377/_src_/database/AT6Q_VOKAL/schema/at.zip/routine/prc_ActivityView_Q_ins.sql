CREATE PROCEDURE [at].[prc_ActivityView_Q_ins]  
(  
 @ActivityViewQID int = null output,  
 @ActivityViewID int,  
 @CategoryID int = null,  
 @QuestionID int = null,  
 @AlternativeID int = null,  
 @SectionID int = null,  
 @No smallint,  
 @cUserid int,  
 @Log smallint = 1,
 @ItemID int = NULL
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [at].[ActivityView_Q]  
 (  
  [ActivityViewID],  
  [CategoryID],  
  [QuestionID],  
  [AlternativeID],  
  [SectionID],  
  [No],
  [ItemID]  
 )  
 VALUES  
 (  
  @ActivityViewID,  
  @CategoryID,  
  @QuestionID,  
  @AlternativeID,  
  @SectionID,  
  @No,
  @ItemID  
 )  
  
 Set @Err = @@Error  
 Set @ActivityViewQID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'ActivityView_Q',0,  
  ( SELECT * FROM [at].[ActivityView_Q]   
   WHERE  
   [ActivityViewQID] = @ActivityViewQID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END  
