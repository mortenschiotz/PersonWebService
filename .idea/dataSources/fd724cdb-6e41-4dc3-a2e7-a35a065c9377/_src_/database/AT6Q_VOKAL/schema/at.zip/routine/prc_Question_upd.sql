


CREATE PROCEDURE [at].[prc_Question_upd]
(
	@QuestionID int,
	@PageID int,
	@ScaleID int=null,
	@No smallint,
	@Type smallint,
	@Inverted bit,
	@Mandatory bit,
	@Status smallint,
	@CssClass nvarchar(64),
	@ExtId nvarchar(64),
	@Tag nvarchar(128),
	@SectionID int = NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Question]
	SET
		[PageID] = @PageID,
		[ScaleID] = @ScaleID,
		[No] = @No,
		[Type] = @Type,
		[Inverted] = @Inverted,
		[Mandatory] = @Mandatory,
		[Status] = @Status,
		[CssClass] = @CssClass,
		[ExtId] = @ExtId,
		[Tag] = @Tag,
		[SectionID] = @SectionID
	WHERE
		[QuestionID] = @QuestionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Question',1,
		( SELECT * FROM [at].[Question] 
			WHERE
			[QuestionID] = @QuestionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


