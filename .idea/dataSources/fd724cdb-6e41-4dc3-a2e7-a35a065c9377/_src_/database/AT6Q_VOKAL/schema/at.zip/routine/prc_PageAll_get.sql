


-- at.[prc_PageAll_get] 19
CREATE PROCEDURE [at].[prc_PageAll_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	P.[PageID],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	P.[No] as Pno,
	ISNULL(P.[Created], 0) AS 'PCreated',
	P.[Type] as PType,
	P.CssClass as PCssClass,
	QuestionID,  IsNull(ScaleID,0) 'ScaleID', Q.No as QNo, Q.Type as QType, Inverted, Mandatory, Status, Q.CssClass, P.ExtId, P.Tag, Q.Created as QCreated, ISNULL(SectionID,0) AS SectionID
	FROM [at].[Page] P 
	JOIN [at].[Question] Q on P.Pageid = Q.PageID
	AND [ActivityID] = @ActivityID
	ORDER BY P.[No],Q.No

	Set @Err = @@Error

	RETURN @Err
END



