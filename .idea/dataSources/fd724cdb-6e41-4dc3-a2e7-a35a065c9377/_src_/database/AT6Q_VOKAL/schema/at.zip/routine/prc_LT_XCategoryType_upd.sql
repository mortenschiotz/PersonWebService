

CREATE PROCEDURE [at].[prc_LT_XCategoryType_upd] (
	@LanguageID INT
	,@XCategoryTypeID INT
	,@Name NVARCHAR(256)
	,@Description NVARCHAR(max)
	,@cUserid INT
	,@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	UPDATE [at].[LT_XCategoryType]
	SET [LanguageID] = @LanguageID
		,[XCTypeID] = @XCategoryTypeID
		,[Name] = @Name
		,[Description] = @Description
	WHERE [LanguageID] = @LanguageID
		AND [XCTypeID] = @XCategoryTypeID

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'LT_XCategoryType'
			,1
			,(
				SELECT *
				FROM [at].[LT_XCategoryType]
				WHERE [LanguageID] = @LanguageID
					AND [XCTypeID] = @XCategoryTypeID
				FOR XML AUTO
				) AS data
			,GETDATE()
	END

	SET @Err = @@Error

	RETURN @Err
END
