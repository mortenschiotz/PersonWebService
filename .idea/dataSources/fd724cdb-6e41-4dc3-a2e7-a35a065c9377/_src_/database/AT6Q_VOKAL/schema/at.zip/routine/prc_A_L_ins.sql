
CREATE PROCEDURE [at].[prc_A_L_ins]
(
	@ActivityID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[A_L]
	(
		[ActivityID],
		[LanguageID]
	)
	VALUES
	(
		@ActivityID,
		@LanguageID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_L',0,
		( SELECT * FROM [at].[A_L] 
			WHERE
			[ActivityID] = @ActivityID AND
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

