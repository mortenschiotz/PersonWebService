
-- [at].[prc_RoleMapping_get] null,33
CREATE PROCEDURE [at].[prc_RoleMapping_get]
(
	@SurveyID int = null,
	@ActivityID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	RMID,
	[RoleID],
	ISNULL([ActivityID],0) as ActivityID,
	ISNULL([SurveyID],0) as SurveyID,
	[UserTypeID]
	FROM [at].[RoleMapping]
	WHERE
	( [SurveyID] = @SurveyID AND @ActivityID IS NULL ) 
	OR ([ActivityID] = @ActivityID AND @SurveyID IS NULL)

	Set @Err = @@Error

	RETURN @Err
END
