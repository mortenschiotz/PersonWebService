
CREATE PROCEDURE [at].[prc_LT_AGroup_ins]
(
	@LanguageID int,
	@AGID int,
	@Name nvarchar(256),
	@Title nvarchar(512),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_AGroup]
	(
		[LanguageID],
		[AGID],
		[Name],
		[Title],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@AGID,
		@Name,
		@Title,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_AGroup',0,
		( SELECT * FROM [at].[LT_AGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AGID] = @AGID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

