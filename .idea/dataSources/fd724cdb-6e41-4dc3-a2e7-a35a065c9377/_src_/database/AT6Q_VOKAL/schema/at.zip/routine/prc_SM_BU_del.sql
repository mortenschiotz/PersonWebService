

CREATE PROCEDURE [at].[prc_SM_BU_del]
(
	@SentMailID int,
	@BatchID int,
	@ResultID bigint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SM_BU',2,
		( SELECT * FROM [at].[SM_BU] 
			WHERE
			[SentMailID] = @SentMailID AND
			[BatchID] = @BatchID AND
			[ResultID] = @ResultID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[SM_BU]
	WHERE
		[SentMailID] = @SentMailID AND
		[BatchID] = @BatchID AND
		[ResultID] = @ResultID

	Set @Err = @@Error

	RETURN @Err
END

