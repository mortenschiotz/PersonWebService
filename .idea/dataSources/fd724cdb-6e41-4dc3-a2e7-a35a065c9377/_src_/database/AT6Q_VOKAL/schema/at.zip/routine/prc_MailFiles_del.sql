

CREATE PROCEDURE [at].[prc_MailFiles_del]
(
	@MailFileID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'MailFiles',2,
		( SELECT * FROM [at].[MailFiles] 
			WHERE
			[MailFileID] = @MailFileID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[MailFiles]
	WHERE
		[MailFileID] = @MailFileID

	Set @Err = @@Error

	RETURN @Err
END

