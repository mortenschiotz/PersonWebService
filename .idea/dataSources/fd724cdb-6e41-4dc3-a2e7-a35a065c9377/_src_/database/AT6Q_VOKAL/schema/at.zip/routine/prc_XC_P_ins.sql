CREATE PROCEDURE [at].[prc_XC_P_ins]
(
	@XCID int,
	@PageID int,
	@cUserid int,
	@Log smallint = 1

)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	INSERT INTO [at].[XC_P]
	(
		[XCID],
		[PageID]
	)
	VALUES
	(
		@XCID,
		@PageID
	)
	Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XC_P',0,
		( SELECT * FROM [at].[XC_P] 
			WHERE
			[XCID] = @XCID AND
			[PageID] = @PageID				 FOR XML AUTO) as data,
				getdate() 
	 END
	RETURN @Err
END
