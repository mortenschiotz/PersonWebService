
CREATE PROCEDURE [at].[prc_DottedRule_del]
(
	@DottedRuleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DottedRule',2,
		( SELECT * FROM [at].[DottedRule] 
			WHERE
			[DottedRuleID] = @DottedRuleID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[DottedRule]
	WHERE
		[DottedRuleID] = @DottedRuleID

	Set @Err = @@Error

	RETURN @Err
END

