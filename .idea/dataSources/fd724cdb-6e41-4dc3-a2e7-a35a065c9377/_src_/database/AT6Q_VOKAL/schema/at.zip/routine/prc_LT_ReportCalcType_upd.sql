
CREATE PROCEDURE [at].[prc_LT_ReportCalcType_upd]
(
	@LanguageID int,
	@ReportCalcTypeID int,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_ReportCalcType]
	SET
		[LanguageID] = @LanguageID,
		[ReportCalcTypeID] = @ReportCalcTypeID,
		[Name] = @Name
	WHERE
		[LanguageID] = @LanguageID AND
		[ReportCalcTypeID] = @ReportCalcTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportCalcType',1,
		( SELECT * FROM [at].[LT_ReportCalcType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportCalcTypeID] = @ReportCalcTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

