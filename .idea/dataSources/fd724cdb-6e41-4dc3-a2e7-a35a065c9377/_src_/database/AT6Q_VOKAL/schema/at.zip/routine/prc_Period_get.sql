

CREATE PROCEDURE [at].[prc_Period_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PeriodID],
	[Ownerid],
	[Created],
	[No],
	[StartDate],
	[Enddate],
	[ExtID]
	FROM [at].[Period]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


