
CREATE PROCEDURE [at].[prc_C_A_upd]
(
	@CustomerID int,
	@ActivityID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[C_A]
	SET
		[CustomerID] = @CustomerID,
		[ActivityID] = @ActivityID,
		[No] = @No
	WHERE
		[CustomerID] = @CustomerID AND
		[ActivityID] = @ActivityID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'C_A',1,
		( SELECT * FROM [at].[C_A] 
			WHERE
			[CustomerID] = @CustomerID AND
			[ActivityID] = @ActivityID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

