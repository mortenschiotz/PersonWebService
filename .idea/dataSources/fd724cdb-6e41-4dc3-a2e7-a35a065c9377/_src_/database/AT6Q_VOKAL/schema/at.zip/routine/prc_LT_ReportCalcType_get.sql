
CREATE PROCEDURE [at].[prc_LT_ReportCalcType_get]
(
	@ReportCalcTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ReportCalcTypeID],
	[Name]
	FROM [at].[LT_ReportCalcType]
	WHERE
	[ReportCalcTypeID] = @ReportCalcTypeID

	Set @Err = @@Error

	RETURN @Err
END

