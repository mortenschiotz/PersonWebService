

CREATE PROCEDURE [at].[prc_Page_del]
(
	@PageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Page',2,
		( SELECT * FROM [at].[Page] 
			WHERE
			[PageID] = @PageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[Page]
	WHERE
		[PageID] = @PageID

	Set @Err = @@Error

	RETURN @Err
END

