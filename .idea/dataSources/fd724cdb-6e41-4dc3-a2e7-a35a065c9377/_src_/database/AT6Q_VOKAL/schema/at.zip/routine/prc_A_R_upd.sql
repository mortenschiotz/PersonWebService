
CREATE PROCEDURE [at].[prc_A_R_upd]
(
	@ActivityID int,
	@RoleID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[A_R]
	SET
		[ActivityID] = @ActivityID,
		[RoleID] = @RoleID,
		[No] = @No
	WHERE
		[ActivityID] = @ActivityID AND
		[RoleID] = @RoleID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'A_R',1,
		( SELECT * FROM [at].[A_R] 
			WHERE
			[ActivityID] = @ActivityID AND
			[RoleID] = @RoleID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

