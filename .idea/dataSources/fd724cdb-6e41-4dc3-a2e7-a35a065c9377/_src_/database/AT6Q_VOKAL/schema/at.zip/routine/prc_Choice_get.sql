CREATE PROCEDURE [at].[prc_Choice_get] (
	@SurveyID INT = NULL
	,@ActivityID INT = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	SELECT [ChoiceID]
		,ISNULL([ActivityID], 0) AS 'ActivityID'
		,ISNULL([SurveyID], 0) AS 'SurveyID'
		,ISNULL([RoleID], 0) AS 'RoleID'
		,ISNULL([DepartmentID], 0) AS 'DepartmentID'
		,ISNULL([HDID], 0) AS 'HDID'
		,ISNULL([DepartmentTypeID], 0) AS 'DepartmentTypeID'
		,ISNULL([UserGroupID], 0) AS 'UserGroupID'
		,ISNULL([UserTypeID], 0) AS 'UserTypeID'
		,[Name]
		,[No]
		,[Type]
		,[Created]
	FROM [at].[Choice]
	WHERE (
			[SurveyID] = @SurveyID
			AND @ActivityID IS NULL
			)
		OR (
			[ActivityID] = @ActivityID
			AND @SurveyID IS NULL
			)
	ORDER BY [No]

	SET @Err = @@Error

	RETURN @Err
END
