
CREATE PROCEDURE [at].[prc_XCategoryType_upd] (
	@XCategoryTypeID INT
	,@OwnerID INT
	,@ExtID NVARCHAR(64)
	,@No SMALLINT
	,@cUserid INT
	,@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	UPDATE [at].[XCategoryType]
	SET [OwnerID] = @OwnerID
		,[ExtID] = @ExtID
		,[No] = @No
	WHERE [XCTypeID] = @XCategoryTypeID

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'XCategoryType'
			,1
			,(
				SELECT *
				FROM [at].[XCategoryType]
				WHERE [XCTypeID] = @XCategoryTypeID
				FOR XML AUTO
				) AS data
			,GETDATE()
	END

	SET @Err = @@Error

	RETURN @Err
END
