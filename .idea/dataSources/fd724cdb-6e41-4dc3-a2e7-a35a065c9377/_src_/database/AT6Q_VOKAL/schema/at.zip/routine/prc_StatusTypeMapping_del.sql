
CREATE PROCEDURE [at].[prc_StatusTypeMapping_del]
(
	@StatusTypeMappingID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'StatusTypeMapping',2,
		( SELECT * FROM [at].[StatusTypeMapping] 
			WHERE
			[StatusTypeMappingID] = @StatusTypeMappingID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[StatusTypeMapping]
	WHERE
		[StatusTypeMappingID] = @StatusTypeMappingID

	Set @Err = @@Error

	RETURN @Err
END

