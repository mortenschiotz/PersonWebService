
CREATE PROCEDURE [at].[prc_ActivityView_Q_get]
(
	@ActivityViewID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityViewQID],
	[ActivityViewID],
	ISNULL([CategoryID], 0) AS 'CategoryID',
	ISNULL([QuestionID], 0) AS 'QuestionID',
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	ISNULL([SectionID], 0) AS 'SectionID',
	[No],
	[ItemID]
	FROM [at].[ActivityView_Q]
	WHERE
	[ActivityViewID] = @ActivityViewID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

