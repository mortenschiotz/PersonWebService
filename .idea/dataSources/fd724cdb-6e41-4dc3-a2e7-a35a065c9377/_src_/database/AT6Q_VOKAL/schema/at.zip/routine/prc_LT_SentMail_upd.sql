
CREATE PROCEDURE [at].[prc_LT_SentMail_upd]
(
	@LanguageID int,
	@SentMailID int,
	@Name nvarchar(256),
	@Subject nvarchar(256),
	@Body nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[LT_SentMail]
	SET
		[LanguageID] = @LanguageID,
		[SentMailID] = @SentMailID,
		[Name] = @Name,
		[Subject] = @Subject,
		[Body] = @Body
	WHERE
		[LanguageID] = @LanguageID AND
		[SentMailID] = @SentMailID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_SentMail',1,
		( SELECT * FROM [at].[LT_SentMail] 
			WHERE
			[LanguageID] = @LanguageID AND
			[SentMailID] = @SentMailID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

