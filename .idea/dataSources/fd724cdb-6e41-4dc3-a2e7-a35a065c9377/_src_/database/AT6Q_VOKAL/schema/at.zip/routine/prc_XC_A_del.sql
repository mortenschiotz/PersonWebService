

CREATE PROCEDURE [at].[prc_XC_A_del]
(
	@XCID int,
	@ActivityID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XC_A',2,
		( SELECT * FROM [at].[XC_A] 
			WHERE
			[XCID] = @XCID AND
			[ActivityID] = @ActivityID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[XC_A]
	WHERE
		[XCID] = @XCID AND
		[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END

