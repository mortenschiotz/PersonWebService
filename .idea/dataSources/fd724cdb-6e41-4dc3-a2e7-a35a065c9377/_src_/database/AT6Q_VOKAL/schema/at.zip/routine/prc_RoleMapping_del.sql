


CREATE PROCEDURE [at].[prc_RoleMapping_del]
(
	@RMID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'RoleMapping',2,
		( SELECT * FROM [at].[RoleMapping] 
			WHERE
			[RMID] = @RMID 
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[RoleMapping]
	WHERE
		[RMID] = @RMID 

	Set @Err = @@Error

	RETURN @Err
END


