

CREATE PROCEDURE [at].[prc_Alternative_del]
(
	@AlternativeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Alternative',2,
		( SELECT * FROM [at].[Alternative] 
			WHERE
			[AlternativeID] = @AlternativeID
			 FOR XML AUTO) as data,
			getdate() 
	END 

	DELETE FROM [at].[Alternative]
	WHERE
		[AlternativeID] = @AlternativeID

	Set @Err = @@Error

	RETURN @Err
END

