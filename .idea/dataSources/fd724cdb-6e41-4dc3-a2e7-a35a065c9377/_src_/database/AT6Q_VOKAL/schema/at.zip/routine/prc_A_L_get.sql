
CREATE PROCEDURE [at].[prc_A_L_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityID],
	[LanguageID]
	FROM [at].[A_L]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END

