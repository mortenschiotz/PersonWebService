CREATE PROCEDURE [at].[prc_B_P_ins]
(
	@BulkID int,
	@PageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[B_P]
	(
		[BulkID],
		[PageID]
	)
	VALUES
	(
		@BulkID,
		@PageID
	)

	Set @Err = @@Error


	RETURN @Err
END


