
CREATE PROCEDURE [at].[prc_LT_LevelGroup_del]
(
	@LanguageID int,
	@LevelGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LevelGroup',2,
		( SELECT * FROM [at].[LT_LevelGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[LevelGroupID] = @LevelGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[LT_LevelGroup]
	WHERE
		[LanguageID] = @LanguageID AND
		[LevelGroupID] = @LevelGroupID

	Set @Err = @@Error

	RETURN @Err
END

