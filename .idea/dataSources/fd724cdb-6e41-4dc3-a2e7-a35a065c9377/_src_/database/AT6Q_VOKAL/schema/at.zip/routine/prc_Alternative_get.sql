CREATE PROCEDURE [at].[prc_Alternative_get]
(
	@ScaleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AlternativeID],
	[ScaleID],
	ISNULL([AGID], 0) AS 'AGID',
	[Type],
	[No],
	[Value],
	[InvertedValue],
	[Calc],
	[SC],
	[MinValue],
	[MaxValue],
	[Format],
	[Size],
	[CssClass],
	[Created],
	[DefaultValue],
	[Tag],
	[ExtID],
	[Width],
	ISNULL([OwnerColorID],0) as 'OwnerColorID',
	DefaultCalcType,
    ParentID,
    UseEncryption
	FROM [at].[Alternative]
	WHERE
	[ScaleID] = @ScaleID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
