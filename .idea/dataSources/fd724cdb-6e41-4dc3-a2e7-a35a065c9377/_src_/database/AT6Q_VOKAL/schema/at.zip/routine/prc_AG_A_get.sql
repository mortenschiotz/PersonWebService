CREATE PROCEDURE [at].[prc_AG_A_get]
(
	@AGID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AGID],
	[AlternativeID]
	FROM [at].[AG_A]
	WHERE
	[AGID] = @AGID

	Set @Err = @@Error

	RETURN @Err
END
