CREATE PROCEDURE [at].[prc_S_CT_del]
(
	@ScaleID int,
	@ReportCalcTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'S_CT',2,
		( SELECT * FROM [at].[S_CT] 
			WHERE
			[ScaleID] = @ScaleID AND
			[ReportCalcTypeID] = @ReportCalcTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [at].[S_CT]
	WHERE
		[ScaleID] = @ScaleID AND
		[ReportCalcTypeID] = @ReportCalcTypeID

	Set @Err = @@Error

	RETURN @Err
END

