
CREATE PROCEDURE [at].[prc_LT_LevelGroup_ins]
(
	@LanguageID int,
	@LevelGroupID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_LevelGroup]
	(
		[LanguageID],
		[LevelGroupID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@LevelGroupID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LevelGroup',0,
		( SELECT * FROM [at].[LT_LevelGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[LevelGroupID] = @LevelGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


