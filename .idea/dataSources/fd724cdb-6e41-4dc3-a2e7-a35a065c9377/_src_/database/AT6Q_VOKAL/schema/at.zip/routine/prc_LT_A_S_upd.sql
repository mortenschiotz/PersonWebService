CREATE PROCEDURE [at].[prc_LT_A_S_upd] (
	@ASID INT,
	@LanguageID INT,
	@StatusName NVARCHAR(512),
	@StatusDescription NVARCHAR(512),
	@ReadOnlyText NVARCHAR(MAX) = '',
	@cUserid INT,
	@Log SMALLINT = 1
	)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	UPDATE [at].[LT_A_S]
	SET [LanguageID] = @LanguageID,
		[StatusName] = @StatusName,
		[StatusDescription] = @StatusDescription,
		[ReadOnlyText] = @ReadOnlyText
	WHERE [LanguageID] = @LanguageID
		AND [ASID] = @ASID

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId,
			TableName,
			Type,
			Data,
			Created
			)
		SELECT @cUserid,
			'LT_A_S',
			1,
			(
				SELECT *
				FROM [at].[LT_A_S]
				WHERE [LanguageID] = @LanguageID
					AND [ASID] = @ASID
				FOR XML AUTO
				) AS data,
			getdate()
	END

	SET @Err = @@Error

	RETURN @Err
END
