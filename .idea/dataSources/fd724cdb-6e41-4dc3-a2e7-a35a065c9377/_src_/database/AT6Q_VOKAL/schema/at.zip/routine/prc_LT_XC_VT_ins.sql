
CREATE PROCEDURE [at].[prc_LT_XC_VT_ins]
(
	@LanguageID int,
	@XCVTID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@TextAbove nvarchar(max),
	@TextBelow nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[LT_XC_VT]
	(
		[LanguageID],
		[XCVTID],
		[Name],
		[Description],
		[TextAbove],
		[TextBelow]
	)
	VALUES
	(
		@LanguageID,
		@XCVTID,
		@Name,
		@Description,
		@TextAbove,
		@TextBelow
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_XC_VT',0,
		( SELECT * FROM [at].[LT_XC_VT] 
			WHERE
			[LanguageID] = @LanguageID AND
			[XCVTID] = @XCVTID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

