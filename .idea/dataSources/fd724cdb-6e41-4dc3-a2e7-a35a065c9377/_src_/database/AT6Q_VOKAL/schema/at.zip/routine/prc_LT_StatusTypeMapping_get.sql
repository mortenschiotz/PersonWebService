
CREATE PROCEDURE [at].[prc_LT_StatusTypeMapping_get]
(
	@StatusTypeMappingID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	SELECT
	[LanguageID],
	[StatusTypeMappingID],
	[ActionName],
	[ActionDescription]
	FROM [at].[LT_StatusTypeMapping]
	WHERE
	[StatusTypeMappingID] = @StatusTypeMappingID
	Set @Err = @@Error
	RETURN @Err

END
