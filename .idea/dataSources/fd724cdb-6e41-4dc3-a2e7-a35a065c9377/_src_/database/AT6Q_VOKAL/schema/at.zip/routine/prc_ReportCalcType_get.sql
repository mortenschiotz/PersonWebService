
CREATE PROCEDURE [at].[prc_ReportCalcType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportCalcTypeID],
	[No],
	[Created]
	FROM [at].[ReportCalcType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

