CREATE PROCEDURE [at].[prc_UG_R_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[UserGroupID],
	[ActivityID],
	[RoleID]
	FROM [at].[UG_R]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END