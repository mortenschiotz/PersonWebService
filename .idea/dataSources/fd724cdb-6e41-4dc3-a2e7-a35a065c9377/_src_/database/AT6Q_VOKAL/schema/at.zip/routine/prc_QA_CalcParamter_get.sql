
CREATE PROCEDURE [at].[prc_QA_CalcParamter_get]
(
	@CFID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[QA_CalcParamterID],
	[CFID],
	[No],
	[Name],
	ISNULL([QuestionID], 0) AS 'QuestionID',
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	ISNULL([CategoryID], 0) AS 'CategoryID',
	[CalcType],
	[Format],
	[Created]
	FROM [at].[QA_CalcParamter]
	WHERE
	[CFID] = @CFID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

