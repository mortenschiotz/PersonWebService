CREATE PROC AT.prc_survey_lastprocessed
(
  @SurveyID INT
 )
 AS
 BEGIN
   UPDATE AT.Survey SET LastProcessed = '1900-01-01'
   WHERE SurveyID = @SurveyID
 
 END