CREATE PROCEDURE [at].[prc_Action_upd]
(
	@ActionID int,
	@ChoiceID int,
	@No smallint,
	@PageID INT=NULL,
	@QuestionID int = null,
	@AlternativeID int = null,
	@Type smallint,
	@AVTID  int =null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[Action]
	SET
		[ChoiceID] = @ChoiceID,
		[No] = @No,
		[PageID] = @PageID,
		[QuestionID] = @QuestionID,
		[AlternativeID] = @AlternativeID,
		[Type] = @Type,
		[AVTID]=@AVTID
	WHERE
		[ActionID] = @ActionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Action',1,
		( SELECT * FROM [at].[Action] 
			WHERE
			[ActionID] = @ActionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
