
CREATE PROCEDURE [at].[prc_Q_C_get]
(
	@CategoryID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[QuestionID],
	[CategoryID],
	[Weight],
	[No],
	[ItemID],
	[Visible]
	FROM [at].[Q_C]
	WHERE
	[CategoryID] = @CategoryID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

