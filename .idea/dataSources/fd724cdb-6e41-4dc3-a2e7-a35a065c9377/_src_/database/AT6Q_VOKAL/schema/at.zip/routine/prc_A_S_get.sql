
CREATE PROCEDURE [at].[prc_A_S_get] 
(
	@ActivityID INT
)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Err INT

	SELECT [ASID],
		[ActivityID],
		[StatusTypeID],
		[No]
	FROM [at].[A_S]
	WHERE [ActivityID] = @ActivityID
	ORDER BY [No]

	SET @Err = @@Error

	RETURN @Err
END

