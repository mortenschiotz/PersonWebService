CREATE PROCEDURE [at].[prc_XCategory_ins]
(
	@XCID int = null output,
	@ParentID int = null,
	@OwnerID int,
	@Type smallint,
	@Status smallint,
	@No smallint,
	@ExtId NVARCHAR(128) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [at].[XCategory]
	(
		[ParentID],
		[OwnerID],
		[Type],
		[Status],
		[No],
		[ExtId]
	)
	VALUES
	(
		@ParentID,
		@OwnerID,
		@Type,
		@Status,
		@No,
		@ExtId
	)

	Set @Err = @@Error
	Set @XCID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'XCategory',0,
		( SELECT * FROM [at].[XCategory] 
			WHERE
			[XCID] = @XCID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
