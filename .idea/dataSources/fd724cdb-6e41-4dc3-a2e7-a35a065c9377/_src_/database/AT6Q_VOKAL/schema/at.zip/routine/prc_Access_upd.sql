CREATE PROCEDURE [at].[prc_Access_upd]  
(  
 @AccessID int,  
 @SurveyID int,  
 @BatchID int = null,  
 @RoleID int=null,  
 @DepartmentID int=null,  
 @DepartmentTypeID int=null,  
 @HDID int=null,  
 @CustomerID int=null,  
 @PageID int=null,  
 @QuestionID int=null,  
 @Type smallint,  
 @Mandatory bit,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 UPDATE [at].[Access]  
 SET  
  [SurveyID] = @SurveyID,  
  [BatchID] = @BatchID,  
  [RoleID] = @RoleID,  
  [DepartmentID] = @DepartmentID,  
  [DepartmentTypeID] = @DepartmentTypeID,  
  [HDID] = @HDID,
  [CustomerID] = @CustomerID,  
  [PageID] = @PageID,  
  [QuestionID] = @QuestionID,  
  [Type] = @Type,  
  [Mandatory] = @Mandatory  
 WHERE  
  [AccessID] = @AccessID  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Access',1,  
  ( SELECT * FROM [at].[Access]   
   WHERE  
   [AccessID] = @AccessID    FOR XML AUTO) as data,  
   getdate()  
 END  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
