
CREATE PROCEDURE [at].[prc_StatusLog_upd]
(
	@StatusLogID int,
	@StatusTypeID int,
	@ResultID bigint = null,
	@CVID int = null,
	@UserID int,
	@Comment ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [at].[StatusLog]
	SET
		[StatusTypeID] = @StatusTypeID,
		[ResultID] = @ResultID,
		[CVID] = @CVID,
		[UserID] = @UserID,
		[Comment] = @Comment
	WHERE
		[StatusLogID] = @StatusLogID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'StatusLog',1,
		( SELECT * FROM [at].[StatusLog] 
			WHERE
			[StatusLogID] = @StatusLogID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

