

CREATE PROCEDURE [rep].[prc_Selection_DT_del]
(
	@SelectionID int,
	@DepartmentTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_DT',2,
		( SELECT * FROM [rep].[Selection_DT] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentTypeID] = @DepartmentTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[Selection_DT]
	WHERE
		[SelectionID] = @SelectionID AND
		[DepartmentTypeID] = @DepartmentTypeID

	Set @Err = @@Error

	RETURN @Err
END

