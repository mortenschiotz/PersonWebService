
CREATE PROCEDURE [rep].[prc_ReportColumnType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportColumnTypeID],
	[No]
	FROM [rep].[ReportColumnType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

