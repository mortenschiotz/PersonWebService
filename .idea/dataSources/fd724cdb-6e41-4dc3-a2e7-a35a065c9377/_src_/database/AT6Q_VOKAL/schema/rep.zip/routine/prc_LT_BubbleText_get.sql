
CREATE PROCEDURE [rep].[prc_LT_BubbleText_get]
(
	@BubbleTextID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[BubbleTextID],
	[Name],
	[Description]
	FROM [rep].[LT_BubbleText]
	WHERE
	[BubbleTextID] = @BubbleTextID

	Set @Err = @@Error

	RETURN @Err
END

