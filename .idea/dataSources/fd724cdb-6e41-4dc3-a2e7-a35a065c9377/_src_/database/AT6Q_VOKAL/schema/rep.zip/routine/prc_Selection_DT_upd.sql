
CREATE PROCEDURE [rep].[prc_Selection_DT_upd]
(
	@SelectionID int,
	@DepartmentTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[Selection_DT]
	SET
		[SelectionID] = @SelectionID,
		[DepartmentTypeID] = @DepartmentTypeID
	WHERE
		[SelectionID] = @SelectionID AND
		[DepartmentTypeID] = @DepartmentTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_DT',1,
		( SELECT * FROM [rep].[Selection_DT] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentTypeID] = @DepartmentTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

