
CREATE PROCEDURE [rep].[prc_LT_ReportColumn_upd]
(
	@LanguageID int,
	@ReportColumnID int,
	@Text nvarchar(max),
	@ToolTip nvarchar(512) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[LT_ReportColumn]
	SET
		[LanguageID] = @LanguageID,
		[ReportColumnID] = @ReportColumnID,
		[Text] = @Text,
		[ToolTip] = @ToolTip
	WHERE
		[LanguageID] = @LanguageID AND
		[ReportColumnID] = @ReportColumnID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportColumn',1,
		( SELECT * FROM [rep].[LT_ReportColumn] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportColumnID] = @ReportColumnID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


