
CREATE PROCEDURE [rep].[prc_Bubble_get]
(
	@OwnerID	int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BubbleID],
	[OwnerID],
	[ActivityID],
	[No],
	[Status],
	[Created]
	FROM [rep].[Bubble]
	WHERE OwnerID = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

