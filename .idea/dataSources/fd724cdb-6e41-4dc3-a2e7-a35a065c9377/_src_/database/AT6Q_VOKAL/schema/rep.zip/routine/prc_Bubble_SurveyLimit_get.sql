
CREATE PROCEDURE [rep].[prc_Bubble_SurveyLimit_get]
(
	@BubbleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BubbleID],
	[SurveyID],
	[AxisNo],
	[LimitLow],
	[LimitHigh]
	FROM [rep].[Bubble_SurveyLimit]
	WHERE
	[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

