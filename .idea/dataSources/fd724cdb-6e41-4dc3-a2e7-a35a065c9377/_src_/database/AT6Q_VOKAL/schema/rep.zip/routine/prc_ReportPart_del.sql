

CREATE PROCEDURE [rep].[prc_ReportPart_del]
(
	@ReportPartID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportPart',2,
		( SELECT * FROM [rep].[ReportPart] 
			WHERE
			[ReportPartID] = @ReportPartID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[ReportPart]
	WHERE
		[ReportPartID] = @ReportPartID

	Set @Err = @@Error

	RETURN @Err
END

