


CREATE PROCEDURE [rep].[prc_LT_ReportPart_get]
(
	@ReportPartID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ReportPartID],
	[Text],
	[Title]
	FROM [rep].[LT_ReportPart]
	WHERE
	[ReportPartID] = @ReportPartID

	Set @Err = @@Error

	RETURN @Err
END


