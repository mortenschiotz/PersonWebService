
CREATE PROCEDURE [rep].[prc_LT_Bubble_upd]
(
	@LanguageID int,
	@BubbleID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[LT_Bubble]
	SET
		[LanguageID] = @LanguageID,
		[BubbleID] = @BubbleID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[BubbleID] = @BubbleID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Bubble',1,
		( SELECT * FROM [rep].[LT_Bubble] 
			WHERE
			[LanguageID] = @LanguageID AND
			[BubbleID] = @BubbleID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

