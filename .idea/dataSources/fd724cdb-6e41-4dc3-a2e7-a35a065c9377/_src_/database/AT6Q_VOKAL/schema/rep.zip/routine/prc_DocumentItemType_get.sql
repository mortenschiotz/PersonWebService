

CREATE PROCEDURE [rep].[prc_DocumentItemType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DocumentItemTypeID],
	[Name],
	[Created]
	FROM [rep].[DocumentItemType]

	Set @Err = @@Error

	RETURN @Err
END


