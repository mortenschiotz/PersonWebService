CREATE PROCEDURE [rep].[prc_UAS_Question_del]       
(        
 @UserActivitySettingID int,
 @QuestionID int,
 @cUserid int,
 @Log smallint = 1
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'UAS_Question',2,        
  (SELECT * FROM [rep].[UAS_Question]
   WHERE        
		[UserActivitySettingID] = @UserActivitySettingID
		AND [QuestionID] = @QuestionID
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [rep].[UAS_Question]
 WHERE        
  [UserActivitySettingID] = @UserActivitySettingID
  AND [QuestionID] = @QuestionID
 Set @Err = @@Error        
        
 RETURN @Err        
END 
