

CREATE PROCEDURE [rep].[prc_DocumentTemplate_get]
(
	@Ownerid int,
	@ActivityID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DocumentTemplateID],
	[DocumentFormatID],
	[OwnerID],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	[Template],
	[Created],
	ISNULL([CustomerID], 0) AS 'CustomerID'
	FROM [rep].[DocumentTemplate]
	WHERE
	[OwnerID] = @Ownerid and
	( [ActivityID] = @ActivityID OR  @ActivityID is NULL)

	Set @Err = @@Error

	RETURN @Err
END



