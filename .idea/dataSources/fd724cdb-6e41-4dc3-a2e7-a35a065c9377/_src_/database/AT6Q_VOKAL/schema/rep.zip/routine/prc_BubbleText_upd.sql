
CREATE PROCEDURE [rep].[prc_BubbleText_upd]
(
	@BubbleTextID int,
	@BubbleID int,
	@No smallint,
	@FillColor varchar(16),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[BubbleText]
	SET
		[BubbleID] = @BubbleID,
		[No] = @No,
		[FillColor] = @FillColor
	WHERE
		[BubbleTextID] = @BubbleTextID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'BubbleText',1,
		( SELECT * FROM [rep].[BubbleText] 
			WHERE
			[BubbleTextID] = @BubbleTextID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

