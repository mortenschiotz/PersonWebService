
CREATE PROCEDURE [rep].[prc_Selection_User_upd]
(
	@SelectionID int,
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[Selection_User]
	SET
		[SelectionID] = @SelectionID,
		[UserID] = @UserID
	WHERE
		[SelectionID] = @SelectionID AND
		[UserID] = @UserID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_User',1,
		( SELECT * FROM [rep].[Selection_User] 
			WHERE
			[SelectionID] = @SelectionID AND
			[UserID] = @UserID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

