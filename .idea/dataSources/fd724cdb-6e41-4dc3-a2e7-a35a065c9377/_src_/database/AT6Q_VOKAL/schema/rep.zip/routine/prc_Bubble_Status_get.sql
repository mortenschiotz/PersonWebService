
CREATE PROCEDURE [rep].[prc_Bubble_Status_get]
(
	@BubbleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BubbleID],
	[SurveyID],
	[LastProcessedDate],
	ISNULL([Reprocess], 0) AS 'Reprocess'
	FROM [rep].[Bubble_Status]
	WHERE
	[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

