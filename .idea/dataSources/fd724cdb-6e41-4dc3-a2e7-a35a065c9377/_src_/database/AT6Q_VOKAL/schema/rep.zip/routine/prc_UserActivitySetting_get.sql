CREATE PROCEDURE [rep].[prc_UserActivitySetting_get]
 @UserID int,
 @ActivityID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserActivitySettingID]
	,[UserID]
	,[ActivityID]
	,[ShowTable]
	,[ShowChart]
	,[ChartTypeID]
	,[ChartTypeIDAvg]
	,[ShowPage]
	,[ShowCategory]
	,[ShowCategoryType]
 FROM             
  [rep].[UserActivitySetting]     
 WHERE        
  [UserID] = @UserID      
  AND [ActivityID] = @ActivityID
 Set @Err = @@Error      
      
 RETURN @Err      
END 
