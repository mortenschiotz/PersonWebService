

CREATE PROCEDURE [rep].[prc_ReportFilter_upd]
(
	@ActivityID int,
	@QuestionID int,
	@FilterDim bit,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[ReportFilter]
	SET
		[ActivityID] = @ActivityID,
		[QuestionID] = @QuestionID,
		[FilterDim] = @FilterDim 
	WHERE
		[ActivityID] = @ActivityID AND
		[QuestionID] = @QuestionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportFilter',1,
		( SELECT * FROM [rep].[ReportFilter] 
			WHERE
			[ActivityID] = @ActivityID AND
			[QuestionID] = @QuestionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


