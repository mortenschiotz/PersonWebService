
CREATE PROCEDURE [rep].[prc_Selection_DT_ins]
(
	@SelectionID int,
	@DepartmentTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_DT]
	(
		[SelectionID],
		[DepartmentTypeID]
	)
	VALUES
	(
		@SelectionID,
		@DepartmentTypeID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_DT',0,
		( SELECT * FROM [rep].[Selection_DT] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentTypeID] = @DepartmentTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

