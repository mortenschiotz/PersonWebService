

CREATE PROCEDURE [rep].[prc_LT_DocumentTemplate_get]
(
	@LanguageID int,
	@DocumentTemplateID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[DocumentTemplateID],
	[yStartPos],
	[FileContent],
	[MIMEType],
	[Size]
	FROM [rep].[LT_DocumentTemplate]
	WHERE
		[LanguageID] = @LanguageID
		AND [DocumentTemplateID] = @DocumentTemplateID

	Set @Err = @@Error

	RETURN @Err
END



