
CREATE PROCEDURE [rep].[prc_BubbleText_ins]
(
	@BubbleTextID int output,
	@BubbleID int,
	@No smallint,
	@FillColor varchar(16),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[BubbleText]
	(
		[BubbleID],
		[No],
		[FillColor]
	)
	VALUES
	(
		@BubbleID,
		@No,
		@FillColor
	)
  Set @BubbleTextID = scope_identity()
	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'BubbleText',0,
		( SELECT * FROM [rep].[BubbleText] 
			WHERE
			[BubbleTextID] = @BubbleTextID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

