
CREATE PROCEDURE [rep].[prc_LT_Bubble_get]
(
	@BubbleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[BubbleID],
	[Name],
	[Description]
	FROM [rep].[LT_Bubble]
	WHERE
	[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

