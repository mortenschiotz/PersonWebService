
CREATE PROCEDURE [rep].[prc_ReportRowType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportRowTypeID],
	[No]
	FROM [rep].[ReportRowType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

