

CREATE PROCEDURE [rep].[prc_DocumentFormat_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DocumentFormatID],
	[Name],
	[Created]
	FROM [rep].[DocumentFormat]

	Set @Err = @@Error

	RETURN @Err
END


