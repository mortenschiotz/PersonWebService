
CREATE PROCEDURE [rep].[prc_DocumentFormat_del]
(
	@DocumentFormatID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DocumentFormat',2,
		( SELECT * FROM [rep].[DocumentFormat] 
			WHERE
			[DocumentFormatID] = @DocumentFormatID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[DocumentFormat]
	WHERE
		[DocumentFormatID] = @DocumentFormatID

	Set @Err = @@Error

	RETURN @Err
END


