

CREATE PROCEDURE [rep].[prc_LT_ReportColumn_del]
(
	@LanguageID int,
	@ReportColumnID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportColumn',2,
		( SELECT * FROM [rep].[LT_ReportColumn] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportColumnID] = @ReportColumnID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[LT_ReportColumn]
	WHERE
		[LanguageID] = @LanguageID AND
		[ReportColumnID] = @ReportColumnID

	Set @Err = @@Error

	RETURN @Err
END

