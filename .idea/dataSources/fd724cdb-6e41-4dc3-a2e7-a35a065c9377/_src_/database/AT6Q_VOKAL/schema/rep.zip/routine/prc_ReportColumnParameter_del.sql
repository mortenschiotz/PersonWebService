

CREATE PROCEDURE [rep].[prc_ReportColumnParameter_del]
(
	@ReportColumnParameterID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportColumnParameter',2,
		( SELECT * FROM [rep].[ReportColumnParameter] 
			WHERE
			[ReportColumnParameterID] = @ReportColumnParameterID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[ReportColumnParameter]
	WHERE
		[ReportColumnParameterID] = @ReportColumnParameterID

	Set @Err = @@Error

	RETURN @Err
END

