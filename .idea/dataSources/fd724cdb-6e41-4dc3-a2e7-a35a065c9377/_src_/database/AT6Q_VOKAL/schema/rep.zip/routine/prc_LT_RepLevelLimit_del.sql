CREATE PROCEDURE [rep].[prc_LT_RepLevelLimit_del]
(
	@RepLevelLimitID int,
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_RepLevelLimit',2,
		( SELECT * FROM [rep].[LT_RepLevelLimit] 
			WHERE
			[RepLevelLimitID] = @RepLevelLimitID AND
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[LT_RepLevelLimit]
	WHERE
		[RepLevelLimitID] = @RepLevelLimitID AND
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

