

CREATE PROCEDURE [rep].[prc_ReportRow_del]
(
	@ReportRowID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportRow',2,
		( SELECT * FROM [rep].[ReportRow] 
			WHERE
			[ReportRowID] = @ReportRowID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[ReportRow]
	WHERE
		[ReportRowID] = @ReportRowID

	Set @Err = @@Error

	RETURN @Err
END

