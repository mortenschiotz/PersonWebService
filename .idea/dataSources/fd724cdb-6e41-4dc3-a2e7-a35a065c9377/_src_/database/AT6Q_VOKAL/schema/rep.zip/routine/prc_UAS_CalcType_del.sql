CREATE PROCEDURE [rep].[prc_UAS_CalcType_del]       
(        
 @UserActivitySettingID int,
 @ReportCalcTypeID int,
 @cUserid int,
 @Log smallint = 1
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'UAS_CalcType',2,        
  (SELECT * FROM [rep].[UAS_CalcType]
   WHERE        
		[UserActivitySettingID] = @UserActivitySettingID
		AND [ReportCalcTypeID] = @ReportCalcTypeID
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [rep].[UAS_CalcType]
 WHERE        
	[UserActivitySettingID] = @UserActivitySettingID
	AND [ReportCalcTypeID] = @ReportCalcTypeID
 Set @Err = @@Error        
        
 RETURN @Err        
END 
