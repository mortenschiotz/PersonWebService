CREATE PROCEDURE [rep].[prc_DocumentTemplate_get_ext]
(		
	@SiteID	int,
	@DocumentFormatID int,
	@ActivityId int,
	@DepartmentId int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err int
	DECLARE @OwnerID int	
	DECLARE @ResultTemplateID int = null
	DECLARE @CustomerId int = null
	
	SET @OwnerID = (SELECT OwnerID FROM [app].[Site] WHERE SiteID = @SiteID)
	IF (@DepartmentId > 0)
	BEGIN
		SET @CustomerId = (SELECT CustomerID FROM org.[Department] WHERE DepartmentID = @DepartmentId)
	END	
	
	IF (@ActivityId = 0) SET @ActivityId = NULL
		
	-- If as document exist with the correct Activityid and Customerid	
	SET @ResultTemplateID = (SELECT TOP 1 DocumentTemplateID FROM [rep].[DocumentTemplate] WHERE CustomerID = @CustomerId AND ActivityID = @ActivityId AND OwnerID = @OwnerID AND DocumentFormatID = @DocumentFormatID)
	IF (@ResultTemplateID is not NULL)
	BEGIN
		GOTO CommitResult
	END
	
	-- If a document exist with the correct Customerid and the ActivityID is set to null
	SET @ResultTemplateID = (SELECT TOP 1 DocumentTemplateID FROM [rep].[DocumentTemplate] WHERE CustomerID = @CustomerId AND ActivityID is NULL AND OwnerID = @OwnerID AND DocumentFormatID = @DocumentFormatID)
	IF (@ResultTemplateID is not NULL)
	BEGIN		
		GOTO CommitResult
	END
	
	-- If as document exist whit the correct Activityid and the customerid is set to null
	SET @ResultTemplateID = (SELECT TOP 1 DocumentTemplateID FROM [rep].[DocumentTemplate] WHERE CustomerID is NULL AND ActivityID = @ActivityId AND OwnerID = @OwnerID AND DocumentFormatID = @DocumentFormatID)
	IF (@ResultTemplateID is not NULL)
	BEGIN
		GOTO CommitResult
	END
	
	-- If a document exist with  null in both ActivityID and CustomerID, use the global template depend on Document Format ID
	IF @DocumentFormatID > 0
	BEGIN
		IF @DocumentFormatID = 1
			SET @ResultTemplateID  = (SELECT [Value] FROM [app].[SiteParameter] WHERE [Key] = 'ExportTemplateWordID')
		ELSE IF @DocumentFormatID = 2
			SET @ResultTemplateID  = (SELECT [Value] FROM [app].[SiteParameter] WHERE [Key] = 'ExportTemplatePdfID')
		ELSE IF @DocumentFormatID = 4
			SET @ResultTemplateID  = (SELECT [Value] FROM [app].[SiteParameter] WHERE [Key] = 'ExportTemplatePptID')	
		IF (@ResultTemplateID is not NULL)
		BEGIN
			GOTO CommitResult
		END
	END	
	
	Set @Err = @@Error
	RETURN @Err
	
	CommitResult:
		SELECT TOP 1 * FROM [rep].[DocumentTemplate] WHERE DocumentTemplateID = @ResultTemplateID
End
