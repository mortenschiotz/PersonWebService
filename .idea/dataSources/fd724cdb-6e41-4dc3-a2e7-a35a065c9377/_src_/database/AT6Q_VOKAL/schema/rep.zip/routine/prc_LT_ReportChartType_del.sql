CREATE PROCEDURE [rep].[prc_LT_ReportChartType_del]
(
	@LanguageID int,
	@ReportChartTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportChartType',2,
		( SELECT * FROM [rep].[LT_ReportChartType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportChartTypeID] = @ReportChartTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[LT_ReportChartType]
	WHERE
		[LanguageID] = @LanguageID AND
		[ReportChartTypeID] = @ReportChartTypeID

	Set @Err = @@Error

	RETURN @Err
END

