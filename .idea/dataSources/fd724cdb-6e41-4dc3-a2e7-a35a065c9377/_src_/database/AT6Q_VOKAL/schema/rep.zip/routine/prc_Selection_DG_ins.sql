
CREATE PROCEDURE [rep].[prc_Selection_DG_ins]
(
	@SelectionID int,
	@DepartmentGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_DG]
	(
		[SelectionID],
		[DepartmentGroupID]
	)
	VALUES
	(
		@SelectionID,
		@DepartmentGroupID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_DG',0,
		( SELECT * FROM [rep].[Selection_DG] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentGroupID] = @DepartmentGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

