CREATE PROCEDURE [rep].[prc_URS_CalcType_ins]
 @UserReportSettingID int,
 @ReportCalcTypeID int,
 @cUserid int,
 @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [rep].[URS_CalcType]
           ([UserReportSettingID]
			,[ReportCalcTypeID])
     VALUES
           (@UserReportSettingID
           ,@ReportCalcTypeID)
           
    Set @Err = @@Error
    
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'URS_CalcType',0,
		( SELECT * FROM [rep].[URS_CalcType]
		  WHERE
			[UserReportSettingID] = @UserReportSettingID
			AND [ReportCalcTypeID] = @ReportCalcTypeID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
