
CREATE PROCEDURE [rep].[prc_Bubble_Category_ins]
(
	@BubbleID int,
	@CategoryID int,
	@AxisNo smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Bubble_Category]
	(
		[BubbleID],
		[CategoryID],
		[AxisNo]
	)
	VALUES
	(
		@BubbleID,
		@CategoryID,
		@AxisNo
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bubble_Category',0,
		( SELECT * FROM [rep].[Bubble_Category] 
			WHERE
			[BubbleID] = @BubbleID AND
			[CategoryID] = @CategoryID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

