CREATE PROCEDURE [rep].[prc_ReportFilter_del]
(
	@ActivityID int,
	@QuestionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportFilter',2,
		( SELECT * FROM [rep].[ReportFilter] 
			WHERE
			[ActivityID] = @ActivityID AND
			[QuestionID] = @QuestionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[ReportFilter]
	WHERE
		[ActivityID] = @ActivityID AND
		[QuestionID] = @QuestionID

	Set @Err = @@Error

	RETURN @Err
END

