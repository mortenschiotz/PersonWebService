
CREATE PROCEDURE [rep].[prc_Selection_QAFilter_get]
(
	@SQAID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SQAID],
	[AlternativeID],
	[Type],
	[Value],
	[CompareTypeID],
	[ItemID]
	FROM [rep].[Selection_QAFilter]
	WHERE
	[SQAID] = @SQAID

	Set @Err = @@Error

	RETURN @Err
END

