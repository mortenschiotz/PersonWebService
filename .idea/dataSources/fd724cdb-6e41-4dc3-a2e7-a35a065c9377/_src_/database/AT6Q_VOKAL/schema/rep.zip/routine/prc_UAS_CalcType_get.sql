CREATE PROCEDURE [rep].[prc_UAS_CalcType_get]
 @UserActivitySettingID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserActivitySettingID]
	,[ReportCalcTypeID]
 FROM             
  [rep].[UAS_CalcType]     
 WHERE        
  [UserActivitySettingID] = @UserActivitySettingID      
 Set @Err = @@Error      
      
 RETURN @Err      
END 
