
CREATE PROCEDURE [rep].[prc_LT_ReportRowType_get]
(
	@ReportRowTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportRowTypeID],
	[LanguageID],
	[Name],
	[Description]
	FROM [rep].[LT_ReportRowType]
	WHERE
	[ReportRowTypeID] = @ReportRowTypeID

	Set @Err = @@Error

	RETURN @Err
END

