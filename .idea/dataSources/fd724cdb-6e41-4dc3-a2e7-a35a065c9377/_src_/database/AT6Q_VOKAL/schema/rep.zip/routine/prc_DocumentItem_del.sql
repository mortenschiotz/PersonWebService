
CREATE PROCEDURE [rep].[prc_DocumentItem_del]
(
	@DocumentItemID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DocumentItem',2,
		( SELECT * FROM [rep].[DocumentItem] 
			WHERE
			[DocumentItemID] = @DocumentItemID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[DocumentItem]
	WHERE
		[DocumentItemID] = @DocumentItemID

	Set @Err = @@Error

	RETURN @Err
END


