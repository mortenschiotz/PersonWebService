
CREATE PROCEDURE [rep].[prc_ReportRowType_ins]
(
	@ReportRowTypeID int = null output,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[ReportRowType]
	(
		[No]
	)
	VALUES
	(
		@No
	)

	Set @Err = @@Error
	Set @ReportRowTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportRowType',0,
		( SELECT * FROM [rep].[ReportRowType] 
			WHERE
			[ReportRowTypeID] = @ReportRowTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

