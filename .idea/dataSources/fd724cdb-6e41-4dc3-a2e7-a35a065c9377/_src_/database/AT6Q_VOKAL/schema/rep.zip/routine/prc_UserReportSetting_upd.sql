CREATE PROCEDURE [rep].[prc_UserReportSetting_upd]
 @UserReportSettingID int = null output,
 @UserID int,
 @ReportID int,
 @ShowTable smallint = 1,
 @ShowChart smallint = 0,
 @ChartTypeID int = 9,
 @ChartTypeIDAvg int = 7,
 @cUserid int,
 @Log smallint = 1
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int  
      
    UPDATE [rep].[UserReportSetting] 
    SET		[ShowTable] = @ShowTable
			,[ShowChart] = @ShowChart
			,[ChartTypeID] = @ChartTypeID
			,[ChartTypeIDAvg] = @ChartTypeIDAvg
     WHERE [UserID] = @UserID
			AND [ReportID] = @ReportID
             
    Set @Err = @@Error  
    Set @UserReportSettingID = scope_identity()  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'UserReportSetting',1,  
  (SELECT * FROM [rep].[UserReportSetting]  
   WHERE  
   [UserReportSettingID] = @UserReportSettingID     FOR XML AUTO) as data,  
    getdate()   
 END  
   
 RETURN @Err         
END  
