
CREATE PROCEDURE [rep].[prc_Report_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportID],
	[OwnerID],
	[UserID],
	[Created],
	[ChartTemplate],
	[DefaultCalcType]
	FROM [rep].[Report]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END

