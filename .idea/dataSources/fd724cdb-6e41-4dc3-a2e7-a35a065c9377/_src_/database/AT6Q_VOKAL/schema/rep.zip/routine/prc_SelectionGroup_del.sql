

CREATE PROCEDURE [rep].[prc_SelectionGroup_del]
(
	@SelectionGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SelectionGroup',2,
		( SELECT * FROM [rep].[SelectionGroup] 
			WHERE
			[SelectionGroupID] = @SelectionGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[SelectionGroup]
	WHERE
		[SelectionGroupID] = @SelectionGroupID

	Set @Err = @@Error

	RETURN @Err
END

