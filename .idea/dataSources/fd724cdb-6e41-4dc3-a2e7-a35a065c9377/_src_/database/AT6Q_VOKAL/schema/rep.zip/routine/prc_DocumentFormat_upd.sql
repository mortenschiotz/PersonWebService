

CREATE PROCEDURE [rep].[prc_DocumentFormat_upd]
(
	@DocumentFormatID int,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[DocumentFormat]
	SET
		[Name] = @Name
	WHERE
		[DocumentFormatID] = @DocumentFormatID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DocumentFormat',1,
		( SELECT * FROM [rep].[DocumentFormat] 
			WHERE
			[DocumentFormatID] = @DocumentFormatID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


