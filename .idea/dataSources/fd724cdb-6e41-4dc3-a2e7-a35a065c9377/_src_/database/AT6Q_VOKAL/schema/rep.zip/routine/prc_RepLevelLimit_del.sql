CREATE PROCEDURE [rep].[prc_RepLevelLimit_del]
(
	@RepLevelLimitID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'RepLevelLimit',2,
		( SELECT * FROM [rep].[RepLevelLimit] 
			WHERE
			[RepLevelLimitID] = @RepLevelLimitID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[RepLevelLimit]
	WHERE
		[RepLevelLimitID] = @RepLevelLimitID

	Set @Err = @@Error

	RETURN @Err
END

