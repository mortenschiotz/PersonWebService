
CREATE PROCEDURE [rep].[prc_SelectionGroup_get]
(
	@UserID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionGroupID],
	[Name],
	[UserID],
	[Created]
	FROM [rep].[SelectionGroup]
	WHERE
	[UserID] = @UserID

	Set @Err = @@Error

	RETURN @Err
END

