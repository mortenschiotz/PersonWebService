

CREATE PROCEDURE [rep].[prc_DF_O_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DF_O_ID],
	[OwnerID],
	[DocumentFormatID]
	FROM [rep].[DF_O]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END


