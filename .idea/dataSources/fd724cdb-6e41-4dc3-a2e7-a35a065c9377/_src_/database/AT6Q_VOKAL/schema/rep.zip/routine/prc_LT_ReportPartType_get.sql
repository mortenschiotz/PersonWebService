
CREATE PROCEDURE [rep].[prc_LT_ReportPartType_get]
(
	@ReportPartTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportPartTypeID],
	[LanguageID],
	[Name],
	[Description]
	FROM [rep].[LT_ReportPartType]
	WHERE
	[ReportPartTypeID] = @ReportPartTypeID

	Set @Err = @@Error

	RETURN @Err
END

