CREATE PROCEDURE [rep].[prc_UAS_Question_ins]
 @UserActivitySettingID int,
 @QuestionID int,
 @cUserid int,
 @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [rep].[UAS_Question]
           ([UserActivitySettingID]
			,[QuestionID])
     VALUES
           (@UserActivitySettingID
           ,@QuestionID)
           
    Set @Err = @@Error
    
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UAS_Question',0,
		( SELECT * FROM [rep].[UAS_Question]
		  WHERE
			[UserActivitySettingID] = @UserActivitySettingID
			AND [QuestionID] = @QuestionID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
