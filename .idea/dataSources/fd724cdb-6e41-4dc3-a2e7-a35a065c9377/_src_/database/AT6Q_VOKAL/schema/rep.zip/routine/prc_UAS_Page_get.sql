CREATE PROCEDURE [rep].[prc_UAS_Page_get]
 @UserActivitySettingID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserActivitySettingID]
	,[PageID]
 FROM             
  [rep].[UAS_Page]     
 WHERE        
  [UserActivitySettingID] = @UserActivitySettingID      
 Set @Err = @@Error      
      
 RETURN @Err      
END 
