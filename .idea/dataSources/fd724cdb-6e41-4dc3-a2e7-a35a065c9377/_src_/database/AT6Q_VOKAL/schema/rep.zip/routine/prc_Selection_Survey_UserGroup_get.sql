
CREATE PROCEDURE [rep].[prc_Selection_Survey_UserGroup_get]
(
	@S_SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[S_SurveyID],
	[UGID]
	FROM [rep].[Selection_Survey_UserGroup]
	WHERE
	[S_SurveyID] = @S_SurveyID

	Set @Err = @@Error

	RETURN @Err
END

