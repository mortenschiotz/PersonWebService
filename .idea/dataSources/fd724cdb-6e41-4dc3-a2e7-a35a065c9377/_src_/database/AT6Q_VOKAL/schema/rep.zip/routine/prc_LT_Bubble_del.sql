

CREATE PROCEDURE [rep].[prc_LT_Bubble_del]
(
	@LanguageID int,
	@BubbleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Bubble',2,
		( SELECT * FROM [rep].[LT_Bubble] 
			WHERE
			[LanguageID] = @LanguageID AND
			[BubbleID] = @BubbleID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[LT_Bubble]
	WHERE
		[LanguageID] = @LanguageID AND
		[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

