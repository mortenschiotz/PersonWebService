
CREATE PROCEDURE [rep].[prc_Selection_Survey_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[S_SurveyID],
	[SelectionID],
	[SurveyID]
	FROM [rep].[Selection_Survey]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

