
CREATE PROCEDURE [rep].[prc_ReportColumnParameter_get]
(
	@ReportColumnID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportColumnParameterID],
	[ReportColumnID],
	[No],
	[Name],
	[ActivityID],
	ISNULL([QuestionID], 0) AS 'QuestionID',
	ISNULL([AlternativeID], 0) AS 'AlternativeID',
	ISNULL([CategoryID], 0) AS 'CategoryID',
	[CalcType],
	[ItemID]

	FROM [rep].[ReportColumnParameter]
	WHERE
	[ReportColumnID] = @ReportColumnID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

