
CREATE PROCEDURE [rep].[prc_Bubble_del]
(
	@BubbleID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bubble',2,
		( SELECT * FROM [rep].[Bubble] 
			WHERE
			[BubbleID] = @BubbleID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[Bubble]
	WHERE
		[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

