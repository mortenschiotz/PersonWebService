

CREATE PROCEDURE [rep].[prc_RepLevelLimit_ins]
(
	@RepLevelLimitID int = null output,
	@ReportColumnID INT=NULL,
	@ReportID INT=NULL,
	@MinValue float,
	@MaxValue float,
	@Sigchange float,
	@Fillcolor varchar(16),
	@BorderColor varchar(16),
	@LevelGroupID int = null,
	@NegativeTrend bit = 0,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[RepLevelLimit]
	(
		[ReportColumnID],
		[ReportID],
		[MinValue],
		[MaxValue],
		[Sigchange],
		[Fillcolor],
		[BorderColor],
		[LevelGroupID],
		[NegativeTrend]
	)
	VALUES
	(
		@ReportColumnID,
		@ReportID,
		@MinValue,
		@MaxValue,
		@Sigchange,
		@Fillcolor,
		@BorderColor,
		@LevelGroupID,
		@NegativeTrend
	)

	Set @Err = @@Error
	Set @RepLevelLimitID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'RepLevelLimit',0,
		( SELECT * FROM [rep].[RepLevelLimit] 
			WHERE
			[RepLevelLimitID] = @RepLevelLimitID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

