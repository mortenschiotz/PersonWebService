
CREATE PROCEDURE [rep].[prc_LT_ReportColumnType_get]
(
	@ReportColumnTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportColumnTypeID],
	[LanguageID],
	[Name],
	[Description]
	FROM [rep].[LT_ReportColumnType]
	WHERE
	[ReportColumnTypeID] = @ReportColumnTypeID

	Set @Err = @@Error

	RETURN @Err
END

