
CREATE PROCEDURE [rep].[prc_Selection_Survey_ins]
(
	@S_SurveyID int = null output,
	@SelectionID int,
	@SurveyID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_Survey]
	(
		[SelectionID],
		[SurveyID]
	)
	VALUES
	(
		@SelectionID,
		@SurveyID
	)

	Set @Err = @@Error
	Set @S_SurveyID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_Survey',0,
		( SELECT * FROM [rep].[Selection_Survey] 
			WHERE
			[S_SurveyID] = @S_SurveyID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

