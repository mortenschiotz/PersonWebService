

CREATE PROCEDURE [rep].[prc_ReportFilter_get]
(
	@ActivityID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ActivityID],
	[QuestionID],
	[FilterDim]
	FROM [rep].[ReportFilter]
	WHERE
	[ActivityID] = @ActivityID

	Set @Err = @@Error

	RETURN @Err
END


