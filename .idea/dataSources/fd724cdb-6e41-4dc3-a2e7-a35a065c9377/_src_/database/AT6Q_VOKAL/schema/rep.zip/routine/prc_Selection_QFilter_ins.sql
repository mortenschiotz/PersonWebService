
CREATE PROCEDURE [rep].[prc_Selection_QFilter_ins]
(
	@SQAID int = null output,
	@SelectionID int,
	@QuestionID int,
	@Type smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_QFilter]
	(
		[SelectionID],
		[QuestionID],
		[Type]
	)
	VALUES
	(
		@SelectionID,
		@QuestionID,
		@Type
	)

	Set @Err = @@Error
	Set @SQAID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_QFilter',0,
		( SELECT * FROM [rep].[Selection_QFilter] 
			WHERE
			[SQAID] = @SQAID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

