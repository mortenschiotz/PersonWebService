
CREATE PROCEDURE [rep].[prc_Bubble_SurveyLimit_ins]
(
	@BubbleID int,
	@SurveyID int,
	@AxisNo smallint,
	@LimitLow float,
	@LimitHigh float,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Bubble_SurveyLimit]
	(
		[BubbleID],
		[SurveyID],
		[AxisNo],
		[LimitLow],
		[LimitHigh]
	)
	VALUES
	(
		@BubbleID,
		@SurveyID,
		@AxisNo,
		@LimitLow,
		@LimitHigh
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bubble_SurveyLimit',0,
		( SELECT * FROM [rep].[Bubble_SurveyLimit] 
			WHERE
			[BubbleID] = @BubbleID AND
			[SurveyID] = @SurveyID AND
			[AxisNo] = @AxisNo				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

