
CREATE PROCEDURE [rep].[prc_Selection_DT_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionID],
	[DepartmentTypeID]
	FROM [rep].[Selection_DT]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

