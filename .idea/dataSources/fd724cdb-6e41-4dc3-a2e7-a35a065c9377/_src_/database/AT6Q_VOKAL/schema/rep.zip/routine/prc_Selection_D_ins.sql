
CREATE PROCEDURE [rep].[prc_Selection_D_ins]
(
	@SelectionID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_D]
	(
		[SelectionID],
		[DepartmentID]
	)
	VALUES
	(
		@SelectionID,
		@DepartmentID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_D',0,
		( SELECT * FROM [rep].[Selection_D] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentID] = @DepartmentID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

