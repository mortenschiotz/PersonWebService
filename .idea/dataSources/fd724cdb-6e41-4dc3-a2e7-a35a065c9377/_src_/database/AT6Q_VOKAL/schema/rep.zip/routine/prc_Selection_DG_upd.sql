
CREATE PROCEDURE [rep].[prc_Selection_DG_upd]
(
	@SelectionID int,
	@DepartmentGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[Selection_DG]
	SET
		[SelectionID] = @SelectionID,
		[DepartmentGroupID] = @DepartmentGroupID
	WHERE
		[SelectionID] = @SelectionID AND
		[DepartmentGroupID] = @DepartmentGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_DG',1,
		( SELECT * FROM [rep].[Selection_DG] 
			WHERE
			[SelectionID] = @SelectionID AND
			[DepartmentGroupID] = @DepartmentGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

