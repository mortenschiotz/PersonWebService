
CREATE PROCEDURE [rep].[prc_ReportColumnType_ins]
(
	@ReportColumnTypeID int = null output,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[ReportColumnType]
	(
		[No]
	)
	VALUES
	(
		@No
	)

	Set @Err = @@Error
	Set @ReportColumnTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportColumnType',0,
		( SELECT * FROM [rep].[ReportColumnType] 
			WHERE
			[ReportColumnTypeID] = @ReportColumnTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

