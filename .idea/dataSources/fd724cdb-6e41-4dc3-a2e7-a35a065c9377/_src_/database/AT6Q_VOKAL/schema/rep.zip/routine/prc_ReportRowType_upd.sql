
CREATE PROCEDURE [rep].[prc_ReportRowType_upd]
(
	@ReportRowTypeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[ReportRowType]
	SET
		[No] = @No
	WHERE
		[ReportRowTypeID] = @ReportRowTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportRowType',1,
		( SELECT * FROM [rep].[ReportRowType] 
			WHERE
			[ReportRowTypeID] = @ReportRowTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

