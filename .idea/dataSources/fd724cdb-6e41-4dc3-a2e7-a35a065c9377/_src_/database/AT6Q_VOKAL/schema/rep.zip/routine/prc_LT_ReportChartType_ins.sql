
CREATE PROCEDURE [rep].[prc_LT_ReportChartType_ins]
(
	@LanguageID int,
	@ReportChartTypeID int,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[LT_ReportChartType]
	(
		[LanguageID],
		[ReportChartTypeID],
		[Name]
	)
	VALUES
	(
		@LanguageID,
		@ReportChartTypeID,
		@Name
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportChartType',0,
		( SELECT * FROM [rep].[LT_ReportChartType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportChartTypeID] = @ReportChartTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

