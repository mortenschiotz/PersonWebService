


CREATE PROCEDURE [rep].[prc_LT_DocumentTemplate_ins]
(
	@LanguageID int,
	@DocumentTemplateID int,
	@yStartPos int = 0,
	@MIMEType nvarchar(50),
	@Size bigint,
	@FileContent as varbinary(Max) = null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[LT_DocumentTemplate]
	(
		[LanguageID],
		[DocumentTemplateID],
		[yStartPos],
		[FileContent],
		[MIMEType],
		[Size]
	)
	VALUES
	(
		@LanguageID,
		@DocumentTemplateID,
		@yStartPos,
		@FileContent,
		@MimeType,
		@Size
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_DocumentTemplate',0,
		( SELECT * FROM [rep].[LT_DocumentTemplate] 
			WHERE
			[LanguageID] = @LanguageID
			AND [DocumentTemplateID] = @DocumentTemplateID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


/****** Object:  StoredProcedure [rep].[prc_LT_DocumentTemplate_ins]    Script Date: 03/10/2011 12:41:33 ******/
SET ANSI_NULLS ON
