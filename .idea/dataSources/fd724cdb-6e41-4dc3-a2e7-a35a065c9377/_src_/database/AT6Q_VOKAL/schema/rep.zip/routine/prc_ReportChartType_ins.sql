
CREATE PROCEDURE [rep].[prc_ReportChartType_ins]
(
	@ReportChartTypeID int,
	@Type smallint,
	@No smallint,
	@DundasID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[ReportChartType]
	(
		[ReportChartTypeID],
		[Type],
		[No],
		[DundasID]
	)
	VALUES
	(
		@ReportChartTypeID,
		@Type,
		@No,
		@DundasID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportChartType',0,
		( SELECT * FROM [rep].[ReportChartType] 
			WHERE
			[ReportChartTypeID] = @ReportChartTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

