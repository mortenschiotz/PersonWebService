CREATE PROCEDURE [rep].[prc_UserReportSetting_get]
 @UserID int,
 @ReportID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserReportSettingID]
	,[UserID]
	,[ReportID]
	,[ShowTable]
	,[ShowChart]
	,[ChartTypeID]
	,[ChartTypeIDAvg]
 FROM             
  [rep].[UserReportSetting]     
 WHERE        
  [UserID] = @UserID      
  AND [ReportID] = @ReportID
 Set @Err = @@Error      
      
 RETURN @Err      
END 
