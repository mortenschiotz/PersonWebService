CREATE PROCEDURE [rep].[prc_UAS_Question_get]
 @UserActivitySettingID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserActivitySettingID]
	,[QuestionID]
 FROM             
  [rep].[UAS_Question]     
 WHERE        
  [UserActivitySettingID] = @UserActivitySettingID      
 Set @Err = @@Error      
      
 RETURN @Err      
END 
