CREATE PROCEDURE [rep].[prc_URS_CalcType_get]
 @UserReportSettingID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [UserReportSettingID]
	,[ReportCalcTypeID]
 FROM             
  [rep].[URS_CalcType]     
 WHERE        
  [UserReportSettingID] = @UserReportSettingID      
 Set @Err = @@Error      
      
 RETURN @Err      
END 
