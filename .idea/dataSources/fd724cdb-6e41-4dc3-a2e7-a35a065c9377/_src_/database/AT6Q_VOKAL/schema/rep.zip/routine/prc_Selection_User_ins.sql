
CREATE PROCEDURE [rep].[prc_Selection_User_ins]
(
	@SelectionID int,
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[Selection_User]
	(
		[SelectionID],
		[UserID]
	)
	VALUES
	(
		@SelectionID,
		@UserID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection_User',0,
		( SELECT * FROM [rep].[Selection_User] 
			WHERE
			[SelectionID] = @SelectionID AND
			[UserID] = @UserID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

