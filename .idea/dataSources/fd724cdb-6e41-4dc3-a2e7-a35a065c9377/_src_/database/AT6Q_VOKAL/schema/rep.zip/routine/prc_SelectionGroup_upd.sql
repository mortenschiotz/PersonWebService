
CREATE PROCEDURE [rep].[prc_SelectionGroup_upd]
(
	@SelectionGroupID int,
	@Name nvarchar(256),
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[SelectionGroup]
	SET
		[Name] = @Name,
		[UserID] = @UserID
	WHERE
		[SelectionGroupID] = @SelectionGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SelectionGroup',1,
		( SELECT * FROM [rep].[SelectionGroup] 
			WHERE
			[SelectionGroupID] = @SelectionGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

