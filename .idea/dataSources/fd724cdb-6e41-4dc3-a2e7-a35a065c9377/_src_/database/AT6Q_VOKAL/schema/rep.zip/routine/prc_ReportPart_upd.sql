


CREATE PROCEDURE [rep].[prc_ReportPart_upd]
(
	@ReportPartID int,
	@ReportID int,
	@Name nvarchar(256),
	@ReportPartTypeID int,
	@SelectionDir smallint,
	@ChartTypeID smallint,
	@ElementID int,
	@No smallint = 0,
	@ScaleMinValue float = 0,
	@ScaleMaxValue float = 1,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[ReportPart]
	SET
		[ReportID] = @ReportID,
		[Name] = @Name,
		[ReportPartTypeID] = @ReportPartTypeID,
		[SelectionDir] = @SelectionDir,
		[ChartTypeID] = @ChartTypeID,
		[ElementID] = @ElementID,
		[No] = @No,
		[ScaleMinValue] = @ScaleMinValue,
		[ScaleMaxValue] = @ScaleMaxValue
	WHERE
		[ReportPartID] = @ReportPartID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportPart',1,
		( SELECT * FROM [rep].[ReportPart] 
			WHERE
			[ReportPartID] = @ReportPartID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END



