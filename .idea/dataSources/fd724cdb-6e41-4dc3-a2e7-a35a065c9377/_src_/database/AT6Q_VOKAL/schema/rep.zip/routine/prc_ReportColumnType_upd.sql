
CREATE PROCEDURE [rep].[prc_ReportColumnType_upd]
(
	@ReportColumnTypeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [rep].[ReportColumnType]
	SET
		[No] = @No
	WHERE
		[ReportColumnTypeID] = @ReportColumnTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportColumnType',1,
		( SELECT * FROM [rep].[ReportColumnType] 
			WHERE
			[ReportColumnTypeID] = @ReportColumnTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

