CREATE PROCEDURE [rep].[prc_ReportPart_get]
(
	@ReportID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportPartID],
	[ReportID],
	[Name],
	[ReportPartTypeID],
	[SelectionDir],
	[ChartTypeID],
	[ElementID],
	[No],
	[Created],
	[ScaleMinValue],
	[ScaleMaxValue]
	FROM [rep].[ReportPart]
	WHERE
	[ReportID] = @ReportID
    order by [No],[ReportPartID]
	Set @Err = @@Error

	RETURN @Err
END


