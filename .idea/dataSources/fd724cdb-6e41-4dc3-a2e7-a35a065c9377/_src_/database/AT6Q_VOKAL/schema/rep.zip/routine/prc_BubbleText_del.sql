

CREATE PROCEDURE [rep].[prc_BubbleText_del]
(
	@BubbleTextID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'BubbleText',2,
		( SELECT * FROM [rep].[BubbleText] 
			WHERE
			[BubbleTextID] = @BubbleTextID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[BubbleText]
	WHERE
		[BubbleTextID] = @BubbleTextID

	Set @Err = @@Error

	RETURN @Err
END

