
CREATE PROCEDURE [rep].[prc_Selection_DG_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionID],
	[DepartmentGroupID]
	FROM [rep].[Selection_DG]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

