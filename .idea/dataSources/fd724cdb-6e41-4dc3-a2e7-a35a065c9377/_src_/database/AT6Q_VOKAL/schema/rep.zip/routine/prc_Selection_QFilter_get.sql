
CREATE PROCEDURE [rep].[prc_Selection_QFilter_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SQAID],
	[SelectionID],
	[QuestionID],
	[Type]
	FROM [rep].[Selection_QFilter]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

