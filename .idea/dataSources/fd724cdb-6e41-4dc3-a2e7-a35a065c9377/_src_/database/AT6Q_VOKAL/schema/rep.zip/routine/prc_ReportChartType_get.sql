
CREATE PROCEDURE [rep].[prc_ReportChartType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportChartTypeID],
	[Type],
	[No],
	[DundasID],
	[Created]
	FROM [rep].[ReportChartType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

