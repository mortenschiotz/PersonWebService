
CREATE PROCEDURE [rep].[prc_ReportPartType_ins]
(
	@ReportPartTypeID int = null output,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[ReportPartType]
	(
		[No]
	)
	VALUES
	(
		@No
	)

	Set @Err = @@Error
	Set @ReportPartTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ReportPartType',0,
		( SELECT * FROM [rep].[ReportPartType] 
			WHERE
			[ReportPartTypeID] = @ReportPartTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

