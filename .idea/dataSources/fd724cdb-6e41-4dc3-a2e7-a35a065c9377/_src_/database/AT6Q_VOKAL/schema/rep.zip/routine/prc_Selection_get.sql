

CREATE PROCEDURE [rep].[prc_Selection_get]
(
	@SelectionGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionID],
	[SelectionGroupID],
	[Active],
	[CustomName],
	[Name],
	ISNULL([ActivityID], 0) AS 'ActivityID',
	[Status],
	ISNULL([StartDate], 0) AS 'StartDate',
	ISNULL([EndDate], 0) AS 'EndDate',
	[Created],
	ISNUll([LevelGroupID],0) as 'LevelGroupID',
    [NO]
	FROM [rep].[Selection]
	WHERE
	[SelectionGroupID] = @SelectionGroupID
    ORDER BY [NO],[SelectionID]

	Set @Err = @@Error

	RETURN @Err
END


