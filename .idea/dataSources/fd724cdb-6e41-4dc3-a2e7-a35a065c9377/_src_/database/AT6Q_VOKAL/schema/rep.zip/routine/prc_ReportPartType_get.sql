
CREATE PROCEDURE [rep].[prc_ReportPartType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportPartTypeID],
	[No]
	FROM [rep].[ReportPartType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

