
CREATE PROCEDURE [rep].[prc_Selection_Result_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionID],
	[ResultID]
	FROM [rep].[Selection_Result]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

