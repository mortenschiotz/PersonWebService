
CREATE PROCEDURE [rep].[prc_BubbleText_get]
(
	@BubbleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BubbleTextID],
	[BubbleID],
	[No],
	[FillColor]
	FROM [rep].[BubbleText]
	WHERE
	[BubbleID] = @BubbleID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

