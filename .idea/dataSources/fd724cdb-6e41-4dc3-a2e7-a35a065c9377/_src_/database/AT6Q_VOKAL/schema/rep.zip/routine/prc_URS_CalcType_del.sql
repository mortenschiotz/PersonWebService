CREATE PROCEDURE [rep].[prc_URS_CalcType_del]       
(        
 @UserReportSettingID int,
 @ReportCalcTypeID int,
 @cUserid int,
 @Log smallint = 1
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'URS_CalcType',2,        
  (SELECT * FROM [rep].[URS_CalcType]
   WHERE        
		[UserReportSettingID] = @UserReportSettingID
		AND [ReportCalcTypeID] = @ReportCalcTypeID
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [rep].[URS_CalcType]
 WHERE        
	[UserReportSettingID] = @UserReportSettingID
	AND [ReportCalcTypeID] = @ReportCalcTypeID
 Set @Err = @@Error        
        
 RETURN @Err        
END 
