
CREATE PROCEDURE [rep].[prc_Selection_del]
(
	@SelectionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Selection',2,
		( SELECT * FROM [rep].[Selection] 
			WHERE
			[SelectionID] = @SelectionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[Selection]
	WHERE
		[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

