

CREATE PROCEDURE [rep].[prc_RepLevelLimit_get]
(
	@ReportID int = Null,
	@ReportColumnID int = Null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[RepLevelLimitID],
	ISNULL([ReportColumnID], 0) AS 'ReportColumnID',
	ISNULL([ReportID], 0) AS 'ReportID',
	[MinValue],
	[MaxValue],
	[Sigchange],
	[Fillcolor],
	[BorderColor],
	[Created],
	isnull([LevelGroupID],0) 'LevelGroupID',
	[NegativeTrend]
	FROM [rep].[RepLevelLimit]
	WHERE
	(NOT ReportID IS NULL AND [ReportID] = @ReportID)
	OR (NOT @ReportColumnID IS NULL AND [ReportColumnID] = @ReportColumnID)

	Set @Err = @@Error

	RETURN @Err
END



