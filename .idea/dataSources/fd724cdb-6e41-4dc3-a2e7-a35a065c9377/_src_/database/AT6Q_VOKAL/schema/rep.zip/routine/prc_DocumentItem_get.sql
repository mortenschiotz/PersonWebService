

CREATE PROCEDURE [rep].[prc_DocumentItem_get]
(
	@DF_O_ID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DocumentItemID],
	[DocumentItemTypeID],
	[DF_O_ID],
	[BGColor],
	[FGColor],
	[FontSize],
	[FontName],
	[FontIsBold],
	ISNULL([BorderColor], '') AS 'BorderColor'
	FROM [rep].[DocumentItem]
	WHERE
	[DF_O_ID] = @DF_O_ID

	Set @Err = @@Error

	RETURN @Err
END


