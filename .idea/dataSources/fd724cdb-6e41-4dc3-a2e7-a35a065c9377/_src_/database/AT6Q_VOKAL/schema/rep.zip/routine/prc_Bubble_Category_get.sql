
CREATE PROCEDURE [rep].[prc_Bubble_Category_get]
(
	@BubbleID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[BubbleID],
	[CategoryID],
	[AxisNo]
	FROM [rep].[Bubble_Category]
	WHERE
	[BubbleID] = @BubbleID

	Set @Err = @@Error

	RETURN @Err
END

