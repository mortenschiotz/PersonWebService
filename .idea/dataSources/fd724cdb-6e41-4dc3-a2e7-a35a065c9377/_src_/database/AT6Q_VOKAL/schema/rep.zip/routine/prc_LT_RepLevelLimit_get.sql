
CREATE PROCEDURE [rep].[prc_LT_RepLevelLimit_get]
(
	@RepLevelLimitID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[RepLevelLimitID],
	[LanguageID],
	[Name],
	[Description]
	FROM [rep].[LT_RepLevelLimit]
	WHERE
	[RepLevelLimitID] = @RepLevelLimitID

	Set @Err = @@Error

	RETURN @Err
END

