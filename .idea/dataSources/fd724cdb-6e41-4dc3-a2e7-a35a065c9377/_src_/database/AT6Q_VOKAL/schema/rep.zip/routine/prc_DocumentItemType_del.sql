
CREATE PROCEDURE [rep].[prc_DocumentItemType_del]
(
	@DocumentItemTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DocumentItemType',2,
		( SELECT * FROM [rep].[DocumentItemType] 
			WHERE
			[DocumentItemTypeID] = @DocumentItemTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[DocumentItemType]
	WHERE
		[DocumentItemTypeID] = @DocumentItemTypeID

	Set @Err = @@Error

	RETURN @Err
END


