

CREATE PROCEDURE [rep].[prc_Bubble_Category_del]
(
	@BubbleID int,
	@CategoryID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Bubble_Category',2,
		( SELECT * FROM [rep].[Bubble_Category] 
			WHERE
			[BubbleID] = @BubbleID AND
			[CategoryID] = @CategoryID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [rep].[Bubble_Category]
	WHERE
		[BubbleID] = @BubbleID AND
		[CategoryID] = @CategoryID

	Set @Err = @@Error

	RETURN @Err
END

