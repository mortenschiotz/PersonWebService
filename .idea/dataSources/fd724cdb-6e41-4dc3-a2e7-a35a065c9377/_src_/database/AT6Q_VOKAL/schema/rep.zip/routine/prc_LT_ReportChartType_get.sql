
CREATE PROCEDURE [rep].[prc_LT_ReportChartType_get]
(
	@ReportChartTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ReportChartTypeID],
	[Name]
	FROM [rep].[LT_ReportChartType]
	WHERE
	[ReportChartTypeID] = @ReportChartTypeID

	Set @Err = @@Error

	RETURN @Err
END

