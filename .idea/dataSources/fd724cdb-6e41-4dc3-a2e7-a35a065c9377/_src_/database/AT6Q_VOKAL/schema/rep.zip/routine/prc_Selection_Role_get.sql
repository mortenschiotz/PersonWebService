
CREATE PROCEDURE [rep].[prc_Selection_Role_get]
(
	@SelectionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[SelectionID],
	[RoleID]
	FROM [rep].[Selection_Role]
	WHERE
	[SelectionID] = @SelectionID

	Set @Err = @@Error

	RETURN @Err
END

