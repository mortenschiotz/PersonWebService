

CREATE PROCEDURE [rep].[prc_LT_ReportColumn_ins]
(
	@LanguageID int,
	@ReportColumnID int,
	@Text nvarchar(max),
	@ToolTip nvarchar(512) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [rep].[LT_ReportColumn]
	(
		[LanguageID],
		[ReportColumnID],
		[Text],
		[ToolTip]
	)
	VALUES
	(
		@LanguageID,
		@ReportColumnID,
		@Text,
		@ToolTip
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ReportColumn',0,
		( SELECT * FROM [rep].[LT_ReportColumn] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ReportColumnID] = @ReportColumnID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


