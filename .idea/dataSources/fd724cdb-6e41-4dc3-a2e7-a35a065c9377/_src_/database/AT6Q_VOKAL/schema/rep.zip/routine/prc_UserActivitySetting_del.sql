CREATE PROCEDURE [rep].[prc_UserActivitySetting_del]        
(        
 @UserActivitySettingID int,
 @cUserid int,
 @Log smallint = 1
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'UserActivitySetting',2,        
  (SELECT * FROM [rep].[UserActivitySetting]
   WHERE        
		[UserActivitySettingID] = @UserActivitySettingID
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [rep].[UserActivitySetting]
 WHERE        
  [UserActivitySettingID] = @UserActivitySettingID
 Set @Err = @@Error        
        
 RETURN @Err        
END 
