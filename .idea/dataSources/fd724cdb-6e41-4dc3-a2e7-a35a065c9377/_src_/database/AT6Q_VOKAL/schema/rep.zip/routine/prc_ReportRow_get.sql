
CREATE PROCEDURE [rep].[prc_ReportRow_get]
(
	@ReportPartID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ReportRowID],
	[ReportPartID],
	[ReportRowTypeID],
	[No],
	[CssClass],
	[Created]
	FROM [rep].[ReportRow]
	WHERE
	[ReportPartID] = @ReportPartID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

