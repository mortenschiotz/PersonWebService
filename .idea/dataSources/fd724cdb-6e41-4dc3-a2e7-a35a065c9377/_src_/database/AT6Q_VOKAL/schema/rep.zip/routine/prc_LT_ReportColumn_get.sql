
CREATE PROCEDURE [rep].[prc_LT_ReportColumn_get]
(
	@ReportColumnID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ReportColumnID],
	[Text],
	[ToolTip]
	FROM [rep].[LT_ReportColumn]
	WHERE
	[ReportColumnID] = @ReportColumnID

	Set @Err = @@Error

	RETURN @Err
END

