
CREATE PROCEDURE [rep].[prc_Selection_Survey_Batch_get]
(
	@S_SurveyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[S_SurveyID],
	[BatchID]
	FROM [rep].[Selection_Survey_Batch]
	WHERE
	[S_SurveyID] = @S_SurveyID

	Set @Err = @@Error

	RETURN @Err
END

