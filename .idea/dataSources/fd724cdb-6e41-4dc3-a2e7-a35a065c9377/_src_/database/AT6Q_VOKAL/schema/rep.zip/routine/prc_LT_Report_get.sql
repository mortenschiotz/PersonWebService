
CREATE PROCEDURE [rep].[prc_LT_Report_get]
(
	@ReportID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ReportID],
	[Name],
	[Text]
	FROM [rep].[LT_Report]
	WHERE
	[ReportID] = @ReportID

	Set @Err = @@Error

	RETURN @Err
END

