
CREATE PROCEDURE [prop].[prc_LT_Prop_del]
(
	@LanguageID int,
	@PropertyID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Prop',2,
		( SELECT * FROM [prop].[LT_Prop] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PropertyID] = @PropertyID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[LT_Prop]
	WHERE
		[LanguageID] = @LanguageID AND
		[PropertyID] = @PropertyID

	Set @Err = @@Error

	RETURN @Err
END

