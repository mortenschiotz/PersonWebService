
CREATE PROCEDURE [prop].[prc_PropValue_get]
(
	@PropertyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PropValueID],
	[PropertyID],
	ISNULL([PropOptionID], 0) AS 'PropOptionID',
	ISNULL([PropFileID], 0) AS 'PropFileID',
	[No],
	[Created],
	ISNULL([CreatedBy], 0) AS 'CreatedBy',
	[Updated],
	ISNULL([UpdatedBy], 0) AS 'UpdatedBy',
	[ItemID],
	[Value]
	FROM [prop].[PropValue]
	WHERE
	[PropertyID] = @PropertyID

	Set @Err = @@Error

	RETURN @Err
END

