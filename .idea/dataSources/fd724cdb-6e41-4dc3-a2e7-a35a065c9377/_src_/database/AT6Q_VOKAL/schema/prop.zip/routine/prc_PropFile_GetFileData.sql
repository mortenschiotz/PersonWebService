
CREATE PROCEDURE [prop].[prc_PropFile_GetFileData]
(
	@PropFileID	int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT FileData
	FROM [prop].[PropFile]
	WHERE [PropFileID] = @PropFileID

	Set @Err = @@Error

	RETURN @Err
End

