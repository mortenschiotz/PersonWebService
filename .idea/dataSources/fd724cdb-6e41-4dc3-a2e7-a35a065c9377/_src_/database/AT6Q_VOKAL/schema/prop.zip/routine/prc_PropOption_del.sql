

CREATE PROCEDURE [prop].[prc_PropOption_del]
(
	@PropOptionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropOption',2,
		( SELECT * FROM [prop].[PropOption] 
			WHERE
			[PropOptionID] = @PropOptionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[PropOption]
	WHERE
		[PropOptionID] = @PropOptionID

	Set @Err = @@Error

	RETURN @Err
END

