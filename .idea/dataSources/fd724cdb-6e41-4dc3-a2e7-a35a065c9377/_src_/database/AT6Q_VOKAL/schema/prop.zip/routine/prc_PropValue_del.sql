

CREATE PROCEDURE [prop].[prc_PropValue_del]
(
	@PropValueID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropValue',2,
		( SELECT * FROM [prop].[PropValue] 
			WHERE
			[PropValueID] = @PropValueID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[PropValue]
	WHERE
		[PropValueID] = @PropValueID

	Set @Err = @@Error

	RETURN @Err
END

