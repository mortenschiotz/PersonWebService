CREATE PROCEDURE [prop].[prc_PropPage_get]
(
	@TableTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PropPageID], 
	[TableTypeID], 
	[Type], 
	[No], 
	[Created]
	FROM [prop].[PropPage]
	WHERE
	[TableTypeID] = @TableTypeID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END