

CREATE PROCEDURE [prop].[prc_LT_PropOption_del]
(
	@LanguageID int,
	@PropOptionID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_PropOption',2,
		( SELECT * FROM [prop].[LT_PropOption] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PropOptionID] = @PropOptionID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[LT_PropOption]
	WHERE
		[LanguageID] = @LanguageID AND
		[PropOptionID] = @PropOptionID

	Set @Err = @@Error

	RETURN @Err
END

