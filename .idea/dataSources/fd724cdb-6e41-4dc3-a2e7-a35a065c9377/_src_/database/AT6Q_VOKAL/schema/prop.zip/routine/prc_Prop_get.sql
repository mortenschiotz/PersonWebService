
CREATE PROCEDURE [prop].[prc_Prop_get]
(
	@PropPageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PropertyID],
	[PropPageID],
	[No],
	[MultiValue],
	[Type],
	[ValueType],
	[FormatString]
	FROM [prop].[Prop]
	WHERE
	[PropPageID] = @PropPageID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

