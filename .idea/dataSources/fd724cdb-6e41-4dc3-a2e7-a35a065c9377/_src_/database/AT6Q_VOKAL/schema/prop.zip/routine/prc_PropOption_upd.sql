
CREATE PROCEDURE [prop].[prc_PropOption_upd]
(
	@PropOptionID int,
	@PropertyID int,
	@Value float,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [prop].[PropOption]
	SET
		[PropertyID] = @PropertyID,
		[Value] = @Value
	WHERE
		[PropOptionID] = @PropOptionID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropOption',1,
		( SELECT * FROM [prop].[PropOption] 
			WHERE
			[PropOptionID] = @PropOptionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

