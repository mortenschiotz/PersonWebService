
CREATE PROCEDURE [prop].[prc_PropOption_get]
(
	@PropertyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PropOptionID],
	[PropertyID],
	[Value]
	FROM [prop].[PropOption]
	WHERE
	[PropertyID] = @PropertyID

	Set @Err = @@Error

	RETURN @Err
END

