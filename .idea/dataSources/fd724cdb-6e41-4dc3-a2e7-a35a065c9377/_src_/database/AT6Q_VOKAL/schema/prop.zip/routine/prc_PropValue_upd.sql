
CREATE PROCEDURE [prop].[prc_PropValue_upd]
(
	@PropValueID int,
	@PropertyID int,
	@PropOptionID int = null,
	@PropFileID int = null,
	@No smallint,
	@Created datetime,
	@CreatedBy INT=NULL,
	@Updated datetime = null output,
	@UpdatedBy INT=NULL,
	@ItemID int,
	@Value ntext,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SET @Updated = getdate()
	UPDATE [prop].[PropValue]
	SET
		[PropertyID] = @PropertyID,
		[PropOptionID] = @PropOptionID,
		[PropFileID] = @PropFileID,
		[No] = @No,
		[Updated] = @Updated,
		[UpdatedBy] = @UpdatedBy,
		[ItemID] = @ItemID,
		[Value] = @Value
	WHERE
		[PropValueID] = @PropValueID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropValue',1,
		( SELECT * FROM [prop].[PropValue] 
			WHERE
			[PropValueID] = @PropValueID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

