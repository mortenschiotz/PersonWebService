

CREATE PROCEDURE [prop].[prc_PropPage_del]
(
	@PropPageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropPage',2,
		( SELECT * FROM [prop].[PropPage] 
			WHERE
			[PropPageID] = @PropPageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[PropPage]
	WHERE
		[PropPageID] = @PropPageID

	Set @Err = @@Error

	RETURN @Err
END

