

CREATE PROCEDURE [prop].[prc_Prop_del]
(
	@PropertyID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Prop',2,
		( SELECT * FROM [prop].[Prop] 
			WHERE
			[PropertyID] = @PropertyID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [prop].[Prop]
	WHERE
		[PropertyID] = @PropertyID

	Set @Err = @@Error

	RETURN @Err
END

