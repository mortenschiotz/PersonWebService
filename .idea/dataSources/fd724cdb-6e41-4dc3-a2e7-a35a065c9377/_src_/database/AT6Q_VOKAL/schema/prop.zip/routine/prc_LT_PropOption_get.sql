
CREATE PROCEDURE [prop].[prc_LT_PropOption_get]
(
	@PropOptionID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PropOptionID],
	[Name],
	[Description]
	FROM [prop].[LT_PropOption]
	WHERE
	[PropOptionID] = @PropOptionID

	Set @Err = @@Error

	RETURN @Err
END

