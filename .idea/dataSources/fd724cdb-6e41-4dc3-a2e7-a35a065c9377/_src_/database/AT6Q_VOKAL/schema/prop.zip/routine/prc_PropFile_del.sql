

CREATE PROCEDURE [prop].[prc_PropFile_del]
(
	@PropFileID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PropFile',33,
		(	SELECT *
			FROM [prop].[PropFile] 
			WHERE [PropFileID] = @PropFileID FOR XML AUTO) as data,
		getdate() 
	END
	
	UPDATE [prop].[PropFile]
	SET
		[Deleted] = 1
	WHERE
		[PropFileID] = @PropFileID
/*
DELETE FROM [prop].[PropFile]
WHERE [FileID] = @FileID
*/
	Set @Err = @@Error

	RETURN @Err
END



