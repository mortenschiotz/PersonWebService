
CREATE PROCEDURE [prop].[prc_LT_PropPage_ins]
(
	@LanguageID int,
	@PropPageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [prop].[LT_PropPage]
	(
		[LanguageID],
		[PropPageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@PropPageID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_PropPage',0,
		( SELECT * FROM [prop].[LT_PropPage] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PropPageID] = @PropPageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

