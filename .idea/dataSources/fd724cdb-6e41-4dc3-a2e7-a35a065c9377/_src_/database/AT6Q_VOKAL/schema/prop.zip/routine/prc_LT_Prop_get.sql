
CREATE PROCEDURE [prop].[prc_LT_Prop_get]
(
	@PropertyID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PropertyID],
	[Name],
	[Description]
	FROM [prop].[LT_Prop]
	WHERE
	[PropertyID] = @PropertyID

	Set @Err = @@Error

	RETURN @Err
END

