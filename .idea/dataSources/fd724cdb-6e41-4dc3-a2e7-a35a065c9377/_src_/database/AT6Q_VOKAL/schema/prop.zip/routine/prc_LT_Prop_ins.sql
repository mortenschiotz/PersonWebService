
CREATE PROCEDURE [prop].[prc_LT_Prop_ins]
(
	@LanguageID int,
	@PropertyID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [prop].[LT_Prop]
	(
		[LanguageID],
		[PropertyID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@PropertyID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Prop',0,
		( SELECT * FROM [prop].[LT_Prop] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PropertyID] = @PropertyID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

