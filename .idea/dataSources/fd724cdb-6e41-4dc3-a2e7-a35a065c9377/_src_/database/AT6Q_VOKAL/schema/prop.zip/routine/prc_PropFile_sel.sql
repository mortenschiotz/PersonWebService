

CREATE PROCEDURE [prop].[prc_PropFile_sel]
(
	@PropFileId int,
	@OwnerId int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT [PropFileId],[GUID],[OwnerId],[CustomerId],[ContentType],[Size],[Title],[FileName],[Description]
	FROM [prop].[PropFile]
	WHERE [PropFileId] = @PropFileId AND OwnerId  = @OwnerId AND Deleted  = 0

	Set @Err = @@Error

	RETURN @Err
END

