CREATE PROCEDURE [prop].[prc_LT_PropPage_get]
(
	@PropPageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT 
	[LanguageID], 
	[PropPageID], 
	[Name], 
	[Description]
	FROM [prop].[LT_PropPage]
	WHERE
	[PropPageID] = @PropPageID

	Set @Err = @@Error

	RETURN @Err
END