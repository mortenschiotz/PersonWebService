
CREATE PROCEDURE [list].[prc_ItemListCommand_get]
	@ItemListID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListCommandID],
		[ItemListID],
		[PlaceAbove],
		[PlaceBelow],
		[MultiCheckCommand],
		[DisabledInEmptyList],
		[CssClass],
		[ClientFunction],
		[Created],
		[No]
	FROM [list].[ItemListCommand]
	WHERE [ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
