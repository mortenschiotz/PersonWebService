CREATE PROCEDURE [list].[prc_LT_ItemList_ins]
(
	@LanguageID int,
	@ItemListID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@RowTooltipText nvarchar(256),
	@EmptyListText nvarchar(max),
    @cUserid int,
    @Log smallint = 1
)    
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	INSERT INTO [list].[LT_ItemList]
           ([LanguageID]
           ,[ItemListID]
           ,[Name]
           ,[Description]
           ,[RowTooltipText]
           ,[EmptyListText])
     VALUES
           (@LanguageID
           ,@ItemListID
           ,@Name
           ,@Description
           ,@RowTooltipText
           ,@EmptyListText)
           
     Set @Err = @@Error
	 IF @Log = 1 
	 BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemList',0,
		( SELECT * FROM [list].[LT_ItemList] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListID] = @ItemListID				 FOR XML AUTO) as data,
				getdate() 
	  END

	
	 RETURN @Err
END
