CREATE PROCEDURE [list].[prc_LT_ItemListField_del]
	@LanguageID int,
	@ItemListFieldID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemListField',2,
		( SELECT * FROM [list].[LT_ItemListField] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListFieldID] = @ItemListFieldID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[LT_ItemListField]
    WHERE
		[LanguageID] = @LanguageID AND
		[ItemListFieldID] = @ItemListFieldID
	
	Set @Err = @@Error

	RETURN @Err
  
END
