CREATE PROCEDURE [list].[prc_ItemList_get]
	@OwnerID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListID],
		[OwnerID],
		[ItemListDataSourceID],
		[ListTableCSSClass],
		[ListTableCSSCStyle],
		[ListHeaderRowCSSClass],
		[ListRowCSSClass],
		[ListAltRowCSSClass],
		[ExpandingItemListDatasourceID],
		[ExpandingListRowCSSClass],
		[ExpandingListAltRowCSSClass],
		[ExpandingExpression],
		[InsertMultiCheckColumn],
		[DisableCheckColumnExpression],
		[DisplayUpperCmdBarThreshold],
		[MaxRows],
		[ExtID],
		[Created]
	FROM [list].[ItemList]
	WHERE [OwnerID] = @OwnerID
	
	Set @Err = @@Error

	RETURN @Err
  
END
