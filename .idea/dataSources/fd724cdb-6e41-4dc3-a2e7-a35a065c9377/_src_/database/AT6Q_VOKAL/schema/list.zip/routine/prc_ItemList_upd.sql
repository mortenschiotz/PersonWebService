CREATE PROCEDURE [list].[prc_ItemList_upd]
	@ItemListID int,
	@OwnerID int,
    @ItemListDataSourceID int = null,
    @ListTableCSSClass nvarchar(128),
    @ListTableCSSCStyle nvarchar(64),
    @ListHeaderRowCSSClass nvarchar(64),
    @ListRowCSSClass nvarchar(64),
    @ListAltRowCSSClass nvarchar(64),
    @ExpandingItemListDatasourceID int = null,
    @ExpandingListRowCSSClass nvarchar(64),
    @ExpandingListAltRowCSSClass nvarchar(64),
    @ExpandingExpression nvarchar(64),
    @InsertMultiCheckColumn bit,
    @DisableCheckColumnExpression nvarchar(128),
    @DisplayUpperCmdBarThreshold int,
    @MaxRows int,
	@ExtID nvarchar(64) = '',
    @cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    UPDATE [list].[ItemList]
    SET 
		[OwnerID] = @OwnerID,
        [ItemListDataSourceID] = @ItemListDataSourceID,
        [ListTableCSSClass] = @ListTableCSSClass,
        [ListTableCSSCStyle] = @ListTableCSSCStyle,
        [ListHeaderRowCSSClass] = @ListHeaderRowCSSClass,
        [ListRowCSSClass] = @ListRowCSSClass,
        [ListAltRowCSSClass] = @ListAltRowCSSClass,
        [ExpandingItemListDatasourceID] = @ExpandingItemListDatasourceID,
        [ExpandingListRowCSSClass] = @ExpandingListRowCSSClass,
        [ExpandingListAltRowCSSClass] = @ExpandingListAltRowCSSClass,
        [ExpandingExpression] = @ExpandingExpression,
        [InsertMultiCheckColumn] = @InsertMultiCheckColumn,
        [DisableCheckColumnExpression] = @DisableCheckColumnExpression,
        [DisplayUpperCmdBarThreshold] = @DisplayUpperCmdBarThreshold,
        [MaxRows] = @MaxRows,
		[ExtID] = @ExtID 
     WHERE 
		[ItemListID] = @ItemListID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemList',1,
		( SELECT * FROM [list].[ItemList] 
			WHERE
			[ItemListID] = @ItemListID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err	
END
