CREATE PROCEDURE [list].[prc_LT_ItemListCommand_del]
	@LanguageID int,
	@ItemListCommandID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemListCommand',2,
		( SELECT * FROM [list].[LT_ItemListCommand] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListCommandID] = @ItemListCommandID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[LT_ItemListCommand]
    WHERE
		[LanguageID] = @LanguageID AND
		[ItemListCommandID] = @ItemListCommandID
	
	Set @Err = @@Error

	RETURN @Err
  
END
