CREATE PROCEDURE [list].[prc_ItemListDataParameter_del]
	@ItemListDataParameterID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListDataParameter',2,
		( SELECT * FROM [list].[ItemListDataParameter] 
			WHERE
			[ItemListDataParameterID] = @ItemListDataParameterID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[ItemListDataParameter]
    WHERE
		[ItemListDataParameterID] = @ItemListDataParameterID
	
	Set @Err = @@Error

	RETURN @Err
  
END
