CREATE PROCEDURE [list].[prc_LT_ItemListDataSource_get]
	@ItemListDataSourceID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[ItemListDataSourceID],
		[Name],
		[Description]
	FROM [list].[LT_ItemListDataSource]
	WHERE [ItemListDataSourceID] = @ItemListDataSourceID
	
	Set @Err = @@Error

	RETURN @Err
  
END
