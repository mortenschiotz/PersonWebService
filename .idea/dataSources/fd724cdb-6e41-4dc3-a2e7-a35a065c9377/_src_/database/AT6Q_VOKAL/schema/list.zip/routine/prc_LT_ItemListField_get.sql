CREATE PROCEDURE [list].[prc_LT_ItemListField_get]
	@ItemListFieldID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[ItemListFieldID],
		[Name],
		[Description],
		[HeaderText],
		[HeaderGroupText],
		[HeaderTooltipText],
		[ItemTooltipText],
		[ItemText],
		[ExpandingItemText],
		[DefaultValues],
		[AvailableValues]
	FROM [list].[LT_ItemListField]
	WHERE [ItemListFieldID] = @ItemListFieldID
	
	Set @Err = @@Error

	RETURN @Err
  
END
