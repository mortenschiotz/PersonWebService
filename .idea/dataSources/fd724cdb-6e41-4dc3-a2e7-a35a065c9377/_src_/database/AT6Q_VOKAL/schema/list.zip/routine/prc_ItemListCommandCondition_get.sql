CREATE PROCEDURE [list].[prc_ItemListCommandCondition_get]
	@ItemListCommandID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    SELECT 
		[ItemListCommandConditionID],
		[ItemListCommandID],
		[Type],
		[Param],
		[Value],
		[Created]
	FROM [list].[ItemListCommandCondition]
	WHERE [ItemListCommandID] = @ItemListCommandID

	Set @Err = @@Error

	RETURN @Err
END
