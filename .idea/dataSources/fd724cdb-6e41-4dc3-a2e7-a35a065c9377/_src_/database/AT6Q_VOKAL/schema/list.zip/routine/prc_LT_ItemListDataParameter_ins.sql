CREATE PROCEDURE [list].[prc_LT_ItemListDataParameter_ins]
(
	@LanguageID int,
	@ItemListDataParameterID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
    @cUserid int,
    @Log smallint = 1
)    
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	INSERT INTO [list].[LT_ItemListDataParameter]
           ([LanguageID]
           ,[ItemListDataParameterID]
           ,[Name]
           ,[Description])
     VALUES
           (@LanguageID
           ,@ItemListDataParameterID
           ,@Name
           ,@Description)
           
     Set @Err = @@Error
	 IF @Log = 1 
	 BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemListDataParameter',0,
		( SELECT * FROM [list].[LT_ItemListDataParameter] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListDataParameterID] = @ItemListDataParameterID				 FOR XML AUTO) as data,
				getdate() 
	  END

	
	 RETURN @Err
END
