CREATE PROCEDURE [list].[prc_LT_ItemList_get]
	@ItemListID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[ItemListID],
		[Name],
		[Description],
		[RowTooltipText],
		[EmptyListText]
	FROM [list].[LT_ItemList]
	WHERE [ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
