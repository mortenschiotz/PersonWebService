CREATE PROCEDURE [list].[prc_ItemListCommandCondition_upd]
	@ItemListCommandConditionID int,
	@ItemListCommandID int,
	@Type nvarchar(32),
	@Param nvarchar(max),
	@Value nvarchar(32),
    @cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    UPDATE [list].[ItemListCommandCondition]
    SET 
		[ItemListCommandID] = @ItemListCommandID,
        [Type] = @Type,
        [Param] = @Param,
        [Value] = @Value
     WHERE 
		[ItemListCommandConditionID] = @ItemListCommandConditionID
		
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListCommandCondition',1,
		( SELECT * FROM [list].[ItemListCommandCondition] 
			WHERE
			[ItemListCommandConditionID] = @ItemListCommandConditionID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err	
END
