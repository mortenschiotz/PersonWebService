CREATE PROCEDURE [list].[prc_ItemListField_get]
	@ItemListID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListFieldID],
		[ItemListID],
		[No],
		[TableTypeID],
		[FieldType],
		[ValueType],
		[FieldName],
		[PropID],
		[QuestionID],
		[OverrideLocked],
		[ShowInUserList],
		[ShowInTableView],
		[ShowInExport],
		[Mandatory],
		[Sortable],
		[SortNo],
		[SortDirection],
		[Width],
		[Align],
		[ItemPrefix],
		[ItemSuffix],
		[HeaderCssClass],
		[ItemCssClass],
		[ColumnCssClass],
		[HeaderGroupCSSClass],
		[HeaderGroupLastItem],
		[Created]
	FROM [list].[ItemListField]
	WHERE [ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
