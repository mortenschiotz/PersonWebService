CREATE PROCEDURE [list].[prc_ItemListFieldCondition_del]
	@ItemListFieldConditionID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListFieldCondition',2,
		( SELECT * FROM [list].[ItemListFieldCondition] 
			WHERE
			[ItemListFieldConditionID] = @ItemListFieldConditionID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[ItemListFieldCondition]
    WHERE
		[ItemListFieldConditionID] = @ItemListFieldConditionID
	
	Set @Err = @@Error

	RETURN @Err
  
END
