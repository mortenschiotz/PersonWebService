CREATE PROCEDURE [list].[prc_ItemListFieldAttribute_upd]
	@ItemListFieldAttributeID int,
	@ItemListFieldID int,
	@key nvarchar(64),
	@Value nvarchar(max)='',
    @cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    UPDATE [list].[ItemListFieldAttribute]
    SET 
		[ItemListFieldID] = @ItemListFieldID,
        [key] = @key,
        [Value] = @Value
     WHERE 
		[ItemListFieldAttributeID] = @ItemListFieldAttributeID
		
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListFieldAttribute',1,
		( SELECT * FROM [list].[ItemListFieldAttribute] 
			WHERE
			[ItemListFieldAttributeID] = @ItemListFieldAttributeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err	
END
