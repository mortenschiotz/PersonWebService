
-- =============================================
CREATE PROCEDURE [list].[prc_ItemListFieldExpandingAttribute_upd]
	@ItemListFieldExpandingAttributeID int,
	@ItemListFieldID int,
	@key nvarchar(64),
	@Value nvarchar(256),
    @cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    UPDATE [list].[ItemListFieldExpandingAttribute]
    SET 
		[ItemListFieldID] = @ItemListFieldID,
        [key] = @key,
        [Value] = @Value
     WHERE 
		[ItemListFieldExpandingAttributeID] = @ItemListFieldExpandingAttributeID
		
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListFieldExpandingAttribute',1,
		( SELECT * FROM [list].[ItemListFieldExpandingAttribute] 
			WHERE
			[ItemListFieldExpandingAttributeID] = @ItemListFieldExpandingAttributeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err	
END

