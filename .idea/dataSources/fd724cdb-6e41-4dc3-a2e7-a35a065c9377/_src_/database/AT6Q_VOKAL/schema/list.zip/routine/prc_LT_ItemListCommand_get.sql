CREATE PROCEDURE [list].[prc_LT_ItemListCommand_get]
	@ItemListCommandID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[ItemListCommandID],
		[Name],
		[Description],
		[Text],
		[TooltipText],
		[HotKey]
	FROM [list].[LT_ItemListCommand]
	WHERE [ItemListCommandID] = @ItemListCommandID
	
	Set @Err = @@Error

	RETURN @Err
  
END
