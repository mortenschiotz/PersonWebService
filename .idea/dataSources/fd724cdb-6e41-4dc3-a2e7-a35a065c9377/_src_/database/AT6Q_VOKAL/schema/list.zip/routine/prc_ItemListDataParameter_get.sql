CREATE PROCEDURE [list].[prc_ItemListDataParameter_get]
	@ItemListDataSourceID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListDataParameterID],
		[ItemListDataSourceID],
		[DataType],
		[Type],
		[Mandatory],
		[DefaultValue],
		[ConstructionPattern],
		[Created]
	FROM [list].[ItemListDataParameter]
	WHERE [ItemListDataSourceID] = @ItemListDataSourceID
	
	Set @Err = @@Error

	RETURN @Err
  
END
