CREATE PROCEDURE [list].[prc_LT_ItemListDataParameter_get]
	@ItemListDataParameterID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[LanguageID],
		[ItemListDataParameterID],
		[Name],
		[Description]
	FROM [list].[LT_ItemListDataParameter]
	WHERE [ItemListDataParameterID] = @ItemListDataParameterID
	
	Set @Err = @@Error

	RETURN @Err
  
END
