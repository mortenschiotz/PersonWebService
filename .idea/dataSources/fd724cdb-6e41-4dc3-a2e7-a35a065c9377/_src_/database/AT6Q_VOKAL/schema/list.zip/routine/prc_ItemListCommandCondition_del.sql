CREATE PROCEDURE [list].[prc_ItemListCommandCondition_del]
	@ItemListCommandConditionID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListCommandCondition',2,
		( SELECT * FROM [list].[ItemListCommandCondition] 
			WHERE
			[ItemListCommandConditionID] = @ItemListCommandConditionID
			 FOR XML AUTO) as data,
			getdate() 
	END 

    DELETE FROM [list].[ItemListCommandCondition]
    WHERE
		[ItemListCommandConditionID] = @ItemListCommandConditionID

	Set @Err = @@Error

	RETURN @Err
END
