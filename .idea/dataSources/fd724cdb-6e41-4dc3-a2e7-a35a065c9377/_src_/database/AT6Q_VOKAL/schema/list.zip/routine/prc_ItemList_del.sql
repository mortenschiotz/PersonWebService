CREATE PROCEDURE [list].[prc_ItemList_del]
	@ItemListID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemList',2,
		( SELECT * FROM [list].[ItemList] 
			WHERE
			[ItemListID] = @ItemListID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[ItemList]
    WHERE
		[ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
