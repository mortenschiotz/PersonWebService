CREATE PROCEDURE [list].[prc_ItemListFieldExpandingAttribute_del]
	@ItemListFieldExpandingAttributeID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListFieldExpandingAttribute',2,
		( SELECT * FROM [list].[ItemListFieldExpandingAttribute] 
			WHERE
			[ItemListFieldExpandingAttributeID] = @ItemListFieldExpandingAttributeID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[ItemListFieldExpandingAttribute]
    WHERE
		[ItemListFieldExpandingAttributeID] = @ItemListFieldExpandingAttributeID
	
	Set @Err = @@Error

	RETURN @Err
  
END
