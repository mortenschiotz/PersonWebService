CREATE PROCEDURE [list].[prc_ItemListFieldExpandingAttribute_get]
	@ItemListFieldID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListFieldExpandingAttributeID],
		[ItemListFieldID],
		[key],
		[Value],
		[Created]
	FROM [list].[ItemListFieldExpandingAttribute]
	WHERE [ItemListFieldID] = @ItemListFieldID
	
	Set @Err = @@Error

	RETURN @Err
  
END
