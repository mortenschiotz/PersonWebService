CREATE PROCEDURE [list].[prc_ItemListCommand_del]
	@ItemListCommandID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListCommand',2,
		( SELECT * FROM [list].[ItemListCommand] 
			WHERE
			[ItemListCommandID] = @ItemListCommandID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[ItemListCommand]
    WHERE
		[ItemListCommandID] = @ItemListCommandID
	
	Set @Err = @@Error

	RETURN @Err
  
END
