CREATE PROCEDURE [list].[prc_ItemListFieldCondition_get]
	@ItemListFieldID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListFieldConditionID],
		[ItemListFieldID],
		[Type],
		[Param],
		[Value],
		[Created]
	FROM [list].[ItemListFieldCondition]
	WHERE [ItemListFieldID] = @ItemListFieldID
	
	Set @Err = @@Error

	RETURN @Err
  
END
