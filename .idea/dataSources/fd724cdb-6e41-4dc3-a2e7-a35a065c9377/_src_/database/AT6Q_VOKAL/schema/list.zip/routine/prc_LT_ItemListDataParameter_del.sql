CREATE PROCEDURE [list].[prc_LT_ItemListDataParameter_del]
	@LanguageID int,
	@ItemListDataParameterID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemListDataParameter',2,
		( SELECT * FROM [list].[LT_ItemListDataParameter] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListDataParameterID] = @ItemListDataParameterID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[LT_ItemListDataParameter]
    WHERE
		[LanguageID] = @LanguageID AND
		[ItemListDataParameterID] = @ItemListDataParameterID
	
	Set @Err = @@Error

	RETURN @Err
  
END
