CREATE PROCEDURE [list].[prc_ItemListFieldAttribute_get]
	@ItemListFieldID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListFieldAttributeID],
		[ItemListFieldID],
		[key],
		[Value],
		[Created]
	FROM [list].[ItemListFieldAttribute]
	WHERE [ItemListFieldID] = @ItemListFieldID
	
	Set @Err = @@Error

	RETURN @Err
  
END
