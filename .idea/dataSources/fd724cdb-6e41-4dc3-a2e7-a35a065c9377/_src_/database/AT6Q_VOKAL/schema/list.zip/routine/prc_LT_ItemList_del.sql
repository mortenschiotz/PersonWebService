CREATE PROCEDURE [list].[prc_LT_ItemList_del]
	@LanguageID int,
	@ItemListID int,
	@cUserid int,
	@Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_ItemList',2,
		( SELECT * FROM [list].[LT_ItemList] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ItemListID] = @ItemListID
			 FOR XML AUTO) as data,
			getdate() 
	END 
	
    DELETE FROM [list].[LT_ItemList]
    WHERE
		[LanguageID] = @LanguageID AND
		[ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
