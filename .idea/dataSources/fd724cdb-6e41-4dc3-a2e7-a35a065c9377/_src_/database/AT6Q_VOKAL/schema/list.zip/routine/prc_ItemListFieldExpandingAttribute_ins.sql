CREATE PROCEDURE [list].[prc_ItemListFieldExpandingAttribute_ins]
(
	@ItemListFieldExpandingAttributeID int = null output,
	@ItemListFieldID int,
	@key nvarchar(64),
	@Value nvarchar(256),
    @cUserid int,
    @Log smallint = 1
)    
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
	INSERT INTO [list].[ItemListFieldExpandingAttribute]
           ([ItemListFieldID]
           ,[key]
           ,[Value])
     VALUES
           (@ItemListFieldID
           ,@key
           ,@Value)
           
     Set @Err = @@Error
	 Set @ItemListFieldExpandingAttributeID = scope_identity()
	 IF @Log = 1 
	 BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ItemListFieldExpandingAttribute',0,
		( SELECT * FROM [list].[ItemListFieldExpandingAttribute]
			WHERE
			[ItemListFieldExpandingAttributeID] = @ItemListFieldExpandingAttributeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	
	 RETURN @Err
END
