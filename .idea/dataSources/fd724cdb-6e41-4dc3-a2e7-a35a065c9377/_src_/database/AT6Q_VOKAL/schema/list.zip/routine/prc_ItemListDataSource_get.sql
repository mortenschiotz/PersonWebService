CREATE PROCEDURE [list].[prc_ItemListDataSource_get]
	@OwnerID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListDataSourceID],
		[OwnerID],
		[FunctionName],
		[Created]
	FROM [list].[ItemListDataSource]
	WHERE [OwnerID] = @OwnerID
	
	Set @Err = @@Error

	RETURN @Err
  
END
