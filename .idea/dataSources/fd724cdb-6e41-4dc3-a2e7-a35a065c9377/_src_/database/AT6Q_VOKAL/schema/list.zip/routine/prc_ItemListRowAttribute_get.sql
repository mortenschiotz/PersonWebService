CREATE PROCEDURE [list].[prc_ItemListRowAttribute_get]
	@ItemListID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
    SELECT 
		[ItemListRowAttributeID],
		[ItemListID],
		[Key],
		[Value],
		[Created]
	FROM [list].[ItemListRowAttribute]
	WHERE [ItemListID] = @ItemListID
	
	Set @Err = @@Error

	RETURN @Err
  
END
