CREATE PROCEDURE [app].[prc_LT_Site_get]  
 @SiteID int  
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int      
 SELECT   
	   [LanguageID]  
      ,[SiteID]  
      ,[Name]  
      ,[Description]  
      ,[HeadData]
      ,[LoginText]  
      ,[FooterText]  
      ,[SupportText]  
      ,[ClosedText]  
      ,[ExtraFooterTextAfterAuthentication]
	  ,[BaseURL]
	  ,[ShortName]
	  ,[ProductURL]		
	  ,[ProductURLTitle]	
	  ,[BlogURL]			
	  ,[BlogURLTitle]	
	  ,[BodyData]
 FROM         
  [LT_Site]  
 WHERE    
  LT_Site.SiteID = @SiteID  
 Set @Err = @@Error  
 
 RETURN @Err  
END  
