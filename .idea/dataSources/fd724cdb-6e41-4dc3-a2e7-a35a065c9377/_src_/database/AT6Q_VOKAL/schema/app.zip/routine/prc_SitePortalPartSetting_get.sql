CREATE PROCEDURE [app].[prc_SitePortalPartSetting_get]      
 @SiteID int      
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
   [SitePortalpartSettingID]
      ,[SiteID]
      ,[No]
      ,[RenderQuestionIfDottedOrZeroForAllSelections]
      ,[RenderCategoryIfDottedOrZeroForAllSelections]
      ,[RenderReportPartRowIfDottedOrZeroForAllSelections]
      ,[ShowAverageOnFactorPortalPart]
      ,[ShowLevelLimitsOnFactorPortalPart]
      ,[ShowLevelOnFactorPortalPart]
 FROM             
  [SitePortalpartSetting]      
 WHERE        
  [SitePortalpartSetting].SiteID = @SiteID      
   ORDER BY [No]  
 Set @Err = @@Error      
      
 RETURN @Err      
END 
