CREATE PROCEDURE [app].[prc_SiteParameter_ins]
	@SiteParameterID int = null output,
	@SiteID int,
	@Key nvarchar(256),
	@Value nvarchar(max),
	@GroupName nvarchar(max)='',
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[SiteParameter]
           ([SiteID]
           ,[Key]
           ,[Value]
		   ,[GroupName])
     VALUES
           (@SiteID
           ,@Key
           ,@Value
		   ,@GroupName)
           
    Set @Err = @@Error
    Set @SiteParameterID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SiteParameter',0,
		( SELECT * FROM [app].[SiteParameter]
			WHERE
			[SiteParameterID] = @SiteParameterID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
