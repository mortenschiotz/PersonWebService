CREATE PROCEDURE [app].[prc_SitePortalpartSetting_upd]
	@SitePortalpartSettingID int = null output,
	@SiteID int,
	@No int,
	@RenderQuestionIfDottedOrZeroForAllSelections bit,
	@RenderCategoryIfDottedOrZeroForAllSelections bit,
	@RenderReportPartRowIfDottedOrZeroForAllSelections bit,
	@ShowAverageOnFactorPortalPart bit,
	@ShowLevelLimitsOnFactorPortalPart bit,
	@ShowLevelOnFactorPortalPart bit,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    UPDATE [app].[SitePortalpartSetting]
    SET
           [No] = @No,
           [RenderQuestionIfDottedOrZeroForAllSelections] = @RenderQuestionIfDottedOrZeroForAllSelections,
           [RenderCategoryIfDottedOrZeroForAllSelections]=  @RenderCategoryIfDottedOrZeroForAllSelections,
           [RenderReportPartRowIfDottedOrZeroForAllSelections] = @RenderReportPartRowIfDottedOrZeroForAllSelections,
           [ShowAverageOnFactorPortalPart] = @ShowAverageOnFactorPortalPart,
           [ShowLevelLimitsOnFactorPortalPart] = @ShowLevelLimitsOnFactorPortalPart,
           [ShowLevelOnFactorPortalPart] = @ShowLevelOnFactorPortalPart
	WHERE 	[SiteID] = @SiteID AND [SitePortalpartSettingID] = @SitePortalpartSettingID
    Set @Err = @@Error
    Set @SitePortalpartSettingID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SitePortalpartSetting',1,
		( SELECT * FROM [app].[SitePortalpartSetting]
			WHERE
			[SitePortalpartSettingID] = @SitePortalpartSettingID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
