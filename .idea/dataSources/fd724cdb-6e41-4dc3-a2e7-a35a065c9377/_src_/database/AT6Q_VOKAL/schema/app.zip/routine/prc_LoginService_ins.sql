CREATE PROCEDURE [app].[prc_LoginService_ins]
	@LoginServiceID int = null output,
	@SiteID int,
	@HomeRealm nvarchar(512),
	@RealmUrl nvarchar(512),
	@IconUrl nvarchar(512),
	@Issuer nvarchar(512),
	@PropertyID int = null,
	@PrimaryClaimType nvarchar(512),
	@SecondaryClaimType nvarchar(512) ='',
	@CheckAvailability nvarchar(512),
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[LoginService]
           ([SiteID]
           ,[HomeRealm]
           ,[RealmUrl]
           ,[IconUrl]
           ,[Issuer]
           ,[PropertyID]
           ,[PrimaryClaimType]
           ,[SecondaryClaimType]
		   ,[Created]
		   ,[CheckAvailability])
    VALUES
           (@SiteID
           ,@HomeRealm
           ,@RealmUrl
           ,@IconUrl
           ,@Issuer 
           ,@PropertyID
           ,@PrimaryClaimType
           ,@SecondaryClaimType
		   ,getdate()
		   ,@CheckAvailability)
           
    Set @Err = @@Error
	Set @LoginServiceID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LoginService',0,
		( SELECT * FROM [app].[LoginService]
			WHERE
			[LoginServiceID] = @LoginServiceID				 FOR XML AUTO) as data,
				getdate() 
	END

	
	RETURN @Err       
END
