

CREATE PROCEDURE [app].[prc_Menu_del]
(
	@MenuID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Menu',2,
		( SELECT * FROM [app].[Menu] 
			WHERE
			[MenuID] = @MenuID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [app].[Menu]
	WHERE
		[MenuID] = @MenuID

	Set @Err = @@Error

	RETURN @Err
END

