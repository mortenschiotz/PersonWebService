CREATE PROCEDURE [app].[prc_SiteParameter_upd]
	@SiteParameterID int = null output,
	@SiteID int,
	@Key nvarchar(256),
	@Value nvarchar(max),
	@GroupName nvarchar(max)='',
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    UPDATE [app].[SiteParameter]
    SET
           [Key] = @Key,
           [Value] = @Value,
		   [GroupName] = @GroupName
	WHERE [SiteID] =@SiteID   
	AND   [SiteParameterID] =@SiteParameterID 
    Set @Err = @@Error
    Set @SiteParameterID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SiteParameter',1,
		( SELECT * FROM [app].[SiteParameter]
			WHERE
			[SiteParameterID] = @SiteParameterID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
