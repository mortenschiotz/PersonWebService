CREATE PROCEDURE [app].[prc_LT_LoginService_del]
	@LanguageID int,
	@LoginServiceID int,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    DELETE [app].[LT_LoginService]
    WHERE     [LoginServiceID] = @LoginServiceID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LoginService',0,
		( SELECT * FROM [app].[LT_LoginService]
			WHERE
			([LoginServiceID] = @LoginServiceID AND [LanguageID] = @LanguageID) 				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
