

CREATE PROCEDURE [app].[prc_MenuItemType_del]
(
	@MenuItemTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'MenuItemType',2,
		( SELECT * FROM [app].[MenuItemType] 
			WHERE
			[MenuItemTypeID] = @MenuItemTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [app].[MenuItemType]
	WHERE
		[MenuItemTypeID] = @MenuItemTypeID

	Set @Err = @@Error

	RETURN @Err
END

