
CREATE PROCEDURE [app].[prc_PortalPage_ins]
(
	@PortalPageID int = null output,
	@OwnerID int,
	@No smallint,
	@Parameter nvarchar(1024) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [app].[PortalPage]
	(
		[OwnerID],
		[No],
		[Parameter]
	)
	VALUES
	(
		@OwnerID,
		@No,
		@Parameter
	)

	Set @Err = @@Error
	Set @PortalPageID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PortalPage',0,
		( SELECT * FROM [app].[PortalPage] 
			WHERE
			[PortalPageID] = @PortalPageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


