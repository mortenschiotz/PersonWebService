CREATE PROCEDURE [app].[prc_MenuItem_get]
(
	@MenuID int,
	@ParentID int = 0
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @ParentID is null
    Begin
      Set @ParentID = 0
	End

	SELECT
	[MenuItemID],
	[MenuID],
	ISNULL([ParentID], 0) AS 'ParentID',
	ISNULL([MenuItemTypeID], 0) AS 'MenuItemTypeID',
	ISNULL([PortalPageID], 0) AS 'PortalPageID',
	[No],
	[CssClass],
	[URL],
	[Target],
	[IsDefault],
	[Active],
	[Created],
    [NoRender]
	FROM [app].[MenuItem]
	WHERE
	[MenuID] = @MenuID AND ISNULL([ParentID],0) = @ParentID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


