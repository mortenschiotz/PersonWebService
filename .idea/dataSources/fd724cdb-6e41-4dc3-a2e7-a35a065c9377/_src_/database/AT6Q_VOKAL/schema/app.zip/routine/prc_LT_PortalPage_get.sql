
CREATE PROCEDURE [app].[prc_LT_PortalPage_get]
(
	@PortalPageID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PortalPageID],
	[Name],
	[Description]
	FROM [app].[LT_PortalPage]
	WHERE
	[PortalPageID] = @PortalPageID

	Set @Err = @@Error

	RETURN @Err
END

