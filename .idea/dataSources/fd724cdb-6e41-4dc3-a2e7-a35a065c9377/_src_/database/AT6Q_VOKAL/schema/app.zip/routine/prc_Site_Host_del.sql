CREATE PROCEDURE [app].[prc_Site_Host_del]
(	
     @SiteHostID int,  
	 @cUserid int,  
	 @Log smallint = 1 
)
AS
BEGIN
	SET NOCOUNT ON;  
	DECLARE @Err Int 
	
	 IF @Log = 1   
	 BEGIN   
	  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
	  SELECT @cUserid,'Site_Host',2,  
	  ( SELECT * FROM [app].[Site_Host]   
	   WHERE  
	   SiteHostID = @SiteHostID  
		FOR XML AUTO) as data,  
	   getdate()   
	 END   
    
	 DELETE FROM [app].[Site_Host]  
	 WHERE  
	  SiteHostID = @SiteHostID  
  
	SET @Err = @@Error  

	RETURN @Err  
END

