CREATE PROCEDURE [app].[prc_SitePortalpartSetting_ins]
	@SitePortalpartSettingID int = null output,
	@SiteID int,
	@No int,
	@RenderQuestionIfDottedOrZeroForAllSelections bit,
	@RenderCategoryIfDottedOrZeroForAllSelections bit,
	@RenderReportPartRowIfDottedOrZeroForAllSelections bit,
	@ShowAverageOnFactorPortalPart bit,
	@ShowLevelLimitsOnFactorPortalPart bit,
	@ShowLevelOnFactorPortalPart bit,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[SitePortalpartSetting]
           ([SiteID]
           ,[No]
           ,[RenderQuestionIfDottedOrZeroForAllSelections]
           ,[RenderCategoryIfDottedOrZeroForAllSelections]
           ,[RenderReportPartRowIfDottedOrZeroForAllSelections]
           ,[ShowAverageOnFactorPortalPart]
           ,[ShowLevelLimitsOnFactorPortalPart]
           ,[ShowLevelOnFactorPortalPart])
     VALUES
           (@SiteID
           ,@No
           ,@RenderQuestionIfDottedOrZeroForAllSelections
           ,@RenderCategoryIfDottedOrZeroForAllSelections
           ,@RenderReportPartRowIfDottedOrZeroForAllSelections
           ,@ShowAverageOnFactorPortalPart
           ,@ShowLevelLimitsOnFactorPortalPart
           ,@ShowLevelOnFactorPortalPart)
           
    Set @Err = @@Error
    Set @SitePortalpartSettingID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SitePortalpartSetting',0,
		( SELECT * FROM [app].[SitePortalpartSetting]
			WHERE
			[SitePortalpartSettingID] = @SitePortalpartSettingID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
