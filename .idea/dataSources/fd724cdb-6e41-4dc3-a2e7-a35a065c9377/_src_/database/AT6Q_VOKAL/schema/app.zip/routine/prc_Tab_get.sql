CREATE PROCEDURE [app].[prc_Tab_get]    
 @SiteID int    
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int        
 SELECT     
	  [TabID] 	
      ,[SiteID]  
      ,[MenuItemID]
      ,[Settings]
      ,[Created]
 FROM           
  [Tab]    
 WHERE      
  [Tab].SiteID = @SiteID    
 Set @Err = @@Error    
    
 RETURN @Err    
END 
