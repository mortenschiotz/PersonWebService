CREATE PROCEDURE [app].[prc_LoginService_upd]
	@LoginServiceID int,
	@SiteID int,
	@HomeRealm nvarchar(512),
	@RealmUrl nvarchar(512),
	@IconUrl nvarchar(512),
	@Issuer nvarchar(512),
	@PropertyID int = null,
	@PrimaryClaimType nvarchar(512),
	@SecondaryClaimType nvarchar(512) ='',
	@CheckAvailability nvarchar(512),
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    UPDATE [app].[LoginService]
    SET    
         [CheckAvailability] = @CheckAvailability,
		 [HomeRealm] = @HomeRealm,
		 [IconUrl] = @IconUrl,
		 [Issuer] = @Issuer,
		 [PrimaryClaimType] = @PrimaryClaimType,
		 [PropertyID] = @PropertyID,
		 [RealmUrl] = @RealmUrl,
		 [SecondaryClaimType] = @SecondaryClaimType,
		 [SiteID] = @SiteID
    WHERE  [LoginServiceID] =    @LoginServiceID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LoginService',0,
		( SELECT * FROM [app].[LoginService]
			WHERE
			[LoginServiceID] = @LoginServiceID				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
