
CREATE PROCEDURE [app].[prc_PortalPartType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PortalPartTypeID],
	[No]
	FROM [app].[PortalPartType]
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

