CREATE PROCEDURE [app].[prc_MenuItem_ins]
(
	@MenuItemID int = null output,
	@MenuID int,
	@ParentID INT=NULL,
	@MenuItemTypeID INT=NULL,
	@PortalPageID INT=NULL,
	@No smallint,
	@CssClass nvarchar(64),
	@URL nvarchar(512),
	@Target nvarchar(64),
	@IsDefault bit,
	@Active bit,
	@cUserid int,
	@Log smallint = 1,
    @NoRender bit = 0
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [app].[MenuItem]
	(
		[MenuID],
		[ParentID],
		[MenuItemTypeID],
		[PortalPageID],
		[No],
		[CssClass],
		[URL],
		[Target],
		[IsDefault],
		[Active],
        [NoRender]
	)
	VALUES
	(
		@MenuID,
		@ParentID,
		@MenuItemTypeID,
		@PortalPageID,
		@No,
		@CssClass,
		@URL,
		@Target,
		@IsDefault,
		@Active,
        @NoRender
	)

	Set @Err = @@Error
	Set @MenuItemID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'MenuItem',0,
		( SELECT * FROM [app].[MenuItem] 
			WHERE
			[MenuItemID] = @MenuItemID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

