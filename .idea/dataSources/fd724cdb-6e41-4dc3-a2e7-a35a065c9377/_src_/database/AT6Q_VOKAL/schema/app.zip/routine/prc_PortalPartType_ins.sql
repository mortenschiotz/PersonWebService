
CREATE PROCEDURE [app].[prc_PortalPartType_ins]
(
	@PortalPartTypeID int = null output,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [app].[PortalPartType]
	(
		[No]
	)
	VALUES
	(
		@No
	)

	Set @Err = @@Error
	Set @PortalPartTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PortalPartType',0,
		( SELECT * FROM [app].[PortalPartType] 
			WHERE
			[PortalPartTypeID] = @PortalPartTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

