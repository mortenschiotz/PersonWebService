CREATE PROCEDURE [app].[prc_OwnerId_By_SiteId_get]
 @SiteId Int
AS
BEGIN
 SELECT [OwnerID]
 FROM [app].[Site]
 Where [app].[Site].SiteID = @SiteId
END
