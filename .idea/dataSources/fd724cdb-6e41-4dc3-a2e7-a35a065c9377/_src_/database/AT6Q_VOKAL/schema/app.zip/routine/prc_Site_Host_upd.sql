CREATE PROCEDURE [app].[prc_Site_Host_upd]
(	@SiteHostID int = null output,  
    @SiteID		INT,
	@HostName	NVARCHAR(256), 
	@Active		BIT,
	@cUserid int,  
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON;  
	DECLARE @Err Int 
	
	UPDATE app.Site_Host
	SET HostName = @HostName,
	    Active = @Active
	WHERE SiteID = @SiteID
	AND   SiteHostID = @SiteHostID
  
	SET @Err = @@Error  
	SET @SiteHostID = scope_identity() 
	 
	IF @Log = 1
	BEGIN
	  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
	  SELECT @cUserid,'Site_Host',1,  
	  ( SELECT * FROM [app].Site_Host  
	   WHERE	   
	   SiteHostID = @SiteHostID     FOR XML AUTO) as data,  
		getdate()
	END
	RETURN @Err  
END
