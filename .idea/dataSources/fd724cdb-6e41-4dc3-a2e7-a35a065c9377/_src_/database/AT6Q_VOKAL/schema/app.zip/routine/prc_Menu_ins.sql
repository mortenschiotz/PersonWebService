CREATE PROCEDURE [app].[prc_Menu_ins]
(
	@MenuID int = null output,
	@OwnerID int,
	@No smallint,
	@Type smallint,
	@ThemeID int = null,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [app].[Menu]
	(
		[OwnerID],
		[No],
		[Type]
	)
	VALUES
	(
		@OwnerID,
		@No,
		@Type
	)

	Set @Err = @@Error
	Set @MenuID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Menu',0,
		( SELECT * FROM [app].[Menu] 
			WHERE
			[MenuID] = @MenuID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


