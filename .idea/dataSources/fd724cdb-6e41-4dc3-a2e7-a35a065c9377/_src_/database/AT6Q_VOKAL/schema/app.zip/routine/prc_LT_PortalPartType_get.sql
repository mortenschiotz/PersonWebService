
CREATE PROCEDURE [app].[prc_LT_PortalPartType_get]
(
	@PortalPartTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[PortalPartTypeID],
	[Name],
	[Description]
	FROM [app].[LT_PortalPartType]
	WHERE
	[PortalPartTypeID] = @PortalPartTypeID

	Set @Err = @@Error

	RETURN @Err
END

