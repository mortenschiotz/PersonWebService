CREATE PROCEDURE [app].[prc_SiteProcessSetting_del]        
(        
 @ProcessSettingID int,    
 @SiteID int,        
 @cUserid int,        
 @Log smallint = 1        
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'SiteProcessSetting',2,        
  ( SELECT * FROM [app].[SiteProcessSetting]         
   WHERE        
   [SiteID] = @SiteID        
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [app].[SiteProcessSetting]        
 WHERE        
  [SiteID] = @SiteID        
  AND [SiteProcessSettingID] = @ProcessSettingID         
 Set @Err = @@Error        
        
 RETURN @Err        
END 
