CREATE PROCEDURE [app].[prc_Site_Language_get]  
 @SiteID int  
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int      
 SELECT   
	  [LanguageID]
      ,[SiteID]
      ,[No]
 FROM         
  [Site_Language]  
 WHERE    
  [Site_Language].SiteID = @SiteID  
 ORDER BY [No]  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
