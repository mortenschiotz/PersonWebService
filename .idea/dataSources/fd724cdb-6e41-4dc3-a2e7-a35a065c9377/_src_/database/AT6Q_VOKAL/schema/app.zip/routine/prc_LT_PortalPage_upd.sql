
CREATE PROCEDURE [app].[prc_LT_PortalPage_upd]
(
	@LanguageID int,
	@PortalPageID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [app].[LT_PortalPage]
	SET
		[LanguageID] = @LanguageID,
		[PortalPageID] = @PortalPageID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[PortalPageID] = @PortalPageID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_PortalPage',1,
		( SELECT * FROM [app].[LT_PortalPage] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PortalPageID] = @PortalPageID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

