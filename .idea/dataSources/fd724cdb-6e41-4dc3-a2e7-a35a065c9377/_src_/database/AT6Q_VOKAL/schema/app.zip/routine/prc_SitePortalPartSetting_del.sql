CREATE PROCEDURE [app].[prc_SitePortalPartSetting_del]        
(        
 @PortalPartSettingID int,    
 @SiteID int,        
 @cUserid int,        
 @Log smallint = 1        
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'SitePortalPartSetting',2,        
  ( SELECT * FROM [app].[SitePortalPartSetting]         
   WHERE        
   [SiteID] = @SiteID        
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [app].[SitePortalPartSetting]        
 WHERE        
  [SiteID] = @SiteID        
  AND [SitePortalPartSettingID] = @PortalPartSettingID         
 Set @Err = @@Error        
        
 RETURN @Err        
END 
