
CREATE PROCEDURE [app].[prc_PP_VT_upd]
(
	@PortalPartID int,
	@ViewTypeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [app].[PP_VT]
	SET
		[PortalPartID] = @PortalPartID,
		[ViewTypeID] = @ViewTypeID,
		[No] = @No
	WHERE
		[PortalPartID] = @PortalPartID AND
		[ViewTypeID] = @ViewTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PP_VT',1,
		( SELECT * FROM [app].[PP_VT] 
			WHERE
			[PortalPartID] = @PortalPartID AND
			[ViewTypeID] = @ViewTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

