CREATE PROCEDURE [app].[prc_Site_Language_del]    
(    
 @LanguageID int,
 @SiteID int,    
 @cUserid int,    
 @Log smallint = 1    
)    
AS    
BEGIN    
 SET NOCOUNT ON    
 DECLARE @Err Int    
    
 IF @Log = 1     
 BEGIN     
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)     
  SELECT @cUserid,'Site_Language',2,    
  ( SELECT * FROM [app].[Site_Language]     
   WHERE    
   [SiteID] = @SiteID    
    FOR XML AUTO) as data,    
   getdate()     
 END     
    
    
 DELETE FROM [app].[Site_Language]    
 WHERE    
  [SiteID] = @SiteID    
  AND [LanguageID]	= @LanguageID     
 Set @Err = @@Error    
    
 RETURN @Err    
END    
