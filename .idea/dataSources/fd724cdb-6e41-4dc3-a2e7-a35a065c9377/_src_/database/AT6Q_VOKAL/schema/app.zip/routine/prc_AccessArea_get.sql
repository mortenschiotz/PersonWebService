

/* ------------------------------------------------------------
   PROCEDURE:    prc_AccessArea_get

   Description:  Selects records from the table 'AccessArea'

   AUTHOR:       LockwoodTech 07.07.2006 12:52:52
   ------------------------------------------------------------ */
CREATE PROCEDURE [app].[prc_AccessArea_get]

As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	Select
	[AccessAreaID],
	[Name]
	FROM [AccessArea]
	Set @Err = @@Error

	RETURN @Err
End

