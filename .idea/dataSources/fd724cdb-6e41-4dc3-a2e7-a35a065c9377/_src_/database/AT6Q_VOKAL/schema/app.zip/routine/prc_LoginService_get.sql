CREATE PROCEDURE [app].[prc_LoginService_get]  
(  
 @SiteID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
	  [LoginServiceID]  
      ,[SiteID]  
      ,[HomeRealm]  
      ,[RealmUrl]  
      ,[IconUrl]  
      ,[Issuer]  
      ,[PropertyID]  
      ,[PrimaryClaimType]  
      ,[Created]  
      ,[SecondaryClaimType]
	  ,[CheckAvailability]
 FROM [app].[LoginService]  
 WHERE  
 [SiteID] = @SiteID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
