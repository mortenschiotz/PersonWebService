CREATE PROCEDURE [app].[prc_LoginService_User_del]
	@LoginServiceID int,
	@UserID int,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    DELETE [app].[LoginService_User]
    WHERE     ([LoginServiceID] = @LoginServiceID)
       AND ([UserID] = @UserID)


    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LoginService_User',2,
		( SELECT * FROM [app].[LoginService_User]
			WHERE
			[LoginServiceID] = @LoginServiceID AND
			[UserID] = @UserID				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
