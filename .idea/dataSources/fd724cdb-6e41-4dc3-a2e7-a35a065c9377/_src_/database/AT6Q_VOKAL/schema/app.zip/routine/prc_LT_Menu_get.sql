
CREATE PROCEDURE [app].[prc_LT_Menu_get]
(
	@MenuID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[MenuID],
	[Name],
	[Description],
	[Title]
	FROM [app].[LT_Menu]
	WHERE
	[MenuID] = @MenuID

	Set @Err = @@Error

	RETURN @Err
END

