CREATE PROCEDURE [app].[prc_Site_Host_get]
(
	@SiteID int
)
AS
BEGIN
	SET NOCOUNT ON;  
	DECLARE @Err Int 
	SELECT
		SiteHostID,
		SiteID,
		HostName,
		Active
	FROM [app].[Site_Host]
	WHERE
		SiteID=@SiteID AND Active = 1

	SET @Err = @@Error  

	RETURN @Err  
END
