CREATE PROCEDURE [app].[prc_Menu_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[MenuID],
	[OwnerID],
	[No],
	[Type],
	[Created],
	ISNULL(ThemeID,0) as 'ThemeID'
	FROM [app].[Menu]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
