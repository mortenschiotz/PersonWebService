CREATE PROCEDURE [app].[prc_LoginService_del]
	@LoginServiceID int,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int

    DELETE [app].[LoginService]
    WHERE     [LoginServiceID] = @LoginServiceID

    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LoginService',0,
		( SELECT * FROM [app].[LoginService]
			WHERE
			[LoginServiceID] = @LoginServiceID				 FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err       
END
