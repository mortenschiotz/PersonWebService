
CREATE PROCEDURE [app].[prc_PortalPage_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PortalPageID],
	[OwnerID],
	[No],
	[Parameter]
	FROM [app].[PortalPage]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

