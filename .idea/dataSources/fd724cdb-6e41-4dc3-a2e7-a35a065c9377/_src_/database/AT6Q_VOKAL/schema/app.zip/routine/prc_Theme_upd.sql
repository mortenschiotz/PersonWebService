
CREATE PROCEDURE [app].[prc_Theme_upd]
(
	@ThemeID int,
	@Name nvarchar(64),
	@StyleSheet nvarchar(256),
	@Parameters nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [app].[Theme]
	SET
		[Name] = @Name,
		[StyleSheet] = @StyleSheet,
		[Parameters] = @Parameters
	WHERE
		[ThemeID] = @ThemeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Theme',1,
		( SELECT * FROM [app].[Theme] 
			WHERE
			[ThemeID] = @ThemeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

