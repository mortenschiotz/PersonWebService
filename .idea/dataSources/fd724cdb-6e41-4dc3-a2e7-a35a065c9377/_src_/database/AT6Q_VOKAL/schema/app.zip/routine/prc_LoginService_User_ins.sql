CREATE PROCEDURE [app].[prc_LoginService_User_ins]
	@LoginServiceID int,
	@UserID int,
	@PrimaryClaimValue nvarchar(512),
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[LoginService_User]
           ([LoginServiceID]
           ,[UserID]
           ,[PrimaryClaimValue])
    VALUES
           (@LoginServiceID
           ,@UserID
           ,@PrimaryClaimValue)
           
    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LoginService_User',0,
		( SELECT * FROM [app].[LoginService_User]
			WHERE
			[LoginServiceID] = @LoginServiceID AND
			[UserID] = @UserID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
