CREATE PROCEDURE [app].[prc_LT_LoginService_ins]
	@LanguageID int,
	@LoginServiceID int,
	@Name nvarchar(512) = NULL,
	@Description nvarchar(max) = NULL,
	@ToolTip nvarchar(512) = NULL,
	@cUserid int,
    @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[LT_LoginService]
           ([LanguageID]
           ,[LoginServiceID]
           ,[Name]
           ,[Description]
           ,[ToolTip])
    VALUES
           (@LanguageID
           ,@LoginServiceID
           ,@Name
           ,@Description
           ,@ToolTip)
           
    Set @Err = @@Error
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_LoginService',0,
		( SELECT * FROM [app].[LT_LoginService]
			WHERE
			[LanguageID] = @LanguageID AND
			[LoginServiceID] = @LoginServiceID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
