CREATE PROCEDURE [app].[prc_SiteUserSetting_get]      
 @SiteID int,
 @UserID int
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [SiteUserSettingID]
     ,[UserID]
     ,[SiteID]
     ,[EditMode]
     ,[AutoFitScreen]
     ,[ScreenResolution]
     ,[ExportTooltip]
 FROM             
  [app].[SiteUserSetting]      
 WHERE        
  [SiteUserSetting].SiteID = @SiteID      
  AND [SiteUserSetting].[UserID] = @UserID
 Set @Err = @@Error      
      
 RETURN @Err      
END 
