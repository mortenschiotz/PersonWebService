CREATE PROCEDURE [app].[prc_Site_Host_getAll]
(
	@SiteID INT
)
AS
BEGIN
	SET NOCOUNT ON;  
	DECLARE @Err INT 
	SELECT
		SiteHostID,
		SiteID,
		HostName,
		Active
	FROM [app].[Site_Host]
	WHERE
		SiteID=@SiteID

	SET @Err = @@Error  

	RETURN @Err  
END

