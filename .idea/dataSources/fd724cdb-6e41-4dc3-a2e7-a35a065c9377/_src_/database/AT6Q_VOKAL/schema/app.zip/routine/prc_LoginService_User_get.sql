

CREATE PROCEDURE [app].[prc_LoginService_User_get]  
(  
 @UserID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [LoginServiceID]  
    ,[UserID]  
    ,[PrimaryClaimValue]  
    ,[Created]  
 FROM [app].[LoginService_User]  
 WHERE  
 [UserID] = @UserID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  

