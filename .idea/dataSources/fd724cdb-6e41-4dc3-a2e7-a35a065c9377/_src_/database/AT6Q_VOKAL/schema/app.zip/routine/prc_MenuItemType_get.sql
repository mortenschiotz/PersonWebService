
CREATE PROCEDURE [app].[prc_MenuItemType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[MenuItemTypeID],
	ISNULL([Name], '') AS 'Name'
	FROM [app].[MenuItemType]

	Set @Err = @@Error

	RETURN @Err
END

