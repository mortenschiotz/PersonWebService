
CREATE PROCEDURE [app].[prc_LT_PortalPartType_upd]
(
	@LanguageID int,
	@PortalPartTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [app].[LT_PortalPartType]
	SET
		[LanguageID] = @LanguageID,
		[PortalPartTypeID] = @PortalPartTypeID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[PortalPartTypeID] = @PortalPartTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_PortalPartType',1,
		( SELECT * FROM [app].[LT_PortalPartType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PortalPartTypeID] = @PortalPartTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

