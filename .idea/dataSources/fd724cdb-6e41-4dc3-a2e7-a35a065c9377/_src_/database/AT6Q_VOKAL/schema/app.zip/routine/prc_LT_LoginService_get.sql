
CREATE PROCEDURE [app].[prc_LT_LoginService_get]  
(  
 @LoginServiceID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [LanguageID]  
      ,[LoginServiceID]  
      ,[Name]  
      ,[Description]  
      ,[ToolTip]  
 FROM [app].[LT_LoginService]  
 WHERE  
 [LoginServiceID] = @LoginServiceID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  

