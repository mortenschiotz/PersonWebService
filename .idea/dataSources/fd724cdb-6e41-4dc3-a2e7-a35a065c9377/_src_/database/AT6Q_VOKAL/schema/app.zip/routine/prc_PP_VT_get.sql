
CREATE PROCEDURE [app].[prc_PP_VT_get]
(
	@PortalPartID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[PortalPartID],
	[ViewTypeID],
	[No]
	FROM [app].[PP_VT]
	WHERE
	[PortalPartID] = @PortalPartID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

