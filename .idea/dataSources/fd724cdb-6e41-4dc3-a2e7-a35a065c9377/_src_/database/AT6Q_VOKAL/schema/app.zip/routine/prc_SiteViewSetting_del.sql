CREATE PROCEDURE [app].[prc_SiteViewSetting_del]        
(        
 @ViewSettingID int,    
 @SiteID int,        
 @cUserid int,        
 @Log smallint = 1        
)        
AS        
BEGIN        
 SET NOCOUNT ON        
 DECLARE @Err Int        
        
 IF @Log = 1         
 BEGIN         
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)         
  SELECT @cUserid,'SiteViewSetting',2,        
  ( SELECT * FROM [app].[SiteViewSetting]         
   WHERE        
   [SiteID] = @SiteID        
    FOR XML AUTO) as data,        
   getdate()         
 END         
        
        
 DELETE FROM [app].[SiteViewSetting]        
 WHERE        
  [SiteID] = @SiteID        
  AND [SiteViewSettingID] = @ViewSettingID         
 Set @Err = @@Error        
        
 RETURN @Err        
END 
