CREATE PROCEDURE [app].[prc_SiteUserSetting_ins]
 @SiteUserSettingID int = null output,
 @UserID int,
 @SiteID int,
 @EditMode smallint,
 @AutoFitScreen smallint,
 @ScreenResolution int,
 @ExportTooltip smallint,
 @cUserid int,
 @Log smallint = 1
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
    
    INSERT INTO [app].[SiteUserSetting]
           ([UserID]
           ,[SiteID]
           ,[EditMode]
           ,[AutoFitScreen]
           ,[ScreenResolution]
           ,[ExportTooltip])
     VALUES
           (@UserID
           ,@SiteID
           ,@EditMode
           ,@AutoFitScreen
           ,@ScreenResolution
           ,@ExportTooltip)
           
    Set @Err = @@Error
    Set @SiteUserSettingID = scope_identity()
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'SiteUserSetting',0,
		( SELECT * FROM [app].[SiteUserSetting]
			WHERE
			[SiteUserSettingID] = @SiteUserSettingID				 FOR XML AUTO) as data,
				getdate() 
	END
	
	RETURN @Err       
END
