CREATE PROCEDURE [app].[prc_LT_PortalPart_del]
(
	@LanguageID int,
	@PortalPartID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_PortalPart',2,
		( SELECT * FROM [app].[LT_PortalPart] 
			WHERE
			[LanguageID] = @LanguageID AND
			[PortalPartID] = @PortalPartID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [app].[LT_PortalPart]
	WHERE
		[LanguageID] = @LanguageID AND
		[PortalPartID] = @PortalPartID

	Set @Err = @@Error

	RETURN @Err
END

