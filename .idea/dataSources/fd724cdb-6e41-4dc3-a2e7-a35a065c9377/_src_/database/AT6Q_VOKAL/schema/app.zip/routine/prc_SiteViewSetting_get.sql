CREATE PROCEDURE [app].[prc_SiteViewSetting_get]      
 @SiteID int      
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	 [SiteViewSettingID]
      ,[SiteID]
      ,[No]
      ,[NumOfDecimals]
      ,[TableIsSelectable]
      ,[TableIsDefaultSelected]
      ,[ChartIsSelectable]
      ,[ChartIsDefaultSelected]
      ,[AverageIsSelectable]
      ,[AverageIsDefaultSelected]
      ,[TrendIsSelectable]
      ,[TrendIsDefaultSelected]
      ,[FrequencyIsSelectable]
      ,[FrequencyIsDefaultSelected]
      ,[NCountIsSelectable]
      ,[NCountIsDefaultSelected]
      ,[StandardDeviationIsSelectable]
      ,[StandardDeviationIsDefaultSelected]
      ,[Created]
      ,[DefaultMinResultDotted]
      ,[DefaultMinQuestionCountDotted]
 FROM             
  [SiteViewSetting]      
 WHERE        
  [SiteViewSetting].SiteID = @SiteID      
   ORDER BY [No]  
 Set @Err = @@Error      
      
 RETURN @Err      
END 
