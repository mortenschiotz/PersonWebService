CREATE PROCEDURE [app].[prc_SiteParameter_get]    
 @SiteID int    
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int        
 SELECT     
	  [SiteParameterID] 	
      ,[SiteID]  
      ,[Key]
      ,[Value]
	  ,[GroupName]
      ,[Created]
 FROM           
  [SiteParameter]    
 WHERE      
  [SiteParameter].SiteID = @SiteID    
 Set @Err = @@Error    
    
 RETURN @Err    
END 

