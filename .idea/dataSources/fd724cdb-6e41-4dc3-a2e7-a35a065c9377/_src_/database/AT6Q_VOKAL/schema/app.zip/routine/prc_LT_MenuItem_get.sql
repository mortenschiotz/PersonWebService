CREATE PROCEDURE [app].[prc_LT_MenuItem_get]  
(  
 @MenuItemID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [LanguageID],  
 [MenuItemID],  
 ISNULL([Name], '') AS 'Name',  
 ISNULL([Description], '') AS 'Description',  
 ISNULL([ToolTip], '') AS 'ToolTip',  
 ISNULL([URL], '') AS 'URL'
 FROM [app].[LT_MenuItem]  
 WHERE  
 [MenuItemID] = @MenuItemID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
    
