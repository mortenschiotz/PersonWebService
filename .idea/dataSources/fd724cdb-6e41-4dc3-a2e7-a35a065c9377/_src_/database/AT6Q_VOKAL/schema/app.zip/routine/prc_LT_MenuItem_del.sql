

CREATE PROCEDURE [app].[prc_LT_MenuItem_del]
(
	@LanguageID int,
	@MenuItemID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_MenuItem',2,
		( SELECT * FROM [app].[LT_MenuItem] 
			WHERE
			[LanguageID] = @LanguageID AND
			[MenuItemID] = @MenuItemID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [app].[LT_MenuItem]
	WHERE
		[LanguageID] = @LanguageID AND
		[MenuItemID] = @MenuItemID

	Set @Err = @@Error

	RETURN @Err
END

