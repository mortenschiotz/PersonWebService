CREATE PROCEDURE [app].[prc_SiteProcessSetting_get]      
 @SiteID int      
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE @Err Int          
 SELECT       
	  [SiteProcessSettingID]
      ,[SiteID]
      ,[No]
      ,[UseLocalProcessGroups]
      ,[AllCanAddAnswers]
      ,[UsePeriod]
      ,[CanChangeuser]
      ,[ShowOnlyAnswersBlowOnAdminPage]
      ,[CanAddProcessGroup]
      ,[CanCreatorEditAnswer]
      ,[ShowEditButtonOnProcessAnswer]
 FROM             
  [SiteProcessSetting]      
 WHERE        
  [SiteProcessSetting].SiteID = @SiteID      
   ORDER BY [No]  
 Set @Err = @@Error      
      
 RETURN @Err      
END 
