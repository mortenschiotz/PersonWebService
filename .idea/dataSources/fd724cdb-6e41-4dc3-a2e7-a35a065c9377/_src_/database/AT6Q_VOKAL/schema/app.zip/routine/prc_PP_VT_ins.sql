
CREATE PROCEDURE [app].[prc_PP_VT_ins]
(
	@PortalPartID int,
	@ViewTypeID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [app].[PP_VT]
	(
		[PortalPartID],
		[ViewTypeID],
		[No]
	)
	VALUES
	(
		@PortalPartID,
		@ViewTypeID,
		@No
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PP_VT',0,
		( SELECT * FROM [app].[PP_VT] 
			WHERE
			[PortalPartID] = @PortalPartID AND
			[ViewTypeID] = @ViewTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

