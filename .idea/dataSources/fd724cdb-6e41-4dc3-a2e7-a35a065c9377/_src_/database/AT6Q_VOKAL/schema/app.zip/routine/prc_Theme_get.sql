
CREATE PROCEDURE [app].[prc_Theme_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ThemeID],
	[Name],
	[StyleSheet],
	[Parameters],
	[Created]
	FROM [app].[Theme]

	Set @Err = @@Error

	RETURN @Err
END

