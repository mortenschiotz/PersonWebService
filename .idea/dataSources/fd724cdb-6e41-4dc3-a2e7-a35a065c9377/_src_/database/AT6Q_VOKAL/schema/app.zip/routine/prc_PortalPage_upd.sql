

CREATE PROCEDURE [app].[prc_PortalPage_upd]
(
	@PortalPageID int,
	@OwnerID int,
	@No smallint,
	@Parameter nvarchar(1024) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [app].[PortalPage]
	SET
		[OwnerID] = @OwnerID,
		[No] = @No,
		[Parameter] = @Parameter 
	WHERE
		[PortalPageID] = @PortalPageID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'PortalPage',1,
		( SELECT * FROM [app].[PortalPage] 
			WHERE
			[PortalPageID] = @PortalPageID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


