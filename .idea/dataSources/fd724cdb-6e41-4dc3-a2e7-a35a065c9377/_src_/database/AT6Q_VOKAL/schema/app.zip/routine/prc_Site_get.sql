CREATE PROCEDURE [app].[prc_Site_get]  
 @OwnerID int  
AS  
BEGIN  
 SET NOCOUNT ON;  
 DECLARE @Err Int      
 SELECT   
	  [SiteID]  
      ,[OwnerID]  
      ,[CodeName]  
      ,[UseNativeLogon]  
      ,[ThemeID]  
      ,[IsClosed]  
      ,[DefaultMenuID]  
      ,[DefaultHierarchyID]  
      ,[UseMultipleMenus]  
      ,[DefaultChartTemplate]  
      ,[UseCustomer]  
      ,[UsePasswordRecovery]  
      ,[MaintenanceMode]
      ,[UseRememberMe]   
      ,[Created]
      ,[UseReturnURL]
      ,[UseSMS]
      ,UseMemoryCache		
	  ,UseDistributedCache	
	  ,DistributedCacheName  
	  ,CacheExpiredAfter
	  ,MailHeaderInfoXCompany 
	  ,MailHeaderInfoMessageID
	  ,LanguageIDWhenNotAuthenticated	
	  ,LogoutURL		
	  ,TimeOutLogoutURL
      ,Logo
	  ,CssVariables
         
 FROM         
  Site  
 WHERE    
  Site.OwnerID = @OwnerID  
 Set @Err = @@Error  

 RETURN @Err  
END   
