CREATE PROCEDURE [app].[prc_MenuItem_upd]
(
@MenuItemID int,
@MenuID int,
@ParentID INT=NULL,
@MenuItemTypeID INT=NULL,
@PortalPageID INT=NULL,
@No smallint,
@CssClass nvarchar(64),
@URL nvarchar(512),
@Target nvarchar(64),
@IsDefault bit,
@Active bit,
@cUserid int,
@Log smallint = 1,
@NoRender bit = 0
)
AS
BEGIN
SET NOCOUNT ON
DECLARE @Err Int
UPDATE [app].[MenuItem]
SET
[MenuID] = @MenuID,
[ParentID] = @ParentID,
[MenuItemTypeID] = @MenuItemTypeID,
[PortalPageID] = @PortalPageID,
[No] = @No,
[CssClass] = @CssClass,
[URL] = @URL,
[Target] = @Target,
[IsDefault] = @IsDefault,
[Active] = @Active,
[NoRender] = @NoRender
WHERE
[MenuItemID] = @MenuItemID
IF @Log = 1
BEGIN
INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)
SELECT @cUserid,'MenuItem',1,
( SELECT * FROM [app].[MenuItem]
WHERE
[MenuItemID] = @MenuItemID FOR XML AUTO) as data,
getdate()
END
Set @Err = @@Error
RETURN @Err
END
