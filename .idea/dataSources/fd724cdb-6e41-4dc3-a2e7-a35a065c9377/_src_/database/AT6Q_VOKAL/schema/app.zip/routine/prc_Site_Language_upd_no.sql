CREATE PROCEDURE [app].[prc_Site_Language_upd_no]    
 @LanguageID int,    
 @SiteID int,    
 @No int,    
 @cUserid int,    
  @Log smallint = 1    
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE @Err Int    
        
    UPDATE [app].[Site_Language]    
    SET   [No] = @No
  
    WHERE [SiteID] = @SiteID  AND [LanguageID] = @LanguageID  
    Set @Err = @@Error    
    IF @Log = 1     
  BEGIN     
   INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)     
   SELECT @cUserid,'Site_Language',1,    
   ( SELECT * FROM [app].[Site_Language]    
    WHERE    
    [LanguageID] = @LanguageID AND    
    [SiteID] = @SiteID     FOR XML AUTO) as data,    
  getdate()     
  END    
     
 RETURN @Err           
END    
