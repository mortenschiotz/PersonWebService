CREATE PROCEDURE [log].[prc_LT_EventKey_del]
(
	@EventKeyID	int,
	@LanguageID	int,
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_EventKey',2,
		( SELECT * FROM [log].[LT_EventKey]
			WHERE
			[EventKeyID] = @EventKeyID AND [LanguageID] = @LanguageID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [log].[LT_EventKey]
	WHERE [EventKeyID] = @EventKeyID AND [LanguageID] = @LanguageID
		
	Set @Err = @@Error
	
	RETURN @Err
END
