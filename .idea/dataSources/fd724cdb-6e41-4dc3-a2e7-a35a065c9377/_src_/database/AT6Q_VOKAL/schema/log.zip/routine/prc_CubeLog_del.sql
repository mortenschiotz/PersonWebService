
CREATE PROCEDURE [log].[prc_CubeLog_del]
(
	@CubeLogID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'CubeLog',2,
		( SELECT * FROM [log].[CubeLog] 
			WHERE
			[CubeLogID] = @CubeLogID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [log].[CubeLog]
	WHERE
		[CubeLogID] = @CubeLogID

	Set @Err = @@Error

	RETURN @Err
END

