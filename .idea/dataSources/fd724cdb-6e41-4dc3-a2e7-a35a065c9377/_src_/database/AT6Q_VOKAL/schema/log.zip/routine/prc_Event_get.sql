CREATE PROCEDURE [log].[prc_Event_get]
    @EventID	int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [EventID],
            [EventTypeID],
            [UserID],
            [IPNumber],
            [TableTypeID],
            [ItemID],
            [Created],
            [ApplicationName],
            [DepartmentID],
            [CustomerID],
            [UserData]
    FROM  [log].[Event]
    WHERE [EventID] = @EventID
	
    Set @Err = @@Error

    RETURN @Err
  
END
