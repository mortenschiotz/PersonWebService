CREATE PROCEDURE [log].[prc_Event_upd]
(
    @EventID			int,
    @EventTypeID		int,
    @UserID				INT=NULL,
    @IPNumber			nvarchar(32),
    @TableTypeID		SMALLINT=NULL,
    @ItemID				INT=NULL,
    @cUserid			int,
    @Log				smallint = 1,
    @ApplicationName	nvarchar(128)='',
    @DepartmentID		INT =NULL,
    @CustomerID			INT =NULL,
    @UserData           XML =NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [log].[Event]
	SET
        [EventTypeID] = @EventTypeID,
        [UserID] = @UserID,
        [IPNumber] = @IPNumber,
        [TableTypeID] = @TableTypeID,
        [ItemID] = @ItemID,
        [ApplicationName]=@ApplicationName,
        [DepartmentID]= @DepartmentID,
        [CustomerID]=@CustomerID,
        [UserData] =@UserData
	WHERE
		 [EventID] = @EventID

	Set @Err = @@Error
	
	IF @Log = 1 AND @cUserid != 0 
	BEGIN	 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Event',1,
		( SELECT * FROM [log].[Event]
			WHERE
			[EventID] = @EventID FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END
