create PROC [log].[prc_Error_ins]
(
	@UserID			bigint,
	@ErrNo			int,
	@ErrDesc		varchar(500),
	@Place			varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON
 	INSERT [log].Errors(UserID, ErrNo, ErrDesc, Place)
 	VALUES(@UserID, @ErrNo, @ErrDesc, @Place) 	
	SET NOCOUNT OFF
END
