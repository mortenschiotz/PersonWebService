CREATE PROCEDURE [log].[prc_EventInfo_ins]
(
	@EventInfoID	int = NULL output,
	@EventID		int,
	@EventKeyID	int,
	@Value		nvarchar(max),
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [log].[EventInfo]
	(
		[EventID],
		[EventKeyID],
		[Value],
		[Created]
	)
	VALUES
	(
		@EventID,
		@EventKeyID,
		@Value,
		getdate()
	)

	Set @Err = @@Error
	Set @EventInfoID = scope_identity()
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'EventInfo',0,
		( SELECT * FROM [log].[EventInfo]
			WHERE
			[EventInfoID] = @EventInfoID FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END
