CREATE PROCEDURE [log].[prc_LT_EventType_get]
	@EventTypeID	int,
	@LanguageID	int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [EventTypeID],
		  [LanguageID],
		  [Name],
		  [Description]
	FROM  [log].[LT_EventType]
	WHERE [EventTypeID] = @EventTypeID
	  AND [LanguageID]  = @LanguageID
	
	Set @Err = @@Error

	RETURN @Err
  
END
