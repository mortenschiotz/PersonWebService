CREATE PROCEDURE [log].[prc_EventInfo_upd]
(
	@EventInfoID	int,
	@EventID		int,
	@EventKeyID	int,
	@Value		nvarchar(max),
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [log].[EventInfo]
	SET
		[EventID] = @EventID,
		[EventKeyID] = @EventKeyID,
		[Value] = @Value
	WHERE
		 [EventInfoID] = @EventInfoID

	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'EventInfo',1,
		( SELECT * FROM [log].[EventInfo]
			WHERE
			[EventInfoID] = @EventInfoID FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END
