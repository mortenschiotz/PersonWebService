
CREATE PROCEDURE [log].[prc_BubbleLog_ins]
(
	@BubbleLogID int = null output,
	@BubbleID int,
	@SurveyID int,
	@Type smallint,
	@Status smallint,
	@Description nvarchar(max),
	@ReportServer nvarchar(64)='',
	@ReportDB nvarchar(64)=''
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [log].[BubbleLog]
	(
		[BubbleID],
		[SurveyID],
		[Type],
		[Status],
		[Description],
		[ReportServer],
		[ReportDB]
	)
	VALUES
	(
		@BubbleID,
		@SurveyID,
		@Type,
		@Status,
		@Description,
		@ReportServer,
		@ReportDB
	)

	Set @Err = @@Error

	RETURN @Err
END

