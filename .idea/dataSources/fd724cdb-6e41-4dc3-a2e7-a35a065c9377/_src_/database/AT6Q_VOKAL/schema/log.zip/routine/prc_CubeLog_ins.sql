
CREATE PROCEDURE [log].[prc_CubeLog_ins]
(
	@CubLogID int = null output,
	@SurveyID int,
	@Type smallint,
	@Status smallint,
	@ReportServer nvarchar(64)='',
	@ReportDB nvarchar(64)='',
	@Description nvarchar(max)
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [log].[CubeLog]
	(
		[SurveyID],
		[Type],
		[Status],
		[Description],
		[ReportServer],
		[ReportDB]
	)
	VALUES
	(
		@SurveyID,
		@Type,
		@Status,
		@Description,
		@ReportServer,
		@ReportDB
	)

	Set @Err = @@Error

	RETURN @Err
END

