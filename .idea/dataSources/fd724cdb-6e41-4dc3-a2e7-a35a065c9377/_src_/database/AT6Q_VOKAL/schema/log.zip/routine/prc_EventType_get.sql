
CREATE PROCEDURE [log].[prc_EventType_get]
	@EventTypeID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [EventTypeID],
		  [ParentID],
		  [CodeName],
		  [OwnerID],
		  [No],
		  [Active]
	FROM [log].[EventType]
	WHERE [EventTypeID] = @EventTypeID
	
	Set @Err = @@Error

	RETURN @Err
  
END
