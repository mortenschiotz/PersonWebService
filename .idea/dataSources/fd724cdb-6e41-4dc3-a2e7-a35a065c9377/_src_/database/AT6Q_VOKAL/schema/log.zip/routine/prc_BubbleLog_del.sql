
CREATE PROCEDURE [log].[prc_BubbleLog_del]
(
	@BubbleLogID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'BubbleLog',2,
		( SELECT * FROM [log].[BubbleLog] 
			WHERE
			[BubbleLogID] = @BubbleLogID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [log].[BubbleLog]
	WHERE
		[BubbleLogID] = @BubbleLogID

	Set @Err = @@Error

	RETURN @Err
END

