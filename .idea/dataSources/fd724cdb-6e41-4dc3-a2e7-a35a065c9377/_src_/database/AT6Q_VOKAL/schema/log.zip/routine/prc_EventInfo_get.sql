CREATE PROCEDURE [log].[prc_EventInfo_get]
	@EventInfoID	int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [EventInfoID],
		  [EventID],
		  [EventKeyID],
		  [Value],
		  [Created]
	FROM  [log].[EventInfo]
	WHERE [EventInfoID] = @EventInfoID
	
	Set @Err = @@Error

	RETURN @Err
  
END
