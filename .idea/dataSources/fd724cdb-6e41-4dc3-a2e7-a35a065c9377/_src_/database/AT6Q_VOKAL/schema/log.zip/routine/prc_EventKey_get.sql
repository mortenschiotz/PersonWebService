CREATE PROCEDURE [log].[prc_EventKey_get]
	@EventKeyID	int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [EventKeyID],
		  [EventTypeID],
		  [CodeName],
		  [Encrypt],
		  [Created]
	FROM  [log].[EventKey]
	WHERE [EventKeyID] = @EventKeyID
	
	Set @Err = @@Error

	RETURN @Err
  
END
