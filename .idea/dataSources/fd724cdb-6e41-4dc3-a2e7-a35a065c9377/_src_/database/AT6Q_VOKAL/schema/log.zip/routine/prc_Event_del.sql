CREATE PROCEDURE [log].[prc_Event_del]
(
	@EventID		int,
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Event',2,
		( SELECT * FROM [log].[Event]
			WHERE
			[EventID] = @EventID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [log].[Event]
	WHERE [EventID] = @EventID
		
	Set @Err = @@Error
	
	RETURN @Err
END
