CREATE PROCEDURE [log].[prc_EventKey_del]
(
	@EventKeyID   int,
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'EventKey',2,
		( SELECT * FROM [log].[EventKey]
			WHERE
			[EventKeyID] = @EventKeyID FOR XML AUTO) as data,
				getdate() 
	 END
	 
	DELETE FROM [log].[EventKey]
	WHERE [EventKeyID] = @EventKeyID
		
	Set @Err = @@Error
	
	RETURN @Err
END
