
CREATE PROCEDURE [log].[prc_LT_EventKey_ins]
(
	@EventKeyID	int = NULL output,
	@LanguageID	int,
	@Name		nvarchar(256),
	@Description	nvarchar(max),
	@cUserid		int,
	@Log			smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [log].[LT_EventKey]
	(
		[EventKeyID],
		[LanguageID],
		[Name],
		[Description]
	)
	VALUES
	(
		@EventKeyID,
		@LanguageID,
		@Name,
		@Description
	)

	Set @Err = @@Error
	
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_EventKey',0,
		( SELECT * FROM [log].[LT_EventKey]
			WHERE
			[EventKeyID] = @EventKeyID AND [LanguageID] = @LanguageID FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END

