CREATE PROCEDURE [log].[prc_Event_ins]
(
    @EventID			int = NULL output,
    @EventTypeID		int,
    @UserID				INT=NULL,
    @IPNumber			nvarchar(32),
    @TableTypeID		SMALLINT=NULL,
    @ItemID				INT=NULL,
    @cUserid			int,
    @Log				smallint = 1,
    @ApplicationName	nvarchar(128)='',
    @DepartmentID		INT =NULL,
    @CustomerID			INT =NULL,
    @UserData           XML =NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [log].[Event]
	(
        [EventTypeID],
        [UserID],
        [IPNumber],
        [TableTypeID],
        [ItemID],
        [Created],
        [ApplicationName],
        [DepartmentID],
        [CustomerID],
        [UserData]
	)
	VALUES
	(
        @EventTypeID,
        @UserID,
        @IPNumber,
        @TableTypeID,
        @ItemID,
        getdate(),
        @ApplicationName,
        @DepartmentID,
        @CustomerID,
        @UserData
	)

	Set @Err = @@Error
	Set @EventID = scope_identity()
	
	IF @Log = 1 AND @cUserid != 0
	BEGIN
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Event',0,
		( SELECT * FROM [log].[Event]
			WHERE
			[EventID] = @EventID FOR XML AUTO) as data,
				getdate() 
	END

	RETURN @Err
END
