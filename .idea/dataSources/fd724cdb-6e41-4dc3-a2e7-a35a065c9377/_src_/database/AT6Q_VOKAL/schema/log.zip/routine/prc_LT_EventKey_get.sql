CREATE PROCEDURE [log].[prc_LT_EventKey_get]
	@EventKeyID	int,
	@LanguageID	int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Err Int
	
     SELECT [LanguageID],
		  [EventKeyID],
		  [Name],
		  [Description]
	FROM  [log].[LT_EventKey]
	WHERE [EventKeyID] = @EventKeyID
	  AND [LanguageID] = @LanguageID
	
	Set @Err = @@Error

	RETURN @Err
  
END
