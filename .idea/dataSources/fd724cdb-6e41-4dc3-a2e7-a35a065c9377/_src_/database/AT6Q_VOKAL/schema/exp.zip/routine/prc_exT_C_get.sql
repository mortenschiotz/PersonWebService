
CREATE PROCEDURE [exp].[prc_exT_C_get]
(
	@ColumnID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[TypeID],
	[ColumnID],
	[No]
	FROM [exp].[exT_C]
	WHERE
	[ColumnID] = @ColumnID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

