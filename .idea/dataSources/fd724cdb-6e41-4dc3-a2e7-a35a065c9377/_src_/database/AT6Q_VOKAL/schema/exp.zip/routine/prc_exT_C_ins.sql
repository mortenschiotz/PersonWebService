
CREATE PROCEDURE [exp].[prc_exT_C_ins]
(
	@TypeID smallint,
	@ColumnID smallint,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [exp].[exT_C]
	(
		[TypeID],
		[ColumnID],
		[No]
	)
	VALUES
	(
		@TypeID,
		@ColumnID,
		@No
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exT_C',0,
		( SELECT * FROM [exp].[exT_C] 
			WHERE
			[TypeID] = @TypeID AND
			[ColumnID] = @ColumnID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

