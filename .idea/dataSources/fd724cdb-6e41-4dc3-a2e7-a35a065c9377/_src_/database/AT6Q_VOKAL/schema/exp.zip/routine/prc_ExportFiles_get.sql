CREATE PROCEDURE [exp].[prc_ExportFiles_get]
(
  @Userid INT
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ExportFileID],
	[UserID],
	[MIMEType],
	[Data],
	[Created],
	[EmailSendtTo],
	[Description],
	[Size],
	[Filename],
	ISNULL([SurveyID], 0) AS 'SurveyID'
	FROM [exp].[ExportFiles]
	WHERE UserId = @Userid

	Set @Err = @@Error

	RETURN @Err
END