CREATE PROCEDURE [exp].[prc_ET_EC_get]
(
	@ExportTypeID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ExportTypeID],
	[ExportColumnID],
	[No]
	FROM [exp].[ET_EC]
	WHERE
	[ExportTypeID] = @ExportTypeID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

