

CREATE PROCEDURE [exp].[prc_LT_exColumn_del]
(
	@LanguageID int,
	@ColumnID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_exColumn',2,
		( SELECT * FROM [exp].[LT_exColumn] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ColumnID] = @ColumnID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [exp].[LT_exColumn]
	WHERE
		[LanguageID] = @LanguageID AND
		[ColumnID] = @ColumnID

	Set @Err = @@Error

	RETURN @Err
END

