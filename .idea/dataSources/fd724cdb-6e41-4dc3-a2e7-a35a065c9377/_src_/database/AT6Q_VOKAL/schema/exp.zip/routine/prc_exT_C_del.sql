

CREATE PROCEDURE [exp].[prc_exT_C_del]
(
	@TypeID smallint,
	@ColumnID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exT_C',2,
		( SELECT * FROM [exp].[exT_C] 
			WHERE
			[TypeID] = @TypeID AND
			[ColumnID] = @ColumnID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [exp].[exT_C]
	WHERE
		[TypeID] = @TypeID AND
		[ColumnID] = @ColumnID

	Set @Err = @@Error

	RETURN @Err
END

