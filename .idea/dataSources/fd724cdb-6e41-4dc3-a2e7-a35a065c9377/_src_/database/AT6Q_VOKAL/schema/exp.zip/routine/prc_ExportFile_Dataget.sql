create PROCEDURE [exp].[prc_ExportFile_Dataget]
(
	@ExportFileID	int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT Data
	FROM [exp].Exportfiles
	WHERE [ExportFileID] = @ExportFileID

	Set @Err = @@Error

	RETURN @Err
End
