CREATE PROCEDURE [exp].[prc_LT_ExportColumn_get]
(
	@ExportColumnID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ExportColumnID],
	[Name],
	[Description]
	FROM [exp].[LT_ExportColumn]
	WHERE
	[ExportColumnID] = @ExportColumnID

	Set @Err = @@Error

	RETURN @Err
END
