
CREATE PROCEDURE [exp].[prc_exType_upd]
(
	@TypeID smallint,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [exp].[exType]
	SET
		[Name] = @Name
	WHERE
		[TypeID] = @TypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exType',1,
		( SELECT * FROM [exp].[exType] 
			WHERE
			[TypeID] = @TypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

