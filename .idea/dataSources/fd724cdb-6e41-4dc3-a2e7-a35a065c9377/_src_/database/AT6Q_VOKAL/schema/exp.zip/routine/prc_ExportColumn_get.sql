CREATE PROCEDURE [exp].[prc_ExportColumn_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ExportColumnID],
	[TableTypeID],
	[ColumnName],
	[DataType]
	FROM [exp].[ExportColumn]

	Set @Err = @@Error

	RETURN @Err
END
