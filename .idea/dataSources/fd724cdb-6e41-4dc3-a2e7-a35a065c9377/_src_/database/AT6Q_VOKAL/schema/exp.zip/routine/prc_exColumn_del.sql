
CREATE PROCEDURE [exp].[prc_exColumn_del]
(
	@ColumnID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exColumn',2,
		( SELECT * FROM [exp].[exColumn] 
			WHERE
			[ColumnID] = @ColumnID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [exp].[exColumn]
	WHERE
		[ColumnID] = @ColumnID

	Set @Err = @@Error

	RETURN @Err
END

