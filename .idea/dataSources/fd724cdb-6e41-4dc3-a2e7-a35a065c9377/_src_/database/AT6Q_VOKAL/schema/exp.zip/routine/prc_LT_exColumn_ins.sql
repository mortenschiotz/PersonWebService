
CREATE PROCEDURE [exp].[prc_LT_exColumn_ins]
(
	@LanguageID int,
	@ColumnID smallint,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [exp].[LT_exColumn]
	(
		[LanguageID],
		[ColumnID],
		[Name]
	)
	VALUES
	(
		@LanguageID,
		@ColumnID,
		@Name
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_exColumn',0,
		( SELECT * FROM [exp].[LT_exColumn] 
			WHERE
			[LanguageID] = @LanguageID AND
			[ColumnID] = @ColumnID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

