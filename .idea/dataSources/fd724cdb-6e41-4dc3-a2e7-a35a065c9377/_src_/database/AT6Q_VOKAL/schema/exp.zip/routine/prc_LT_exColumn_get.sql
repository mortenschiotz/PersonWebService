
CREATE PROCEDURE [exp].[prc_LT_exColumn_get]
(
	@ColumnID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[ColumnID],
	[Name]
	FROM [exp].[LT_exColumn]
	WHERE
	[ColumnID] = @ColumnID

	Set @Err = @@Error

	RETURN @Err
END

