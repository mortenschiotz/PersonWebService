
CREATE PROCEDURE [exp].[prc_exT_C_upd]
(
	@TypeID smallint,
	@ColumnID smallint,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [exp].[exT_C]
	SET
		[TypeID] = @TypeID,
		[ColumnID] = @ColumnID,
		[No] = @No
	WHERE
		[TypeID] = @TypeID AND
		[ColumnID] = @ColumnID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exT_C',1,
		( SELECT * FROM [exp].[exT_C] 
			WHERE
			[TypeID] = @TypeID AND
			[ColumnID] = @ColumnID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

