
CREATE PROCEDURE [exp].[prc_exType_ins]
(
	@TypeID smallint = null output,
	@Name nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [exp].[exType]
	(
		[Name]
	)
	VALUES
	(
		@Name
	)

	Set @Err = @@Error
	Set @TypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exType',0,
		( SELECT * FROM [exp].[exType] 
			WHERE
			[TypeID] = @TypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

