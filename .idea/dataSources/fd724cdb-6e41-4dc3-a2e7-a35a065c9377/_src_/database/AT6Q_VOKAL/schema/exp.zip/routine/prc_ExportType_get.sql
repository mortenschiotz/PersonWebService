CREATE PROCEDURE [exp].[prc_ExportType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ExportTypeID],
	[Name]
	FROM [exp].[ExportType]

	Set @Err = @@Error

	RETURN @Err
END