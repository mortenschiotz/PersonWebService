

CREATE PROCEDURE [exp].[prc_ExportFiles_del]
(
	@ExportFileID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'ExportFiles',2,
		( SELECT * FROM [exp].[ExportFiles] 
			WHERE
			[ExportFileID] = @ExportFileID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [exp].[ExportFiles]
	WHERE
		[ExportFileID] = @ExportFileID

	Set @Err = @@Error

	RETURN @Err
END

