
CREATE PROCEDURE [exp].[prc_exColumn_ins]
(
	@ColumnID smallint = null output,
	@TableTypeID smallint,
	@PropertyName nvarchar(64),
	@DataType nvarchar(64),
	@No smallint,
	@FriendlyName nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [exp].[exColumn]
	(
		[TableTypeID],
		[PropertyName],
		[DataType],
		[No],
		[FriendlyName]
	)
	VALUES
	(
		@TableTypeID,
		@PropertyName,
		@DataType,
		@No,
		@FriendlyName
	)

	Set @Err = @@Error
	Set @ColumnID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exColumn',0,
		( SELECT * FROM [exp].[exColumn] 
			WHERE
			[ColumnID] = @ColumnID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

