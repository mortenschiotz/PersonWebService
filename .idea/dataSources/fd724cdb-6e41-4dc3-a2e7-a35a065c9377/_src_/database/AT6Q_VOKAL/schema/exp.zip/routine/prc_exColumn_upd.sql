
CREATE PROCEDURE [exp].[prc_exColumn_upd]
(
	@ColumnID smallint,
	@TableTypeID smallint,
	@PropertyName nvarchar(64),
	@DataType nvarchar(64),
	@No smallint,
	@FriendlyName nvarchar(256),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [exp].[exColumn]
	SET
		[TableTypeID] = @TableTypeID,
		[PropertyName] = @PropertyName,
		[DataType] = @DataType,
		[No] = @No,
		[FriendlyName] = @FriendlyName
	WHERE
		[ColumnID] = @ColumnID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'exColumn',1,
		( SELECT * FROM [exp].[exColumn] 
			WHERE
			[ColumnID] = @ColumnID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

