

CREATE PROCEDURE [form].[prc_FormCell_upd]
(
	@FormCellID int,
	@FormRowID int,
	@No smallint,
	@CellTypeID smallint,
	@FormFieldID INT=NULL,
	@FormCommandID INT=NULL,
	@CssClass nvarchar(128),
	@Alignment smallint,
	@Colspan smallint,
	@Width smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [form].[FormCell]
	SET
		[FormRowID] = @FormRowID,
		[No] = @No,
		[CellTypeID] = @CellTypeID,
		[FormFieldID] = @FormFieldID,
		[FormCommandID] = @FormCommandID,
		[CssClass] = @CssClass,
		[Alignment] = @Alignment,
		[Colspan] = @Colspan,
		[Width] = @Width
	WHERE
		[FormCellID] = @FormCellID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'FormCell',1,
		( SELECT * FROM [form].[FormCell] 
			WHERE
			[FormCellID] = @FormCellID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


