
CREATE PROCEDURE [form].[prc_FormFieldCondition_get] @FormFieldID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Err INT

	SELECT [FormFieldConditionID]
		,[FormFieldID]
		,[Type]
		,[Param]
		,[Value]
		,[Created]
	FROM [form].[FormFieldCondition]
	WHERE [FormFieldID] = @FormFieldID

	SET @Err = @@Error

	RETURN @Err
END
