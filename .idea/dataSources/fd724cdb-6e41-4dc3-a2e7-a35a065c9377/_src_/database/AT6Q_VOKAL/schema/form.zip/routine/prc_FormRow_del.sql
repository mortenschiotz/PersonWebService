

CREATE PROCEDURE [form].[prc_FormRow_del]
(
	@FormRowID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'FormRow',2,
		( SELECT * FROM [form].[FormRow] 
			WHERE
			[FormRowID] = @FormRowID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [form].[FormRow]
	WHERE
		[FormRowID] = @FormRowID

	Set @Err = @@Error

	RETURN @Err
END

