
CREATE PROCEDURE [form].[prc_LT_FormField_ins]
(
	@LanguageID int,
	@FormFieldID int,
	@Name nvarchar(256),
	@RegularExpression nvarchar(256),
	@RegularExpressionText nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [form].[LT_FormField]
	(
		[LanguageID],
		[FormFieldID],
		[Name],
		[RegularExpression],
		[RegularExpressionText],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@FormFieldID,
		@Name,
		@RegularExpression,
		@RegularExpressionText,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_FormField',0,
		( SELECT * FROM [form].[LT_FormField] 
			WHERE
			[LanguageID] = @LanguageID AND
			[FormFieldID] = @FormFieldID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

