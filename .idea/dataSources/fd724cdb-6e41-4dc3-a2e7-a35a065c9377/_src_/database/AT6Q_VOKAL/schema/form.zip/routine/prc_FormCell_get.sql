
CREATE PROCEDURE [form].[prc_FormCell_get]
(
	@FormRowID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[FormCellID],
	[FormRowID],
	[No],
	[CellTypeID],
	ISNULL([FormFieldID], 0) AS 'FormFieldID',
	ISNULL([FormCommandID], 0) AS 'FormCommandID',
	[CssClass],
	[Alignment],
	[Colspan],
	[Width],
	[Created]
	FROM [form].[FormCell]
	WHERE
	[FormRowID] = @FormRowID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

