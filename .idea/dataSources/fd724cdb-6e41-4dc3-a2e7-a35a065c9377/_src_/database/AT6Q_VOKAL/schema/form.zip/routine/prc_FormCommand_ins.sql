CREATE PROCEDURE [form].[prc_FormCommand_ins]
(
	@FormCommandID int = null output,
	@FormID int,
	@No smallint,
	@FormMode smallint,
	@FormCommandType smallint,
	@CssClass nvarchar(256),
	@ClientFunction nvarchar(256),
	@CommandGroupClass nvarchar(50)=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [form].[FormCommand]
	(
		[FormID],
		[No],
		[FormMode],
		[FormCommandType],
		[CssClass],
		[ClientFunction],
		[CommandGroupClass]
	)
	VALUES
	(
		@FormID,
		@No,
		@FormMode,
		@FormCommandType,
		@CssClass,
		@ClientFunction,
		@CommandGroupClass
	)

	Set @Err = @@Error
	Set @FormCommandID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'FormCommand',0,
		( SELECT * FROM [form].[FormCommand] 
			WHERE
			[FormCommandID] = @FormCommandID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


