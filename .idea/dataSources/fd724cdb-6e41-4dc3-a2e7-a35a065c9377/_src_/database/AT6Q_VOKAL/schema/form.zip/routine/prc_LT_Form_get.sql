
CREATE PROCEDURE [form].[prc_LT_Form_get]
(
	@FormID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[FormID],
	[Name],
	[Description]
	FROM [form].[LT_Form]
	WHERE
	[FormID] = @FormID

	Set @Err = @@Error

	RETURN @Err
END

