
CREATE PROCEDURE [form].[prc_Form_del]
(
	@FormID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Form',2,
		( SELECT * FROM [form].[Form] 
			WHERE
			[FormID] = @FormID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [form].[Form]
	WHERE
		[FormID] = @FormID

	Set @Err = @@Error

	RETURN @Err
END

