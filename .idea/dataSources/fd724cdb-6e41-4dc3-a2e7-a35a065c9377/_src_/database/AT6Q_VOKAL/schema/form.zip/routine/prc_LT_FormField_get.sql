
CREATE PROCEDURE [form].[prc_LT_FormField_get]
(
	@FormFieldID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[FormFieldID],
	[Name],
	[RegularExpression],
	[RegularExpressionText],
	[Description]
	FROM [form].[LT_FormField]
	WHERE
	[FormFieldID] = @FormFieldID

	Set @Err = @@Error

	RETURN @Err
END

