
CREATE PROCEDURE [form].[prc_FormCommandCondition_get] @FormCommandID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Err INT

	SELECT [FormCommandConditionID]
		,[FormCommandID]
		,[Type]
		,[Param]
		,[Value]
		,[Created]
	FROM [form].[FormCommandCondition]
	WHERE [FormCommandID] = @FormCommandID

	SET @Err = @@Error

	RETURN @Err
END
