
CREATE PROCEDURE [form].[prc_LT_FormCommand_get]
(
	@FormCommandID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[FormCommandID],
	[Name],
	[ErrorMsg],
	[ConfirmMsg],
	[Description]
	FROM [form].[LT_FormCommand]
	WHERE
	[FormCommandID] = @FormCommandID

	Set @Err = @@Error

	RETURN @Err
END

