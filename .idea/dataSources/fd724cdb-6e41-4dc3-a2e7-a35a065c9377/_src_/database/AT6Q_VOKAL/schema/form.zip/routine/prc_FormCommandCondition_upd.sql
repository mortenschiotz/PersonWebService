CREATE PROCEDURE [form].[prc_FormCommandCondition_upd] @FormCommandConditionID INT,
	@FormCommandID INT,
	@Type NVARCHAR(32),
	@Param NVARCHAR(MAX),
	@Value NVARCHAR(32),
	@cUserid INT,
	@Log SMALLINT = 1
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Err INT

	UPDATE [form].[FormCommandCondition]
	SET [FormCommandID] = @FormCommandID,
		[Type] = @Type,
		[Param] = @Param,
		[Value] = @Value
	WHERE [FormCommandConditionID] = @FormCommandConditionID

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId,
			TableName,
			Type,
			Data,
			Created
			)
		SELECT @cUserid,
			'FormCommandCondition',
			1,
			(
				SELECT *
				FROM [form].[FormCommandCondition]
				WHERE [FormCommandConditionID] = @FormCommandConditionID
				FOR XML AUTO
				) AS data,
			getdate()
	END

	SET @Err = @@Error

	RETURN @Err
END

