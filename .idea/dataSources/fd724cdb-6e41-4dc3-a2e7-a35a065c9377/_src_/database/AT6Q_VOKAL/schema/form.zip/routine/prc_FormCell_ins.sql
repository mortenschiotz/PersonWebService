

CREATE PROCEDURE [form].[prc_FormCell_ins]
(
	@FormCellID int = null output,
	@FormRowID int,
	@No smallint,
	@CellTypeID smallint,
	@FormFieldID INT=NULL,
	@FormCommandID INT=NULL,
	@CssClass nvarchar(128),
	@Alignment smallint,
	@Colspan smallint,
	@Width smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [form].[FormCell]
	(
		[FormRowID],
		[No],
		[CellTypeID],
		[FormFieldID],
		[FormCommandID],
		[CssClass],
		[Alignment],
		[Colspan],
		[Width]
	)
	VALUES
	(
		@FormRowID,
		@No,
		@CellTypeID,
		@FormFieldID,
		@FormCommandID,
		@CssClass,
		@Alignment,
		@Colspan,
		@Width
	)

	Set @Err = @@Error
	Set @FormCellID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'FormCell',0,
		( SELECT * FROM [form].[FormCell] 
			WHERE
			[FormCellID] = @FormCellID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


