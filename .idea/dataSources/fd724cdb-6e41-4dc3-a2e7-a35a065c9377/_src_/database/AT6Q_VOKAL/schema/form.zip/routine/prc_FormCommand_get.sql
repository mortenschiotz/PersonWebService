CREATE PROCEDURE [form].[prc_FormCommand_get]
(
	@FormID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[FormCommandID],
	[FormID],
	[No],
	[FormMode],
	[FormCommandType],
	[CssClass],
	[ClientFunction],
	[Created],
	[CommandGroupClass]
	FROM [form].[FormCommand]
	WHERE
	[FormID] = @FormID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END


