

CREATE PROCEDURE [form].[prc_LT_FormField_del]
(
	@LanguageID int,
	@FormFieldID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_FormField',2,
		( SELECT * FROM [form].[LT_FormField] 
			WHERE
			[LanguageID] = @LanguageID AND
			[FormFieldID] = @FormFieldID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [form].[LT_FormField]
	WHERE
		[LanguageID] = @LanguageID AND
		[FormFieldID] = @FormFieldID

	Set @Err = @@Error

	RETURN @Err
END

