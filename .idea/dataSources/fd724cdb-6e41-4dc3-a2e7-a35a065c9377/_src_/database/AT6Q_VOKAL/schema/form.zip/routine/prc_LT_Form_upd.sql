
CREATE PROCEDURE [form].[prc_LT_Form_upd]
(
	@LanguageID int,
	@FormID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [form].[LT_Form]
	SET
		[LanguageID] = @LanguageID,
		[FormID] = @FormID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[FormID] = @FormID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_Form',1,
		( SELECT * FROM [form].[LT_Form] 
			WHERE
			[LanguageID] = @LanguageID AND
			[FormID] = @FormID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

