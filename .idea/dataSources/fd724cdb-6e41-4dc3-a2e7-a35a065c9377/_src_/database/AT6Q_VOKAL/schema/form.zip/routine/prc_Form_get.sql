

CREATE PROCEDURE [form].[prc_Form_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[FormID],
	[OwnerID],
	[ElementID],
	[TableTypeID],
	ISNULL([ContextFormFieldID], 0) AS 'ContextFormFieldID',
	[Type],
	[FName],
	[CssClass],
	[ExtID],
	[Created]
	FROM [form].[Form]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END


