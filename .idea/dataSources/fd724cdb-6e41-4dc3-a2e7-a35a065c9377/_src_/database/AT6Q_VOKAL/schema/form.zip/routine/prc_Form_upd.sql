

CREATE PROCEDURE [form].[prc_Form_upd]
(
	@FormID int,
	@OwnerID int,
	@ElementID int,
	@TableTypeID smallint,
	@ContextFormFieldID INT=NULL,
	@Type smallint,
	@FName nvarchar(64),
	@CssClass nvarchar(128),
	@ExtID nvarchar(64) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [form].[Form]
	SET
		[OwnerID] = @OwnerID,
		[ElementID] = @ElementID,
		[TableTypeID] = @TableTypeID,
		[ContextFormFieldID] = @ContextFormFieldID,
		[Type] = @Type,
		[FName] = @FName,
		[CssClass] = @CssClass,
		[ExtID] = @ExtID
	WHERE
		[FormID] = @FormID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Form',1,
		( SELECT * FROM [form].[Form] 
			WHERE
			[FormID] = @FormID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END


