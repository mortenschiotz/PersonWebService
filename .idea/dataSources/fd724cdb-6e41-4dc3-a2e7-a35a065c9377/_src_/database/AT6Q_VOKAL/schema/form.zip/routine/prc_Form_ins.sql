

CREATE PROCEDURE [form].[prc_Form_ins]
(
	@FormID int = null output,
	@OwnerID int,
	@ElementID int,
	@TableTypeID smallint,
	@ContextFormFieldID INT=NULL,
	@Type smallint,
	@FName nvarchar(64),
	@CssClass nvarchar(128),
	@ExtID nvarchar(64) = '',
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [form].[Form]
	(
		[OwnerID],
		[ElementID],
		[TableTypeID],
		[ContextFormFieldID],
		[Type],
		[FName],
		[CssClass],
		[ExtID]
	)
	VALUES
	(
		@OwnerID,
		@ElementID,
		@TableTypeID,
		@ContextFormFieldID,
		@Type,
		@FName,
		@CssClass,
		@ExtID
	)

	Set @Err = @@Error
	Set @FormID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Form',0,
		( SELECT * FROM [form].[Form] 
			WHERE
			[FormID] = @FormID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END


