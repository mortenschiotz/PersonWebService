
CREATE PROCEDURE [form].[prc_FormCommandCondition_del] @FormCommandConditionID INT
	,@cUserid INT
	,@Log SMALLINT = 1
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Err INT

	IF @Log = 1
	BEGIN
		INSERT INTO [Log].[AuditLog] (
			UserId
			,TableName
			,Type
			,Data
			,Created
			)
		SELECT @cUserid
			,'FormCommandCondition'
			,2
			,(
				SELECT *
				FROM [form].[FormCommandCondition]
				WHERE [FormCommandConditionID] = @FormCommandConditionID
				FOR XML AUTO
				) AS data
			,getdate()
	END

	DELETE
	FROM [form].[FormCommandCondition]
	WHERE [FormCommandConditionID] = @FormCommandConditionID

	SET @Err = @@Error

	RETURN @Err
END
