
CREATE PROCEDURE [form].[prc_LT_FormCommand_upd]
(
	@LanguageID int,
	@FormCommandID int,
	@Name nvarchar(256),
	@ErrorMsg nvarchar(max),
	@ConfirmMsg nvarchar(max),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [form].[LT_FormCommand]
	SET
		[LanguageID] = @LanguageID,
		[FormCommandID] = @FormCommandID,
		[Name] = @Name,
		[ErrorMsg] = @ErrorMsg,
		[ConfirmMsg] = @ConfirmMsg,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[FormCommandID] = @FormCommandID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_FormCommand',1,
		( SELECT * FROM [form].[LT_FormCommand] 
			WHERE
			[LanguageID] = @LanguageID AND
			[FormCommandID] = @FormCommandID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

