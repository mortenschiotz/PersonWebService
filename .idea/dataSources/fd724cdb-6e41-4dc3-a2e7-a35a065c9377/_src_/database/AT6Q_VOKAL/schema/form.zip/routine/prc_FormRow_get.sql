
CREATE PROCEDURE [form].[prc_FormRow_get]
(
	@FormID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[FormRowID],
	[FormID],
	[No],
	[RowTypeID],
	[CssClass],
	[Created]
	FROM [form].[FormRow]
	WHERE
	[FormID] = @FormID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

