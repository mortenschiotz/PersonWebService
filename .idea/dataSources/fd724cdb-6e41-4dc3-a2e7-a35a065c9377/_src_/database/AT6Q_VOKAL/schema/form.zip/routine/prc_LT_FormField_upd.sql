
CREATE PROCEDURE [form].[prc_LT_FormField_upd]
(
	@LanguageID int,
	@FormFieldID int,
	@Name nvarchar(256),
	@RegularExpression nvarchar(256),
	@RegularExpressionText nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [form].[LT_FormField]
	SET
		[LanguageID] = @LanguageID,
		[FormFieldID] = @FormFieldID,
		[Name] = @Name,
		[RegularExpression] = @RegularExpression,
		[RegularExpressionText] = @RegularExpressionText,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[FormFieldID] = @FormFieldID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_FormField',1,
		( SELECT * FROM [form].[LT_FormField] 
			WHERE
			[LanguageID] = @LanguageID AND
			[FormFieldID] = @FormFieldID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

