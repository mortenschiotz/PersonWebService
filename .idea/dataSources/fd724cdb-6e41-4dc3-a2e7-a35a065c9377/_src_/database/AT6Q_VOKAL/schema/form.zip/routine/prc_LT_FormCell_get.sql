
CREATE PROCEDURE [form].[prc_LT_FormCell_get]
(
	@FormCellID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[FormCellID],
	[Name],
	[ToolTip],
	[Description]
	FROM [form].[LT_FormCell]
	WHERE
	[FormCellID] = @FormCellID

	Set @Err = @@Error

	RETURN @Err
END

