/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_Search_ByProfileLetter]
(
     @SearchString1 nvarchar(max) ='O',
     @SearchString2 nvarchar(max) ='S,R',
     @SearchString3 nvarchar(max) ='P',
     @HDID          int=0,
     @CustomerID    int =16,
     @ActivityID    int =4,
     @QuestionID    int =4193,
     @AlternativeID int = 474,
     @LanguageID   int =1
) 
AS
BEGIN
DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
DECLARE @sqlCommand nvarchar(max) ='',@Parameters nvarchar(max)=''
DECLARE @ReportServer nvarchar(max), @ReportDB nvarchar(max)
CREATE TABLE  #t_result  (UserID int)

DECLARE c_ResultDatabase CURSOR READ_ONLY FOR
SELECT   s.ReportServer, s.ReportDB
FROM	at.Survey s JOIN at.Activity act ON act.ActivityID = s.ActivityID 
WHERE  s.[Status]=2
	  AND s.ActivityID =@ActivityID	
OPEN c_ResultDatabase
FETCH NEXT FROM c_ResultDatabase INTO @ReportServer, @ReportDB
WHILE @@FETCH_STATUS=0
BEGIN
SET @sqlCommand ='
    INSERT INTO #t_result 
    SELECT r.UserID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Answer a
    INNER JOIN [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Result r ON r. ResultID = a.ResultID AND r.StatusTypeID =3 
    WHERE 
    a.QuestionID = @QuestionID AND a.AlternativeID =@AlternativeID AND
    ((@SearchString1 IS NULL OR EXISTS (select 1 FROM  dbo.StringToArray (@SearchString1,'','') WHERE ParseValue = SUBSTRING(a.Free,1,1)))
    AND (@SearchString2 IS NULL OR (EXISTS (select 1 FROM  dbo.StringToArray (@SearchString2,'','') WHERE ParseValue = SUBSTRING(a.Free,2,1))))
    AND (@SearchString3 IS NULL OR (EXISTS (select 1 FROM  dbo.StringToArray (@SearchString3,'','') WHERE ParseValue = SUBSTRING(a.Free,3,1))))
    )
    AND a.itemid = @LanguageID
    '
      SET @Parameters = N'@SearchString1 nvarchar(max),@SearchString2 nvarchar(max),@SearchString3 nvarchar(max),@QuestionID int, @AlternativeID int,@LanguageID int'
	  EXECUTE sp_executesql @sqlCommand, @Parameters, @SearchString1 = @SearchString1,  @SearchString2 = @SearchString2, @SearchString3 = @SearchString3,@QuestionID=@QuestionID,@AlternativeID=@AlternativeID,@LanguageID =@LanguageID

FETCH NEXT FROM c_ResultDatabase INTO  @ReportServer, @ReportDB
END
CLOSE c_ResultDatabase
DEALLOCATE c_ResultDatabase
SELECT DISTINCT
	u.[UserID],
	u.[DepartmentID],
	u.[LanguageID],
	u.[UserName],
	u.[LastName],
	u.[FirstName],
	u.[Email],
	u.[ExtID],
	u.[SSN],
	u.[Created],
	u.[Mobile],
	u.[Tag],
	u.[Locked],
	u.[Ownerid],
	d.[Name] as DepartmentName,
    u.EntityStatusID,
    u.Deleted,
    u.EntityStatusReasonID
	FROM org.[User] u
	INNER JOIN org.[H_D] hd on hd.DepartmentID = u.DepartmentID and (@HDID = 0 OR (hd.path like  '%\' + cast(@HDID as varchar(16)) + '\%' and hd.deleted = 0))
	INNER JOIN org.[Department] d on d.DepartmentID = hd.DepartmentID and ( @HDID <> 0 OR ( hd.DepartmentID IN (SELECT d.DepartmentID from org.Customer c INNER JOIN org.Department d ON d.CustomerID = c.CustomerID AND c.CustomerID =@CustomerID) )) AND d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
    INNER JOIN  #t_result r ON r.UserID = u.UserID
    WHERE u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
DROP TABLE #t_result
END
