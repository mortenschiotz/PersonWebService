/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_H_D_getAll]
(
	@ParentID		int = NULL,
	@HierarchyID	int = NULL,
	@DepartmentID int = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF NOT @ParentID IS NULL
		Select
		hd.[HDID],
		hd.[HierarchyID],
		hd.[DepartmentID],
		ISNULL([ParentID], 0) ParentID,
		hd.[Path],
		hd.[PathName],
		hd.[Created],
		hd.[Deleted],
        d.[EntityStatusID],
        d.[Deleted] AS [DepartmentDeleted]
		FROM org.[H_D] hd
		join org.department d  on d.departmentid = hd.departmentid
		WHERE hd.[ParentID] = @ParentID
		--order by d.Name asc
	ELSE
		Select
		hd.[HDID],
		hd.[HierarchyID],
		hd.[DepartmentID],
		ISNULL([ParentID], 0) ParentID,
		hd.[Path],
		hd.[PathName],
		hd.[Created],
		hd.[Deleted],
		d.[EntityStatusID],
        d.[Deleted] AS [DepartmentDeleted]
		FROM org.[H_D] hd
		join org.department d  on d.departmentid = hd.departmentid
		WHERE hd.[HierarchyID] = @HierarchyID
		--order by d.Name asc
	Set @Err = @@Error

	RETURN @Err
END
