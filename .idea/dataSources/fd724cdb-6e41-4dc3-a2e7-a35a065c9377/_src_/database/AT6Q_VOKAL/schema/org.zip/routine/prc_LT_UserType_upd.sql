
CREATE PROCEDURE [org].[prc_LT_UserType_upd]
(
	@LanguageID int,
	@UserTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[LT_UserType]
	SET
		[LanguageID] = @LanguageID,
		[UserTypeID] = @UserTypeID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[UserTypeID] = @UserTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UserType',1,
		( SELECT * FROM [org].[LT_UserType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UserTypeID] = @UserTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

