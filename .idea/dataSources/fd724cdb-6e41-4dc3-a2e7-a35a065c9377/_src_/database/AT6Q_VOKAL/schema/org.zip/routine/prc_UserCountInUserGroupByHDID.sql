/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_UserCountInUserGroupByHDID]
(
  @HDID			    int,
  @PeriodID		    int,
  @DepartmentTypeIDList varchar(max),
  @GroupLevel		    int = 1	 -- 0: detail, 1: parent level (1 level under @HDID), 2: total
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
    
    IF @GroupLevel = 2
    BEGIN
	   SELECT @HDID AS UserGroupID, CONVERT(nvarchar(16), @HDID) AS UserGroupName, count(ugu.UserID) as 'UserCount'
	   FROM org.UserGroup ug
	   JOIN org.UG_U ugu ON ugu.UserGroupID = ug.UserGroupID AND ug.PeriodID = @PeriodID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
	   JOIN org.H_D hd ON hd.DepartmentID = ug.DepartmentID AND hd.[Path] like '%\' + CONVERT(nvarchar(16), @HDID) + '\%'
	   JOIN org.[User] u ON u.UserID = ugu.UserID AND u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
	   JOIN org.DT_UG dtug ON dtug.UserGroupID = ug.UserGroupID AND dtug.DepartmentTypeID IN (SELECT Value From dbo.funcListToTableInt(@DepartmentTypeIDList,','))
    END
    ELSE
    BEGIN
	   SELECT ISNULL(parent_hd.HDID, ug.UserGroupID) AS UserGroupID, ISNULL(parent_hd.Name, ug.Name) AS UserGroupName, count(ugu.UserID) as 'UserCount'
	   FROM org.UserGroup ug
	   JOIN org.UG_U ugu ON ugu.UserGroupID = ug.UserGroupID AND ug.PeriodID = @PeriodID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
	   JOIN org.H_D hd ON hd.DepartmentID = ug.DepartmentID AND hd.[Path] like '%\' + CONVERT(nvarchar(16), @HDID) + '\%'
	   JOIN org.[User] u ON u.UserID = ugu.UserID AND u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
	   JOIN org.DT_UG dtug ON dtug.UserGroupID = ug.UserGroupID AND dtug.DepartmentTypeID IN (SELECT Value From dbo.funcListToTableInt(@DepartmentTypeIDList,','))
	   LEFT JOIN (SELECT phd.HDID, phd.[Path], d1.DepartmentID, d1.Name FROM org.H_D phd JOIN org.Department d1 ON d1.DepartmentID = phd.DepartmentID WHERE phd.ParentID=@HDID) AS parent_hd ON hd.[Path] LIKE '%' + [parent_hd].[Path] + '%' AND @GroupLevel = 1
	   GROUP BY ISNULL(parent_hd.HDID, ug.UserGroupID), ISNULL(parent_hd.Name, ug.Name)
	   ORDER BY ISNULL(parent_hd.Name, ug.Name)
    END
END
