

CREATE PROCEDURE [org].[prc_DepartmentGroup_del]
(
	@DepartmentGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DepartmentGroup',2,
		( SELECT * FROM [org].[DepartmentGroup] 
			WHERE
			[DepartmentGroupID] = @DepartmentGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM dbo.AccessGroupMember
	WHERE [DepartmentGroupID] = @DepartmentGroupID

	DELETE FROM [org].[DepartmentGroup]
	WHERE
	[DepartmentGroupID] = @DepartmentGroupID

	Set @Err = @@Error

	RETURN @Err
END

