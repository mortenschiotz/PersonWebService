/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_get]
(  
 @DepartmentID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int, @Unknown INT = 0, @EntityStatusID_Active INT = 1, @Inactive INT = 2  
 SELECT @EntityStatusID_Active = EntityStatusID FROM EntityStatus WHERE CodeName='Active'
 SELECT @Unknown  = EntityStatusID FROM EntityStatus WHERE CodeName='Unknown'
 SELECT @Inactive = EntityStatusID FROM EntityStatus WHERE CodeName='Inactive'
 
 SELECT  
 [UserID],  
 [Ownerid],  
 [DepartmentID],  
 [LanguageID],  
 ISNULL([RoleID], 0) AS 'RoleID',  
 [UserName],  
 [Password],  
 [LastName],  
 [FirstName],  
 [Email],  
 [Mobile],  
 [ExtID],  
 [SSN],  
 [Tag],  
 [Locked],  
 [ChangePassword],  
 [HashPassword],  
 [SaltPassword],  
 [OneTimePassword],  
 [OTPExpireTime],  
 [Created],  
 [CountryCode],
 [Gender],
 [DateOfBirth],
 [ForceUserLoginAgain],
 [LastUpdated],
 [LastUpdatedBy],
 [LastSynchronized],
 [ArchetypeID],
 [CustomerID],
 [Deleted],
 [EntityStatusID],
 [EntityStatusReasonID]
 FROM [org].[User]  
 WHERE  
 [DepartmentID] = @DepartmentID  
 AND [EntityStatusID] IN (@EntityStatusID_Active, @Unknown, @Inactive) 
 AND [Deleted] IS NULL

 Set @Err = @@Error  

 RETURN @Err  
END 
