
CREATE PROCEDURE [org].[prc_UsergroupType_upd]
(
	@UsergroupTypeID int,
	@OwnerID int,
	@ExtID nvarchar(64),
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[UsergroupType]
	SET
		[OwnerID] = @OwnerID,
		[ExtID] = @ExtID,
		[No] = @No
	WHERE
		[UsergroupTypeID] = @UsergroupTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UsergroupType',1,
		( SELECT * FROM [org].[UsergroupType] 
			WHERE
			[UsergroupTypeID] = @UsergroupTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

