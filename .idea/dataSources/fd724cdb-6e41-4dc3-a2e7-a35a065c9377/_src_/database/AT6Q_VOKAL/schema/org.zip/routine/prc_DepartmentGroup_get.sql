
CREATE PROCEDURE [org].[prc_DepartmentGroup_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DepartmentGroupID],
	[OwnerID],
	[ExtID],
	[No],
	[Created]
	FROM [org].[DepartmentGroup]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

