CREATE PROCEDURE [org].[prc_Customer_del]  
(  
 @CustomerID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Customer',2,  
  ( SELECT * FROM [org].[Customer]   
   WHERE  
   [CustomerID] = @CustomerID  
    FOR XML AUTO) as data,  
   getdate()   
 END   
  
 DELETE FROM dbo.AccessGroupMember WHERE CustomerID = @CustomerID  
 DELETE FROM [org].[Customer]  
 WHERE  
 [CustomerID] = @CustomerID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
  
