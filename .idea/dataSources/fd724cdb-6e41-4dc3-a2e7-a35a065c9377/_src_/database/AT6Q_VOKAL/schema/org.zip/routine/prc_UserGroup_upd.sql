CREATE PROCEDURE [org].[prc_UserGroup_upd]  
(  
 @UserGroupID int,  
 @OwnerID int,  
 @DepartmentID int,  
 @SurveyId int = null,  
 @Name nvarchar(256),  
 @Description ntext,  
 @PeriodID int = NULL,  
 @ExtID nvarchar(64) = '',  
 @Userid int = NULL,  
 @UserGroupTypeID int = NULL,  
 @Tag nvarchar(max)='',  
 @cUserid int,  
 @Log smallint = 1,
 @LastUpdated datetime2='',
 @LastUpdatedBy int = NULL,
 @LastSynchronized datetime2='',
 @ArchetypeID int = NULL,
 @Deleted datetime2 = NULL,
 @EntityStatusID int = NULL,
 @EntityStatusReasonID int = NULL    
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 UPDATE [org].[UserGroup]  
 SET  
	[OwnerID] = @OwnerID,  
	[DepartmentID] = @DepartmentID,  
	[SurveyId] = @SurveyId,  
	[Name] = @Name,  
	[Description] = @Description,  
	[PeriodID] = @PeriodID,  
	[ExtID] = @ExtID,  
	[UserID] = @Userid,  
	[UserGroupTypeID] = @UserGroupTypeID,  
	[Tag] = @Tag,
	[LastUpdated] = @LastUpdated,
	[LastUpdatedBy] = @LastUpdatedBy,
	[LastSynchronized] = @LastSynchronized,
	[ArchetypeID] =  @ArchetypeID ,
	[Deleted]	=	@Deleted ,
	[EntityStatusID] = @EntityStatusID ,
	[EntityStatusReasonID] = @EntityStatusReasonID   
 WHERE  
    [UserGroupID] = @UserGroupID  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'UserGroup',1,  
  ( SELECT * FROM [org].[UserGroup]   
   WHERE  
   [UserGroupID] = @UserGroupID    FOR XML AUTO) as data,  
   getdate()  
 END  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END
