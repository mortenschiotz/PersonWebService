/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_UserGroup_get]
(
	@DepartmentID int = null,
	@SurveyID int= null,
	@Userid int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	SELECT
	ug.[UserGroupID],
	ug.[OwnerID],
	ISNULL(ug.[DepartmentID], 0) AS 'DepartmentID',
	ISNULL(ug.[SurveyId], 0) AS 'SurveyId',
	ug.[Name],
	ug.[Description],
	ug.[Created],
	ug.[ExtID],
	ISNULL(ug.[PeriodID],0) AS 'PeriodID',
	ISNULL (ug.[UserID],0) AS 'UserID',
	ISNULL (ug.[UsergroupTypeID],0) as 'UserGroupTypeID',
	ug.[Tag],
	ug.[LastUpdated],
	ug.[LastUpdatedBy],
	ug.[LastSynchronized],
	ug.[ArchetypeID],
	ug.[Deleted],
	ug.[EntityStatusID],
	ug.[EntityStatusReasonID]
	FROM [org].[UserGroup] ug
	LEFT JOIN [org].Department d on d.DepartmentID = ug.DepartmentID
	WHERE
	( ug.[DepartmentID] = @DepartmentID OR @DepartmentID is null )
	AND (ug.[SurveyId] = @SurveyID OR @SurveyID is null)
	AND (ug.[UserId] = @UserID OR @UserID is null)
	AND (ug.DepartmentID IS NULL OR (d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL))
	AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
	Set @Err = @@Error

	RETURN @Err
END
