
CREATE PROCEDURE [org].[prc_LT_DepartmentType_ins]
(
	@LanguageID int,
	@DepartmentTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[LT_DepartmentType]
	(
		[LanguageID],
		[DepartmentTypeID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@DepartmentTypeID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_DepartmentType',0,
		( SELECT * FROM [org].[LT_DepartmentType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[DepartmentTypeID] = @DepartmentTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

