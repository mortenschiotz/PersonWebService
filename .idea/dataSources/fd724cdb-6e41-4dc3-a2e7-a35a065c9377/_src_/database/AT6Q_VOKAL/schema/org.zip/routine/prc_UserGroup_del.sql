

CREATE PROCEDURE [org].[prc_UserGroup_del]
(
	@UserGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UserGroup',2,
		( SELECT * FROM [org].[UserGroup] 
			WHERE
			[UserGroupID] = @UserGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[UserGroup]
	WHERE
	[UserGroupID] = @UserGroupID

	Set @Err = @@Error

	RETURN @Err
END

