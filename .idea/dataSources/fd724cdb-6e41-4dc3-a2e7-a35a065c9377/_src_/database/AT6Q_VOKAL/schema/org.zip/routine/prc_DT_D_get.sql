
CREATE PROCEDURE [org].[prc_DT_D_get]
(
	@DepartmentID int = null,
	@DepartmentTypeID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
	
	IF @DepartmentTypeID IS NULL
		SELECT
		[DepartmentTypeID],
		[DepartmentID]
		FROM [org].[DT_D]
		WHERE
		[DepartmentID] = @DepartmentID
	ELSE
		SELECT
		[DepartmentTypeID],
		[DepartmentID]
		FROM [org].[DT_D]
		WHERE
		[DepartmentTypeID] = @DepartmentTypeID
	
	Set @Err = @@Error

	RETURN @Err
END

