CREATE PROCEDURE [org].[prc_UsergroupType_del]
(
	@UsergroupTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UsergroupType',2,
		( SELECT * FROM [org].[UsergroupType] 
			WHERE
			[UsergroupTypeID] = @UsergroupTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[UsergroupType]
	WHERE
		[UsergroupTypeID] = @UsergroupTypeID

	Set @Err = @@Error

	RETURN @Err
END

