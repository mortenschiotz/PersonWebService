/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROC [org].[prc_UserByUTID_getExceptHDID]
(
  @HDID INT,
  @UsertypeID int,
  @UsertypeID2 INT
)
AS
BEGIN
DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
SELECT u.[UserID],
	u.[Ownerid],
	u.[DepartmentID],
	u.[LanguageID],
	ISNULL(u.[RoleID], 0) AS 'RoleID',
	u.[UserName],
	u.[Password],
	u.[LastName],
	u.[FirstName],
	u.[Email],
	u.[Mobile],
	u.[ExtID],
	u.[SSN],
	u.[Tag],
	u.[Locked],
	u.[ChangePassword],
	u.[HashPassword],
	u.[SaltPassword],
	u.[OneTimePassword],
	u.[OTPExpireTime],
	u.[Created],
	d.Name as DepartmentName,
    u.EntityStatusID
FROM org.H_D hd 
JOIN org.[USER] u ON u.departmentid = hd.departmentid
JOIN org.[Department] d ON u.departmentid = d.departmentid and d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
JOIN org.[UT_U] utu on utu.userid = u.userid and (utu.usertypeid = @Usertypeid)
JOIN org.[UT_U] utu2 on utu2.userid = u.userid and (utu2.usertypeid = @Usertypeid2)
WHERE hd.PATH LIKE '%\' + cast(@HDID as nvarchar(16)) + '\%'
AND u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL AND hd.HDID <> @HDID
END
