

CREATE PROCEDURE [org].[prc_Hierarchy_del]
(
	@HierarchyID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Hierarchy',2,
		( SELECT * FROM [org].[Hierarchy] 
			WHERE
			[HierarchyID] = @HierarchyID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[Hierarchy]
	WHERE
	[HierarchyID] = @HierarchyID

	Set @Err = @@Error

	RETURN @Err
END

