/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_SubDepartmentWithType_get]
(   @HDID               int,
    @DepartmentTypeID   int = 0,
    @UserTypeID         int = 0,
    @GetCurrentHDSum    bit = 0,
    @CheckBatchInSub    bit = 0,
    @SurveyID           int = 0
) AS
BEGIN
    SET NOCOUNT ON

    DECLARE @EntityStatusID_Active int
    SELECT @EntityStatusID_Active = [EntityStatusID] FROM [EntityStatus] WHERE [CodeName] = 'Active'

    DECLARE @SubHD TABLE (HDID int, DepartmentID int, [HasGivenDT] int)
    
    IF @GetCurrentHDSum = 1
    BEGIN
        INSERT INTO @SubHD ([HDID], [DepartmentID], [HasGivenDT])
        SELECT hd.[HDID], hd.[DepartmentID], 0 FROM [org].[H_D] hd WHERE hd.[HDID] = @HDID AND hd.[Deleted] = 0
    END
    ELSE
    BEGIN
        INSERT INTO @SubHD ([HDID], [DepartmentID], [HasGivenDT])
        SELECT hd.[HDID], hd.[DepartmentID], 0 FROM [org].[H_D] hd WHERE hd.[ParentID] = @HDID AND hd.[Deleted] = 0
    END

    IF @CheckBatchInSub = 1
    BEGIN
        DELETE shd FROM @SubHD shd WHERE NOT EXISTS (SELECT 1 FROM [org].[H_D] hd WHERE hd.[ParentID] = shd.HDID AND hd.[Deleted] = 0)
        
        UPDATE shd SET [HasGivenDT] = 1 FROM @SubHD shd 
        WHERE EXISTS (SELECT 1 FROM [org].[H_D] hd JOIN [org].[DT_D] dtd ON hd.[DepartmentID] = dtd.[DepartmentID] AND dtd.[DepartmentTypeID] = @DepartmentTypeID AND hd.[ParentID] = shd.[HDID] AND hd.[Deleted] = 0)
        
        DELETE shd FROM @SubHD shd WHERE NOT EXISTS (SELECT 1 FROM [org].[H_D] hd JOIN [at].[Batch] b ON hd.[DepartmentID] = b.[DepartmentID] AND hd.[Path] LIKE '%\' + CONVERT(nvarchar(16), shd.HDID) + '\%' AND hd.[Deleted] = 0 AND b.[Status] > 0
                                                     AND (b.[SurveyID] = @SurveyID OR @SurveyID = 0))
    END
    ELSE
    BEGIN
        UPDATE shd SET [HasGivenDT] = 1 FROM @SubHD shd 
        WHERE EXISTS (SELECT 1 FROM [org].[H_D] hd JOIN [org].[DT_D] dtd ON hd.[DepartmentID] = dtd.[DepartmentID] AND dtd.[DepartmentTypeID] = @DepartmentTypeID AND hd.[ParentID] = shd.[HDID] AND hd.[Deleted] = 0)
    END

    SELECT phd.[HDID], pd.[DepartmentID], pd.[Name], phd.[HasGivenDT], @SurveyID SurveyID
    FROM @SubHD phd JOIN [org].[Department] pd ON phd.[DepartmentID] = pd.[DepartmentID] AND pd.[EntityStatusID] = @EntityStatusID_Active AND pd.[Deleted] IS NULL
END
