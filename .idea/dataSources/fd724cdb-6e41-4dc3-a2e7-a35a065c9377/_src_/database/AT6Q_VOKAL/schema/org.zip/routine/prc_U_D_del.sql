
CREATE PROCEDURE [org].[prc_U_D_del]
(
	@U_DID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'U_D',2,
		( SELECT * FROM [org].[U_D] 
			WHERE
			[U_DID] = @U_DID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[U_D]
	WHERE
		[U_DID] = @U_DID

	Set @Err = @@Error

	RETURN @Err
END

