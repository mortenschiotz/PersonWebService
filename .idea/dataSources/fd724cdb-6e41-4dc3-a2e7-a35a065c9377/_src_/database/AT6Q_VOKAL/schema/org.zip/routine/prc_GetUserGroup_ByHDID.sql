/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_GetUserGroup_ByHDID]
(
	@UserID				INT,
	@OwnerID			INT,
	@UserGroupTypeID	varchar(max),
	@HDID				INT
)
AS
BEGIN
	DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	SELECT 
		ug.UserGroupID,
		ug.OwnerID,
		ug.DepartmentID,
		ug.SurveyId,
		ug.Name,
		ug.Description,
		ug.Created,
		ug.ExtID,
		ug.PeriodID,
		ug.UserID,
		ug.UserGroupTypeID,
		ug.Tag
	 FROM org.UserGroup ug
		INNER JOIN org.Department d ON d.DepartmentID = ug.DepartmentID
		INNER JOIN org.[H_D] hd on hd.DepartmentID = d.DepartmentID and hd.path like  '%\' + cast(@HDID as varchar(16)) + '\%' and hd.deleted = 0
		
	WHERE 
		ug.UserID =@UserID			AND 
		ug.OwnerID = @OwnerID		AND
		ug.UserGroupTypeID IN (SELECT value FROM dbo.funcListToTableInt(@UserGroupTypeID,','))
		AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
END
