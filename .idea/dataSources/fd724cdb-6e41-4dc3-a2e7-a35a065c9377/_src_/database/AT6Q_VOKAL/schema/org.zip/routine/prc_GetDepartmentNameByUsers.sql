CREATE PROCEDURE [org].[prc_GetDepartmentNameByUsers]
(
	@ListUserID varchar(max)=''
)
AS
BEGIN
	SET NOCOUNT ON
	SELECT u.UserID as UserId, d.Name as DepartmentName, d.DepartmentID FROM org.[User] u INNER JOIN  org.Department d ON u.DepartmentID = d.DepartmentID
	WHERE u.UserID IN (SELECT value FROM dbo.funcListToTableInt(@ListUserID,','))
END
