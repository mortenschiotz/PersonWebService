
CREATE PROCEDURE [org].[prc_LT_DepartmentGroup_get]
(
	@DepartmentGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[DepartmentGroupID],
	[Name],
	[Description]
	FROM [org].[LT_DepartmentGroup]
	WHERE
	[DepartmentGroupID] = @DepartmentGroupID

	Set @Err = @@Error

	RETURN @Err
END

