CREATE PROCEDURE [org].[prc_Customer_ins]  
(  
 @CustomerID int = null output,  
 @OwnerID int,  
 @LanguageID int,  
 @Name nvarchar(256),  
 @Status smallint,  
 @HasUserIntegration smallint, 
 @ExtID nvarchar(64),
 @RootMenuID int,
 @CodeName nvarchar(256),
 @Logo nvarchar(max),
 @CssVariables nvarchar(max),
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 INSERT INTO [org].[Customer]  
 (  
  [OwnerID],  
  [Name],  
  [LanguageID],  
  [Status],  
  [HasUserIntegration],
  [ExtID],
  [RootMenuID],
  [CodeName],
  [Logo],
  [CssVariables]
 )  
 VALUES  
 (  
  @OwnerID,  
  @Name,  
  @LanguageID,  
  @Status,  
  @HasUserIntegration,
  @ExtID,
  @RootMenuID,
  @CodeName,
  @Logo,
  @CssVariables
 )  
  
 Set @Err = @@Error  
 Set @CustomerID = scope_identity()  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Customer',0,  
  ( SELECT * FROM [org].[Customer]   
   WHERE  
   [CustomerID] = @CustomerID     FOR XML AUTO) as data,  
    getdate()   
  END  
  
 RETURN @Err  
END  
