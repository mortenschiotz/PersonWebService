
CREATE PROCEDURE [org].[prc_U_D_UT_ins]
(
	@U_DID int,
	@UsertypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[U_D_UT]
	(
		[U_DID],
		[UsertypeID]
	)
	VALUES
	(
		@U_DID,
		@UsertypeID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'U_D_UT',0,
		( SELECT * FROM [org].[U_D_UT] 
			WHERE
			[U_DID] = @U_DID AND
			[UsertypeID] = @UsertypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

