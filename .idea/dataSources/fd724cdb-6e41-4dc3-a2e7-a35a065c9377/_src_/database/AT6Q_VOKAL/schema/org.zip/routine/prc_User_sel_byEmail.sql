/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_sel_byEmail]
(    
  @Email nvarchar(256),    
  @OwnerId int  
 )    
AS    
BEGIN
	DECLARE @EntityStatusID INT = 0
	SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'

	Select UserID, Ownerid, DepartmentID, LanguageID, isnull(RoleID,0) 'RoleID', UserName, Password, LastName, FirstName, Email, Mobile, ExtID, SSN, Tag,
           Locked, ChangePassword, Created, [HashPassword], [SaltPassword],	[OneTimePassword], [OTPExpireTime], CountryCode
	FROM org.[User]    
	WHERE Email = @Email    
	AND Ownerid = @OwnerId
	AND EntityStatusID = @EntityStatusID AND Deleted IS NULL	 
END
