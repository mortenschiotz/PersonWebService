
CREATE PROCEDURE [org].[prc_LT_UserType_get]
(
	@UserTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[UserTypeID],
	[Name],
	[Description]
	FROM [org].[LT_UserType]
	WHERE [UserTypeID] = @UserTypeID

	Set @Err = @@Error

	RETURN @Err
END

