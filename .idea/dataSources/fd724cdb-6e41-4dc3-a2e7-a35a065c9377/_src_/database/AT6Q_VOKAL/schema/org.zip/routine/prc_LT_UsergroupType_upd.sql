
CREATE PROCEDURE [org].[prc_LT_UsergroupType_upd]
(
	@LanguageID int,
	@UsergroupTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[LT_UsergroupType]
	SET
		[LanguageID] = @LanguageID,
		[UsergroupTypeID] = @UsergroupTypeID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[UsergroupTypeID] = @UsergroupTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UsergroupType',1,
		( SELECT * FROM [org].[LT_UsergroupType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UsergroupTypeID] = @UsergroupTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

