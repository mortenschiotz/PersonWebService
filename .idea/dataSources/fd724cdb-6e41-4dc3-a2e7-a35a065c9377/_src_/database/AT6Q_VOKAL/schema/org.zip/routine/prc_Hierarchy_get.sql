
CREATE PROCEDURE [org].[prc_Hierarchy_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[HierarchyID],
	[OwnerID],
	[Name],
	[Description],
	[Type],
	[Deleted],
	[Created]
	FROM [org].[Hierarchy]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END

