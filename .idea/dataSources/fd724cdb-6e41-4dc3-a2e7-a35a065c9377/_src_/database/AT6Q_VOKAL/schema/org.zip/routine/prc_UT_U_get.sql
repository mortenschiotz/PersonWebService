
CREATE PROCEDURE [org].[prc_UT_U_get]
(
	@UserID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[UserTypeID],
	[UserID]
	FROM [org].[UT_U]
	WHERE
	[UserID] = @UserID

	Set @Err = @@Error

	RETURN @Err
END

