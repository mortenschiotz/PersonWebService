CREATE trigger [org].[H_DInsert]
ON [org].[H_D]
AFTER INSERT
as 
--IF  @@Nestlevel < 4
--BEGIN
   Update org.H_D  set  path = dbo.getpath(h.HDID), pathname = dbo.getpathname(h.HDID)
   from H_D h join inserted i on (h.HDID = i.HDID or h.parentid = h.HDID or h.path like '%\' + cast(i.HDID as varchar(16)) + '\%')
--END
