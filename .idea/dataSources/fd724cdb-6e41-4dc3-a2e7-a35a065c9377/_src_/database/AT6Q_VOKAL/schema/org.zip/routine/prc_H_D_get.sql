/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_H_D_get]
(
	@ParentID		int = NULL,
	@HierarchyID	int = NULL,
	@DepartmentID int = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
	
	IF NOT @ParentID IS NULL
		Select
		hd.[HDID],
		hd.[HierarchyID],
		hd.[DepartmentID],
		ISNULL([ParentID], 0) ParentID,
		hd.[Path],
		hd.[PathName],
		hd.[Created]
		FROM org.[H_D] hd
		join org.department d  on d.departmentid = hd.departmentid
		WHERE hd.[ParentID] = @ParentID AND hd.[Deleted] = 0 and d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
		--order by d.Name asc
	ELSE
		Select
		hd.[HDID],
		hd.[HierarchyID],
		hd.[DepartmentID],
		ISNULL([ParentID], 0) ParentID,
		hd.[Path],
		hd.[PathName],
		hd.[Created]
		FROM org.[H_D] hd
		join org.department d  on d.departmentid = hd.departmentid
		WHERE hd.[HierarchyID] = @HierarchyID AND hd.[Deleted] = 0 and d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
		--WHERE hd.[HierarchyID] = @HierarchyID AND hd.Departmentid = @DepartmentID AND hd.[Deleted] = 0
		--order by d.Name asc
	Set @Err = @@Error

	RETURN @Err
END
