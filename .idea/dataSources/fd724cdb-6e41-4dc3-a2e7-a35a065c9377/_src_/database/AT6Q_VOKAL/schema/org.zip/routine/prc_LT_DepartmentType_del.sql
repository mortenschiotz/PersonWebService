

CREATE PROCEDURE [org].[prc_LT_DepartmentType_del]
(
	@LanguageID int,
	@DepartmentTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_DepartmentType',2,
		( SELECT * FROM [org].[LT_DepartmentType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[DepartmentTypeID] = @DepartmentTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[LT_DepartmentType]
	WHERE
	[LanguageID] = @LanguageID AND
	[DepartmentTypeID] = @DepartmentTypeID

	Set @Err = @@Error

	RETURN @Err
END

