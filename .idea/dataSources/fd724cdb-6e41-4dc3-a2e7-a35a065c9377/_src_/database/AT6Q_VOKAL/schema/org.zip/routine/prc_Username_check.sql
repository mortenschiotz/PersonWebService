/* ------------------------------------------------------------
   PROCEDURE:    prc_Username_check

   Description:  

   AUTHOR:       Morty
   ------------------------------------------------------------ */
CREATE PROCEDURE [org].[prc_Username_check]
(
	@Username		varchar(50),
	@Found			bit OUTPUT
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err	Int,
			@Count	int
			

	Select
	@Count = COUNT(*)
	FROM [org].[User]
	WHERE UserName LIKE @Username
	
	IF @Count > 0
		SET @Found = 1
	ELSE
		SET @Found = 0
	Set @Err = @@Error

	RETURN @Err
End




