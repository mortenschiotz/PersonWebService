

CREATE PROCEDURE [org].[prc_DG_D_del]
(
	@DepartmentGroupID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DG_D',2,
		( SELECT * FROM [org].[DG_D] 
			WHERE
			[DepartmentGroupID] = @DepartmentGroupID AND
			[DepartmentID] = @DepartmentID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[DG_D]
	WHERE
	[DepartmentGroupID] = @DepartmentGroupID AND
	[DepartmentID] = @DepartmentID

	Set @Err = @@Error

	RETURN @Err
END

