
CREATE PROCEDURE [org].[prc_U_D_upd]
(
	@U_DID int,
	@DepartmentID int,
	@UserID int,
	@Selected bit,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[U_D]
	SET
		[DepartmentID] = @DepartmentID,
		[UserID] = @UserID,
		[Selected] = @Selected
	WHERE
		[U_DID] = @U_DID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'U_D',1,
		( SELECT * FROM [org].[U_D] 
			WHERE
			[U_DID] = @U_DID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

