CREATE PROCEDURE [org].[prc_Customer_get]  
(  
 @OwnerID int  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 SELECT  
 [CustomerID],  
 [OwnerID],  
 [LanguageID],
 [Name],  
 [Status],  
 [Created],  
 [ExtID],
 [HasUserIntegration],
 [RootMenuID],
 [CodeName],
 [Logo],
 [CssVariables]
 FROM [org].[Customer]  
 WHERE  
 [OwnerID] = @OwnerID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
