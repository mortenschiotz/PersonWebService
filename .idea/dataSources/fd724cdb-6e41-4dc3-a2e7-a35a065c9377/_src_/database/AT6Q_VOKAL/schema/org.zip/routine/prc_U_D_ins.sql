
CREATE PROCEDURE [org].[prc_U_D_ins]
(
	@U_DID int = null output,
	@DepartmentID int,
	@UserID int,
	@Selected bit,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[U_D]
	(
		[DepartmentID],
		[UserID],
		[Selected]
	)
	VALUES
	(
		@DepartmentID,
		@UserID,
		@Selected
	)

	Set @Err = @@Error
	Set @U_DID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'U_D',0,
		( SELECT * FROM [org].[U_D] 
			WHERE
			[U_DID] = @U_DID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

