
CREATE PROCEDURE [org].[prc_DT_UG_get]
(
	@UserGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[UserGroupID],
	[DepartmentTypeID]	
	FROM [org].[DT_UG]	
	WHERE
	[UserGroupID] = @UserGroupID

	Set @Err = @@Error

	RETURN @Err
END

