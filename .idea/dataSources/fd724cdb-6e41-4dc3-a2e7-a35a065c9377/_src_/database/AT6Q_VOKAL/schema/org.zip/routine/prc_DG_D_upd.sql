
CREATE PROCEDURE [org].[prc_DG_D_upd]
(
	@DepartmentGroupID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[DG_D]
	SET
		[DepartmentGroupID] = @DepartmentGroupID,
		[DepartmentID] = @DepartmentID
	WHERE
		[DepartmentGroupID] = @DepartmentGroupID AND
		[DepartmentID] = @DepartmentID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DG_D',1,
		( SELECT * FROM [org].[DG_D] 
			WHERE
			[DepartmentGroupID] = @DepartmentGroupID AND
			[DepartmentID] = @DepartmentID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

