
CREATE PROCEDURE [org].[prc_UT_U_ins]
(
	@UserTypeID int,
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[UT_U]
	(
		[UserTypeID],
		[UserID]
	)
	VALUES
	(
		@UserTypeID,
		@UserID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UT_U',0,
		( SELECT * FROM [org].[UT_U] 
			WHERE
			[UserTypeID] = @UserTypeID AND
			[UserID] = @UserID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

