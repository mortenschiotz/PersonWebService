/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
    2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_UserWithGroup_search_by_HDID]
(
	@HDID int,
	@SearchString	nvarchar(32),
	@SearchUsername int=0,
	@SearchExtID	int=0
)
As
BEGIN
	SET NOCOUNT ON
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
	DECLARE @Err Int,
		   @ColumnDelimiter nvarchar(2) = '*',
		   @RowDelimiter nvarchar(2) = '|'

	Select
	u.[UserID],
	u.[DepartmentID],
	u.[LanguageID],
	u.[UserName],
	u.[Password],
	u.[LastName],
	u.[FirstName],
	u.[Email],
	u.[ExtID],
	u.[SSN],
	u.[Created],
	u.[Mobile],
	u.[Tag],
	u.[Locked],
	u.[Ownerid],
	u.ChangePassword,
	d.Name as DepartmentName,
	(SELECT convert(nvarchar,ug.UserGroupID) + @ColumnDelimiter + ug.Name + @RowDelimiter
	 FROM   org.UG_U ugu INNER JOIN org.UserGroup ug ON ugu.UserGroupID = ug.UserGroupID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
	 WHERE  ugu.UserID = u.UserID
	 FOR XML PATH ('')) AS 'strUserGroups',
     u.EntityStatusID,
     u.Deleted,
     u.EntityStatusReasonID
	FROM org.[User] u
	inner join org.[H_D] hd on hd.DepartmentID = u.DepartmentID and hd.path like  '%\' + cast(@HDID as varchar(16)) + '\%' and hd.deleted = 0
	inner join org.[Department] d on d.DepartmentID = hd.DepartmentID and d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
	WHERE ((u.[UserName] like N'%'+ @SearchString + '%')
	OR (u.[FirstName] like N'%'+ @SearchString + '%')
	OR (u.[FirstName] + ' ' + u.[LastName]  like N'%'+ @SearchString + '%')
	OR (u.[LastName] like N'%'+ @SearchString + '%')
	OR (u.[Email] like N'%'+ @SearchString + '%')
	OR (u.[UserID] like N'%'+ @SearchString + '%')
	OR (u.[ExtID] like N'%'+ @SearchString + '%')
	OR (u.[Mobile] like N'%'+ @SearchString + '%'))
	AND (u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL)

	Set @Err = @@Error

	RETURN @Err
End
