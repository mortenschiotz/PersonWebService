
CREATE PROCEDURE [org].[prc_LT_UserType_ins]
(
	@LanguageID int,
	@UserTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[LT_UserType]
	(
		[LanguageID],
		[UserTypeID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@UserTypeID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UserType',0,
		( SELECT * FROM [org].[LT_UserType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UserTypeID] = @UserTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

