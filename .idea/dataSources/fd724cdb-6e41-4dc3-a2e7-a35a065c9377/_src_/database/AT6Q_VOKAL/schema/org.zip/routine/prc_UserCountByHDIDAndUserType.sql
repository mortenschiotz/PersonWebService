CREATE PROC [org].[prc_UserCountByHDIDAndUserType]
(
  @HDID INT,
  @Usertypeid INT,
  @IncludeTop smallint = 1
)
AS
BEGIN
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

    SELECT count(u.userid) as 'Antall' FROM org.H_D hd 
    JOIN org.department d ON hd.PATH LIKE '%\' + cast(@HDID as nvarchar(16)) + '\%' AND d.departmentid = hd.departmentid 
    JOIN org.[USER] u ON u.departmentid = d.departmentid
    JOIN org.[UT_U] utu on utu.userid = u.userid and (utu.usertypeid = @Usertypeid)
    WHERE u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL AND (@IncludeTop = 1 OR hd.HDID <> @HDID)
END
