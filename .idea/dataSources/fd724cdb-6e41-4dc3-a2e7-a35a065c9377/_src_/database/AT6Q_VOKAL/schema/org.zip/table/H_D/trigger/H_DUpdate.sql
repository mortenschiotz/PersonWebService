CREATE trigger [org].[H_DUpdate]
ON [org].[H_D]
AFTER UPDATE
as 
IF update([parentid]) AND (SELECT trigger_nestlevel(object_ID('[org].[H_DUpdate]'))) < 2
BEGIN
   Update org.H_D set path = dbo.getpath(h.HDID), pathname = dbo.getpathname(h.HDID)
   from H_D h join inserted i on (h.HDID = i.HDID or h.parentid = h.HDID or h.path like '%\' + cast(i.HDID as varchar(8)) + '\%')
END
