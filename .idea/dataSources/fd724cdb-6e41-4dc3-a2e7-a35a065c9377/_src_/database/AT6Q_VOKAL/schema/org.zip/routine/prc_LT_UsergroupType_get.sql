
CREATE PROCEDURE [org].[prc_LT_UsergroupType_get]
(
	@UsergroupTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[UsergroupTypeID],
	[Name],
	[Description]
	FROM [org].[LT_UsergroupType]
	WHERE
	[UsergroupTypeID] = @UsergroupTypeID

	Set @Err = @@Error

	RETURN @Err
END

