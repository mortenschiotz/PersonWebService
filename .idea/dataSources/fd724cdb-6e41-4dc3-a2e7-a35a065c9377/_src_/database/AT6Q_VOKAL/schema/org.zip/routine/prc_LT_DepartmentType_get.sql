
CREATE PROCEDURE [org].[prc_LT_DepartmentType_get]
(
	@DepartmentTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[DepartmentTypeID],
	[Name],
	[Description]
	FROM [org].[LT_DepartmentType]
	WHERE
	[DepartmentTypeID] = @DepartmentTypeID

	Set @Err = @@Error

	RETURN @Err
END

