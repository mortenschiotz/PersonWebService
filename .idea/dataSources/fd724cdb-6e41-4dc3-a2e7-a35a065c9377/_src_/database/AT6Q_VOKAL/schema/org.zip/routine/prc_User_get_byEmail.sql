/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_get_byEmail]
(    
  @Email nvarchar(256)
 )    
AS
BEGIN
  Select UserID, Ownerid, DepartmentID, LanguageID, isnull(RoleID,0) 'RoleID', UserName, Password, LastName, FirstName, Email, Mobile, ExtID, SSN, Tag,
    Locked, ChangePassword, Created, CountryCode, ForceUserLoginAgain, EntityStatusID, Deleted, EntityStatusReasonID
  FROM org.[User] 
  WHERE Email = @Email
END
