CREATE PROCEDURE [org].[prc_UserGroup_ins]
(
	@UserGroupID int = null output,
	@OwnerID int,
	@DepartmentID int = null,
	@SurveyId int = null,
	@Name nvarchar(256),
	@Description ntext,
	@PeriodID int = NULL,
	@ExtID nvarchar(64) = '',
	@Userid int = NULL,
	@UsergroupTypeID int = NULL,
	@Tag nvarchar(max)='',
	@cUserid int,
	@Log smallint = 1,
	@LastUpdated datetime2='',
	@LastUpdatedBy int = NULL,
	@LastSynchronized datetime2='',
	@ArchetypeID int = NULL,
	@Deleted datetime2= NULL,
	@EntityStatusID int = NULL,
	@EntityStatusReasonID int = NULL   
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[UserGroup]
	(
		[OwnerID],
		[DepartmentID],
		[SurveyId],
		[Name],
		[Description],
		[PeriodID],
		[ExtID],
		[UserID],
		[UsergroupTypeID],
		[Tag],
		[LastUpdated],
		[LastUpdatedBy],
		[LastSynchronized],
		[ArchetypeID],
		[Deleted],
		[EntityStatusID],
		[EntityStatusReasonID] 
	)
	VALUES
	(
		@OwnerID,
		@DepartmentID,
		@SurveyId,
		@Name,
		@Description,
		@PeriodID,
		@ExtID,
		@Userid,
		@UsergroupTypeID,
		@Tag,
		@LastUpdated ,
		@LastUpdatedBy,
		@LastSynchronized,
		@ArchetypeID,
		@Deleted,
		@EntityStatusID,
		@EntityStatusReasonID     
	)

	Set @Err = @@Error
	Set @UserGroupID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UserGroup',0,
		( SELECT * FROM [org].[UserGroup] 
			WHERE
			[UserGroupID] = @UserGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
