/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_Department_upd]
(
	@DepartmentID int,
	@LanguageID int,
	@OwnerID int,
	@CustomerID int = null,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@Adress nvarchar(512),
	@PostalCode nvarchar(32),
	@City nvarchar(64),
	@OrgNo varchar(16),
	@ExtID nvarchar(64),
	@Tag nvarchar(max),
	@Locked smallint,
	@CountryCode int =0,
	@cUserid int,
	@Log smallint = 1,
	@LastUpdated datetime2='',
	@LastUpdatedBy int = NULL,
	@LastSynchronized datetime2='',
	@ArchetypeID int = NULL,
	@Deleted datetime2 = NULL,
	@EntityStatusID int = NULL,
	@EntityStatusReasonID int = NULL  
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[Department]
	SET
		[LanguageID] = @LanguageID,
		[OwnerID] = @OwnerID,
		[CustomerID] = @CustomerID,
		[Name] = @Name,
		[Description] = @Description,
		[Adress] = @Adress,
		[PostalCode] = @PostalCode,
		[City] = @City,
		[OrgNo] = @OrgNo,
		[ExtID] = @ExtID,
		[Tag] = @Tag,
		[Locked] = @Locked,
		[CountryCode]=@CountryCode,
		[LastUpdated] = @LastUpdated,
		[LastUpdatedBy] = @LastUpdatedBy,
		[LastSynchronized] = @LastSynchronized,
		[ArchetypeID] =  @ArchetypeID,
		[Deleted]	=	@Deleted ,
		[EntityStatusID] = @EntityStatusID ,
		[EntityStatusReasonID] = @EntityStatusReasonID  
	WHERE
		[DepartmentID] = @DepartmentID

	Update H_d set pathname = dbo.getpathname(HDID) 
    where departmentid = @Departmentid
    
	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Department',1,
		( SELECT * FROM [org].[Department] 
			WHERE
			[DepartmentID] = @DepartmentID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
