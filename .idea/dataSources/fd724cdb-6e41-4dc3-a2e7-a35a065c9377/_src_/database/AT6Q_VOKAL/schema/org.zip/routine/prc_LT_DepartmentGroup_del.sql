

CREATE PROCEDURE [org].[prc_LT_DepartmentGroup_del]
(
	@LanguageID int,
	@DepartmentGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_DepartmentGroup',2,
		( SELECT * FROM [org].[LT_DepartmentGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[DepartmentGroupID] = @DepartmentGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[LT_DepartmentGroup]
	WHERE
	[LanguageID] = @LanguageID AND
	[DepartmentGroupID] = @DepartmentGroupID

	Set @Err = @@Error

	RETURN @Err
END

