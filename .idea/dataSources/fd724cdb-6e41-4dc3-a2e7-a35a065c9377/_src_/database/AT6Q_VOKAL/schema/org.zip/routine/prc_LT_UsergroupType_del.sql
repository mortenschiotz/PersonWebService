CREATE PROCEDURE [org].[prc_LT_UsergroupType_del]
(
	@LanguageID int,
	@UsergroupTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UsergroupType',2,
		( SELECT * FROM [org].[LT_UsergroupType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UsergroupTypeID] = @UsergroupTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[LT_UsergroupType]
	WHERE
		[LanguageID] = @LanguageID AND
		[UsergroupTypeID] = @UsergroupTypeID

	Set @Err = @@Error

	RETURN @Err
END

