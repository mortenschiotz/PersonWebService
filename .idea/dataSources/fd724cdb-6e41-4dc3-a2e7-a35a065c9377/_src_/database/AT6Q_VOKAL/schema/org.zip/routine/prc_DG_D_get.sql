
CREATE PROCEDURE [org].[prc_DG_D_get]
(
	@DepartmentID int = null,
	@DepartmentGroupID int = null
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @DepartmentGroupID IS NULL
		SELECT
		[DepartmentGroupID],
		[DepartmentID]
		FROM [org].[DG_D]
		WHERE
		[DepartmentID] = @DepartmentID
	ELSE
		SELECT
		[DepartmentGroupID],
		[DepartmentID]
		FROM [org].[DG_D]
		WHERE
		[DepartmentGroupID] = @DepartmentGroupID
		
	Set @Err = @@Error

	RETURN @Err
END

