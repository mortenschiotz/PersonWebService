/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_GetUserGroup_ByCutomerID]
(
	@UserID				INT,
	@CustomerID			INT,
	@OwnerID			INT,
	@UserGroupTypeID	varchar(max)
)
AS
BEGIN
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	SELECT 
		ug.UserGroupID,
		ug.OwnerID,
		ug.DepartmentID,
		ug.SurveyId,
		ug.Name,
		ug.Description,
		ug.Created,
		ug.ExtID,
		ug.PeriodID,
		ug.UserID,
		ug.UserGroupTypeID,
		ug.Tag
	 FROM org.UserGroup ug
		INNER JOIN org.Department d ON d.DepartmentID = ug.DepartmentID
		INNER JOIN org.Customer c ON d.CustomerID = c.CustomerID
	WHERE 
		ug.UserID =@UserID			AND 
		c.CustomerID =@CustomerID	AND
		ug.OwnerID = @OwnerID		AND
		ug.UserGroupTypeID IN (SELECT value FROM dbo.funcListToTableInt(@UserGroupTypeID,','))
		AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
END
