 CREATE PROC [org].[prc_UserCountByHDID]
(
  @HDID INT
)
AS
BEGIN
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

    SELECT count(u.userid) as 'Antall' FROM org.H_D hd 
    JOIN org.department d ON hd.PATH LIKE '%\' + cast(@HDID as nvarchar(16)) + '\%' AND d.departmentid = hd.departmentid 
    JOIN org.[USER] u ON u.departmentid = d.departmentid
    WHERE u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
END
