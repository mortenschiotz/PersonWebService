/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_MultiDel]
(		
    @OutResult  varchar(max) out,
    @OwnerId    int,
    @UserIds    nvarchar(max) = N'',
    @UserId     int,		
    @Log        smallint = 1
)
AS
BEGIN TRAN
	SET NOCOUNT ON	
	DECLARE @sqlCommand_UpdateUsers as nvarchar(MAX)
	DECLARE @SurveyIds as varchar(MAX) = ''  -- Not null
	DECLARE @ResultIds as varchar(MAX) = ''  -- Not null
	DECLARE @Result int = 0	

	BEGIN TRY	
		IF len(@UserIds) > 0
		BEGIN
		DECLARE @EntityStatusID INT = 0, @DeactiveEntityStatusID INT = 0, @StatusReason_ManuallySetDeactive int, @StatusReason_DeactivatedByRelatedObject int
		SELECT @EntityStatusID = EntityStatusID FROM EntityStatus WHERE CodeName='Deactive'
        SELECT @StatusReason_ManuallySetDeactive = [EntityStatusReasonID] FROM [EntityStatusReason] WHERE [CodeName] = 'Deactive_ManuallySetDeactive'
        SELECT @StatusReason_DeactivatedByRelatedObject = [EntityStatusReasonID] FROM [EntityStatusReason] WHERE [CodeName] = 'Deactive_SetByRelatedObject'

		SET @sqlCommand_UpdateUsers = N'UPDATE [org].[User]
		SET [UserName] = ''DEL_'' + cast([UserID] AS VARCHAR(32)) + ''_''+ [UserName],
            [EntityStatusID] = ' + CONVERT(NVARCHAR(14), @EntityStatusID) + ',
            [EntityStatusReasonID] = ' + CAST(@StatusReason_ManuallySetDeactive AS nvarchar(32)) + '
		WHERE  UserID IN (' + @UserIds + ')'
		--Delete users
		exec sp_executesql @sqlCommand_UpdateUsers
		
		CREATE TABLE #temptable (SurveyID bigint, ResultID bigint)
		
		-- Set status for results on HD, loop for all Report database	
		DECLARE ReportDB_cursor CURSOR FORWARD_ONLY READ_ONLY FOR
		SELECT DISTINCT s.ReportServer, s.ReportDB FROM at.Survey s JOIN at.Activity a ON s.ActivityID = a.ActivityID AND a.OwnerID = @OwnerId
		
		DECLARE @ReportServer nvarchar(64), @ReportDB nvarchar(64), @sqlCommand nvarchar(max)
		SELECT TOP 1 @ReportServer = ReportServer, @ReportDB = ReportDB FROM at.Activity WHERE OwnerID = @OwnerId
		SET @sqlCommand = N'SELECT @p_DeactiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Deactive'''
		EXECUTE sp_executesql @sqlCommand, N'@p_DeactiveEntityStatusID INT OUTPUT', @p_DeactiveEntityStatusID = @DeactiveEntityStatusID OUTPUT
				
		OPEN ReportDB_cursor		
		FETCH NEXT FROM ReportDB_cursor INTO @ReportServer, @ReportDB
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			DECLARE @sqlCommand1 as nvarchar(MAX) = 'INSERT INTO #temptable (SurveyID, ResultID)
			SELECT R.SurveyID, R.ResultID FROM [' + @ReportServer + '].[' + @ReportDB + '].[dbo].[Result] R JOIN [' + @ReportServer + '].[' + @ReportDB + '].[dbo].[Survey] S ON R.SurveyID=S.SurveyID AND S.DeleteResultOnUserDelete=1  WHERE R.UserID in (' + @UserIds + ')  
			UPDATE R SET R.EntityStatusID = ' + CAST(@DeactiveEntityStatusID AS VARCHAR(32)) + ',
                         R.[EntityStatusReasonID] = ' + CAST(@StatusReason_DeactivatedByRelatedObject AS VARCHAR(32)) + '
            FROM [' + @ReportServer + '].[' + @ReportDB + '].[dbo].[Result] R  JOIN [' + @ReportServer + '].[' + @ReportDB + '].[dbo].[Survey] S ON R.SurveyID=S.SurveyID AND S.DeleteResultOnUserDelete=1  WHERE R.UserID in (' + @UserIds + ')  
			SELECT SurveyID, ResultID FROM #temptable'						
			EXEC sp_executesql @sqlCommand1
					
			FETCH NEXT FROM ReportDB_cursor INTO @ReportServer, @ReportDB
		END	
		
		SET @SurveyIds = stuff((select ',' + cast(a.SurveyID AS VARCHAR(32)) as 'text()' from (select distinct SurveyID from #temptable) as a for xml path('')), 1, 1, '')
		SET @ResultIds = stuff((select ',' + cast(ResultID AS VARCHAR(32)) as 'text()' from #temptable for xml path('')), 1, 1, '')
		
		DECLARE @sqlCommand_UpdateSurveys as nvarchar(MAX)
		SET @sqlCommand_UpdateSurveys = N'UPDATE [at].[Survey]
		SET [ReProcessOLAP] = 2
		WHERE  SurveyID IN (' + @SurveyIds + ')'
		-- Reprocess surveys
		exec sp_executesql @sqlCommand_UpdateSurveys
		
		-- Write log
		IF @Log = 1 
		BEGIN 
		DECLARE @sqlCommand_WriteLog as nvarchar(MAX)
		SET @sqlCommand_WriteLog = N'INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
			SELECT '+ cast(@UserId AS VARCHAR(32)) +',''User'',2,
			( SELECT * FROM [org].[User] 
				WHERE UserID IN (' + @UserIds + ')  FOR XML AUTO) as data,getdate()'
		exec sp_executesql @sqlCommand_WriteLog
		END 
		END
		--print 'Update child department : ' + @ResultIds + @SurveyIds
		--GOTO RollbackResult		 
		
	END TRY
	BEGIN CATCH		
		Set @Result = @@Error	
		GOTO RollbackResult
	END CATCH
	
CommitResult:
	IF((SELECT CURSOR_STATUS('global','ReportDB_cursor')) = 1)
	BEGIN
		CLOSE ReportDB_cursor
		DEALLOCATE ReportDB_cursor
	END
	
	COMMIT TRAN	
	
	IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#temptable')) DROP TABLE #temptable
	
	SET @OutResult = cast(@Result AS VARCHAR(max)) + '|' + ISNULL(@ResultIds,'')	
	RETURN @Result
	
RollbackResult:		
	--SELECT convert(VARCHAR(MAX),ERROR_MESSAGE())	
	IF((SELECT CURSOR_STATUS('global','ReportDB_cursor')) = 1)
	BEGIN
		CLOSE ReportDB_cursor
		DEALLOCATE ReportDB_cursor
	END	
	
	ROLLBACK TRAN		
	
	IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#temptable')) DROP TABLE #temptable
	
	SET @OutResult = cast(@Result AS VARCHAR(1000))	
	RETURN @Result
