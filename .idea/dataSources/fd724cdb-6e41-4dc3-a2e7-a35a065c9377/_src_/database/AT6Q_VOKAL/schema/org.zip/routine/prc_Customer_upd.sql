CREATE PROCEDURE [org].[prc_Customer_upd]  
(  
 @CustomerID int,  
 @OwnerID int,  
 @LanguageID int,  
 @Name nvarchar(256),  
 @Status smallint,  
 @HasUserIntegration smallint, 
 @ExtID nvarchar(64),
 @RootMenuID int,  
 @CodeName nvarchar(256),
 @Logo nvarchar(max),
 @CssVariables nvarchar(max),
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 UPDATE [org].[Customer]  
 SET  
  [OwnerID] = @OwnerID,  
  [LanguageID] = @LanguageID,  
  [Name] = @Name,  
  [Status] = @Status,  
  [HasUserIntegration] = @HasUserIntegration, 
  [ExtID] = @ExtID,
  [RootMenuID] = @RootMenuID,
  [CodeName] = @CodeName,
  [Logo] = @Logo,
  [CssVariables] = @CssVariables
 WHERE  
  [CustomerID] = @CustomerID  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'Customer',1,  
  ( SELECT * FROM [org].[Customer]   
   WHERE  
   [CustomerID] = @CustomerID    FOR XML AUTO) as data,  
   getdate()  
 END  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END 
