
CREATE PROCEDURE [org].[prc_DT_D_upd]
(
	@DepartmentTypeID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[DT_D]
	SET
		[DepartmentTypeID] = @DepartmentTypeID,
		[DepartmentID] = @DepartmentID
	WHERE
		[DepartmentTypeID] = @DepartmentTypeID AND
		[DepartmentID] = @DepartmentID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DT_D',1,
		( SELECT * FROM [org].[DT_D] 
			WHERE
			[DepartmentTypeID] = @DepartmentTypeID AND
			[DepartmentID] = @DepartmentID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

