
CREATE PROCEDURE [org].[prc_DT_D_ins]
(
	@DepartmentTypeID int,
	@DepartmentID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[DT_D]
	(
		[DepartmentTypeID],
		[DepartmentID]
	)
	VALUES
	(
		@DepartmentTypeID,
		@DepartmentID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DT_D',0,
		( SELECT * FROM [org].[DT_D] 
			WHERE
			[DepartmentTypeID] = @DepartmentTypeID AND
			[DepartmentID] = @DepartmentID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

