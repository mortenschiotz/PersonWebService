
CREATE PROCEDURE [org].[prc_U_D_UT_get]
(
	@U_DID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[U_DID],
	[UsertypeID]
	FROM [org].[U_D_UT]
	WHERE
	[U_DID] = @U_DID

	Set @Err = @@Error

	RETURN @Err
END

