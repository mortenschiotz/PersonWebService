
CREATE PROCEDURE [org].[prc_UsergroupType_ins]
(
	@UsergroupTypeID int = null output,
	@OwnerID int,
	@ExtID nvarchar(64),
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[UsergroupType]
	(
		[OwnerID],
		[ExtID],
		[No]
	)
	VALUES
	(
		@OwnerID,
		@ExtID,
		@No
	)

	Set @Err = @@Error
	Set @UsergroupTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UsergroupType',0,
		( SELECT * FROM [org].[UsergroupType] 
			WHERE
			[UsergroupTypeID] = @UsergroupTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

