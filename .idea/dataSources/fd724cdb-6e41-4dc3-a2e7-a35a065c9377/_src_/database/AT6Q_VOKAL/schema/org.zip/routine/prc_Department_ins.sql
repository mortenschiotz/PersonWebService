/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_Department_ins]
(
	@DepartmentID int = null output,
	@LanguageID int,
	@OwnerID int,
	@CustomerID int = NULL,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@Adress nvarchar(512),
	@PostalCode nvarchar(32),
	@City nvarchar(64),
	@OrgNo varchar(16),
	@ExtID nvarchar(64),
	@Tag nvarchar(max),
	@Locked smallint,
	@CountryCode int =0,
	@cUserid int,
	@Log smallint = 1,
	@LastUpdated datetime2='',
	@LastUpdatedBy int = NULL,
	@LastSynchronized datetime2='',
	@ArchetypeID int = NULL,
	@Deleted datetime2 = NULL,
	@EntityStatusID int = NULL,
	@EntityStatusReasonID int = NULL   
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[Department]
	(
		[LanguageID],
		[OwnerID],
        [CustomerID],
		[Name],
		[Description],
		[Adress],
		[PostalCode],
		[City],
		[OrgNo],
		[ExtID],
		[Tag],
		[Locked],
		[CountryCode],
		[LastUpdated],
		[LastUpdatedBy],
		[LastSynchronized],
		[ArchetypeID],
		[Deleted],
		[EntityStatusID],
		[EntityStatusReasonID]    
	)
	VALUES
	(
		@LanguageID,
		@OwnerID,
		@CustomerID,
		@Name,
		@Description,
		@Adress,
		@PostalCode,
		@City,
		@OrgNo,
		@ExtID,
		@Tag,
		@Locked,
		@CountryCode,
		@LastUpdated ,
		@LastUpdatedBy,
		@LastSynchronized,
		@ArchetypeID,
		@Deleted,
		@EntityStatusID,
		@EntityStatusReasonID     
	)

	Set @Err = @@Error
	Set @DepartmentID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Department',0,
		( SELECT * FROM [org].[Department] 
			WHERE
			[DepartmentID] = @DepartmentID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END
