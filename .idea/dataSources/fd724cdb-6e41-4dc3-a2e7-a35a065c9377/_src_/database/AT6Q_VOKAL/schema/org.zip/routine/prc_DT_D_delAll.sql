CREATE PROCEDURE [org].[prc_DT_D_delAll]
(	
	@DepartmentID int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	DELETE
	FROM [org].[DT_D]
	WHERE	
	[DepartmentID] = @DepartmentID
	AND DepartmentTypeID > 1
	Set @Err = @@Error

	RETURN @Err
End