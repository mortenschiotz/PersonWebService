/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_UG_U_get_ByUser]
(
	@UserID	            int,
    @UserGroupTypeID    varchar(max) = ''
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	Select
	ugu.UserGroupID,
	ug.Name,
    ug.UserID GroupOwnerID
	FROM org.UG_U ugu JOIN org.UserGroup ug ON ugu.UserGroupID = ug.UserGroupID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
     AND (ISNULL(@UserGroupTypeID,'') = '' OR ug.UserGroupTypeID IN (SELECT * FROM dbo.funcListToTableInt(@UserGroupTypeID,',')))
	WHERE ugu.[UserID] = @UserID

	Set @Err = @@Error

	RETURN @Err
End
