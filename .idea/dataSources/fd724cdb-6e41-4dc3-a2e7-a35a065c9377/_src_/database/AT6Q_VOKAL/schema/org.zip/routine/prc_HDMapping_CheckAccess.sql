CREATE PROCEDURE [org].[prc_HDMapping_CheckAccess]
(
    @MappingHDIDList varchar(max),
    @CheckingDepartmentIDList varchar(max)
)
AS
BEGIN
    WITH HDID_Recursive AS (
        SELECT hdo.HDID, hdo.ParentID, hdo.DepartmentID
        FROM org.H_D hdo
        WHERE hdo.HDID IN (select value from dbo.funcListToTableInt(@MappingHDIDList,','))
        UNION ALL
        SELECT hdp.HDID, hdp.ParentID, hdp.DepartmentID
        FROM org.H_D hdp
        INNER JOIN HDID_Recursive map ON map.HDID= hdp.ParentID
    )
    SELECT DISTINCT hd.DepartmentID,hd.HDID
    FROM HDID_Recursive hd WHERE hd.DepartmentID IN (select value from dbo.funcListToTableInt(@CheckingDepartmentIDList,','))
END
