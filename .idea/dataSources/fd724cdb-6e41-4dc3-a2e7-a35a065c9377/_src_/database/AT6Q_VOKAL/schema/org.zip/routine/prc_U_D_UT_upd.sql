
CREATE PROCEDURE [org].[prc_U_D_UT_upd]
(
	@U_DID int,
	@UsertypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[U_D_UT]
	SET
		[U_DID] = @U_DID,
		[UsertypeID] = @UsertypeID
	WHERE
		[U_DID] = @U_DID AND
		[UsertypeID] = @UsertypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'U_D_UT',1,
		( SELECT * FROM [org].[U_D_UT] 
			WHERE
			[U_DID] = @U_DID AND
			[UsertypeID] = @UsertypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

