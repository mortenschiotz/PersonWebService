/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_Department_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[DepartmentID],
	[LanguageID],
	[OwnerID],
    ISNULL([CustomerID],0) CustomerID,
	[Name],
	[Description],
	[Adress],
	[PostalCode],
	[City],
	[OrgNo],
	[Created],
	[ExtID],
	[Tag],
	[Locked],
	[CountryCode],
	[LastUpdated],
	[LastUpdatedBy],
	[LastSynchronized],
	[ArchetypeID],
	[Deleted],
	[EntityStatusID],
	[EntityStatusReasonID]
	FROM [org].[Department]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END
