
CREATE PROCEDURE [org].[prc_UsergroupType_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[UsergroupTypeID],
	[OwnerID],
	[ExtID],
	[No],
	[Created]
	FROM [org].[UsergroupType]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

