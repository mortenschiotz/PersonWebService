CREATE PROCEDURE [org].[Login]
(
	@UserName	nvarchar(128),
	@PassWord	nvarchar(64),
	@UserID		int		OUTPUT,
	@LanguageID	int=1		OUTPUT,
	@DepartmentID	int		OUTPUT,
	@Firstname	nvarchar(64) 	OUTPUT,
	@Lastname	nvarchar(64) 	OUTPUT,
	@Email		nvarchar(256) 	OUTPUT,
	@Mobile		nvarchar(16) 	OUTPUT,
	@ExtId		nvarchar(64) 	OUTPUT,
	@Status		smallint 	OUTPUT,
	@EntityStatus   int         OUTPUT,
	@OwnerId	int	,
	@ErrNo		int		OUTPUT,
	@ChangePassword bit = 0 OUTPUT
)
AS
BEGIN

	DECLARE @Err Int, @EntityStatusID INT = 0
	SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'

	SELECT 
		@DepartmentID = DepartmentID,
		@LanguageID = LanguageID,
		@UserID = UserID,
		@Firstname = Firstname,
		@Lastname = Lastname,
		@Email = Email,
		@Mobile = Mobile,
		@ExtId = ExtId,
		@Status = [Status],
		@EntityStatus = EntityStatusID,
		@OwnerId = OwnerId,
		@ChangePassword = ChangePassword
	FROM 	
		[User] 
	WHERE 	
		UserName = @UserName
		AND ([Password] = @Password OR [OneTimePassword]= @PassWord)
		AND EntityStatusID = @EntityStatusID
		AND Deleted IS NULL
		AND [Ownerid] = @OwnerId

	Set @Err = @@Error
	RETURN @Err
END

