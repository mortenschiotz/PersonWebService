/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_UG_U_get]
(
	@UserGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	SELECT
	ug.[UserGroupID],
	ug.[UserID],
	u.[DepartmentID],
	u.FirstName,
	u.LastName,
	u.[Email],
    u.[Mobile],
    u.[ExtID],
    u.[SSN],
    u.[Tag],
    u.[Locked],
    u.[Gender],
    u.[DateOfBirth],
    u.[Created],
    u.[ChangePassword],
    u.[HashPassword],
    u.[SaltPassword],
    u.[OneTimePassword],
    u.[OTPExpireTime],
    u.[CountryCode],
    u.EntityStatusID,
    u.Deleted,
    u.EntityStatusReasonID
	FROM [org].[UG_U] ug
	INNER JOIN [org].[User] u ON ug.UserID = u.UserID AND u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
	WHERE
	[UserGroupID] = @UserGroupID

	Set @Err = @@Error

	RETURN @Err
END
