CREATE PROCEDURE [org].[prc_UserByGroup_PagingGet]
(
	@UserGroupID	int,
	@RowCount		int output,
	@RowIndex		int,
	@PageSize		int,
	@DenyUTIDList nvarchar(max) = '',
    @UTIDList nvarchar(max) = ''
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int, @ToRow int, @EntityStatusID INT = 0

	SELECT value INTO #DenyUTtable FROM dbo.funcListToTableInt(@DenyUTIDList, ',') 
    SELECT value INTO #UTTable FROM dbo.funcListToTableInt(@UTIDList, ',')

	SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'

	SELECT @RowCount = count(ugu.UserID) 
	FROM [org].[UG_U] ugu
	INNER JOIN [org].[User] u ON ugu.UserID = u.UserID AND u.EntityStatusID = @EntityStatusID AND u.Deleted IS NULL
	WHERE [UserGroupID] = @UserGroupID
      AND (EXISTS (SELECT 1 FROM org.UT_U utu2 WHERE utu2.UserID = ugu.UserID AND utu2.UserTypeID IN (SELECT value FROM #UTTable)) OR @UTIDList = '')
      AND (NOT EXISTS (SELECT 1 FROM org.UT_U utu WHERE utu.UserID = ugu.UserID AND utu.UserTypeID IN (SELECT value FROM #DenyUTtable)) OR @DenyUTIDList = '')
	
	IF @RowIndex > @RowCount
	BEGIN
	   RETURN
	END
	
	SET @ToRow = @RowIndex + @PageSize - 1
	IF @ToRow > @RowCount
	BEGIN
	   SET @ToRow = @RowCount
	END
	
	SELECT v.[UserGroupID],
		   v.[UserID],
		   v.[DepartmentID],
		   v.FirstName,
		   v.LastName 
	FROM (
	SELECT  row_number() OVER (ORDER BY u.FirstName, u.LastName) AS RowNum,
		   ugu.[UserGroupID],
		   ugu.[UserID],
		   u.[DepartmentID],
		   u.FirstName,
		   u.LastName
	FROM [org].[UG_U] ugu
	INNER JOIN [org].[User] u ON ugu.UserID = u.UserID AND u.EntityStatusID = @EntityStatusID AND u.Deleted IS NULL

	WHERE [UserGroupID] = @UserGroupID
      AND (EXISTS (SELECT 1 FROM org.UT_U utu2 WHERE utu2.UserID = ugu.UserID AND utu2.UserTypeID IN (SELECT value FROM #UTTable)) OR @UTIDList = '')
      AND (NOT EXISTS (SELECT 1 FROM org.UT_U utu WHERE utu.UserID = ugu.UserID AND utu.UserTypeID IN (SELECT value FROM #DenyUTtable)) OR @DenyUTIDList = '')

	) v WHERE v.RowNum BETWEEN @RowIndex AND @ToRow

    DROP TABLE #DenyUTtable;
	DROP TABLE #UTtable;

	Set @Err = @@Error

	RETURN @Err
END

