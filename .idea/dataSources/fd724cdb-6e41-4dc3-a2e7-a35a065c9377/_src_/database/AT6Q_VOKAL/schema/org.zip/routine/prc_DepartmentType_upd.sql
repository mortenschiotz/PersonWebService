CREATE PROCEDURE [org].[prc_DepartmentType_upd]
(
	@DepartmentTypeID int,
	@OwnerID int,
	@ExtID nvarchar(64),
	@No smallint,
	@cUserid int,
	@Log smallint = 1,
	@ArchetypeID int = NULL,
	@ParentID int = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[DepartmentType]
	SET
		[OwnerID] = @OwnerID,
		[ExtID] = @ExtID,
		[No] = @No,
		[ArchetypeID] = @ArchetypeID,
		[ParentID] = @ParentID
	WHERE
		[DepartmentTypeID] = @DepartmentTypeID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DepartmentType',1,
		( SELECT * FROM [org].[DepartmentType] 
			WHERE
			[DepartmentTypeID] = @DepartmentTypeID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END
