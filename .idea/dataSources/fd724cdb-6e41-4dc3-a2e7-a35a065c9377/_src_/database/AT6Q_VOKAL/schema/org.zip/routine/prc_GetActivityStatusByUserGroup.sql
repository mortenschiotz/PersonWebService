/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROC [org].[prc_GetActivityStatusByUserGroup]
(
  @UserGroupIDList	    varchar(max)='',
  @ActivityList         NVARCHAR(MAX),
  @ExcludeStatusTypeID  varchar(max),
  @PriorStatusTypeID    INT

)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE
		  @ColumnDelimiter	  nvarchar(5) = CHAR(131) + CHAR(7),
		  @RowDelimiter	  nvarchar(5) = CHAR(137) + CHAR(8),
		  @ColumnDefinition	  nvarchar(max) = N'',		-- in form of Activity_ + ID from @ActivityList
		  @sqlCommand		  nvarchar(max) = N'',
		  @UpdateCommand	  nvarchar(max) = N'',
		  @Parameters		  nvarchar(max) = N'@p_StatusTypeID int,@p_UserID int',
		  @ActivityID		  int,
		  @EntityStatusID INT = 0

	SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'

    DECLARE c_Activity CURSOR READ_ONLY FOR
    SELECT ParseValue FROM dbo.StringToArray(@ActivityList,',')

    SELECT
        u.[UserID],
		u.[DepartmentID],
		u.[UserName],
		u.[LastName],
		u.[FirstName],
		d.Name as DepartmentName,
		(SELECT convert(nvarchar,ug.UserGroupID) + @ColumnDelimiter + ug.Name + @ColumnDelimiter + convert(nvarchar,ug.UserGroupTypeID) + @RowDelimiter
		  FROM   org.UG_U ugu INNER JOIN org.UserGroup ug ON ugu.UserGroupID = ug.UserGroupID AND ug.EntityStatusID = @EntityStatusID AND ug.Deleted IS NULL
		  WHERE  ugu.UserID = u.UserID
		  FOR XML PATH ('')) AS 'StrUserGroups'
	INTO #ResultStatus
	FROM org.[USER] u 
	INNER JOIN org.[Department] d ON u.departmentid = d.departmentid and d.EntityStatusID = @EntityStatusID AND d.Deleted IS NULL
	INNER JOIN org.UG_U ugu ON ugu.UserID = u.UserID
	INNER JOIN org.UserGroup g ON ugu.UserGroupID = g.UserGroupID AND g.EntityStatusID = @EntityStatusID AND g.Deleted IS NULL
	WHERE g.UserGroupID IN (SELECT ParseValue FROM dbo.StringToArray(@UserGroupIDList,','))
	AND u.EntityStatusID = @EntityStatusID AND u.Deleted IS NULL

    DECLARE c_Users CURSOR SCROLL READ_ONLY FOR
    SELECT UserID FROM #ResultStatus
    OPEN c_Users

    DECLARE @v_UserID int, @v_StatusTypeID int

    SET @sqlCommand = 'ALTER TABLE #ResultStatus ADD '

    OPEN c_Activity
	   FETCH NEXT FROM c_Activity INTO @ActivityID
	   WHILE @@FETCH_STATUS=0
	   BEGIN
		  -- Add column to temp table to store result status
		  SET @ColumnDefinition = @sqlCommand + N'Activity_' + convert(nvarchar,@ActivityID) + N' int'
		  EXECUTE sp_executesql @ColumnDefinition

		  FETCH FIRST FROM c_Users INTO @v_UserID
		  WHILE @@FETCH_STATUS=0
		  BEGIN
			 EXEC @v_StatusTypeID = [at].[GetLatestStatusByActivity] @v_UserID, @ActivityID, @ExcludeStatusTypeID, @PriorStatusTypeID

			 SET @UpdateCommand = 'UPDATE #ResultStatus SET Activity_' + convert(nvarchar,@ActivityID) + ' = @p_StatusTypeID '
							+ 'WHERE UserID = @p_UserID'
			 EXECUTE sp_executesql @UpdateCommand, @Parameters, @p_StatusTypeID = @v_StatusTypeID, @p_UserID = @v_UserID
			 FETCH NEXT FROM c_Users INTO @v_UserID
		  END
		  FETCH NEXT FROM c_Activity INTO @ActivityID
	   END
    CLOSE c_Activity
    DEALLOCATE c_Activity

    CLOSE c_Users
    DEALLOCATE c_Users

    SELECT * FROM #ResultStatus  

    DROP TABLE #ResultStatus
END
