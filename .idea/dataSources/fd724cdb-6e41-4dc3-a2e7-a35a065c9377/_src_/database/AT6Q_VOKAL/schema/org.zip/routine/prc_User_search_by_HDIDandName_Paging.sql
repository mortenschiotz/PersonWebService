/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
    2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_search_by_HDIDandName_Paging]
(
	@HDID					int,
	@SearchString		   nvarchar(32),
	@UserTypeIDList	   varchar(max),
	@DeniedUserTypeIDList  varchar(max),
	@RowCount			   int output,
	@RowIndex			   int,
	@PageSize			   int,
	@SearchInOwnedGroup	   bit = 0,
	@GroupOwnerUserID	   int = 0,
	@UserGroupIDList	   varchar(max)='',
	@CustomerID			   int =0
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int, @ToRow int
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	Select row_number() OVER (ORDER BY u.FirstName, u.LastName) AS RowNum,
	u.[UserID],
	u.[DepartmentID],
	u.[LanguageID],
	u.[UserName],
	u.[Password],
	u.[LastName],
	u.[FirstName],
	u.[Email],
	u.[ExtID],
	u.[SSN],
	u.[Created],
	u.[Mobile],
	u.[Tag],
	u.[Locked],
	u.[Ownerid],
	u.[ChangePassword],
	d.[Name] as DepartmentName,
    u.[Gender],
    u.EntityStatusID
	INTO #SearchResult
	FROM org.[User] u
	inner join org.[H_D] hd on hd.DepartmentID = u.DepartmentID and (@HDID = 0 OR (hd.path like  '%\' + cast(@HDID as varchar(16)) + '\%' and hd.deleted = 0))
	inner join org.[Department] d on d.DepartmentID = hd.DepartmentID and ( @HDID <> 0 OR ( hd.DepartmentID IN (SELECT d.DepartmentID from org.Customer c INNER JOIN org.Department d ON d.CustomerID = c.CustomerID AND c.CustomerID =@CustomerID) )) AND d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL
	WHERE ((u.[FirstName] like N'%'+ @SearchString + '%')
	OR (u.[FirstName] + ' ' + u.[LastName]  like N'%'+ @SearchString + '%')
	OR (u.[LastName] like N'%'+ @SearchString + '%')
	OR (u.UserName LIKE N'%'+ @SearchString + '%')
	OR (u.Mobile LIKE N'%'+ @SearchString + '%'))
	AND (u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL)
	AND EXISTS (SELECT 1 FROM org.UT_U utu WHERE utu.UserTypeID IN (SELECT ParseValue FROM dbo.StringToArray(@UserTypeIDList,','))
									 AND utu.UserID = u.UserID)
     AND NOT EXISTS (SELECT 2 FROM org.UT_U utu2 WHERE utu2.UserTypeID IN (SELECT ParseValue FROM dbo.StringToArray(@DeniedUserTypeIDList,','))
										 AND utu2.UserID = u.UserID)
	AND ((@SearchInOwnedGroup = 0 AND @UserGroupIDList='')
	     OR EXISTS (SELECT 3 FROM org.UG_U ugu JOIN org.UserGroup ug ON ugu.UserGroupID = ug.UserGroupID AND ug.UserID = @GroupOwnerUserID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
				 WHERE ugu.UserID = u.UserID
				   AND (@UserGroupIDList = ''
					   OR  EXISTS  (SELECT 4  FROM dbo.StringToArray(@UserGroupIDList,',') where ParseValue =ugu.UserGroupID)
					   )
				)
	    )
	ORDER BY u.FirstName, u.LastName
	
	SELECT @RowCount = COUNT(UserID) FROM #SearchResult	
	
	IF @RowIndex > @RowCount
	BEGIN
	   RETURN
	END
	
	SET @ToRow = @RowIndex + @PageSize - 1
	IF @ToRow > @RowCount
	BEGIN
	   SET @ToRow = @RowCount
	END
	
	SELECT  RowNum,[UserID],
		   [DepartmentID],
		   [LanguageID],
		   [UserName],
		   [Password],
		   [LastName],
		   [FirstName],
		   [Email],
		   [ExtID],
		   [SSN],
		   [Created],
		   [Mobile],
		   [Tag],
		   [Locked],
		   [Ownerid],
		   [ChangePassword],
		   [DepartmentName],
           [Gender],
           [EntityStatusID]
	FROM  #SearchResult
	WHERE RowNum BETWEEN @RowIndex AND @ToRow	

	Set @Err = @@Error

	RETURN @Err
End
