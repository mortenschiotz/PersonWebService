/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
-- EXEC [org].[prc_UserCountInUserGroupByDepID] 23824, 4, '38'
*/
CREATE PROCEDURE [org].[prc_UserCountInUserGroupByDepID]
(
  @DepartmentID	    int,
  @PeriodID		    int,
  @DepartmentTypeIDList varchar(max)
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
    
    SELECT ug.UserGroupID, ug.Name UserGroupName, count(ugu.UserID) as 'UserCount'
    FROM org.UserGroup ug
    JOIN org.UG_U ugu ON ugu.UserGroupID = ug.UserGroupID AND ug.DepartmentID = @DepartmentID AND ug.PeriodID = @PeriodID AND ug.EntityStatusID = @ActiveEntityStatusID AND ug.Deleted IS NULL
    JOIN org.[User] u ON u.UserID = ugu.UserID AND u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL
    JOIN org.DT_UG dtug ON dtug.UserGroupID = ug.UserGroupID AND dtug.DepartmentTypeID IN (SELECT Value From dbo.funcListToTableInt(@DepartmentTypeIDList,','))
    GROUP BY ug.UserGroupID, ug.Name
    ORDER BY ug.Name
END  
