
CREATE PROCEDURE [org].[prc_LT_UsergroupType_ins]
(
	@LanguageID int,
	@UsergroupTypeID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[LT_UsergroupType]
	(
		[LanguageID],
		[UsergroupTypeID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@UsergroupTypeID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UsergroupType',0,
		( SELECT * FROM [org].[LT_UsergroupType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UsergroupTypeID] = @UsergroupTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

