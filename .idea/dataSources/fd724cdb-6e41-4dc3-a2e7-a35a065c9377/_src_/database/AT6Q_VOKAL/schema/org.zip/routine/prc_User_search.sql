/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_search]  
(  
 @HierarchyID int,  
 @SearchString nvarchar(32)  
)  
As  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int, @EntityStatusID INT = 0
 SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'
  
 Select  
 u.[UserID],  
 u.[DepartmentID],  
 u.[LanguageID],  
 u.[UserName],  
 u.[Password],  
 u.[LastName],  
 u.[FirstName],  
 u.[Email],  
 u.[ExtID],  
 u.[SSN],  
 u.[Created],  
 u.[Mobile],  
 u.[Tag],  
 u.Locked,  
 u.Gender,
 u.DateOfBirth,
 u.ChangePassword,  
 u.[HashPassword],  
 u.[SaltPassword],  
 u.[OneTimePassword],  
 u.[OTPExpireTime],  
 u.CountryCode,
 u.EntityStatusID,
 u.Deleted,
 u.EntityStatusReasonID
 FROM org.[User] u  
 join org.[H_D] hd on hd.DepartmentID = u.DepartmentID and hd.HierarchyID = @HierarchyID
 LEFT JOIN app.LoginService_User lsu ON u.UserID = lsu.UserID
 WHERE ((u.[UserName] like '%'+ @SearchString + '%')  
 OR (u.[FirstName] like '%'+ @SearchString + '%')  
 OR (u.[FirstName] + ' ' + u.[LastName]  like '%'+ @SearchString + '%')  
 OR (u.[LastName] like '%'+ @SearchString + '%')  
 OR (u.[Email] like '%'+ @SearchString + '%')  
 OR (u.[UserID] like '%'+ @SearchString + '%')  
 OR (u.[ExtID] like '%'+ @SearchString + '%')  
 OR (u.[Mobile] like '%'+ @SearchString + '%')  
 OR (u.[SSN] like '%'+ @SearchString + '%')
 OR (lsu.PrimaryClaimValue like '%'+ @SearchString + '%'))
 AND u.EntityStatusID = @EntityStatusID 
 AND u.Deleted IS NULL 
  
 Set @Err = @@Error  
  
 RETURN @Err  
End
