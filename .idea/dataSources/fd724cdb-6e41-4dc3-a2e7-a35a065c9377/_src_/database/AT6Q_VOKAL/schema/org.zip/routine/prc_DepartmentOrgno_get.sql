/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_DepartmentOrgno_get]
(
    @Orgno VARCHAR(15),
    @Ownerid INT
)
AS
BEGIN
	DECLARE @EntityStatusID INT = 0
	SELECT @EntityStatusID = EntityStatusID FROM EntityStatus WHERE CodeName='Active'
    SELECT  [DepartmentID],
            [LanguageID],
            [OwnerID],
            ISNULL([CustomerID],0) CustomerID,
            [Name],
            [Description],
            [Adress],
            [PostalCode],
            [City],
            [OrgNo],
            [Created],
            [ExtID],
            [Tag],
            [Locked],
			[CountryCode],
			[Deleted],
			[EntityStatusID],
			[EntityStatusReasonID]
    FROM  org.Department
    WHERE orgno = @Orgno AND OwnerId = @Ownerid and [EntityStatusID] = @EntityStatusID AND Deleted IS NULL
      AND departmentid in (Select departmentid from H_D where deleted = 0)
END
