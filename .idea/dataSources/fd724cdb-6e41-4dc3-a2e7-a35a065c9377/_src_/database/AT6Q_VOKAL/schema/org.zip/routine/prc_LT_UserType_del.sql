

CREATE PROCEDURE [org].[prc_LT_UserType_del]
(
	@LanguageID int,
	@UserTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_UserType',2,
		( SELECT * FROM [org].[LT_UserType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[UserTypeID] = @UserTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[LT_UserType]
	WHERE
	[LanguageID] = @LanguageID AND
	[UserTypeID] = @UserTypeID

	Set @Err = @@Error

	RETURN @Err
END

