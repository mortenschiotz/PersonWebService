/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_sel_bySSN]
(
  @SSN nvarchar(64),
  @OwnerId int
 )
AS
BEGIN
  Select UserID, Ownerid, DepartmentID, LanguageID, isnull(RoleID,0) 'RoleID', UserName, Password, LastName, FirstName, Email, Mobile, 
    ExtID, SSN, Tag, Locked, ChangePassword, Created, [HashPassword], [SaltPassword],[OneTimePassword], [OTPExpireTime], CountryCode, 
    [EntityStatusID], Deleted, EntityStatusReasonID
  FROM org.[User]
  WHERE SSN = @SSN and OwnerId = @OwnerId
END
