/*  2016-10-10 Ray: Remove column Status from org.User, org.Department, RDB.dbo.Result
*/
CREATE PROCEDURE [org].[prc_User_ins]
(  
 @UserID int = null output,  
 @Ownerid int,  
 @DepartmentID int,  
 @LanguageID int,  
 @RoleID int = null,  
 @UserName nvarchar(128),  
 @Password nvarchar(64),  
 @LastName nvarchar(64),  
 @FirstName nvarchar(64),  
 @Email nvarchar(256),  
 @Mobile nvarchar(16),  
 @ExtID nvarchar(64),  
 @SSN nvarchar(64),  
 @Tag nvarchar(128),  
 @Locked smallint,  
 @ChangePassword bit,  
 @HashPassword nvarchar(128)='',  
 @SaltPassword nvarchar(64)='',  
 @OneTimePassword nvarchar(64)='',  
 @OTPExpireTime smalldatetime='',  
 @cUserid int,  
 @Log smallint = 1,  
 @CountryCode int = 0,
 @Gender smallint = 0,
 @DateOfBirth date='' ,
 @ForceUserLoginAgain BIT =0,
 @LastUpdated datetime2='',
 @LastUpdatedBy int = NULL,
 @LastSynchronized datetime2='',
 @ArchetypeID int = NULL,
 @CustomerID int = NULL,
 @Deleted datetime2 = NULL,
 @EntityStatusID int = NULL,
 @EntityStatusReasonID int = NULL
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  

 INSERT INTO [org].[User]  
 (  
  [Ownerid],  
  [DepartmentID],  
  [LanguageID],  
  [RoleID],  
  [UserName],  
  [Password],  
  [LastName],  
  [FirstName],  
  [Email],  
  [Mobile],  
  [ExtID],  
  [SSN],  
  [Tag],  
  [Locked],  
  [ChangePassword],  
  [HashPassword],  
  [SaltPassword],  
  [OneTimePassword],  
  [OTPExpireTime],  
  [CountryCode],
  [Gender],
  [DateOfBirth],
  [ForceUserLoginAgain],
  [LastUpdated],
  [LastUpdatedBy],
  [LastSynchronized],
  [ArchetypeID],
  [CustomerID],
  [Deleted],
  [EntityStatusID],
  [EntityStatusReasonID]    
 )  
 VALUES  
 (  
  @Ownerid,  
  @DepartmentID,  
  @LanguageID,  
  @RoleID,  
  @UserName,  
  @Password,  
  @LastName,  
  @FirstName,  
  @Email,  
  @Mobile,  
  @ExtID,  
  @SSN,  
  @Tag,  
  @Locked,  
  @ChangePassword,  
  @HashPassword,  
  @SaltPassword,  
  @OneTimePassword,  
  @OTPExpireTime,  
  @CountryCode,
  @Gender,
  @DateOfBirth,
  @ForceUserLoginAgain,
  @LastUpdated ,
  @LastUpdatedBy,
  @LastSynchronized,
  @ArchetypeID,
  @CustomerID,
  @Deleted,
  @EntityStatusID,
  @EntityStatusReasonID   
 )  

 Set @Err = @@Error  
 Set @UserID = scope_identity()  

 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'User',0,  
  ( SELECT * FROM [org].[User]   
   WHERE  
   [UserID] = @UserID     FOR XML AUTO) as data,  
    getdate()   
  END  

 RETURN @Err  
END
