/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_UserCountInUserGroupByUserAndType]
(	
	@ListUserID                 varchar(max)='',
	@UserTypeID                 int,
	@UserGroupTypeID            varchar(128),
	@DenyUserTypeList           nvarchar(max) ='',
    @CountInGroupOwnerCurrentHD bit = 0
)
AS
BEGIN
	DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	IF @CountInGroupOwnerCurrentHD = 0
    BEGIN
        SELECT COUNT( DISTINCT ugu.UserID) as [Count], uag.UserID
	    FROM org.UG_U ugu 
	    JOIN org.UserGroup uag ON ugu.UserGroupID  =  uag.UserGroupID AND uag.EntityStatusID = @ActiveEntityStatusID AND uag.Deleted IS NULL
	    JOIN org.[User] us ON us.UserID =ugu.UserID AND us.EntityStatusID = @ActiveEntityStatusID AND us.Deleted IS NULL
	    JOIN org.UT_U utu ON us.UserID = utu.UserID
	    WHERE uag.UserID IN (SELECT value FROM dbo.funcListToTableInt(@ListUserID,',')) 
          AND uag.UserGroupTypeID IN (SELECT value FROM dbo.funcListToTableInt(@UserGroupTypeID,','))
          AND utu.UserTypeID = @UserTypeID
	      AND NOT EXISTS (SELECT 1 FROM org.UT_U utu2 WHERE utu2.UserID = ugu.UserID AND utu2.UserTypeID IN (SELECT value FROm dbo.funcListToTableInt(@DenyUserTypeList,',')))
	    Group BY  uag.UserID
    END
    ELSE
    BEGIN
        SELECT COUNT( DISTINCT ugu.UserID) as [Count], uag.UserID
	    FROM org.UG_U ugu 
	    JOIN org.UserGroup uag ON ugu.UserGroupID  =  uag.UserGroupID AND uag.EntityStatusID = @ActiveEntityStatusID AND uag.Deleted IS NULL
	    JOIN org.[User] us ON us.UserID =ugu.UserID AND us.EntityStatusID = @ActiveEntityStatusID AND us.Deleted IS NULL
	    JOIN org.UT_U utu ON us.UserID = utu.UserID
        JOIN [org].[User] u ON uag.[UserID] = u.[UserID]
        JOIN [org].[H_D] phd ON u.[DepartmentID] = phd.[DepartmentID]
        JOIN [org].[H_D] chd ON us.[DepartmentID] = chd.[DepartmentID] AND chd.[Path] LIKE '%\' + CONVERT(nvarchar(32), phd.[HDID]) + '\%'
	    WHERE uag.UserID IN (SELECT value FROM dbo.funcListToTableInt(@ListUserID,',')) 
          AND uag.UserGroupTypeID IN (SELECT value FROM dbo.funcListToTableInt(@UserGroupTypeID,','))
          AND utu.UserTypeID = @UserTypeID
	      AND NOT EXISTS (SELECT 1 FROM org.UT_U utu2 WHERE utu2.UserID = ugu.UserID AND utu2.UserTypeID IN (SELECT value FROm dbo.funcListToTableInt(@DenyUserTypeList,',')))
	    Group BY  uag.UserID
    END
END
