
CREATE PROCEDURE [org].[prc_DepartmentGroup_upd]
(
	@DepartmentGroupID int,
	@OwnerID int,
	@ExtID nvarchar(64),
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [org].[DepartmentGroup]
	SET
		[OwnerID] = @OwnerID,
		[ExtID] = @ExtID,
		[No] = @No
	WHERE
		[DepartmentGroupID] = @DepartmentGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'DepartmentGroup',1,
		( SELECT * FROM [org].[DepartmentGroup] 
			WHERE
			[DepartmentGroupID] = @DepartmentGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

