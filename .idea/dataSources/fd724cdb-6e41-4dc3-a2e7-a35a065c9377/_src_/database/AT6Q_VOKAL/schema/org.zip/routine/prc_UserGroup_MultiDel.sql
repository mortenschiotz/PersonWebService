/*
	Steve - Sept 22 2016 - EntityStatus for table UserGroup
*/
CREATE PROCEDURE [org].[prc_UserGroup_MultiDel]
(
    @UserGroupIDList    varchar(max),
    @UserID		    int,
    @MoveToNewGroup	    bit = 0,
    @NewGroupID	    int = 0,
    @HardDelete	    bit = 0
)
AS
BEGIN
    SET NOCOUNT ON
    
    SELECT ParseValue AS UserGroupID INTO #UserGroupList FROM dbo.StringToArray(@UserGroupIDList, ',')
    SELECT DISTINCT ugu.UserID INTO #UserList FROM org.UG_U ugu WHERE ugu.UserGroupID IN (SELECT UserGroupID FROM #UserGroupList)
    
    BEGIN TRANSACTION
		IF @HardDelete = 1
		BEGIN
			-- Remove users from being deleted groups
			DELETE FROM org.UG_U WHERE UserGroupID IN (SELECT UserGroupID FROM #UserGroupList)
		END
	   IF @@ERROR<>0 AND @@TRANCOUNT>0
	   BEGIN
		  ROLLBACK TRANSACTION
		  GOTO Finish
	   END
        
	   -- Move users to new group
	   IF @MoveToNewGroup = 1 AND @NewGroupID != 0
	   BEGIN
		  INSERT INTO org.UG_U (UserGroupID, UserID)
		  SELECT @NewGroupID, ul.UserID FROM #UserList ul
		  WHERE NOT EXISTS (SELECT 1 FROM org.UG_U ugu WHERE ugu.UserID = ul.UserID)
		  
		  IF @@ERROR<>0 AND @@TRANCOUNT>0
		  BEGIN
			 ROLLBACK TRANSACTION
			 GOTO Finish
		  END
	   END
        
		IF @HardDelete = 1
		BEGIN
			-- Delete groups in list
			DELETE FROM org.UserGroup WHERE UserGroupID IN (SELECT UserGroupID FROM #UserGroupList)
		END
		ELSE
		BEGIN
			DECLARE @DeactiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Deactive')
			-- Mark soft-deleted groups in list
			UPDATE org.UserGroup SET EntityStatusID = @DeactiveEntityStatusID WHERE UserGroupID IN (SELECT UserGroupID FROM #UserGroupList)
		END
	   IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
    COMMIT TRANSACTION
Finish:
    -- Drop temp tables
    DROP TABLE #UserGroupList
    DROP TABLE #UserList
END
