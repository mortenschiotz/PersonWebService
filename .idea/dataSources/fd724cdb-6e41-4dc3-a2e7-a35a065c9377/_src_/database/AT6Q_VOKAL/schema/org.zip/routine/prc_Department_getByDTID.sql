CREATE PROCEDURE [org].[prc_Department_getByDTID]
(
	@ParentID               INT,
    @ListDepartmentTypeID   VARCHAR(MAX)
)
AS
BEGIN
	SET NOCOUNT ON  
    DECLARE @Err int
    
    IF OBJECT_ID('tempdb..#ListDepartmentTypeID') IS NOT NULL DROP TABLE #ListDepartmentTypeID    
    SELECT Value AS DepartmentTypeID INTO #ListDepartmentTypeID FROM [dbo].[funcListToTableInt](@ListDepartmentTypeID, ',')
    
    SELECT DEPT.*                  
	FROM [org].[Department] AS DEPT
    JOIN org.H_D AS HD ON HD.DepartmentID = DEPT.DepartmentID  AND HD.Deleted = 0 AND HD.[Path] LIKE '%\'+ CONVERT(VARCHAR(32),@ParentID) +'\%' 	         
    WHERE EXISTS (SELECT 1 FROM org.DT_D dtd JOIN #ListDepartmentTypeID l ON dtd.[DepartmentTypeID] = l.[DepartmentTypeID]
                                                                         AND dtd.[DepartmentID] = DEPT.[DepartmentID])
	SET @Err = @@Error
    DROP TABLE #ListDepartmentTypeID

	RETURN @Err
END
