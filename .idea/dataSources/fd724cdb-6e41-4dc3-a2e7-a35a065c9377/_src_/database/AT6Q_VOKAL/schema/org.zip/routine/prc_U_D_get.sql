
CREATE PROCEDURE [org].[prc_U_D_get]
(
	@UserID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[U_DID],
	[DepartmentID],
	[UserID],
	[Selected],
	[Created]
	FROM [org].[U_D]
	WHERE
	[UserID] = @UserID

	Set @Err = @@Error

	RETURN @Err
END

