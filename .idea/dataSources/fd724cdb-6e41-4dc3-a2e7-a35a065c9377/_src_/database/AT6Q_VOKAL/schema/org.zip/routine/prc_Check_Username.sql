CREATE PROC org.prc_Check_Username
(
  @UserCount int = null output,
  @Ownerid INT,
  @userid INT,
  @username NVARCHAR(128)
)
AS
  SELECT @UserCount = COUNT(Userid) 
  FROM org.[USER]
  WHERE ownerid = @ownerid
  AND username = @username
  AND userid <> @userid  