

CREATE PROCEDURE [org].[prc_Owner_del]
(
	@OwnerID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Owner',2,
		( SELECT * FROM [org].[Owner] 
			WHERE
			[OwnerID] = @OwnerID
			 FOR XML AUTO) as data,
			getdate() 
	END 

    DELETE FROM dbo.AccessGroup WHERE OwnerID = @OwnerID

	DELETE FROM [org].[Owner]
	WHERE [OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END

