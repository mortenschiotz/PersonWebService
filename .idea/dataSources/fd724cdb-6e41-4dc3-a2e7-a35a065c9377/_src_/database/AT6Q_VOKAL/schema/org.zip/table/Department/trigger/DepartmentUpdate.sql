CREATE trigger [org].[DepartmentUpdate]
ON [org].[Department]
AFTER UPDATE
as 

IF  update([name]) AND(SELECT trigger_nestlevel(object_ID('[org].[DepartmentUpdate]'))) < 2
BEGIN
   Update org.H_D  set  pathname = dbo.getpathname(HDID)
   Where hdid IN ( select h2.hdid
   from H_D h join inserted i on h.departmentid = i.departmentid 
   Join H_D h2 on h2.path like '%\' + cast(h.hdid as nvarchar(16)) + '\%'
   )
END
