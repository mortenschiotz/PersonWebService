
CREATE PROCEDURE [org].[prc_UG_U_ins]
(
	@UserGroupID int,
	@UserID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [org].[UG_U]
	(
		[UserGroupID],
		[UserID]
	)
	VALUES
	(
		@UserGroupID,
		@UserID
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UG_U',0,
		( SELECT * FROM [org].[UG_U] 
			WHERE
			[UserGroupID] = @UserGroupID AND
			[UserID] = @UserID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

