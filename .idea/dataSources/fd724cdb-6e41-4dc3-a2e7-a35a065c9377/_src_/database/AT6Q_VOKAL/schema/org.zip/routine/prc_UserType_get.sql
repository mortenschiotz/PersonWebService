CREATE PROCEDURE [org].[prc_UserType_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[UserTypeID],
	[OwnerID],
	[ExtID],
	[No],
	[Created],
	[ArchetypeID],
	[ParentID]
	FROM [org].[UserType]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END
