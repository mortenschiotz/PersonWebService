

CREATE PROCEDURE [org].[prc_UserType_del]
(
	@UserTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'UserType',2,
		( SELECT * FROM [org].[UserType] 
			WHERE
			[UserTypeID] = @UserTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [org].[UserType]
	WHERE
	[UserTypeID] = @UserTypeID

	Set @Err = @@Error

	RETURN @Err
END

