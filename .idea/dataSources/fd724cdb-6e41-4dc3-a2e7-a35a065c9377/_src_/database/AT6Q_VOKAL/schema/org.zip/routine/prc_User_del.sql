CREATE PROCEDURE [org].[prc_User_del]  
(  
 @UserID int,  
 @cUserid int,  
 @Log smallint = 1  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  
  
 IF @Log = 1   
 BEGIN   
  INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created)   
  SELECT @cUserid,'User',2,  
  ( SELECT * FROM [org].[User]   
   WHERE  
   [UserID] = @UserID  
    FOR XML AUTO) as data,  
   getdate()   
 END   
  
    UPDATE AT.[Batch] set Userid = NULL where UserID = @Userid  
      
      
    Delete org.ug_u where usergroupid in (Select usergroupid from org.usergroup where userid = @Userid)  
    Delete org.usergroup where userid = @Userid  
    Delete org.U_D where UserID = @Userid
	Delete app.LoginService_User where UserID = @UserId
    Delete note.NoteSubscription WHERE UserID = @UserId
	
 DELETE FROM [org].[User]  
 WHERE  
 [UserID] = @UserID  
  
 Set @Err = @@Error  
  
 RETURN @Err  
END  
