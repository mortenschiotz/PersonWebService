CREATE PROCEDURE [dbo].[prc_AnswersGetByResultIds]
 @ResultIds NVARCHAR(MAX), 
 @SurveyId INT
AS
BEGIN
 DECLARE @ReportServer NVARCHAR(64),@ReportDB NVARCHAR(64)
 SELECT @ReportServer=ReportServer,@ReportDB=ReportDB FROM at.Survey
 WHERE SurveyID=@SurveyId
 DECLARE @sqlCommand NVARCHAR(max),@sqlParameters NVARCHAR(Max)
 SET @sqlCommand='SELECT a.AnswerID, a.ItemID, a.ResultID, a.QuestionID, a.AlternativeID, a.Value, a.DateValue, a.Free, a.No'+ 
  ' FROM ['+ @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Answer a'+
     ' WHERE a.ResultID IN ('+@ResultIds+')
       OPTION (TABLE HINT(a, INDEX (IX_ResultID)))'     
 SET @sqlParameters = N'@p_SurveyID int'
 EXECUTE sp_executesql @sqlCommand, @sqlParameters, @p_SurveyID = @SurveyId
END
