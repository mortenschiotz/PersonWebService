
CREATE PROCEDURE [dbo].[prc_LT_AccessGroup_upd]
(
	@LanguageID int,
	@AccessGroupID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [dbo].[LT_AccessGroup]
	SET
		[LanguageID] = @LanguageID,
		[AccessGroupID] = @AccessGroupID,
		[Name] = @Name,
		[Description] = @Description
	WHERE
		[LanguageID] = @LanguageID AND
		[AccessGroupID] = @AccessGroupID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_AccessGroup',1,
		( SELECT * FROM [dbo].[LT_AccessGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AccessGroupID] = @AccessGroupID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

