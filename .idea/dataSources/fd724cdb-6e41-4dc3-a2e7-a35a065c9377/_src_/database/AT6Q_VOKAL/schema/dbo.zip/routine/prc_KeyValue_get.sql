
CREATE PROCEDURE [dbo].[prc_KeyValue_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[Id],
	[Type],
	[Key],
	[Value]
	FROM [dbo].[KeyValue]

	Set @Err = @@Error

	RETURN @Err
END

