-- [tool_Activity_copy] 6,26,127
CREATE PROC [dbo].[tool_Activity_copy] 
(
	@FromActivityID	int,
	@ToActivityID	int,
	@PageID			int
)
AS
BEGIN
-- DELETE Mapping
--DELETE imp.CON_QMAPPING WHERE ActivityID = @ToActivityID
--DELETE imp.CON_SCALEMAPPING WHERE ActivityID = @ToActivityID
--DELETE imp.CON_ALTMAPPING WHERE ActivityID = @ToActivityID
Set XACT_ABORT ON
-- Scale
DECLARE @MinS	int,
		@MaxS	int,
		@Type	smallint,
		@MinV	float,
		@MaxV	float,
		@Tag	nvarchar(64),
		@ID		int,
		@TmpID	int,
		@NewID	int

SET @TmpID = 0

Create table #SM ( ActivityID int , ToId int, FromID Int)
Create table #AM ( ActivityID int , ToId int, FromID Int)
Create table #QM ( ActivityID int , ToId int, FromID Int)

DECLARE curAG CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT DISTINCT S.ScaleID, S.MinSelect, S.MaxSelect, S.Type, S.MinValue, S.MaxValue, S.Tag
FROM AT4Q_PILOT.dbo.Scale S
INNER JOIN AT4Q_PILOT.dbo.Question Q ON Q.ScaleID = S.ScaleID
INNER JOIN imp.CON_QFILTER I ON Q.QuestionID = I.QuestionID
WHERE I.ActivityID = 26 and Q.Questionid > 5991 and s.ScaleID > 1241

OPEN curAG
FETCH NEXT FROM curAG INTO @ID, @MinS, @MaxS, @Type, @MinV, @MaxV, @Tag

WHILE (@@FETCH_STATUS = 0)
BEGIN
	IF @TmpID <> @ID
	BEGIN
		INSERT at.Scale(ActivityID, MinSelect, MaxSelect, Type, MinValue, MaxValue, Tag)
		VALUES(@ToActivityID, @MinS, @MaxS, @Type, @MinV, @MaxV, @ID)
		SET @NewID = scope_identity()
		INSERT #SM(ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)
	END
	FETCH NEXT FROM curAG INTO @ID, @MinS, @MaxS, @Type, @MinV, @MaxV, @Tag
END
CLOSE curAG
DEALLOCATE curAG
INSERT at.LT_Scale(LanguageID, ScaleID, Name, Title, Description)
SELECT LT.LanguageID, CS.ToID, Name, Title, ToolTip
FROM at.Scale S
INNER JOIN #SM CS ON S.ScaleID = CS.ToID
INNER JOIN AT4Q_PILOT.dbo.LT_Scale LT ON CS.FromID = LT.ScaleID
WHERE S.ActivityID = 26 and s.Scaleid > 1332


-- Alternative
DECLARE curAlt CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT S.ScaleID, AlternativeID
FROM AT4Q_PILOT.dbo.Alternative A
INNER JOIN #SM CS ON A.ScaleID = CS.FromID and CS.FROMID > 1309
INNER JOIN at.Scale S ON CS.ToID = S.ScaleID
WHERE S.ActivityID = 26

OPEN curAlt
FETCH NEXT FROM curAlt INTO @TmpID, @ID

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT at.Alternative(ScaleID, Type, No, Value, InvertedValue, Calc, SC, MinValue, MaxValue, Format, Size, CssClass, DefaultValue, Tag,ExtID)
	SELECT @TmpID, Type, No, Value, InvertedValue, Calc, SC, MinValue, MaxValue, Format, Size, CssClass, DefaultValue, Tag, @ID
	FROM AT4Q_PILOT.dbo.Alternative 	
	WHERE AlternativeID = @ID

	SET @NewID = scope_identity()
	
	INSERT #AM (ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)

	INSERT at.LT_Alternative(LanguageID, AlternativeID, Name, Label, Description)
	SELECT LanguageID, @NewID, Name, Label, ToolTip
	FROM AT4Q_PILOT.dbo.LT_Alternative
	WHERE AlternativeID = @ID  

	FETCH NEXT FROM curAlt INTO @TmpID, @ID
END
CLOSE curAlt
DEALLOCATE curAlt

-- Questions
DECLARE curQuest CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT DISTINCT QuestionID
FROM AT4Q_FELLES.dbo.Question Q
JOIN AT4Q_FELLES.dbo.Page P on Q.Pageid = p.Pageid
and  P.ActivityID = @FromActivityID   
Order by QuestionID

OPEN curQuest
FETCH NEXT FROM curQuest INTO @ID

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT at.Question(PageID, No , Type  , Inverted, Mandatory, ScaleID, Status  , CssClass, ExtID, Tag)
	SELECT            @PageID, @ID, Q.Type, Inverted, Mandatory, CS.ToID, Q.Status, CssClass, @ID, Tag
	FROM AT4Q_PILOT.dbo.Question Q		
	LEFT OUTER JOIN #SM CS ON Q.ScaleID = CS.FromID AND CS.ActivityID = @ToActivityID
	WHERE Q.QuestionID = @ID 

	SET @NewID = scope_identity()
	INSERT #QM(ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)
	
	FETCH NEXT FROM curQuest INTO @ID
END
CLOSE curQuest
DEALLOCATE curQuest

INSERT at.LT_Question(LanguageID, QuestionID, Name, Title, ReportText, Description)
SELECT DISTINCT LanguageID, CQ.ToID, CAST(Text as nvarchar(2000)), HeadLine, ReportText, ''
FROM AT4Q_FELLES.dbo.LT_Question LTQ 
INNER JOIN #QM CQ ON LTQ.QuestionID = CQ.FromID AND CQ.ActivityID = @ToActivityID

UPDATE at.Question 
SET Type=1 
FROM at.Question Q
WHERE Q.PageID = @PageID AND Q.ScaleID IS NULL

END
