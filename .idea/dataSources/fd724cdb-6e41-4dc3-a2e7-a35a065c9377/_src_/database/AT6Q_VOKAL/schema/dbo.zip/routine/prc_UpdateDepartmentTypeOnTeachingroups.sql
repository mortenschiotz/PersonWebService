CREATE PROCEDURE [dbo].[prc_UpdateDepartmentTypeOnTeachingroups]
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @PeriodID int = 9
 
    SELECT ug.[UserGroupID], ug.[Name], dtug.[DepartmentTypeID], lt.[Name] AS [DepartmentType], 'Before Fix' AS [Description]
    FROM [org].[UserGroup] ug LEFT JOIN [org].[DT_UG] dtug ON dtug.[UserGroupID] = ug.[UserGroupID]
    LEFT JOIN [org].[LT_DepartmentType] lt ON lt.[DepartmentTypeID] = dtug.[DepartmentTypeID] AND lt.[LanguageID] = 1
    --     INNER JOIN org.Department d ON ug.DepartmentId = d.DepartmentId AND d.CustomerID = 499
    WHERE ug.[PeriodID] = @PeriodID AND ug.[UsergroupTypeID] = 1
    ORDER BY ug.[UserGroupID]
 
 
    RAISERROR ('Remove department types of teaching groups where no learner''s levels match', 0, 1) WITH NOWAIT
    DELETE dtug
    --DECLARE @PeriodID int = 9   select *
    FROM [org].[DT_UG] dtug JOIN [org].[UserGroup] ug ON dtug.[UserGroupID] = ug.[UserGroupID] AND ug.[PeriodID] = @PeriodID AND ug.[UsergroupTypeID] = 1
    --     INNER JOIN org.Department d ON ug.DepartmentId = d.DepartmentId AND d.CustomerID = 499
    WHERE NOT EXISTS (SELECT 1 FROM [ObjectMapping] om
                               JOIN [org].[UserType] ut ON om.[FromTableTypeID] = 27 AND om.[ToTableTypeID] = 26 AND om.[FromID] = dtug.[DepartmentTypeID]
                                    AND ut.[UserTypeID] = om.[ToID]
                               JOIN [org].[UT_U] utu ON ut.[UserTypeID] = utu.[UserTypeID]
                               JOIN [org].[UG_U] ugu ON utu.[UserID] = ugu.[UserID] AND ugu.[UserGroupID] = ug.[UserGroupID])
    RAISERROR ('%d rows deleted', 0, 1, @@rowcount) WITH NOWAIT
 
    RAISERROR ('Add department types for teaching groups based on learner''s levels', 0, 1) WITH NOWAIT
    INSERT INTO org.DT_UG ([DepartmentTypeID], [UserGroupID])
    --DECLARE @PeriodID int = 9
    SELECT DISTINCT om.[ToID], ug.[UserGroupID]
    FROM [org].[UserGroup] ug JOIN [org].[UG_U] ugu ON ug.[UserGroupID] = ugu.[UserGroupID] AND ug.[PeriodID] = @PeriodID AND ug.[UsergroupTypeID] = 1
    --     INNER JOIN org.Department d ON ug.DepartmentId = d.DepartmentId AND d.CustomerID = 499
    JOIN [org].[UT_U] utu ON ugu.[UserID] = utu.[UserID]
    JOIN [ObjectMapping] om ON om.[FromTableTypeID] = 26 AND om.[ToTableTypeID] = 27 AND om.[FromID] = utu.[UserTypeID]
    WHERE NOT EXISTS (SELECT 1 FROM [org].[DT_UG] dtug WHERE dtug.[DepartmentTypeID] = om.[ToID] AND dtug.[UserGroupID] = ug.[UserGroupID])
    RAISERROR ('%d rows added', 0, 1, @@rowcount) WITH NOWAIT
 
    SELECT ug.[UserGroupID], ug.[Name], dtug.[DepartmentTypeID], lt.[Name] AS [DepartmentType], 'After Fix' AS [Description], hd.[PathName]
    FROM [org].[UserGroup] ug JOIN [org].[H_D] hd ON ug.[DepartmentID] = hd.[DepartmentID]
    --     INNER JOIN org.Department d ON ug.DepartmentId = d.DepartmentId AND d.CustomerID = 499
    LEFT JOIN [org].[DT_UG] dtug ON dtug.[UserGroupID] = ug.[UserGroupID]
    LEFT JOIN [org].[LT_DepartmentType] lt ON lt.[DepartmentTypeID] = dtug.[DepartmentTypeID] AND lt.[LanguageID] = 1
    WHERE ug.[PeriodID] = @PeriodID AND ug.[UsergroupTypeID] = 1
    ORDER BY ug.[UserGroupID]
END
