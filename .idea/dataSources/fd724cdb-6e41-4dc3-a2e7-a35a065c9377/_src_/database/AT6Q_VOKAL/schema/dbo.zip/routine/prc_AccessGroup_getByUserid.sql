-- exec [dbo].[prc_AccessGroup_getByUserid]  15, 22, 6, null, 5 
-- exec [dbo].[prc_AccessGroup_getByUserid]  15, 22, 6, null, null
-- exec [dbo].[prc_AccessGroup_getByUserid]  9, 107824, 23824, 0, 61
CREATE PROCEDURE [dbo].[prc_AccessGroup_getByUserid]
(
@OwnerId INT,
@UserId INT,
@Departmentid INT,
@RoleId INT ,
@CustomerID INT = NULL
)
AS
BEGIN
    SET NOCOUNT ON
    
    DECLARE @Path NVARCHAR(1800), @UserDepID int, @NestedLevel int = 0
    DECLARE @HDIDS TABLE (HDID INT )
    DECLARE @UserTypeTable TABLE (UserTypeID int)
    DECLARE @CheckedAGMember TABLE (AccessGroupMemberID int)
    
    SELECT @UserDepID = Departmentid from org.[user] where userid = @Userid

    DECLARE Table_Cursor CURSOR READ_ONLY
    FOR SELECT RIGHT([PATH],LEN([PATH])-1) FROM [org].H_D WHERE Departmentid = @Departmentid

    CREATE TABLE #AccessGroupByUser (AccessGroupID int, OwnerID int, [No] smallint, Created smalldatetime)
    CREATE TABLE #RecursiveAGMember (AccessGroupMemberID int, AccessGroupID int, UserID int, UserTypeID int, DepartmentID int, HDID int, UserGroupID int, RoleID int, DepartmentTypeID int, DepartmentGroupID int, CustomerID int, ExtGroupID int)

    OPEN Table_Cursor
	   FETCH NEXT FROM Table_Cursor INTO @Path
	   WHILE(@@FETCH_STATUS=0)
	   BEGIN
		  PRINT @Path
		  INSERT INTO @HDIDS (HDID )
		  SELECT VALUE FROM dbo.funcListToTableInt(@Path,'\')
		  FETCH NEXT FROM Table_Cursor INTO @Path
	   END
    CLOSE Table_Cursor
    DEALLOCATE Table_Cursor

    SET @Path = ''
    IF @UserDepID = @Departmentid
    BEGIN
	   INSERT INTO @UserTypeTable(UserTypeID) SELECT UserTypeID FROM org.UT_U WHERE UserId = @UserId 
    END
    ELSE
    BEGIN
	   INSERT INTO @UserTypeTable(UserTypeID)
	   SELECT udut.UserTypeID FROM org.U_D ud JOIN org.U_D_UT udut ON ud.userid = @userid
									   AND ud.departmentid = @Departmentid
									   AND ud.u_did = udut.u_did
    END

    -- Get all leaf level Access group members
    INSERT INTO #AccessGroupByUser
    SELECT AG.AccessGroupID, AG.OwnerID, AG.[No], AG.Created
    FROM	 dbo.AccessGroup AG
    JOIN   dbo.AccessGroupMember AGM ON AG.AccessGroupID = AGM.AccessGroupID AND AG.OwnerId = @OwnerID
    WHERE
    ( AGM.UserId is null OR AGM.userid = @Userid ) AND
    ( AGM.RoleId = @RoleID OR AGM.RoleId IS NULL) AND
    ( AGM.DepartmentTypeID IN ( SELECT DepartmentTypeID FROM org.DT_D WHERE DepartmentId = @Departmentid) OR AGM.DepartmentTypeID IS NULL) AND
    ( AGM.UserGroupID IN ( SELECT UserGroupID FROM org.UG_U WHERE UserId = @UserId) OR AGM.UserGroupID IS NULL) AND
    ( AGM.UserTypeID IN ( SELECT UserTypeID FROM @UserTypeTable) OR AGM.UserTypeID IS NULL) AND
    ( AGM.DepartmentGroupID IN ( SELECT DepartmentGroupID FROM org.DG_D WHERE DepartmentId = @Departmentid) OR AGM.DepartmentGroupID IS NULL) AND
    ( AGM.HDID IN (SELECT HDID FROM @HDIDS) OR AGM.HDID IS NULL) AND
    ( AGM.Departmentid = @Departmentid OR AGM.Departmentid IS NULL ) AND
    ( AGM.CustomerID = @CustomerID OR AGM.CustomerID IS NULL) AND
    AGM.ExtGroupID IS NULL

    INSERT INTO #RecursiveAGMember (AccessGroupMemberID, AccessGroupID, UserID, UserTypeID, DepartmentID, HDID, UserGroupID, RoleID, DepartmentTypeID, DepartmentGroupID, CustomerID, ExtGroupID)
    SELECT  AccessGroupMemberID, AccessGroupID, UserID, UserTypeID, DepartmentID, HDID, UserGroupID, RoleID, DepartmentTypeID, DepartmentGroupID, CustomerID, ExtGroupID
    FROM	  dbo.AccessGroupMember AGM
    WHERE	  AGM.ExtGroupID > 0
    
    -- Get all nested level Access group members
    WHILE EXISTS (SELECT 1 FROM #RecursiveAGMember AGM WHERE EXISTS (SELECT 1 FROM #AccessGroupByUser AG1 WHERE AG1.AccessGroupID = AGM.ExtGroupID)
										   AND NOT EXISTS (SELECT 1 FROM #AccessGroupByUser AG2 WHERE AG2.AccessGroupID = AGM.AccessGroupID)
			  ) AND @NestedLevel < 32
    BEGIN
	   SET @NestedLevel += 1
	   
	   INSERT INTO @CheckedAGMember(AccessGroupMemberID)
	   SELECT AccessGroupMemberID FROM #RecursiveAGMember AGM
	   WHERE  EXISTS  (SELECT 1 FROM #AccessGroupByUser AG1 WHERE AG1.AccessGroupID = AGM.ExtGroupID)
	   AND NOT EXISTS (SELECT 1 FROM #AccessGroupByUser AG2 WHERE AG2.AccessGroupID = AGM.AccessGroupID)
	   
	   INSERT INTO #AccessGroupByUser
	   SELECT AG.AccessGroupID, AG.OwnerID, AG.[No], AG.Created
	   FROM   dbo.AccessGroup AG
	   JOIN   #RecursiveAGMember AGM ON AG.AccessGroupID = AGM.AccessGroupID AND AG.OwnerId = @OwnerID
	   WHERE
	   ( AGM.UserId is null OR AGM.userid = @Userid ) AND
	   ( AGM.RoleId = @RoleID OR AGM.RoleId IS NULL) AND
	   ( AGM.DepartmentTypeID IN ( SELECT DepartmentTypeID FROM org.DT_D WHERE DepartmentId = @Departmentid) OR AGM.DepartmentTypeID IS NULL) AND
	   ( AGM.UserGroupID IN ( SELECT UserGroupID FROM org.UG_U WHERE UserId = @UserId) OR AGM.UserGroupID IS NULL) AND
	   ( AGM.UserTypeID IN ( SELECT UserTypeID FROM @UserTypeTable) OR AGM.UserTypeID IS NULL) AND
	   ( AGM.DepartmentGroupID IN ( SELECT DepartmentGroupID FROM org.DG_D WHERE DepartmentId = @Departmentid) OR AGM.DepartmentGroupID IS NULL) AND
	   ( AGM.HDID IN (SELECT HDID FROM @HDIDS) OR AGM.HDID IS NULL) AND
	   ( AGM.Departmentid = @Departmentid OR AGM.Departmentid IS NULL ) AND
	   ( AGM.CustomerID = @CustomerID OR AGM.CustomerID IS NULL) AND
	   EXISTS		   (SELECT 1 FROM #AccessGroupByUser AG1 WHERE AG1.AccessGroupID = AGM.ExtGroupID)
	   AND NOT EXISTS (SELECT 1 FROM #AccessGroupByUser AG2 WHERE AG2.AccessGroupID = AGM.AccessGroupID)
	   
	   DELETE AGM FROM #RecursiveAGMember AGM
	   WHERE AccessGroupMemberID IN (SELECT AccessGroupMemberID FROM @CheckedAGMember)
	   
	   DELETE FROM @CheckedAGMember
    END

    PRINT 'Nested level: ' + convert(nvarchar(5),@NestedLevel)
    SELECT DISTINCT * FROM #AccessGroupByUser
    DROP TABLE #AccessGroupByUser
    DROP TABLE #RecursiveAGMember
END
