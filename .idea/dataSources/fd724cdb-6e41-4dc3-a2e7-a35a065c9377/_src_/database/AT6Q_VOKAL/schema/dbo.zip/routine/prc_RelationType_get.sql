
CREATE PROCEDURE [dbo].[prc_RelationType_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[RelationTypeID],
	ISNULL([OwnerID], 0) AS 'OwnerID',
	ISNULL([No], 0) AS 'No',
	[Created]
	FROM [dbo].[RelationType]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

