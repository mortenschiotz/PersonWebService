CREATE PROCEDURE [dbo].[prc_VOKAL_StartNY_Step5]
(
	@SiteId INT
 )
AS
BEGIN
--- Set all INTegration-schools to completed NSY process

DECLARE @OwnerId AS INT = NULL;
DECLARE @DT_Skole AS INT = NULL; 
DECLARE @PROP_MaintenanceMode INT = NULL;
DECLARE @EntityStatusID_Active INT = 0, @EntityStatusID_Inactive INT = 0

SELECT @EntityStatusID_Active   = EntityStatusID FROM EntityStatus WHERE CodeName = 'Active'
SELECT @EntityStatusID_Inactive = EntityStatusID FROM EntityStatus WHERE CodeName = 'Inactive'

SELECT @DT_Skole = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.Common.SchoolDepartmentTypeId'
AND sp.SiteID =  @SiteId;

IF(@DT_Skole IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.Common.SchoolDepartmentTypeId NOT defined', 10, 1);
END


SELECT @PROP_MaintenanceMode = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.NewSchoolYear.MaintenanceModeProp'
AND sp.SiteID =  @SiteId
;
IF(@PROP_MaintenanceMode IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.NewSchoolYear.MaintenanceModeProp NOT defined', 10, 1);
END


SELECT @OwnerId = s.OwnerID
FROM app.Site AS s
WHERE s.SiteID = @SiteId;

IF(@OwnerId IS NULL)
BEGIN	
	DECLARE @errorMsg AS VARCHAR(MAX) = 'Owner-id NOT defined for site ' + CAST(@siteId AS VARCHAR(3));
	RAISERROR(@errorMsg, 10, 1)
END

IF(@OwnerId IS NOT NULL AND @DT_Skole IS NOT NULL)
BEGIN
	
	DECLARE @DepartmentID int
	DECLARE cur_department CURSOR FOR
	-- List alle INTegrasjons-skolene tilhørENDe skoleeieren
	SELECT d.departmentid FROM org.department d
	JOIN org.dt_d dtd ON dtd.departmentid = d.departmentid AND dtd.departmenttypeid = @DT_Skole
    JOIN [org].[H_D] hd ON hd.[DepartmentID] = d.[DepartmentID] AND hd.[Deleted] = 0
	WHERE d.ownerid = @OwnerID
	  AND d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserINTegration = 1 )
      AND d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive)
      AND d.Deleted IS NULL -- only not deleted schools

	OPEN cur_department
	FETCH NEXT FROM cur_department INTO @DepartmentID
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE pv
		SET propoptionid = 7 /* Fullført */, updated = GETDATE()
		FROM prop.propvalue pv
		WHERE pv.propertyid = @PROP_MaintenanceMode AND propoptionid = 6 /* Underveis */
		  AND pv.itemid = @DepartmentID
		FETCH NEXT FROM cur_department INTO @DepartmentID
	END
	CLOSE cur_department
	DEALLOCATE cur_department
END
END
