

CREATE PROCEDURE [dbo].[prc_Language_del]
(
	@LanguageID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Language',2,
		( SELECT * FROM [dbo].[Language] 
			WHERE
			[LanguageID] = @LanguageID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[Language]
	WHERE
		[LanguageID] = @LanguageID

	Set @Err = @@Error

	RETURN @Err
END

