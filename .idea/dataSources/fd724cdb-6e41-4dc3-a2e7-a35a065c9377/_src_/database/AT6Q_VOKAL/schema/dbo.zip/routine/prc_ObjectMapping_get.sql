

CREATE PROCEDURE [dbo].[prc_ObjectMapping_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[OMID],
	[OwnerID],
	[FromTableTypeID],
	[FromID],
	[ToTableTypeID],
	[ToID],
	[RelationTypeID]
	FROM [dbo].[ObjectMapping]
	WHERE
	[OwnerID] = @OwnerID

	Set @Err = @@Error

	RETURN @Err
END


