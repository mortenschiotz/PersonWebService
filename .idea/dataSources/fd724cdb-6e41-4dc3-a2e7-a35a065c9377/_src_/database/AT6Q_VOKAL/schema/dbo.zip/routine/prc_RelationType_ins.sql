
CREATE PROCEDURE [dbo].[prc_RelationType_ins]
(
	@RelationTypeID int = null output,
	@OwnerID INT=NULL,
	@No SMALLINT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[RelationType]
	(
		[OwnerID],
		[No]
	)
	VALUES
	(
		@OwnerID,
		@No
	)

	Set @Err = @@Error
	Set @RelationTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'RelationType',0,
		( SELECT * FROM [dbo].[RelationType] 
			WHERE
			[RelationTypeID] = @RelationTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

