
CREATE PROCEDURE [dbo].[prc_Language_ins]
(
	@LanguageID int,
	@LanguageCode varchar(5),
	@Dir varchar(3),
	@Name nvarchar(64),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[Language]
	(
		[LanguageID],
		[LanguageCode],
		[Dir],
		[Name]
	)
	VALUES
	(
		@LanguageID,
		@LanguageCode,
		@Dir,
		@Name
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Language',0,
		( SELECT * FROM [dbo].[Language] 
			WHERE
			[LanguageID] = @LanguageID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

