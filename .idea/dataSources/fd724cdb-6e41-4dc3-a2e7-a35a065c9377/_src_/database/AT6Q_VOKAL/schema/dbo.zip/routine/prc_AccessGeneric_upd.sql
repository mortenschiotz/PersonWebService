
CREATE PROCEDURE [dbo].[prc_AccessGeneric_upd]
(
	@AccessID int,
	@TableTypeID smallint,
	@Elementid int,
	@Type smallint,
	@AccessGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [dbo].[AccessGeneric]
	SET
		[TableTypeID] = @TableTypeID,
		[Elementid] = @Elementid,
		[Type] = @Type,
		[AccessGroupID] = @AccessGroupID
	WHERE
		[AccessID] = @AccessID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGeneric',1,
		( SELECT * FROM [dbo].[AccessGeneric] 
			WHERE
			[AccessID] = @AccessID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

