CREATE PROCEDURE [dbo].[prc_VOKAL_StartNY_Step3]
(
	@SiteId             INT,
    @LanguageID         INT = 0,
    @FileName           NVARCHAR(MAX) = '',
    @FileTitle          NVARCHAR(MAX) = '',
    @FileDescription    NVARCHAR(MAX) = ''
)
AS
BEGIN
/*
NOTE:The elevkart-user must have e-mail to you (rsa@conexus.no) because the email regarding zip-generated for the school will be sent to this address.

Make one procedure to trigger the right job for a school. Remember that I must be receiver, not the school admins.
(Has created stored procedrue at [CreateJobForPDFCreation], which is used by the cursor below:) 

CURSOR running for a customer which parse all schools, create temporary users AND register one job per school for PDF-archive for graduates.
*/
DECLARE @hdid_skole AS INT; 
DECLARE @departmentid_skole AS INT; 
DECLARE @database AS VARCHAR(100);
DECLARE @UserString  NVARCHAR(MAX);
DECLARE @OwnerId AS INT = NULL;
DECLARE @DT_Skole AS INT = NULL; 
DECLARE @UT_AVG INT = NULL;
DECLARE @UsernameForPDFCreation AS VARCHAR(8) = 'vokalINT'
DECLARE @UserIdForPDFCreation AS VARCHAR(MAX) = NULL;

SELECT @database = DB_NAME();

SELECT @DT_Skole = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.Common.SchoolDepartmentTypeId'
AND sp.SiteID =  @SiteId
;

IF(@DT_Skole IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.Common.SchoolDepartmentTypeId not defined', 10, 1);
END


SELECT @UT_AVG  = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.Admin.GraduatesUserType'
AND sp.SiteID = @SiteId
;

IF(@UT_AVG IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.Admin.GraduatesUserType not defined', 10, 1);
END


SELECT @OwnerId = s.OwnerID
FROM app.Site AS s
WHERE s.SiteID = @SiteId

IF(@OwnerId IS NULL)
BEGIN	
	DECLARE @errorMsg AS VARCHAR(MAX) = 'Owner-id not defined for site ' + cast(@siteId AS VARCHAR(3));
	RAISERROR(@errorMsg, 10, 1)
END


SELECT @UserIdForPDFCreation = u.UserID
FROM org.[User] AS u
WHERE u.UserName = @UsernameForPDFCreation
;

IF(@UserIdForPDFCreation IS NULL)
BEGIN	
	RAISERROR('User for creating PDF jobs IS NOT defined', 10, 1)
END

IF(@DT_Skole IS NOT NULL
	AND @UT_AVG IS NOT NULL
	AND @OwnerId IS NOT NULL
	AND @UserIdForPDFCreation IS NOT NULL
)
BEGIN
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

	DECLARE curSchools CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
	SELECT DISTINCT hd.hdid, d.departmentid
	FROM org.department d
	JOIN org.dt_d dtd ON dtd.departmentid = d.departmentid AND dtd.departmenttypeid = @DT_Skole
	JOIN org.h_d hd ON hd.departmentid = d.departmentid AND hd.[Deleted] = 0
	WHERE d.ownerid = @OwnerID AND d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserINTegration = 1)
      AND d.EntityStatusID = @ActiveEntityStatusID AND d.Deleted IS NULL -- only active schools

	OPEN curSchools
	FETCH NEXT FROM curSchools INTO @hdid_skole, @departmentid_skole

	WHILE (@@FETCH_STATUS = 0)
	BEGIN

		SET @UserString = NULL

		SELECT @UserString = COALESCE(@UserString + ', ', '') + CAST(u.userid AS VARCHAR)  FROM org.[user] u 
		JOIN org.[UT_U] utu ON u.userid = utu.UserID AND utu.UserTypeID = @UT_AVG AND departmentid = @departmentid_skole AND u.EntityStatusID = @ActiveEntityStatusID
	
		IF @UserString IS NULL
		BEGIN
		 SET @UserString = ''
		END
		PrINT @departmentid_skole
		PrINT @UserString
		
		EXEC [dbo].[CreateJobForPDFCreation]  
			@UserIdForPDFCreation , 
			@hdid_skole, 
			@UsernameForPDFCreation, 
			'', 
			@@SERVERNAME, 
			@database,
			@UserString,
            @LanguageID,
            @SiteID,
            @FileName,
            @FileTitle,
            @FileDescription

		FETCH NEXT FROM curSchools INTO @hdid_skole, @departmentid_skole
	END	

	CLOSE curSchools
	DEALLOCATE curSchools
	END
END
