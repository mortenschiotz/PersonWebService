


CREATE PROCEDURE [dbo].[prc_TableType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[TableTypeID],
	[Name],
	[Schema],
	[Type]
	FROM [dbo].[TableType]

	Set @Err = @@Error

	RETURN @Err
END


