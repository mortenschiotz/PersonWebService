CREATE FUNCTION [dbo].[fn_RandomPassword]()
RETURNS varchar(6)
AS
BEGIN
	DECLARE @RandomPassword varchar(6)

	SELECT @RandomPassword = RandomPassword
	FROM view_RandomPassword6

	RETURN @RandomPassword

END