CREATE PROC [dbo].[tool_Result_copy] --193, 23, 568, 19
(
	@FromSurveyID	int,
	@ToSurveyID	int,
	@BatchID	int,
	@ActivityID	int
)
AS
BEGIN	

	INSERT Strutsen.AT5R_COMMON.dbo.Result(StartDate, EndDate, RoleID, UserID, SurveyID, BatchID, LanguageID, PageNo, DepartmentID, Anonymous, ShowBack, ResultKey, Status)
	SELECT StartDate, EndDate, CR.ToID, NULL, @ToSurveyID, @BatchID, r.LanguageID, PageNo, D2.DepartmentID, Anonymous, ShowBack,CAST(r.ResultID as varchar(20)), r.Status
	FROM Hauken.AT4R_PILOT_2008.dbo.Result R with (nolock)	
	INNER JOIN Hauken.AT4Q_PILOT.dbo.Department CD ON R.DepartmentID = CD.DepartmentID
	INNER JOIN org.Department D ON CD.OrgNo = D.OrgNo COLLATE Danish_Norwegian_CI_AS	
	INNER JOIN Hauken.AT4R_PILOT_2008.dbo.Answer A ON R.ResultID = A.ResultID AND A.QuestionID = 567 
	INNER JOIN imp.CON_UTDPROG PM ON A.AlternativeID = PM.AlternativeID
	INNER JOIN org.H_D HD ON D.DepartmentID = HD.DepartmentID
	INNER JOIN org.H_D HD2 on HD2.ParentID = HD.HDID
	INNER JOIN org.Department D2 ON HD2.DepartmentID = D2.DepartmentID AND PM.UTDANNINGSPROGRAM = D2.ExtID
	INNER JOIN imp.CON_ROLEMAPPING CR ON R.RoleID = CR.FromID AND CR.ActivityID = @ActivityID
	WHERE R.SurveyID = @FromSurveyID AND NOT R.EndDate IS NULL AND R.Status = 0


	INSERT Strutsen.AT5R_COMMON.dbo.Answer(ResultID, QuestionID, AlternativeID, Value, Free)
	SELECT R2.ResultID, CQ.ToID, CA.ToID, Value, Free 
	FROM Hauken.AT4R_PILOT_2008.dbo.Answer A with (nolock)
	INNER JOIN Hauken.AT4R_PILOT_2008.dbo.Result R ON NOT R.EndDate IS NULL AND A.ResultID = R.ResultID	
	INNER JOIN Strutsen.AT5R_COMMON.dbo.Result R2 ON R2.BatchID = @BatchID AND R.ResultID = CAST(R2.ResultKey as int)
	INNER JOIN imp.CON_QMAPPING CQ ON A.QuestionID = CQ.FromID AND CQ.ActivityID = @ActivityID
	INNER JOIN imp.CON_ALTMAPPING CA ON A.AlternativeID = CA.FromID AND CA.ActivityID = @ActivityID
	WHERE R.SurveyID = @FromSurveyID

END



