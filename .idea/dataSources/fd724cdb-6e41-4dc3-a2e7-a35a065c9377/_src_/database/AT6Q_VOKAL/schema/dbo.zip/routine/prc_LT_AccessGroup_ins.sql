
CREATE PROCEDURE [dbo].[prc_LT_AccessGroup_ins]
(
	@LanguageID int,
	@AccessGroupID int,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[LT_AccessGroup]
	(
		[LanguageID],
		[AccessGroupID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@AccessGroupID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_AccessGroup',0,
		( SELECT * FROM [dbo].[LT_AccessGroup] 
			WHERE
			[LanguageID] = @LanguageID AND
			[AccessGroupID] = @AccessGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

