
CREATE PROCEDURE [dbo].[prc_AccessGroup_get]
(
	@OwnerID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AccessGroupID],
	[OwnerID],
	[No],
	[Created]
	FROM [dbo].[AccessGroup]
	WHERE
	[OwnerID] = @OwnerID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

