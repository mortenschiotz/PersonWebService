

CREATE PROCEDURE [dbo].[prc_AccessGroup_getByExternalId]  
(
@OwnerId INT,
@UserId INT,
@Departmentid INT
)
AS

BEGIN

DECLARE @RoleId INT
DECLARE @CustomerID INT

--Select Role ID
SELECT @RoleId = RoleID
FROM org.[User]
WHERE org.[User].UserID = @UserId

--Select CustomerID
SELECT @CustomerID = CustomerID
FROM org.Department
WHERE DepartmentID = @Departmentid

CREATE TABLE #TempUserAccessGroup
(
 UserId INT,
 DepartmentId INT,
 AccessGroupID INT
)

CREATE TABLE #AccessGroupByUser (AccessGroupID int, OwnerID int, [No] smallint, Created smalldatetime)

INSERT INTO #AccessGroupByUser 
Exec prc_AccessGroup_getByUserid @OwnerId,@UserId,@Departmentid,@RoleId,@CustomerID

INSERT INTO #TempUserAccessGroup
( UserId ,
  DepartmentId ,
  AccessGroupID
)
(SELECT @UserId, @Departmentid, AccessGroupID
	FROM #AccessGroupByUser
)

SELECT * FROM #TempUserAccessGroup FOR XML RAW ('AG'); 

DROP TABLE #TempUserAccessGroup
DROP TABLE #AccessGroupByUser

END
