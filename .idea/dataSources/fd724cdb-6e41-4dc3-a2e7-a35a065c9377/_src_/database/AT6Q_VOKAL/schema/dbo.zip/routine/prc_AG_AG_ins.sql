
CREATE PROCEDURE [dbo].[prc_AG_AG_ins]
(
	@AG_AGID int = null output,
	@AccessGroupID int,
	@ToAccessGroupID int,
	@Type int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[AG_AG]
	(
		[AccessGroupID],
		[ToAccessGroupID],
		[Type]
	)
	VALUES
	(
		@AccessGroupID,
		@ToAccessGroupID,
		@Type
	)

	Set @Err = @@Error
	Set @AG_AGID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AG_AG',0,
		( SELECT * FROM [dbo].[AG_AG] 
			WHERE
			[AG_AGID] = @AG_AGID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

