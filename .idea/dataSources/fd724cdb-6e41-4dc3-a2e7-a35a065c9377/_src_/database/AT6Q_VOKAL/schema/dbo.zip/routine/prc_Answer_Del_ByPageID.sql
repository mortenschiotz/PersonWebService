/*
    Sarah - Oct 10, 2016 - Remove column Status on User, Department and Result tables
*/
CREATE PROCEDURE [dbo].[prc_Answer_Del_ByPageID]
	@SurveyID		int, 
	@ResultIDList	varchar(max),
	@PageIDList		varchar(max),
	@DeleteAll		bit =0,
	@ErrorMessage	nvarchar(max) OUTPUT,
	@DeleteResult   smallint = 0
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @ReportServer nvarchar(64), @ReportDB nvarchar(64), @sqlCommand nvarchar(max), @QuestionIDList varchar(max), @Error int, @DeactiveEntityStatusID INT = 0
    DECLARE @DeactiveReasonEntityStatusID INT = (SELECT EntityStatusReasonID FROM EntityStatusReason WHERE CodeName='Inactive_ManuallySetInactive')

    SELECT @ReportServer = ReportServer, @ReportDB = ReportDB FROM at.Survey WHERE SurveyID = @SurveyID
	SELECT @QuestionIDList = STUFF((SELECT ',' + CONVERT(VARCHAR(16),q.QuestionID) AS [text()]
							 FROM at.Question q
							 WHERE q.PageID IN (SELECT Value FROM dbo.funcListToTableInt(@PageIDList,','))
							   AND (@DeleteAll=1 OR (q.ExtId != 'metadata' AND @DeleteAll=0)) 
							 FOR XML PATH ('')),1,1,'')
	
	SET @sqlCommand = N'SELECT @p_DeactiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Deactive'''
	EXECUTE sp_executesql @sqlCommand, N'@p_DeactiveEntityStatusID INT OUTPUT', @p_DeactiveEntityStatusID = @DeactiveEntityStatusID OUTPUT

    SET @ErrorMessage = N''
    SET @sqlCommand = N'DELETE a FROM [' + @ReportServer + '].[' + @ReportDB + '].[dbo].Answer a
    WHERE a.ResultID IN (' + @ResultIDList + ')
      AND a.QuestionID IN (' + @QuestionIDList + ')'
    EXEC @Error = sp_executesql @sqlCommand
    --Case: Soft delete Result
    IF (@DeleteResult=1)
    BEGIN
        SET @sqlCommand = N'UPDATE [' + @ReportServer + '].[' + @ReportDB + '].[dbo].Result SET EntityStatusReasonID = '+CONVERT(NVARCHAR(14), @DeactiveReasonEntityStatusID)
        +', EntityStatusID = '+CONVERT(NVARCHAR(14), @DeactiveEntityStatusID)+'
        WHERE ResultID IN (' + @ResultIDList + ') AND NOT EXISTS (SELECT 1 FROM Answer  a WHERE a.ResultID =Result.ResultID)'
        EXEC @Error = sp_executesql @sqlCommand
    END
    --Case: Hard delete Result
    IF (@DeleteResult=2)
    BEGIN
        SET @sqlCommand = N'DELETE [' + @ReportServer + '].[' + @ReportDB + '].[dbo].Result
        WHERE ResultID IN (' + @ResultIDList + ') AND NOT EXISTS (SELECT 1 FROM Answer  a WHERE a.ResultID =Result.ResultID)'
        EXEC @Error = sp_executesql @sqlCommand
    END
    IF @Error != 0 SET @ErrorMessage = ERROR_NUMBER() + ' - ' + ERROR_MESSAGE()
    --Last modified: Steven
END
