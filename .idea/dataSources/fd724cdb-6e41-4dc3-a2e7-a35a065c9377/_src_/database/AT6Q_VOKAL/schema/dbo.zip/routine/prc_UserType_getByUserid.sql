-- EXEC [dbo].[prc_UserType_getByUserid]  31,5 
CREATE PROCEDURE [dbo].[prc_UserType_getByUserid]
(
@UserId INT,
@Departmentid INT
)
AS
DECLARE @UserDepID as int
Select @UserDepID = Departmentid from org.[user] where userid = @Userid

IF @UserDepID = @Departmentid
BEGIN
SELECT UserTypeID FROM org.UT_U WHERE UserID = @Userid
END
ELSE
BEGIN
SELECT  udut.UserTypeID
FROM	   org.U_D_UT udut JOIN org.U_D ud ON udut.U_DID = ud.U_DID AND ud.DepartmentID = @Departmentid AND ud.UserID = @Userid
END
