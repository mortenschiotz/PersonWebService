CREATE PROCEDURE [dbo].[prc_Archetype_del]
(
	@ArchetypeID smallint, 
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	DELETE FROM [dbo].[Archetype]
	WHERE
		[ArchetypeID] = @ArchetypeID

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'Archetype',2,
		( SELECT * FROM [dbo].[Archetype]
			WHERE
			[ArchetypeID] = @ArchetypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

