CREATE PROCEDURE [dbo].[prc_VOKAL_StartNY_Step2]
(
	@SiteId INT
 )
AS
BEGIN
/*
  Run startNY in R-database for each school that has Integration
*/
DECLARE @hdid_skole AS INT; 
DECLARE @batchid		AS INT;
DECLARE @surveyid		AS INT;
DECLARE @newsurveyid	AS INT;
DECLARE @ActivityID     AS INT;

DECLARE @DT_Skole AS INT = NULL; 
DECLARE @PeriodID INT = NULL;
DECLARE @NewPeriodID INT = NULL;
DECLARE @OwnerId AS INT = NULL;
DECLARE @error_message AS NVARCHAR(MAX);
DECLARE @EntityStatusID_Active INT = 0, @EntityStatusID_Inactive INT = 0

SELECT @EntityStatusID_Active   = EntityStatusID FROM EntityStatus WHERE CodeName = 'Active'
SELECT @EntityStatusID_Inactive = EntityStatusID FROM EntityStatus WHERE CodeName = 'Inactive'

SELECT @DT_Skole = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.Common.SchoolDepartmentTypeId'
AND sp.SiteID =  @SiteId
;
IF(@DT_Skole IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.Common.SchoolDepartmentTypeId not defined', 10, 1);
END


SELECT @PeriodID = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.NewSchoolYear.CurrentPeriodId'
AND sp.SiteID = @SiteId
;
IF(@PeriodID IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.NewSchoolYear.CurrentPeriodId not defined', 10, 1);
END


SELECT @NewPeriodID = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.NewSchoolYear.NextPeriodId'
AND sp.SiteID = @SiteId
;
IF(@NewPeriodID IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.NewSchoolYear.NextPeriodId not defined', 10, 1);
END


SELECT @OwnerId = s.OwnerID
FROM app.Site AS s
WHERE s.SiteID = @SiteId;

IF(@OwnerId IS NULL)
BEGIN	
	DECLARE @errorMsg AS VARCHAR(MAX) = 'Owner-id not defined for site ' + cast(@siteId AS varchar(3));
	RAISERROR(@errorMsg, 10, 1)
END

DECLARE @XCID_DenyTransferResultTable TABLE (XCID INT)
DECLARE @XCID_DenyTransferResult NVARCHAR(MAX)

SELECT @XCID_DenyTransferResult = [Value] FROM [app].[SiteParameter] WHERE [SiteID] = @SiteID AND [Key] = 'XCID_DenyTransferResult'
IF ISNULL(@XCID_DenyTransferResult, '') != ''
BEGIN
    INSERT INTO @XCID_DenyTransferResultTable ([XCID]) SELECT [Value] FROM dbo.funcListToTableINT(@XCID_DenyTransferResult, ',')
END

IF(@DT_Skole IS NOT NULL
	AND @PeriodID IS NOT NULL
	AND @OwnerId IS NOT NULL)
BEGIN

	SET NOCOUNT ON
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	DECLARE curBatches CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
	SELECT DISTINCT b.batchid, s.surveyid, CASE WHEN a.type = 3 THEN ISNULL(s2.surveyid,0) ELSE 0 END  -- type 3 = kartleggingsverktøy
		, hd.hdid, s.[ActivityID]
	FROM at.batch b
	INNER JOIN at.survey s	on s.surveyid = b.surveyid AND s.periodid = @periodid
	INNER JOIN at.activity a ON a.activityid = s.activityid
	INNER JOIN org.department d ON d.departmentid = b.departmentid
	INNER JOIN org.h_d hd ON hd.departmentid = d.departmentid AND hd.[Deleted] = 0
	INNER JOIN org.dt_d dtd ON dtd.departmentid = d.departmentid AND dtd.departmenttypeid = @DT_Skole
	LEFT JOIN at.survey s2 ON s2.activityid = s.activityid AND s2.periodid = @newperiodid AND s2.FROMSurveyID = s.SurveyID
	WHERE d.ownerid = @OwnerID
	  AND d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserINTegration = 1)
	  AND 0 < ( SELECT COUNT(*) FROM [dbo].[Synonym_VOKAL_Result] WHERE batchid = b.batchid) -- only with results
	  AND ( s2.surveyid IS NULL OR (0 < (SELECT COUNT(*) FROM at.batch WHERE surveyid = s2.surveyid))) -- only with at least 1 batch
      AND d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive)
      AND d.Deleted IS NULL -- only not deleted schools

		BEGIN TRANSACTION
		BEGIN TRY

			OPEN curBatches
			FETCH NEXT FROM curBatches INTO @batchid, @surveyid, @newsurveyid, @hdid_skole, @ActivityID

			WHILE (@@FETCH_STATUS = 0)
			BEGIN
				IF EXISTS (SELECT 1 FROM [at].[XC_A] xca JOIN @XCID_DenyTransferResultTable xt ON xca.[XCID] = xt.[XCID] AND xca.[ActivityID] = @ActivityID)
                BEGIN
                    SET @newsurveyid = 0
                END
                --PRINT cast(@hdid_skole AS nvarchar(16)) + ':'  + cast(@Periodid AS nvarchar(16)) + ':' + cast(@surveyid AS nvarchar(16)) + ':' +  cast(@batchid AS nvarchar(16)) + ':' + cast(@newsurveyid AS nvarchar(16))
				EXEC dbo.[Synonym_prc_VOKAL_startNY] @hdid_skole, @Periodid, @surveyid, @batchid, @newsurveyid, 3, 5
				--PRINT 'dbo.[Synonym_prc_VOKAL_startNY run' 
				FETCH NEXT FROM curBatches INTO @batchid, @surveyid, @newsurveyid, @hdid_skole, @ActivityID
			END	

			CLOSE curBatches
			DEALLOCATE curBatches
			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
			IF CURSOR_STATUS('global','curBatches') = 1
			BEGIN
				CLOSE curBatches
				DEALLOCATE curBatches
			END 
			 
		END CATCH
	END
END
