
CREATE PROCEDURE [dbo].[prc_AccessGeneric_ins]
(
	@AccessID int = null output,
	@TableTypeID smallint,
	@Elementid int,
	@Type smallint,
	@AccessGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[AccessGeneric]
	(
		[TableTypeID],
		[Elementid],
		[Type],
		[AccessGroupID]
	)
	VALUES
	(
		@TableTypeID,
		@Elementid,
		@Type,
		@AccessGroupID
	)

	Set @Err = @@Error
	Set @AccessID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGeneric',0,
		( SELECT * FROM [dbo].[AccessGeneric] 
			WHERE
			[AccessID] = @AccessID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

