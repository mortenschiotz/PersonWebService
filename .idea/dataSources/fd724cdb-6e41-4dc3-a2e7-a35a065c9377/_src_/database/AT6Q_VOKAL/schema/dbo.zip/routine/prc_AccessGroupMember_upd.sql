
CREATE PROCEDURE [dbo].[prc_AccessGroupMember_upd]
(
	@AccessGroupMemberID int,
	@AccessGroupID int,
	@UserID INT=NULL,
	@UserTypeID INT=NULL,
	@DepartmentID INT=NULL,
	@HDID INT=NULL,
	@UserGroupID INT=NULL,
	@RoleID INT=NULL,
	@DepartmentTypeID INT=NULL,
	@DepartmentGroupID INT=NULL,
	@Customerid INT=NULL,
	@ExtGroupID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [dbo].[AccessGroupMember]
	SET
		[AccessGroupID] = @AccessGroupID,
		[UserID] = @UserID,
		[UserTypeID] = @UserTypeID,
		[DepartmentID] = @DepartmentID,
		[HDID] = @HDID,
		[UserGroupID] = @UserGroupID,
		[RoleID] = @RoleID,
		[DepartmentTypeID] = @DepartmentTypeID,
		[DepartmentGroupID] = @DepartmentGroupID,
		[Customerid] = @Customerid,
		[ExtGroupID] = @ExtGroupID
	WHERE
		[AccessGroupMemberID] = @AccessGroupMemberID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGroupMember',1,
		( SELECT * FROM [dbo].[AccessGroupMember] 
			WHERE
			[AccessGroupMemberID] = @AccessGroupMemberID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

