
CREATE PROCEDURE [dbo].[prc_AccessGroup_ins]
(
	@AccessGroupID int = null output,
	@OwnerID int,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[AccessGroup]
	(
		[OwnerID],
		[No]
	)
	VALUES
	(
		@OwnerID,
		@No
	)

	Set @Err = @@Error
	Set @AccessGroupID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGroup',0,
		( SELECT * FROM [dbo].[AccessGroup] 
			WHERE
			[AccessGroupID] = @AccessGroupID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

