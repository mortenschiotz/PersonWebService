CREATE PROCEDURE [dbo].[prc_Archetype_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[ArchetypeID],
	[CodeName],
	[TableTypeID]
	FROM [dbo].[Archetype]

	Set @Err = @@Error

	RETURN @Err
END

