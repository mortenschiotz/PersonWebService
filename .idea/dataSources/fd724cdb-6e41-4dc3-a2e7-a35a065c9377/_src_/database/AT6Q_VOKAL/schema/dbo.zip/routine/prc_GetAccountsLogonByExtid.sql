CREATE PROCEDURE [dbo].[prc_GetAccountsLogonByExtid]
(
	@ExtId		nvarchar(64),
	@UserName	nvarchar(128) = NULL, /* OPTIONAL */
	@OwnerId	int	,
	@ErrNo		int		OUTPUT
)
AS
BEGIN
DECLARE @EntityStatusID INT = 0 
SELECT @EntityStatusID=EntityStatusID FROM EntityStatus WHERE CodeName='Active'
DECLARE @ret as integer		
		SELECT 	
			u.UserName,
			u.DepartmentID,
			u.UserID,
			u.OwnerId,
			u.FirstName,
			u.LastName,
			d.Name AS DepartmentName,
			u.LanguageID,
			d.CustomerID,
			u.SSN,
			u.Deleted,
			u.EntityStatusID,
			u.EntityStatusReasonID
		FROM 	
			[org].[User] u
			INNER JOIN org.Department d ON u.DepartmentID = d.DepartmentID
		WHERE
			((@UserName IS NULL) OR (UserName = @UserName))
			AND u.[ExtId] = @ExtId
			AND u.[ExtId] IS NOT NULL
			AND u.[ExtId] <> ''
			AND u.[EntityStatusID] = @EntityStatusID
			AND u.[Ownerid] = @OwnerId
			ORDER BY u.Created 
    
SET @ret = @@ROWCOUNT
IF @ret < 1 
BEGIN
	SET @ErrNo = 1 /* the user wasn't found */
END
ELSE
BEGIN	
	IF @ret > 1 
	BEGIN
		SET @ErrNo = 2 /* multiple users was found */
	END
	ELSE
	BEGIN	
		SET @ErrNo = 0
	END
END
END

