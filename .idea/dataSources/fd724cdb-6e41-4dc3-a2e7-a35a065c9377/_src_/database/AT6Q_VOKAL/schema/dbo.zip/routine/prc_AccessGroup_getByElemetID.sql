CREATE PROC dbo.prc_AccessGroup_getByElemetID
(
  @TableTypeID INT,
  @ElementID INT,
  @OwnerID INT
)
AS
  SELECT A.*
  FROM  dbo.AccessGroup AG
  JOIN dbo.AccessGeneric A ON AG.AccessGroupID = A.AccessGroupID 
							  AND AG.OwnerID = @OwnerID
							  AND A.ElementID = @ElementID
							  AND A.TableTypeID = @TableTypeID