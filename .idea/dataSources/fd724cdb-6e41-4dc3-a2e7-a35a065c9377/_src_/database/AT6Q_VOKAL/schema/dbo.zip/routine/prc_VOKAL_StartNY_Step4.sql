CREATE PROCEDURE [dbo].[prc_VOKAL_StartNY_Step4]
(
	@SiteId INT
)
AS
BEGIN
/* Run after PDF creation AND new students created*/   
--delete FROM org.ut_u
--WHERE usertypeid in (@AvgangsElevUID,@InntakselevUID) AND userid in
--(
--	SELECT u.userid FROM org.[user] u
--	inner join org.department d ON d.departmentid = u.departmentid AND  d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserINTegration = 1) AND d.ownerid = @OwnerID
--	inner join org.ut_u utu ON utu.userid = u.userid AND utu.usertypeid in (@AvgangsElevUID,@InntakselevUID)
--)

DECLARE @NewPeriodID INT = NULL;
DECLARE @DT_Skole AS INT = NULL; 
DECLARE @OwnerId AS INT = NULL;
DECLARE @AG_FinishedNSY AS INT = 0;
DECLARE @PROP_ActivePeriodID INT = NULL;
DECLARE @EntityStatusID_Active INT = 0, @EntityStatusID_Inactive INT = 0

SELECT @EntityStatusID_Active   = EntityStatusID FROM EntityStatus WHERE CodeName = 'Active'
SELECT @EntityStatusID_Inactive = EntityStatusID FROM EntityStatus WHERE CodeName = 'Inactive'

SELECT @NewPeriodID = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.NewSchoolYear.NextPeriodId'
AND sp.SiteID = @SiteId ;

SELECT @AG_FinishedNSY = ISNULL([Value], 0) 
FROM [app].[SiteParameter] 
WHERE [SiteID] = @SiteID AND [Key] = 'AG_FinishedNSY';

IF(@NewPeriodID IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.NewSchoolYear.NextPeriodId not defined', 10, 1);
END

SELECT @DT_Skole = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.Common.SchoolDepartmentTypeId'
AND sp.SiteID =  @SiteId
;

IF(@DT_Skole IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.Common.SchoolDepartmentTypeId not defined', 10, 1);
END


SELECT @PROP_ActivePeriodID = sp.value 
FROM app.SiteParameter AS sp
WHERE sp.[Key] = 'Platform.NewSchoolYear.CurrentPeriodProp'
AND sp.SiteID =  @SiteId
;
IF(@PROP_ActivePeriodID IS NULL)
BEGIN
	RAISERROR(N'Site param for Platform.NewSchoolYear.CurrentPeriodProp not defined', 10, 1);
END


SELECT @OwnerId = s.OwnerID
FROM app.Site AS s
WHERE s.SiteID = @SiteId;

IF(@OwnerId IS NULL)
BEGIN	
	DECLARE @errorMsg AS varchar(max) = 'Owner-id not defined for site ' + cast(@siteId AS varchar(3));
	RAISERROR(@errorMsg, 10, 1)
END

IF(@NewPeriodID IS NOT NULL
	AND @DT_Skole IS NOT NULL
	AND @OwnerId IS NOT NULL
)
BEGIN
	DECLARE @DepartmentID int
	DECLARE cur_department CURSOR FOR
	-- List out all Integration schools belonging to the school owner
	SELECT d.departmentid FROM org.department d
	JOIN org.dt_d dtd ON dtd.departmentid = d.departmentid AND dtd.departmenttypeid = @DT_Skole
    JOIN [org].[H_D] hd ON hd.[DepartmentID] = d.[DepartmentID] AND hd.[Deleted] = 0
	WHERE d.ownerid = @OwnerID
	  AND d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserIntegration = 1)
	  AND d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive)
      AND d.Deleted IS NULL -- only not deleted schools

	OPEN cur_department
	FETCH NEXT FROM cur_department INTO @DepartmentID
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE pv SET pv.Value=@NewPeriodID, pv.[Updated] = GETDATE()
		FROM prop.PropValue pv
		WHERE pv.PropertyID = @PROP_ActivePeriodID
		  AND pv.itemid = @DepartmentID
		FETCH NEXT FROM cur_department INTO @DepartmentID
	END
	CLOSE cur_department
	DEALLOCATE cur_department
END
	-- Hide the menu "Nasjonale prøver" for all INTegration schools after run NSY
	INSERT INTO [AccessGroupMember] ([AccessGroupID], [HDID])  
    SELECT @AG_FinishedNSY ,hd.HDID 
    FROM org.department d
    JOIN org.dt_d dtd ON dtd.departmentid = d.departmentid AND dtd.departmenttypeid = @DT_Skole
    JOIN org.H_D hd ON hd.DepartmentID= d.DepartmentID AND hd.[Deleted] = 0
	WHERE d.ownerid = @OwnerID
      AND d.customerid IN (SELECT customerid FROM org.Customer WHERE HasUserIntegration = 1)
      AND d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive)
      AND d.Deleted IS NULL -- only not deleted schools
END
