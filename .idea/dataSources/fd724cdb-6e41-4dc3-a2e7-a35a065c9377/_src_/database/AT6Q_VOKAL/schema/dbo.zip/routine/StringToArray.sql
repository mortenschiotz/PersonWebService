 /*
 DECLARE @StartTime DateTime,
   @EndTime DateTime
 SET @StartTime = GETDATE()
 
 SELECT * FROM [dbo].[ArrayToString] ('1233@a589as','@') 
 
 SET @EndTime = GETDATE()
 SELECT CONVERT(varchar(10),DATEDIFF(millisecond, @StartTime, @EndTime)) + '  Milliseconds'
*/

CREATE FUNCTION [dbo].[StringToArray] (@Array nvarchar(MAX),@Separator_Char nvarchar(5))
RETURNS @ParseTable table
 (ParseValue nvarchar(1000))
AS
BEGIN
 IF(LEN(@Array) > 0)
 BEGIN
	 DECLARE @Separator_position int,
	   @Array_value nvarchar(1000),
	   @Separator_Search nvarchar(7),
	   @Separator_Len smallint
	 SELECT @Array = @Array + @Separator_Char
	 SET @Separator_Search = '%' + @Separator_Char + '%'
	 SET @Separator_Len = LEN(@Separator_Char)
	 
	 IF(@Separator_Len > 0)
	 BEGIN
	  WHILE patindex(@Separator_Search , @Array) <> 0
	  BEGIN
	   SET @Separator_position =  patindex(@Separator_Search , @Array) + @Separator_Len - 1
	   SET @Array_value = RTRIM(LTRIM(left(@Array, @Separator_position + 1 - @Separator_Len)))  
	   INSERT @ParseTable(ParseValue) VALUES (SUBSTRING(@Array_value,0,LEN(@Array_value)))
	   SET @Array = stuff(@Array,1, @Separator_position, '')
	  END 
	 END
 END
 RETURN
END
