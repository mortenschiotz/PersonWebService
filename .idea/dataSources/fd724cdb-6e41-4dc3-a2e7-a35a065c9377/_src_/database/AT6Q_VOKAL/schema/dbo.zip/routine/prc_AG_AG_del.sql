

CREATE PROCEDURE [dbo].[prc_AG_AG_del]
(
	@AG_AGID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AG_AG',2,
		( SELECT * FROM [dbo].[AG_AG] 
			WHERE
			[AG_AGID] = @AG_AGID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[AG_AG]
	WHERE
		[AG_AGID] = @AG_AGID

	Set @Err = @@Error

	RETURN @Err
END

