CREATE PROC [dbo].[tool_Report_Karaktere]
(
  @ReportID AS INT = 1,
  @ReportPartname AS VARCHAR(256) = 'Fellesfag - graf',
  @CategoryID as int = 97
)
AS
 DECLARE @ReportPartID INT,
		@ReportRowID INT,
		@ReportColumnID INT,
        @RowNo as int
 

  INSERT INTO rep.ReportPart(ReportID, Name, ReportPartTypeID, SelectionDir, GraphTypeID, ElementID, Created)
  VALUES (@ReportID,@ReportPartname,2,1,-1,0,GETDATE())

  SET @ReportPartID = SCOPE_IDENTITY()

  INSERT INTO rep.LT_ReportPart(LanguageID, ReportPartID, TEXT)
  VALUES (1,@ReportPartID,@ReportPartname)

  -- Header row
  INSERT INTO rep.ReportRow(ReportPartID, ReportRowTypeID, NO, CssClass, Created)
  VALUES (@ReportPartID,1,0,'',GETDATE())

  SET @ReportRowID = SCOPE_IDENTITY()

  INSERT INTO rep.ReportColumn(ReportRowID, NO, ReportColumnTypeID, Formula, width, Format, URL)
  VALUES (@ReportRowID,0,1,'',0,'','')  

  SET @ReportColumnID = SCOPE_IDENTITY()

  INSERT INTO rep.LT_ReportColumn(LanguageID, ReportColumnID, TEXT)
  VALUES (1,@ReportColumnID,'Fag')

  INSERT INTO rep.ReportColumn(ReportRowID, NO, ReportColumnTypeID, Formula, width, Format, URL)
  VALUES (@ReportRowID,1,2,'',0,'','')  

  SET @ReportColumnID = SCOPE_IDENTITY()

  INSERT INTO rep.LT_ReportColumn(LanguageID, ReportColumnID, TEXT)
  VALUES (1,@ReportColumnID,'Differanse Eksamen - Standpunkt')

