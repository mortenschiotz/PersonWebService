
CREATE PROCEDURE [dbo].[prc_AccessGroupMember_get]
(
	@AccessGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AccessGroupMemberID],
	[AccessGroupID],
	ISNULL([UserID], 0) AS 'UserID',
	ISNULL([UserTypeID], 0) AS 'UserTypeID',
	ISNULL([DepartmentID], 0) AS 'DepartmentID',
	ISNULL([HDID], 0) AS 'HDID',
	ISNULL([UserGroupID], 0) AS 'UserGroupID',
	ISNULL([RoleID], 0) AS 'RoleID',
	ISNULL([DepartmentTypeID], 0) AS 'DepartmentTypeID',
	ISNULL([DepartmentGroupID], 0) AS 'DepartmentGroupID',
    ISNULL([CustomerID],0) AS 'CustomerID',
    ISNULL([ExtGroupID],0) AS 'ExtGroupID'
	FROM [dbo].[AccessGroupMember]
	WHERE
	[AccessGroupID] = @AccessGroupID

	Set @Err = @@Error

	RETURN @Err
END

