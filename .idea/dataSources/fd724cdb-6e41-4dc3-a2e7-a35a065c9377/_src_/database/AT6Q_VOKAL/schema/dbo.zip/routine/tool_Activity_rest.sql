create PROC [dbo].[tool_Activity_rest] 
(
	@FromActivityID	int,
	@ToActivityID	int,
	@PageID			int
)
AS
BEGIN
-- DELETE Mapping
DELETE imp.CON_QMAPPING WHERE ActivityID = @ToActivityID
DELETE imp.CON_SCALEMAPPING WHERE ActivityID = @ToActivityID
DELETE imp.CON_ALTMAPPING WHERE ActivityID = @ToActivityID

-- Scale
DECLARE @MinS	int,
		@MaxS	int,
		@Type	smallint,
		@MinV	float,
		@MaxV	float,
		@Tag	nvarchar(64),
		@ID		int,
		@TmpID	int,
		@NewID	int

SET @TmpID = 0

DECLARE curAG CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT DISTINCT S.ScaleID, S.MinSelect, S.MaxSelect, S.Type, S.MinValue, S.MaxValue, S.Tag
FROM Hauken.AT4Q_PILOT.dbo.Scale S
INNER JOIN Hauken.AT4Q_PILOT.dbo.Question Q ON Q.ScaleID = S.ScaleID
INNER JOIN imp.CON_QFILTER I ON Q.QuestionID = I.QuestionID
WHERE I.ActivityID = @ToActivityID


OPEN curAG
FETCH NEXT FROM curAG INTO @ID, @MinS, @MaxS, @Type, @MinV, @MaxV, @Tag

WHILE (@@FETCH_STATUS = 0)
BEGIN
	IF @TmpID <> @ID
	BEGIN
		INSERT at.Scale(ActivityID, MinSelect, MaxSelect, Type, MinValue, MaxValue, Tag)
		VALUES(@ToActivityID, @MinS, @MaxS, @Type, @MinV, @MaxV, @Tag)
		SET @NewID = scope_identity()
		INSERT imp.CON_SCALEMAPPING(ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)
	END
	FETCH NEXT FROM curAG INTO @ID, @MinS, @MaxS, @Type, @MinV, @MaxV, @Tag
END
CLOSE curAG
DEALLOCATE curAG
INSERT at.LT_Scale(LanguageID, ScaleID, Name, Title, Description)
SELECT LT.LanguageID, CS.ToID, Name, Title, ToolTip
FROM at.Scale S
INNER JOIN imp.CON_SCALEMAPPING CS ON S.ScaleID = CS.ToID
INNER JOIN Hauken.AT4Q_PILOT.dbo.LT_Scale LT ON CS.FromID = LT.ScaleID
WHERE S.ActivityID = @ToActivityID


-- Alternative
DECLARE curAlt CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT S.ScaleID, AlternativeID
FROM Hauken.AT4Q_PILOT.dbo.Alternative A
INNER JOIN imp.CON_SCALEMAPPING CS ON A.ScaleID = CS.FromID
INNER JOIN at.Scale S ON CS.ToID = S.ScaleID
WHERE S.ActivityID = @ToActivityID

OPEN curAlt
FETCH NEXT FROM curAlt INTO @TmpID, @ID

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT at.Alternative(ScaleID, Type, No, Value, InvertedValue, Calc, SC, MinValue, MaxValue, Format, Size, CssClass, DefaultValue, Tag)
	SELECT @TmpID, Type, No, Value, InvertedValue, Calc, SC, MinValue, MaxValue, Format, Size, CssClass, DefaultValue, Tag
	FROM Hauken.AT4Q_PILOT.dbo.Alternative 	
	WHERE AlternativeID = @ID

	SET @NewID = scope_identity()
	
	INSERT imp.CON_ALTMAPPING(ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)

	INSERT at.LT_Alternative(LanguageID, AlternativeID, Name, Label, Description)
	SELECT LanguageID, @NewID, Name, Label, ToolTip
	FROM Hauken.AT4Q_PILOT.dbo.LT_Alternative
	WHERE AlternativeID = @ID 

	FETCH NEXT FROM curAlt INTO @TmpID, @ID
END
CLOSE curAlt
DEALLOCATE curAlt

-- Questions
DECLARE curQuest CURSOR LOCAL FAST_FORWARD READ_ONLY FOR 
SELECT DISTINCT QuestionID
FROM imp.CON_QFILTER
WHERE ActivityID = @ToActivityID

OPEN curQuest
FETCH NEXT FROM curQuest INTO @ID

WHILE (@@FETCH_STATUS = 0)
BEGIN
	INSERT at.Question(PageID, No, Type, Inverted, Mandatory, ScaleID, Status, CssClass, ExtID, Tag)
	SELECT @PageID, Q.No, Q.Type, Inverted, Mandatory, CS.ToID, Q.Status, CssClass, Variable, Tag
	FROM Hauken.AT4Q_PILOT.dbo.Question Q		
	LEFT OUTER JOIN imp.CON_SCALEMAPPING CS ON Q.ScaleID = CS.FromID AND CS.ActivityID = @ToActivityID
	WHERE Q.QuestionID = @ID 

	SET @NewID = scope_identity()
	INSERT imp.CON_QMAPPING(ActivityID, ToID, FromID) VALUES(@ToActivityID, @NewID, @ID)
	
	FETCH NEXT FROM curQuest INTO @ID
END
CLOSE curQuest
DEALLOCATE curQuest

INSERT at.LT_Question(LanguageID, QuestionID, Name, Title, ReportText, Description)
SELECT DISTINCT LanguageID, CQ.ToID, CAST(Text as nvarchar(2000)), HeadLine, ReportText, ''
FROM Hauken.AT4Q_PILOT.dbo.LT_Question LTQ 
INNER JOIN imp.CON_QMAPPING CQ ON LTQ.QuestionID = CQ.FromID AND CQ.ActivityID = @ToActivityID

UPDATE at.Question 
SET Type=1 
FROM at.Question Q
WHERE Q.PageID = @PageID AND Q.ScaleID IS NULL

END
