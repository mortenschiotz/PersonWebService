CREATE PROCEDURE [dbo].[prc_Invited_Finished_getByBatchList]
(
    @BatchIDList    varchar(max)
)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @Err Int, @ActiveEntityStatusID INT = 0
    --DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')
    IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#T_BatchCouting')) DROP TABLE #T_BatchCouting
    DECLARE @BatchID INT, @ReportDB NVARCHAR(MAX), @ReportServer NVARCHAR(MAX), @Sql_command NVARCHAR(MAX)

	SELECT TOP 1 @ReportServer = ReportServer, @ReportDB = ReportDB FROM at.Activity
	SET @Sql_command = N'SELECT @p_ActiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Active'''
	EXECUTE sp_executesql @sql_Command, N'@p_ActiveEntityStatusID INT OUTPUT', @p_ActiveEntityStatusID = @ActiveEntityStatusID OUTPUT

    CREATE TABLE #T_BatchCouting (BatchID INT, Invited INT, Finished INT)
    DECLARE c_ResultDatabase CURSOR READ_ONLY FOR
    SELECT DISTINCT s.ReportDB,s.ReportServer FROM 
    at.Survey s INNER JOIN 
    at.Batch  b ON b.SurveyID = s.SurveyID WHERE b.BatchID IN (SELECT [ParseValue] FROM dbo.StringToArray(@BatchIDList, ','))
    OPEN c_ResultDatabase
    FETCH NEXT FROM c_ResultDatabase INTO  @ReportDB, @ReportServer
	    WHILE @@FETCH_STATUS=0
	    BEGIN
	        SET @Sql_command ='
	        INSERT INTO #T_BatchCouting SELECT  BatchID,
                count(*) as Invited,
                count(EndDate) as Finished
	            FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.[Result]
                WHERE [BatchID] IN (SELECT [ParseValue] FROM dbo.StringToArray('''+@BatchIDList+''', '',''))
                  AND [EntityStatusID] = ' + CONVERT(NVARCHAR(14), @ActiveEntityStatusID)+ ' AND Deleted IS NULL
                GROUP BY BatchID
	        '
	       EXECUTE sp_executesql @Sql_command
    	   
	       FETCH NEXT FROM c_ResultDatabase INTO  @ReportDB, @ReportServer
	    END
	    CLOSE c_ResultDatabase
	    DEALLOCATE c_ResultDatabase
    SELECT BatchID, SUM(Invited) as Invited, SUM(Finished) as Finished FROM #T_BatchCouting GROUP BY BatchID ORDER BY BatchID 
    DROP TABLE #T_BatchCouting

	Set @Err = @@Error

	RETURN @Err
END
