
CREATE PROCEDURE [dbo].[prc_LT_AccessGroup_get]
(
	@AccessGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[AccessGroupID],
	[Name],
	[Description]
	FROM [dbo].[LT_AccessGroup]
	WHERE
	[AccessGroupID] = @AccessGroupID

	Set @Err = @@Error

	RETURN @Err
END

