
CREATE PROCEDURE [dbo].[prc_Department_get_single]
(
   @DepartmentID int
)
As
BEGIN
 DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

 SELECT DepartmentID, LanguageID, Name, Description, OrgNo, Status, 
    ISNULL(OwnerID, 0) OwnerID, Created, ExtID, Tag, Adress, PostalCode, City, Locked, EntityStatusID, EntityStatusReason 
 FROM department 
 WHERE departmentid = @DepartmentID AND EntityStatusID = @ActiveEntityStatusID
END
