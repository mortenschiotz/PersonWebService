
create PROC [dbo].[add_batch_to_survey] 
(
@SurveyID as int,
@SchoolsGrade as int
)
AS
BEGIN
declare @StartDate as date
declare @EndDate as date
set @StartDate=(select StartDate from at.Survey where surveyid=@SurveyId)
set @EndDate=(select EndDate from at.Survey where surveyid=@SurveyId)
declare @GradeDepartmentTypeId as int
set @GradeDepartmentTypeId=37+@SchoolsGrade

--update dates on any existing batches
update at.Batch set StartDate=@StartDate, enddate=@EndDate where SurveyID=@SurveyID 
--insert new batches
insert into at.Batch (SurveyID, DepartmentID, Name, No, StartDate, EndDate, Status, MailStatus) 
select @SurveyID, school.DepartmentID, school.Name, 0, @StartDate, @EndDate, 2, 0  from org.Department school 
join org.dt_d dtschool on school.DepartmentID=dtschool.DepartmentID and dtschool.DepartmentTypeID=36 --skole 
join org.dt_d dtgrade on school.DepartmentID=dtgrade.DepartmentID and dtgrade.DepartmentTypeID=@GradeDepartmentTypeId 
and school.DepartmentID not in (select bTo.DepartmentID from at.Batch bTo where bTo.SurveyID=@SurveyID) --except if batch already exist
and school.CustomerID in (select a.customerid from AccessGroupMember a where a.AccessGroupID=84) -- customer is using Feide
end
