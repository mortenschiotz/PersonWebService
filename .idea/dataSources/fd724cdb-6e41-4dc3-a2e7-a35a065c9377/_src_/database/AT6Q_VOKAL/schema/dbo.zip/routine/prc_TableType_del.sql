


CREATE PROCEDURE [dbo].[prc_TableType_del]
(
	@TableTypeID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'TableType',2,
		( SELECT * FROM [dbo].[TableType] 
			WHERE
			[TableTypeID] = @TableTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[TableType]
	WHERE
		[TableTypeID] = @TableTypeID

	Set @Err = @@Error

	RETURN @Err
END


