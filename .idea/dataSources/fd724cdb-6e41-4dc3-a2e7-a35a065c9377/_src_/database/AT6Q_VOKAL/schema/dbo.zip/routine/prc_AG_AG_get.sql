
CREATE PROCEDURE [dbo].[prc_AG_AG_get]
(
	@AccessGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AG_AGID],
	[AccessGroupID],
	[ToAccessGroupID],
	[Type]
	FROM [dbo].[AG_AG]
	WHERE
	[AccessGroupID] = @AccessGroupID

	Set @Err = @@Error

	RETURN @Err
END

