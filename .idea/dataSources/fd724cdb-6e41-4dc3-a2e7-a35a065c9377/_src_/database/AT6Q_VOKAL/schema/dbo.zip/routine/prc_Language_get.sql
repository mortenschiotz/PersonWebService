
CREATE PROCEDURE [dbo].[prc_Language_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[LanguageCode],
	[Dir],
	[Name],
	[Created]
	FROM [dbo].[Language]

	Set @Err = @@Error

	RETURN @Err
END

