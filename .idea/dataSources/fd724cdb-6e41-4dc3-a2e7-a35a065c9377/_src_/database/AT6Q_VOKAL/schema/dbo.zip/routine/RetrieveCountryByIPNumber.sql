

CREATE PROCEDURE [dbo].[RetrieveCountryByIPNumber]
(
	@IPNumber	numeric
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[Country_Code_2],
	[Country_Code_3],
	[Country_Name]
	FROM [dbo].[IP_Country]
	WHERE @IPNumber between IP_From AND IP_To

	Set @Err = @@Error

	RETURN @Err
END

