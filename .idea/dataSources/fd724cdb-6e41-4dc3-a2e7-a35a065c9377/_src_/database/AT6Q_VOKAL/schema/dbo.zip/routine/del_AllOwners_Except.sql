
-- del_AllOwners_Except 3
/*	Opprettet av : Morten Ø
	Dato : 09.09.2010
	
	Sletter alle [Owner] bortsett fra angitt OwnerID
	Se dbo.[del_Owner] for mer info
*/

CREATE proc [dbo].[del_AllOwners_Except](
	@OwnerID	int
) AS
BEGIN
	DECLARE @TmpID	int
	BEGIN TRANSACTION TT
	DECLARE curO CURSOR LOCAL FAST_FORWARD READ_ONLY FOR
	SELECT OwnerID
	FROM org.[Owner] WHERE OwnerID <> @OwnerID

	OPEN curO
	FETCH NEXT FROM curO INTO @TmpID
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		EXEC del_Owner @TmpID
		FETCH NEXT FROM curO INTO @TmpID
	END
	CLOSE curO
	DEALLOCATE curO
	COMMIT TRANSACTION TT
END
