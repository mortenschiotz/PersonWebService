
CREATE PROCEDURE [dbo].[prc_KeyValue_del]
(
	@Id int,
	@Type tinyint,
	@Key varchar(50),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'KeyValue',2,
		( SELECT * FROM [dbo].[KeyValue] 
			WHERE
			[Id] = @Id AND
			[Type] = @Type AND
			[Key] = @Key
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[KeyValue]
	WHERE
		[Id] = @Id AND
		[Type] = @Type AND
		[Key] = @Key

	Set @Err = @@Error

	RETURN @Err
END

