CREATE PROCEDURE [dbo].[prc_GUIText_get]
(
	@LanguageID	int
)
As
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	Select
	[LanguageID],
	[ItemID],
	[Text]
	FROM [GUIText]
	WHERE LanguageID = @LanguageID
	ORDER BY ItemID
	Set @Err = @@Error

	RETURN @Err
End


