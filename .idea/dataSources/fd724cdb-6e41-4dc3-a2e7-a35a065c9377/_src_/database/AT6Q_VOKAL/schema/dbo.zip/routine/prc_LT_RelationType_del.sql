CREATE PROCEDURE [dbo].[prc_LT_RelationType_del]
(
	@LanguageID int,
	@RelationTypeID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_RelationType',2,
		( SELECT * FROM [dbo].[LT_RelationType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[RelationTypeID] = @RelationTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[LT_RelationType]
	WHERE
		[LanguageID] = @LanguageID AND
		[RelationTypeID] = @RelationTypeID

	Set @Err = @@Error

	RETURN @Err
END

