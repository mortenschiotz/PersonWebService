--Get XCategory Activity List    
-- exec [dbo].[prc_XCategoryActivityList_get] 2,'2,3'
CREATE PROCEDURE [dbo].[prc_XCategoryActivityList_get]
	@xCategoryId int,	
	@xCategoryIds varchar(MAX)
AS
BEGIN 	
	SELECT * FROM at.XC_A
	WHERE CHARINDEX(',' + CONVERT(varchar(10),XCID) + ',',',' + @xCategoryIds + ',') <> 0
		AND ActivityID in (SELECT ActivityID FROM at.XC_A WHERE XCID = @xCategoryId)		
END
/********************************/

