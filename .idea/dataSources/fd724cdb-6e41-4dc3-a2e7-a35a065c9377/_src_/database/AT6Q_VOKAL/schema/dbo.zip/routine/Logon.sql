/*
    Sarah - Oct 10, 2016 - Remove column Status on User, Department and Result tables
*/
CREATE PROCEDURE [dbo].[Logon]
(
	@UserName	nvarchar(128),
	@PassWord	nvarchar(64),
	@UserID		int		OUTPUT,
	@LanguageID	int=1		OUTPUT,
	@DepartmentID	int		OUTPUT,
	@Firstname	nvarchar(64) 	OUTPUT,
	@Lastname	nvarchar(64) 	OUTPUT,
	@Email		nvarchar(256) 	OUTPUT,
	@Mobile		nvarchar(16) 	OUTPUT,
	@ExtId		nvarchar(64) 	OUTPUT,
	@OwnerId	int	,
	@ErrNo		int		OUTPUT,
	@ChangePassword bit = 0 OUTPUT,
	@LogonType	INT =0 OUTPUT
)
AS
BEGIN
DECLARE @DescrytPass nvarchar(max)= dbo.DecryptString(@Password)
DECLARE @EntityStatusID INT = 0 
SELECT @EntityStatusID=EntityStatusID FROM EntityStatus WHERE CodeName='Active'
IF @DescrytPass = ''
BEGIN
	SET @ErrNo = 1
    RETURN
END

IF ((SELECT UseOTPCaseSensitive FROM org.Owner WHERE OwnerID = @OwnerId) =1)
	BEGIN
		SELECT 	
			@DepartmentID = DepartmentID,
			@LanguageID = LanguageID,
			@UserID = UserID,
			@Firstname = Firstname,
			@Lastname = Lastname,
			@Email = Email,
			@Mobile = Mobile,
			@ExtId = ExtId,
			@OwnerId = OwnerId,
			@ChangePassword = ChangePassword,
			@LogonType= 
			CASE WHEN [Password] = @Password THEN 0
			ELSE 1
			END
		FROM 	
			[org].[User] 
		WHERE 	
			UserName = @UserName
			And ([Password] = @PassWord OR dbo.DecryptString([OneTimePassword])= @DescrytPass COLLATE SQL_Latin1_General_CP1_CS_AS)
			AND [EntityStatusID] = @EntityStatusID
			AND [Ownerid] = @OwnerId
	END
ELSE
	BEGIN
		SELECT 	
			@DepartmentID = DepartmentID,
			@LanguageID = LanguageID,
			@UserID = UserID,
			@Firstname = Firstname,
			@Lastname = Lastname,
			@Email = Email,
			@Mobile = Mobile,
			@ExtId = ExtId,
			@OwnerId = OwnerId,
			@ChangePassword = ChangePassword,
			@LogonType= 
			CASE WHEN [Password] = @Password THEN 0
			ELSE 1
			END
		FROM 	
			[org].[User] 
		WHERE 	
			UserName = @UserName
			And ([Password] = @PassWord OR dbo.DecryptString([OneTimePassword])= @DescrytPass)
			AND [EntityStatusID] = @EntityStatusID
			AND [Ownerid] = @OwnerId
	END
	
IF @@RowCount < 1 
BEGIN
	SET @ErrNo = 1
END
ELSE
BEGIN	
	SET @ErrNo = 0
END
END
