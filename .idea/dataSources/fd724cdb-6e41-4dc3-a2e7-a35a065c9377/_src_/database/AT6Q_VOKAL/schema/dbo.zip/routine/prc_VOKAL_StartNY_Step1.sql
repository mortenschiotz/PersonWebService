CREATE PROCEDURE [dbo].[prc_VOKAL_StartNY_Step1]
(
    @SiteId     int,
    @Sync       BIT = 0
)
AS
BEGIN

declare @DT_Skole as INT = null; 
declare @OldPeriodID INT = null;
declare @DT_KLASSE INT = null;
declare @DT_RelTypeID INT = null;
declare @UT_RelTypeID INT = null;
declare @UT_Avgang INT = null;
declare @UT_Elev INT = null;
declare @OwnerId as int = null;
declare @PROP_MaintenanceMode int = NULL;

declare @hdid_skole as int;
declare @error_message as nvarchar(max);
DECLARE @EntityStatusID_Active INT = 0, @EntityStatusID_Inactive INT = 0

SELECT @EntityStatusID_Active   = EntityStatusID FROM EntityStatus WHERE CodeName = 'Active'
SELECT @EntityStatusID_Inactive = EntityStatusID FROM EntityStatus WHERE CodeName = 'Inactive'

select @DT_Skole = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.Common.SchoolDepartmentTypeId'
and sp.SiteID =  @SiteId
;
if(@DT_Skole is null)
begin
	raiserror(N'Site param for Platform.Common.SchoolDepartmentTypeId not defined', 10, 1);
end


select @OldPeriodID = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.NewSchoolYear.CurrentPeriodId'
and sp.SiteID = @SiteId
;
if(@OldPeriodID is null)
begin
	raiserror(N'Site param for Platform.NewSchoolYear.CurrentPeriodId not defined', 10, 1);
end


select @DT_KLASSE = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.Common.ClassDepartmentTypeId'
and sp.SiteID = @SiteId
;
if(@DT_KLASSE is null)
begin
	raiserror(N'Site param for Platform.Common.ClassDepartmentTypeId not defined', 10, 1);
end



select @DT_RelTypeID = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.NewSchoolYear.RelationTypeIdDepartmentType'
and sp.SiteID = @SiteId
;
if(@DT_RelTypeID is null)
begin
	raiserror(N'Site param for Platform.NewSchoolYear.RelationTypeIdDepartmentType not defined', 10, 1);
end


select @UT_RelTypeID  = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.NewSchoolYear.RelationTypeIdUserType'
and sp.SiteID = @SiteId
;
if(@UT_RelTypeID is null)
begin
	raiserror(N'Site param for Platform.NewSchoolYear.RelationTypeIdUserType not defined', 10, 1);
end


select @UT_Avgang  = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.Admin.GraduatesUserType'
and sp.SiteID = @SiteId
;
if(@UT_Avgang is null)
begin
	raiserror(N'Site param for Platform.Admin.GraduatesUserType not defined', 10, 1);
end


select @UT_Elev  = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.Common.ElevUserType'
and sp.SiteID = @SiteId
;
if(@UT_Elev is null)
begin
	raiserror(N'Site param for Platform.Common.ElevUserType not defined', 10, 1);
end


select @PROP_MaintenanceMode = sp.value 
from app.SiteParameter as sp
where sp.[Key] = 'Platform.NewSchoolYear.MaintenanceModeProp'
and sp.SiteID =  @SiteId
;
if(@PROP_MaintenanceMode is null)
begin
	raiserror(N'Site param for Platform.NewSchoolYear.MaintenanceModeProp not defined', 10, 1);
end


select @OwnerId = s.OwnerID
from app.Site as s
where s.SiteID = @SiteId
if(@OwnerId is null)
begin	
	declare @errorMsg as varchar(max) = 'Owner-id not defined for site ' + cast(@siteId as varchar(3));
	raiserror(@errorMsg, 10, 1)
end

if(@DT_Skole is not null
	and @OldPeriodID is not null
	and @DT_KLASSE is not null
	and @DT_RelTypeID is not null
	and @UT_RelTypeID is not null
	and @UT_Avgang is not null
	and @UT_Elev is not null
	and @OwnerId is not null)
begin
	-- updates status for all schools for a given customer to 6=Underveis
	update pv
	set pv.propoptionid = 6, pv.[Updated] = GETDATE()
	from prop.propvalue pv 
	inner join org.Department d on d.DepartmentID = pv.ItemID and d.OwnerID = @OwnerID and d.CustomerID in (Select customerid From org.Customer where HasUserIntegration = 1 )
	where pv.propertyid = @PROP_MaintenanceMode and pv.propoptionid in (5,7) and d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive) AND d.Deleted IS NULL


	declare curSchools cursor local fast_forward read_only for 
	select distinct hd.hdid
	from org.department d
	join org.dt_d dtd on dtd.departmentid = d.departmentid and dtd.departmenttypeid = @DT_Skole
	join org.h_d hd on hd.departmentid = d.departmentid AND hd.[Deleted] = 0
	where d.ownerid = @OwnerID
		AND d.customerid IN (Select customerid From org.Customer where HasUserIntegration = 1 )
		AND d.EntityStatusID IN (@EntityStatusID_Active, @EntityStatusID_Inactive)
		AND d.Deleted IS NULL


	OPEN curSchools
	FETCH NEXT FROM curSchools INTO @hdid_skole

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		exec dbo.prc_VOKAL_startNY
		@OldPeriodID,
		@hdid_skole,
		@DT_KLASSE,
		@DT_RelTypeID,
		@UT_RelTypeID,
		@UT_Avgang,
		@error_message OUTPUT,
		@Sync,
		@UT_Elev
	
		FETCH NEXT FROM curSchools INTO @hdid_skole	
	END	
	CLOSE curSchools
	DEALLOCATE curSchools
	END
END
