CREATE PROCEDURE [dbo].[prc_DeactivateUser]
AS
BEGIN
-- Learners
UPDATE u
SET u.EntityStatusID = 3, u.EntityStatusReasonID = 303
FROM org.[User] u
WHERE u.CustomerID in (488,495,496,497,498) and u.EntityStatusID = 1 and u.ArchetypeID = 2 and u.locked = 1 and u.LastSynchronized < GETDATE() -5
 
-- Employees
UPDATE u
SET u.EntityStatusID = 3, u.EntityStatusReasonID = 303
FROM org.[User] u
    JOIN org.department d ON d.departmentid = u.departmentid and d.archetypeid = 4
WHERE u.CustomerID in (488,495,496,497,498) and u.EntityStatusID = 1 and u.ArchetypeID = 1 and u.locked = 1 and u.LastSynchronized < GETDATE() - 5
END
