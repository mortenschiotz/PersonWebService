
CREATE PROCEDURE [dbo].[prc_AccessGroupMember_ins]
(
	@AccessGroupMemberID int = null output,
	@AccessGroupID int,
	@UserID INT=NULL,
	@UserTypeID INT=NULL,
	@DepartmentID INT=NULL,
	@HDID INT=NULL,
	@UserGroupID INT=NULL,
	@RoleID INT=NULL,
	@DepartmentTypeID INT=NULL,
	@DepartmentGroupID INT=NULL,
	@CustomerID INT=NULL,
	@ExtGroupID INT=NULL,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [dbo].[AccessGroupMember]
	(
		[AccessGroupID],
		[UserID],
		[UserTypeID],
		[DepartmentID],
		[HDID],
		[UserGroupID],
		[RoleID],
		[DepartmentTypeID],
		[DepartmentGroupID],
		[CustomerID],
		[ExtGroupID]
	)
	VALUES
	(
		@AccessGroupID,
		@UserID,
		@UserTypeID,
		@DepartmentID,
		@HDID,
		@UserGroupID,
		@RoleID,
		@DepartmentTypeID,
		@DepartmentGroupID,
		@CustomerID,
		@ExtGroupID
	)

	Set @Err = @@Error
	Set @AccessGroupMemberID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGroupMember',0,
		( SELECT * FROM [dbo].[AccessGroupMember] 
			WHERE
			[AccessGroupMemberID] = @AccessGroupMemberID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

