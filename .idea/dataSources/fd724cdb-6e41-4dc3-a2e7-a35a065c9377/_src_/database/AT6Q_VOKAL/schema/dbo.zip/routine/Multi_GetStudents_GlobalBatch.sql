/*
    Sarah - Oct 10, 2016 - Remove column Status on User, Department and Result tables
*/
CREATE PROCEDURE [dbo].[Multi_GetStudents_GlobalBatch] 
    @DepartmentID   int,
    @BatchID        int,
    @UserTypeID     int,
    @LanguageID     int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @ActiveEntityStatusID INT = (SELECT EntityStatusID FROM EntityStatus WHERE CodeName='Active')

    -- Insert statements for procedure here
	select u.UserID,d.DepartmentID,d.name 'DepartmentName',ut.name 'UTName',utu.UserTypeID,u.FirstName,u.LastName,isnull(max(r.Resultid),0) 'ResultID', ISNULL(CONVERT(nvarchar(32),u.DateOfBirth,102),'') AS [BirthDate]
	from org.Department d
	join org.[User] u on  u.DepartmentID=d.DepartmentID
	join org.UT_U utu on u.UserID=utu.UserID and utu.UserTypeID=@UserTypeID --between 40 and 49
	join org.LT_userType ut on utu.UserTypeID=ut.UserTypeID AND ut.[LanguageID] = @LanguageID
	left outer join [dbo].[Synonym_VOKAL_Result] r on u.UserID=r.userid and r.BatchID=@BatchID AND r.EntityStatusID = @ActiveEntityStatusID AND r.Deleted IS NULL
	where u.EntityStatusID = @ActiveEntityStatusID AND u.Deleted IS NULL AND d.DepartmentID in (select DepartmentID from org.H_D where ParentID in (select HDID from org.H_D where DepartmentID=@DepartmentID))
	group BY u.UserID,d.DepartmentID,d.name,ut.name,utu.UserTypeID,u.FirstName,u.LastName,u.DateOfBirth
	order by d.name,u.LastName,u.FirstName

END
