CREATE PROCEDURE [dbo].[prc_AccessGenerics_getByOwnerId]
	@OwnerId int
AS
BEGIN 	
	SELECT A.*
	FROM  dbo.AccessGeneric A INNER JOIN dbo.AccessGroup AG ON AG.AccessGroupID = A.AccessGroupID 
	WHERE AG.OwnerID = @OwnerID
END
