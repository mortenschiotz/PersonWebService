CREATE Proc dbo.tool_karakter_reportRow
(
 @ReportpartID as int = 2,
 @RowName as varchar(256) = 'Samfunnsfag',
 @Cat1 as int = 396,
 @Cat2 as int =397,
 @ActivityID as int = 19
)
as
 Declare @RowNo as Int,
		 @RowID as int,
			@ColID int

 Select @RowNo = max(No) +1  from rep.reportrow where reportpartid = @ReportpartID
 PRINT @RowNo

 Insert into rep.ReportRow(ReportPartID, ReportRowTypeID, No, CssClass, Created)
 Values (@ReportpartID,2,@RowNo,'',getdate())

 SET @RowID = SCOPE_IDENTITY()

 Insert into rep.ReportColumn(ReportRowID, No, ReportColumnTypeID, Formula, width, Format, URL)
 values(@RowID,0,1,'',0,'','')

 SET @ColID = SCOPE_IDENTITY()
 Insert into rep.LT_ReportColumn (LanguageID, ReportColumnID, Text)
 Values (1,@ColID,@RowName)
 
 Insert into rep.ReportColumn(ReportRowID, No, ReportColumnTypeID, Formula, width, Format, URL)
 values(@RowID,1,2,'A-B',0,'0.##','')

 SET @ColID = SCOPE_IDENTITY()
 
  Insert into rep.ReportColumnParameter(ReportColumnID, No, Name, ActivityID, QuestionID, AlternativeID, CategoryID, CalcType)
  Values (@ColID,0,'A',@ActivityID,null,null,@Cat1,1)
 
  Insert into rep.ReportColumnParameter(ReportColumnID, No, Name, ActivityID, QuestionID, AlternativeID, CategoryID, CalcType)
  Values (@ColID,0,'B',@ActivityID,null,null,@Cat2,1)
 
 