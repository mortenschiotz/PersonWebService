CREATE PROCEDURE [dbo].[prc_AnswerGetByUserIDs]
	@UserIds NVARCHAR(MAX), 
	@SurveyId INT,
	@BatchId INT,
	@AlternativeIds NVARCHAR(MAX)=''
AS
BEGIN
	DECLARE @ReportServer NVARCHAR(64),@ReportDB NVARCHAR(64), @ActiveEntityStatusID INT = 0
	--SELECT @EntityStatusID = EntityStatusID FROM dbo.EntityStatus WHERE CodeName = N'Active'
	SELECT @ReportServer=ReportServer,@ReportDB=ReportDB FROM at.Survey
	WHERE SurveyID=@SurveyId
	DECLARE @sqlCommand NVARCHAR(max),@sqlParameters NVARCHAR(Max)

	SET @sqlCommand = N'SELECT @p_ActiveEntityStatusID = EntityStatusID FROM [' + @ReportServer + '].[' + @ReportDB + '].' + 'dbo.EntityStatus WHERE CodeName = ''Active'''
	EXECUTE sp_executesql @sqlCommand, N'@p_ActiveEntityStatusID INT OUTPUT', @p_ActiveEntityStatusID = @ActiveEntityStatusID OUTPUT

	SET @sqlCommand='SELECT r.UserID,a.AnswerID,a.ResultID,a.QuestionID,a.AlternativeID,a.Value,a.Free,a.No,a.ItemID,ISNULL(a.DateValue,'''') as DateValue'+ 
		',r.LastUpdated,(u.FirstName + '' '' + u.LastName) as CompleteName,r.StatusTypeID FROM ['+ 
		@ReportServer + '].[' + @ReportDB + '].' + 'dbo.Answer a INNER JOIN [' +
	    @ReportServer + '].[' + @ReportDB + '].' + 'dbo.Result r on a.ResultID = r.ResultID '+
	    'LEFT JOIN org.[User] u ON r.LastUpdatedBy = u.UserID ' +
	    'WHERE r.SurveyID=@p_SurveyID AND r.BatchID=@p_BatchID AND r.UserID IN ('+@UserIds+') AND  r.EntityStatusID = '+ CONVERT(NVARCHAR(12), @ActiveEntityStatusID) +' AND r.Deleted IS NULL '
	    IF ISNULL(@AlternativeIds,'') != ''
	    BEGIN
	      SET @sqlCommand += ' AND a.AlternativeID IN (' + @AlternativeIds + ') '
	    END
	SET @sqlParameters = N'@p_SurveyID int,@p_BatchID int'
	EXECUTE sp_executesql @sqlCommand, @sqlParameters, @p_SurveyID = @SurveyId, @p_BatchID = @BatchId
END
