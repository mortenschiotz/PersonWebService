CREATE PROCEDURE [dbo].[prc_Job_getByOwnerId]  
(  
 @OwnerID smallint = 0  
)  
AS  
BEGIN  
 SET NOCOUNT ON  
 DECLARE @Err Int  

 SELECT  
 [JobID],  
 [JobTypeID],  
 [JobStatusID],  
 [OwnerID],  
 [UserID],  
 [Name],  
 [Priority],  
 ISNULL([Option], 0) AS 'Option',  
 [Created],  
 [StartDate],  
 ISNULL([EndDate], '1900-01-01') AS 'EndDate',  
 [Description]  
 FROM [job].[Job]  
 WHERE  
 [OwnerID] = @OwnerID  

 Set @Err = @@Error  

 RETURN @Err  
END  

