
CREATE PROCEDURE [dbo].[prc_LT_RelationType_get]
(
	@RelationTypeID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[RelationTypeID],
	[Name],
	[Description]
	FROM [dbo].[LT_RelationType]
	WHERE
	[RelationTypeID] = @RelationTypeID

	Set @Err = @@Error

	RETURN @Err
END

