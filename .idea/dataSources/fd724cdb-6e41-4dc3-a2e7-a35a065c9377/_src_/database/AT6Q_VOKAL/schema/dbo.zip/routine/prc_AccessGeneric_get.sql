
CREATE PROCEDURE [dbo].[prc_AccessGeneric_get]
(
	@AccessGroupID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[AccessID],
	ISNULL([TableTypeID], 0) AS 'TableTypeID',
	ISNULL([Elementid], 0) AS 'Elementid',
	[Type],
	[AccessGroupID],
	[Created]
	FROM [dbo].[AccessGeneric]
	WHERE
	[AccessGroupID] = @AccessGroupID

	Set @Err = @@Error

	RETURN @Err
END

