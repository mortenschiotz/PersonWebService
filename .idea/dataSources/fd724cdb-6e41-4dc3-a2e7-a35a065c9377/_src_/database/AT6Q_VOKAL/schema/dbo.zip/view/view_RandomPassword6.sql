CREATE VIEW [dbo].[view_RandomPassword6] AS 
-- select * from view_RandomPassword6
SELECT
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case
	
	+
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case
	+
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case
	+
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case
	+
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case
	+
	CHAR(ROUND(65 + (RAND() * (25)),0)) -- get random upper case

	as RandomPassword