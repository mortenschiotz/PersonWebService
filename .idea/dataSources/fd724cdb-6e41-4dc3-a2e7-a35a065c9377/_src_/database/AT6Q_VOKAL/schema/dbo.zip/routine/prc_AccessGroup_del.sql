

CREATE PROCEDURE [dbo].[prc_AccessGroup_del]
(
	@AccessGroupID int,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'AccessGroup',2,
		( SELECT * FROM [dbo].[AccessGroup] 
			WHERE
			[AccessGroupID] = @AccessGroupID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [dbo].[AccessGroup]
	WHERE
		[AccessGroupID] = @AccessGroupID

	Set @Err = @@Error

	RETURN @Err
END

