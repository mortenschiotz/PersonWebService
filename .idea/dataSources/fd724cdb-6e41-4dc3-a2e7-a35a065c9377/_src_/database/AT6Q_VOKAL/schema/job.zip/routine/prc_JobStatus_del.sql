

CREATE PROCEDURE [job].[prc_JobStatus_del]
(
	@JobStatusID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'JobStatus',2,
		( SELECT * FROM [job].[JobStatus] 
			WHERE
			[JobStatusID] = @JobStatusID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [job].[JobStatus]
	WHERE
	[JobStatusID] = @JobStatusID

	Set @Err = @@Error

	RETURN @Err
END

