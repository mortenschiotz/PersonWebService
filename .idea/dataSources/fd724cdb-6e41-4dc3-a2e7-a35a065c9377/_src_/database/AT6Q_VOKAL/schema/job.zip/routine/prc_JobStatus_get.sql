CREATE PROCEDURE [job].[prc_JobStatus_get]
AS
BEGIN
	SELECT [JobStatusID],[No]
	FROM [job].[JobStatus]
END
