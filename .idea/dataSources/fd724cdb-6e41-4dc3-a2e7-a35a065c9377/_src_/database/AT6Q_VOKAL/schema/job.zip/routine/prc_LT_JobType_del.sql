

CREATE PROCEDURE [job].[prc_LT_JobType_del]
(
	@LanguageID int,
	@JobTypeID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_JobType',2,
		( SELECT * FROM [job].[LT_JobType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[JobTypeID] = @JobTypeID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [job].[LT_JobType]
	WHERE
	[LanguageID] = @LanguageID AND
	[JobTypeID] = @JobTypeID

	Set @Err = @@Error

	RETURN @Err
END

