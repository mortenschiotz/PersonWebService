

CREATE PROC [job].[update_Job]
(
	@JobID 			bigint,
	@JobStatusID	tinyint
)
AS
BEGIN
UPDATE job.Job
SET JobStatusID = @JobStatusID
WHERE JobID = @JobID
END

