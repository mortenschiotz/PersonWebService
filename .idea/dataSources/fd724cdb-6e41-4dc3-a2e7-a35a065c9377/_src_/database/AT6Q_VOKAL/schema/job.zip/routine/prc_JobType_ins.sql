
CREATE PROCEDURE [job].[prc_JobType_ins]
(
	@JobTypeID smallint = null output,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [job].[JobType]
	(
		[No]
	)
	VALUES
	(
		@No
	)

	Set @Err = @@Error
	Set @JobTypeID = scope_identity()

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'JobType',0,
		( SELECT * FROM [job].[JobType] 
			WHERE
			[JobTypeID] = @JobTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

