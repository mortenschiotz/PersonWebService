CREATE procedure [job].[add_Status]
	@JobID    bigint,
	@Status   text,
	@Type			smallint
	AS 
	INSERT INTO [JobStatusLog]
	(
		[JobID],
		[Description],
		[JobStatusID],
		Created
	)
	VALUES
	(
		@JobID,
		@Status,
		@Type,
		getdate()
	)
	RETURN @@ERROR