CREATE PROC [job].[prc_CubeCreate_get]
AS
  SELECT top 5 S.SurveyID,s.ActivityID,COALESCE(S.OLAPDB,A.OLAPDB,O.OLAPDB) AS OLAPDB,
  COALESCE(S.OLAPServer,A.OLAPServer,O.OLAPServer) AS OLAPServer,
  COALESCE(S.ReportDB,O.ReportDB) AS ReportDB,
  COALESCE(S.ReportServer,O.ReportServer) AS ReportServer,
  S.LastProcessed
  FROM AT.Survey S
  JOIN AT.Activity A on A.ActivityID = S.ActivityID AND A.[UseOLAP] = 1
  JOIN ORG.[Owner] O on O.Ownerid = A.Ownerid 
  WHERE S.LastProcessed = '1900-01-01'
