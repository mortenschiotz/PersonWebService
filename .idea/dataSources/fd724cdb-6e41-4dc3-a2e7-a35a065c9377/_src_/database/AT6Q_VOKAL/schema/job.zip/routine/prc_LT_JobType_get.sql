
CREATE PROCEDURE [job].[prc_LT_JobType_get]
(
	@JobTypeID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[JobTypeID],
	[Name],
	[Description]
	FROM [job].[LT_JobType]
	WHERE
	[JobTypeID] = @JobTypeID

	Set @Err = @@Error

	RETURN @Err
END

