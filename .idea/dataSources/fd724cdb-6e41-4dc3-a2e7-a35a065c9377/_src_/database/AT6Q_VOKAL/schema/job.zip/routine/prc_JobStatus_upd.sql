
CREATE PROCEDURE [job].[prc_JobStatus_upd]
(
	@JobStatusID smallint,
	@No smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	UPDATE [job].[JobStatus]
	SET
		[No] = @No
	WHERE
		[JobStatusID] = @JobStatusID

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'JobStatus',1,
		( SELECT * FROM [job].[JobStatus] 
			WHERE
			[JobStatusID] = @JobStatusID			 FOR XML AUTO) as data,
			getdate()
	END

	Set @Err = @@Error

	RETURN @Err
END

