

CREATE PROCEDURE [job].[prc_LT_JobStatus_del]
(
	@LanguageID int,
	@JobStatusID smallint,
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_JobStatus',2,
		( SELECT * FROM [job].[LT_JobStatus] 
			WHERE
			[LanguageID] = @LanguageID AND
			[JobStatusID] = @JobStatusID
			 FOR XML AUTO) as data,
			getdate() 
	END 


	DELETE FROM [job].[LT_JobStatus]
	WHERE
	[LanguageID] = @LanguageID AND
	[JobStatusID] = @JobStatusID

	Set @Err = @@Error

	RETURN @Err
END

