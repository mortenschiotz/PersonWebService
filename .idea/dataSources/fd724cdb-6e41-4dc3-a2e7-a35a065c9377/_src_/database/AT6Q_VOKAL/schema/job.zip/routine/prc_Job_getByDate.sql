CREATE PROCEDURE [job].[prc_Job_getByDate]
(
	@OwnerID int,
	@RecentDays int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
		[JobID],
		[JobTypeID],
		[JobStatusID],
		[OwnerID],
		[UserID],
		[Name],
		[Priority],
		ISNULL([Option], 0) AS 'Option',
		[Created],
		[StartDate],
		[EndDate],
		[Description]
	FROM [job].[Job]
	WHERE
		[OwnerID] = @OwnerID AND
		datediff(day,[Created],getdate()) <= @RecentDays

	Set @Err = @@Error

	RETURN @Err
END
