CREATE PROC [job].[get_Jobs]
(@types as varchar(200))
AS
SELECT TOP 10 * FROM Job 
WHERE StartDate <= getdate() AND (JobStatusID = 0)
  AND JobTypeId IN (
     SELECT Value 
     FROM [dbo].[funcListToTableInt](@types,',')
  )
ORDER BY Priority, JobID
