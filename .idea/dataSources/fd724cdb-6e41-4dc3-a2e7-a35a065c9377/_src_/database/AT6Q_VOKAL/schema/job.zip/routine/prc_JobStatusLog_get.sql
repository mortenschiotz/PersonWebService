
CREATE PROCEDURE [job].[prc_JobStatusLog_get]
(
	@JobID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[JobStatusLogID],
	[JobID],
	[JobStatusID],
	[Description],
	[Created]
	FROM [job].[JobStatusLog]
	WHERE
	[JobID] = @JobID

	Set @Err = @@Error

	RETURN @Err
END

