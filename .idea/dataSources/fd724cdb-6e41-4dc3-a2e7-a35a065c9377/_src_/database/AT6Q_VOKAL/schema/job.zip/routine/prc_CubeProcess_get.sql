CREATE PROC [job].[prc_CubeProcess_get]
AS
  SELECT top 5 S.SurveyID,s.ActivityID,COALESCE(S.OLAPDB,A.OLAPDB,O.OLAPDB) AS OLAPDB,
  COALESCE(S.OLAPServer,A.OLAPServer,O.OLAPServer) AS OLAPServer,
  COALESCE(S.ReportDB,O.ReportDB) AS ReportDB,
  COALESCE(S.ReportServer,O.ReportServer) AS ReportServer,
  S.LastProcessed,
  ReProcessOLAP,
  S.ProcessCategorys
  FROM AT.Survey S
  JOIN AT.Activity A on A.ActivityID = S.ActivityID AND A.[UseOLAP] = 1
  JOIN ORG.[Owner] O on O.Ownerid = A.Ownerid 
  WHERE (S.LastProcessed <> '1900-01-01' AND S.Enddate > getdate() -2 and s.LastProcessed < getdate() - 0.95 AND Datepart(hh,getdate()) IN (0,1,2,3,4,5) AND S.ReProcessOLAP >= 0) 
  OR ReProcessOLAP = 1
  OR ( ReProcessOLAP = 2 and Datepart(hh,getdate()) IN (0,1,2,3,4,5,6) and S.LastProcessed <> '1900-01-01')
  ORDER BY S.LastProcessed

