CREATE PROCEDURE [job].[prc_Job_find]
(
	@JobID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
		[JobID],
		[JobTypeID],
		[JobStatusID],
		[OwnerID],
		[UserID],
		[Name],
		[Priority],
		ISNULL([Option], 0) AS 'Option',
		[Created],
		[StartDate],
		[EndDate],
		[Description]
	FROM [job].[Job]
	WHERE
		[JobID] = @JobID

	Set @Err = @@Error

	RETURN @Err
END
