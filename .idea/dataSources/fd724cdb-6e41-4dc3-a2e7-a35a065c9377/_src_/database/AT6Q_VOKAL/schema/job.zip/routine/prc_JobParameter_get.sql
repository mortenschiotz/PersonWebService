
CREATE PROCEDURE [job].[prc_JobParameter_get]
(
	@JobID int
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[JobParameterID],
	[JobID],
	[No],
	[Name],
	[Value],
	[Type]
	FROM [job].[JobParameter]
	WHERE
	[JobID] = @JobID
	ORDER BY [No]

	Set @Err = @@Error

	RETURN @Err
END

