
CREATE PROCEDURE [job].[prc_LT_JobStatus_ins]
(
	@LanguageID int,
	@JobStatusID smallint,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [job].[LT_JobStatus]
	(
		[LanguageID],
		[JobStatusID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@JobStatusID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_JobStatus',0,
		( SELECT * FROM [job].[LT_JobStatus] 
			WHERE
			[LanguageID] = @LanguageID AND
			[JobStatusID] = @JobStatusID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

