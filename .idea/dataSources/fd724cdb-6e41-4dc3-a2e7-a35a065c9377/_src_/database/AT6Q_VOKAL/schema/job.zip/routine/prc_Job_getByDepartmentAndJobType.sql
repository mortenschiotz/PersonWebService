

CREATE PROCEDURE [job].[prc_Job_getByDepartmentAndJobType]
(
	@OwnerID int,
	@DepartmentID  int,
	@JobTypeID int
)
AS
BEGIN
select j.[JobID],
	 j.[JobTypeID],
	 j.[JobStatusID],
	 j.[OwnerID],
	 j.[UserID],
	 j.[Name],
	 j.[Priority],
	 ISNULL(j.[Option], 0) AS 'Option',
	 j.[Created],
	 j.[StartDate],
	ISNULL( j.[EndDate], '1900-01-01') AS 'EndDate',
	 j.[Description]
from job.Job j
	join  job.JobParameter jp on j.JobID = jp.JobID and  jp.Name = 'DepartmentID' and jp.Value = cast(@Departmentid as nvarchar(16))
where j.JobTypeID = @JobTypeID and j.OwnerID = @OwnerID
END

