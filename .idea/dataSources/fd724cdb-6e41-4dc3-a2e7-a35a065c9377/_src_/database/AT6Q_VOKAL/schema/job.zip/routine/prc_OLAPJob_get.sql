
CREATE PROCEDURE [job].[prc_OLAPJob_get]
(
	@JobStatusID smallint = 0
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[JobID],
	[JobTypeID],
	[JobStatusID],
	[OwnerID],
	[UserID],
	[Name],
	[Priority],
	ISNULL([Option], 0) AS 'Option',
	[Created],
	[StartDate],
	ISNULL([EndDate], '1900-01-01') AS 'EndDate',
	[Description]
	FROM [job].[Job]
	WHERE [JobStatusID] = @JobStatusID
	AND JOBTYPEID = 14
	ORDER BY StartDate, [Priority]
	

	Set @Err = @@Error

	RETURN @Err
END

