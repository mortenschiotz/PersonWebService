
CREATE PROCEDURE [job].[prc_LT_JobType_ins]
(
	@LanguageID int,
	@JobTypeID smallint,
	@Name nvarchar(256),
	@Description nvarchar(max),
	@cUserid int,
	@Log smallint = 1
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	INSERT INTO [job].[LT_JobType]
	(
		[LanguageID],
		[JobTypeID],
		[Name],
		[Description]
	)
	VALUES
	(
		@LanguageID,
		@JobTypeID,
		@Name,
		@Description
	)

	Set @Err = @@Error

	IF @Log = 1 
	BEGIN 
		INSERT INTO [Log].[AuditLog] ( UserId, TableName, Type, Data, Created) 
		SELECT @cUserid,'LT_JobType',0,
		( SELECT * FROM [job].[LT_JobType] 
			WHERE
			[LanguageID] = @LanguageID AND
			[JobTypeID] = @JobTypeID				 FOR XML AUTO) as data,
				getdate() 
	 END

	RETURN @Err
END

