

CREATE PROC [job].[get_JobParameters]
(
	@JobID	bigint
)
AS
SELECT 
  JobParameterId as Id,
  [No],
  [Name], 
  Value,
  [Type]
FROM JobParameter 
WHERE JobID = @JobID ORDER BY No
