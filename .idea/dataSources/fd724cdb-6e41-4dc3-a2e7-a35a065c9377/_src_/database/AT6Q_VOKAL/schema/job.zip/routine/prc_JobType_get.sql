

CREATE PROCEDURE [job].[prc_JobType_get]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	   [JobTypeID]
      ,[No]
      ,[Created]
	FROM [job].[JobType]
	
	Set @Err = @@Error

	RETURN @Err
END


