
CREATE PROCEDURE [job].[prc_LT_JobStatus_get]
(
	@JobStatusID smallint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Err Int

	SELECT
	[LanguageID],
	[JobStatusID],
	[Name],
	[Description]
	FROM [job].[LT_JobStatus]
	WHERE
	[JobStatusID] = @JobStatusID

	Set @Err = @@Error

	RETURN @Err
END

